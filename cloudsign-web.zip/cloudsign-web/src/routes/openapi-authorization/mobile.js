import loadingPage from "@page-components/openapi-authorization/mobile/loading.vue"
import authFramework from "@page-components/openapi-authorization/mobile/auth-framework.vue"
import chooseTypes from "@page-components/openapi-authorization/mobile/choose-authtype.vue"
import phoneAuth from "@components/openapi-authorization-auth/person-mobile/person-phone.vue"
import faceAuth from "@components/openapi-authorization-auth/person-mobile/person-face.vue"
import phoneFaceAuth from "@components/openapi-authorization-auth/person-mobile/person-phone-face.vue"
import zhimaAuth from "@components/openapi-authorization-auth/person-mobile/person-zhima.vue"

import authResult from "@components/openapi-authorization-auth/person-mobile/auth-result"
let routerConfig = {
    mode: "history",
    base: "/openapi-authorization",
    routes: [
        {
            path: "/",
            meta: {
                title: ""
            },
            component: loadingPage
        },
        {
            path: "/verification",
            name: "verification",
            meta: {
                title: "注册"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/mobile/verification.vue"))
                }, "async-verification")
            }
        },
        {
            path: "/authentication",
            name: "authentication",
            meta: {
                title: "身份验证"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/mobile/authentication.vue"))
                }, "async-authentication")
            }
        },
        {
            path: "/enterprise-authentication",
            name: "enterprise-authentication",
            meta: {
                title: "身份验证"
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/mobile/enterprise-authentication.vue"))
                }, "async-enterprise-authentication")
            }
        },
        {
            path: "/person",
            name: "person-auth",
            component: chooseTypes,
        },
        {
            path: "",
            component: authFramework,
            children: [
                {
                    path: "phone-auth",
                    component: phoneAuth,
                },
                {
                    path: "zhima-auth",
                    component: zhimaAuth,
                },
                {
                    path: "face-auth",
                    component: faceAuth,
                },
                {
                    path: "phone-face-auth",
                    component: phoneFaceAuth,
                }
            ]
        },
        {
            path: "/result",
            component: authResult,
        },
        {
            path: "/enterprise",
            name: "enterprise-auth",
            meta: {
                title: "企业实名认证",
            },
            component: resolve => {
                require.ensure([], () => {
                    resolve(require("@page-components/openapi-authorization/mobile/enterprise-auth.vue"))
                }, "async-enterprise-auth")
            } 
        },
    ]
}

export default routerConfig