import "../common.js"
import "script-loader!@commons/compatible-localstorage.js"

const autoComputeZoom = _ => {
    let screenWidth = document.documentElement.clientWidth
    let screenHeight = document.documentElement.clientHeight
    let remPx = 100
    if (screenHeight > screenWidth){ //竖屏
        document.documentElement.style.fontSize = screenWidth / 375 * remPx + "px"
    } else { //横屏
        document.documentElement.style.fontSize = screenHeight / 375 * remPx + "px"
    }
}


window.addEventListener("load", autoComputeZoom)
window.addEventListener("resize", autoComputeZoom)

import Vue from "vue"
//vue-router 引入
import VueRouter from "vue-router"
Vue.use(VueRouter)

//vuex 引入
import Vuex from "vuex"
Vue.use(Vuex)

import Mint from "mint-ui"
import "mint-ui/lib/style.css"
Vue.use(Mint)

import {
    Loading,
    InputNumber,
    Input,
    Button
} from "element-ui"
Vue.use(Loading.directive)
Vue.use(InputNumber)
Vue.use(Input)
Vue.use(Button)

//imgAutoSize 引入
import ImgAutoSize from "@commons/vue-img-auto-size.js"
Vue.use(ImgAutoSize)

import "@styles/mobile/common.less"

//生成uuid
window.GUID = function () {
    return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4())
    function S4() {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1)
    }
}