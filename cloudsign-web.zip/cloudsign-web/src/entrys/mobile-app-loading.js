/* 应用启动入口 */
import "./common.js"

import "@styles/mobile/common.less"

require.ensure([], () => {
    require("./mobile/common.js")
    require("./mobile/mobile-index.js")
}, err => {
    console.error(err)
}, "async-app-mobile")