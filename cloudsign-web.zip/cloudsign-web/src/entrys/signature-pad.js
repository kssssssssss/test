import "./common.js"
import "@styles/icons/style.css"

import Vue from "vue"
import signaturePad from "@page-components/externals/signature-pad.vue"

const autoComputeZoom = _ => {
    let screenWidth = document.documentElement.clientWidth
    let remPx = 100
    document.documentElement.style.fontSize = screenWidth / 375 * remPx + "px"
}

window.addEventListener("load", autoComputeZoom)
window.addEventListener("resize", autoComputeZoom)

document.body.style = "font-size:0.16rem"

new Vue({
    el: "#app",
    template: "<signaturePad />",
    components: {
        signaturePad
    }
})