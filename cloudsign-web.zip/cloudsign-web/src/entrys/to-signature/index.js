import "../common.js"
import "@styles/to-signature/index.less"
import Vue from "vue"

import VueRouter from "vue-router"
Vue.use(VueRouter)

import Vuex from "vuex"
Vue.use(Vuex)

//element-ui 引入
import {
    Row,
    Col,
    Message,
    MessageBox,
    Input,
    Button,
    Checkbox,
    Loading,
    Select,
    Option,
    InputNumber,
    Dialog,
    Carousel,
    CarouselItem,
    DatePicker,
    Switch,
    Radio,
    RadioGroup,
    RadioButton,
    Popover,
    InfiniteScroll,
    Tooltip
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Loading)
Vue.use(Select)
Vue.use(Option)
Vue.use(InputNumber)
Vue.use(Dialog)
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.use(DatePicker)
Vue.use(Switch)
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.use(RadioButton)
Vue.use(Popover)
Vue.use(InfiniteScroll)
Vue.use(Tooltip)
Vue.prototype.$message = Message
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt

import routerConfig from "@routes/to-signature/index.js"
let router = new VueRouter(routerConfig)

if (!/\/result/.test(location.href.split("?")[0])){
    router.push({
        path: `/${location.search}`,
    })
}

import storeConfig from "@store/to-signature/index.js"
let store = new Vuex.Store(storeConfig)

//APP注册
import App from "./app.vue"

let vm = new Vue(Object.assign(App, {
    router,
    store
}))
vm.$mount("#app")