import "../common.js"
import "@styles/to-signature/mobile-index.less"

const autoComputeZoom = _ => {
    let screenWidth = document.documentElement.clientWidth
    let screenHeight = document.documentElement.clientHeight
    let remPx = 100
    if (screenHeight > screenWidth){ //竖屏
        document.documentElement.style.fontSize = screenWidth / 375 * remPx + "px"
    } else { //横屏
        document.documentElement.style.fontSize = screenHeight / 375 * remPx + "px"
    }
}

window.addEventListener("load", autoComputeZoom)
window.addEventListener("resize", autoComputeZoom)

import Vue from "vue"
import VueRouter from "vue-router"
Vue.use(VueRouter)

import Vuex from "vuex"
Vue.use(Vuex)

//移动端的依赖
import Mint from "mint-ui"
import "mint-ui/lib/style.css"
Vue.use(Mint)

import {
    Loading,
    Input,
    InputNumber
} from "element-ui"
Vue.use(Loading.directive)
Vue.use(Input)
Vue.use(InputNumber)
Vue.prototype.$loading = Loading.service

import routerConfig from "@routes/to-signature/index-mobile.js"
let router = new VueRouter(routerConfig)

if (!/\/result/.test(location.href.split("?")[0])){
    router.push({
        path: `/${location.search}`,
    })
}

import storeConfig from "@store/to-signature/index.js"
let store = new Vuex.Store(storeConfig)

//APP注册
import App from "./app.vue"

let vm = new Vue(Object.assign(App, {
    router,
    store
}))
vm.$mount("#mobile")