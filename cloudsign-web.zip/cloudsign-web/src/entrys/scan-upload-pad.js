import "./common.js"
import "@styles/common.less"

import Vue from "vue"
import scanUpload from "@page-components/externals/upload-stamp.vue"
//element-ui 引入
import {
    Input,
    Button,
    Loading,
} from "element-ui"
Vue.use(Input)
Vue.use(Button)
Vue.use(Loading.directive)
Vue.prototype.$loading = Loading.service
new Vue({
    el: "#app",
    template: "<scanUpload />",
    components: {
        scanUpload
    }
})