import "./common.js"
import "@styles/common.less"
import Vue from "vue"
import register from "@page-components/externals/register.vue"

//element-ui 引入
import {
    Row,
    Col,
    Message,
    Input,
    Button,
    Checkbox,
    Form,
    FormItem,
    Alert,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Alert)
Vue.prototype.$message = Message

new Vue({
    el: "#app",
    template: "<register />",
    components: {
        register
    }
})