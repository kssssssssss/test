import Vue from "vue"
import VueRouter from "vue-router"
import VueRouterTitle from "vue-router-title"
import VueRouterHistory from "@commons/vue-router-history"
import Vuex from "vuex"
import vuexRouterSync from "@commons/vuex-router-sync.js"
import VuexPluginAuthority from "@commons/vuex-plugin-authority.js"
import routerConfig from "@routes/pc/router.js"
import storeConfig from "@store/index.js"
import axios from "@interfaces/axios.js"
import SystemLoading from "@commons/system-loading.js"
import { MessageBox } from "element-ui"
import NetworkeWatcher from "@commons/check-networkstatus.js"
import "@commons/wesign-signature-sdk-child.js"
import { notifyer } from "@notifications/index.js"

//全局阻止右键事件，防止用户印章图片被另存下载
window.addEventListener("contextmenu", e => {
    e.preventDefault()
})

let store = null
let router = null
store = new Vuex.Store(storeConfig)
axios.defaults.withCredentials = true
//网站监测
let networkWatcher = new NetworkeWatcher({
    onOffline(){
        MessageBox.alert("您的网络存在异常，请检查网络是否正常连接", "掉线了！", {
            confirmButtonText: "我知道了",
            callback: action => {
                networkWatcher.onLine = true
            },
            type: "error"
        })
    },
})

axios.interceptors.response.use(function (config) {
    store.dispatch("updateUserActive")
    return config
}, function (error) {
    if (error.message === "Network Error"){
        networkWatcher.checkNetwork()
    } else if (error.response && error.response.data){
        let body = error.response.data
        let code = body.code
        if (code === 401){
            store.dispatch("userNotActive")
        }
    }
    return Promise.reject(error)
})


APPStart()

function APPStart(){
    SystemLoading.open()
    SystemLoading.setLoadingText("正在加载中...")

    let timeCount = 0

    let handle = setInterval(_ => {
        timeCount++
        if (timeCount === 1){
            SystemLoading.setLoadingText("加载中，请耐心等待...")
        } else if (timeCount === 2){
            SystemLoading.setLoadingText("稍等，网络有点慢，正在努力加载...")
        }
    }, 5000)

    store.dispatch("init").then(_ => {
        clearInterval(handle)
        SystemLoading.setLoadingText("初始化路由...")
        router = new VueRouter(routerConfig)
        notifyer.init(router)

        new VueRouterHistory(router)
        vuexRouterSync(store, router)
        
        new VuexPluginAuthority({
            auths: {
                "IS_USER"(getters){ //是否是成员
                    return getters.userEdition === "p"
                },
                "IS_ENTERPRISE"(getters){ //是否是企业
                    return getters.userEdition === "e"
                },
                "AUTH_CONTROL_ENVELOPE"(getters, auths){
                    if (auths.USER_AUTHED){
                        if (auths.IS_ENTERPRISE){
                            if (auths.ENTERPRISE_AUTHED){
                                return true
                            } else {
                                return false
                            }
                        } else {
                            return true
                        }
                    }
                    return false
                },
                "USER_AUTHED"(getters){
                    return getters.userIddtvStatus === "PASSED"
                },
                "ENTERPRISE_AUTHED"(getters){ //企业是否认证
                    return getters.enterpriseIddtvStatus === "SENIOR_PASSED" || getters.enterpriseIddtvStatus === "SENIOR_NO_CERT"
                }
            },
            router,
            store,
            moduleName: "auths"
        })
    
        VueRouterTitle({
            router,
            store,
            beforeEach(title, to, {store, router}){
                return `大家签 | ${title}`
            }
        })
        
    }).then(val => {
        SystemLoading.setLoadingText("正在启动应用...")
        new Vue({
            el: "#app",
            router,
            store,
            mounted(){
                SystemLoading.close()
            },
            template: "<router-view></router-view>"
        })
    }).catch(err => {
        let msg = err.message
        if (msg === "ERROR_NOT_ACTIVE" || msg === "ERROR_NOT_LOGIN"){
            SystemLoading.setLoadingText("用户登录已失效，正在跳转至登录页面")
            location.href = `/login?targetURL=${encodeURIComponent(location.href)}`
        } else {
            console.error(err)
            SystemLoading.setLoadingText("网络请求不给力，请稍候再试...")
            SystemLoading.stopWithCallback(APPStart, APPQuit)
        }
    })
}

function APPQuit(){
    store.commit("user_logout")
}