import "./common.js"
import "@styles/icons/style.css"

import Vue from "vue"
import {
    Row,
    Col,
    Input,
    Button,
    Dialog,
    InputNumber,
    Checkbox,
    Radio,
    RadioGroup,
    Select,
    Option,
    Message,
    MessageBox,
    Notification,
    Switch,
    Loading,
    Tooltip,
    Autocomplete,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Dialog)
Vue.use(InputNumber)
Vue.use(Checkbox)
Vue.use(Radio)
Vue.use(RadioGroup)
Vue.use(Select)
Vue.use(Option)
Vue.use(Switch)
Vue.use(Loading)
Vue.use(Tooltip)
Vue.use(Autocomplete)
Vue.prototype.$message = Message
Vue.prototype.$msgbox = MessageBox
Vue.prototype.$alert = MessageBox.alert
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$prompt = MessageBox.prompt
Vue.prototype.$notify = Notification

import templateRender from "@page-components/templates/template-render.vue"
new Vue({
    el: "#app",
    template: "<templateRender />",
    components: {
        templateRender
    }
})