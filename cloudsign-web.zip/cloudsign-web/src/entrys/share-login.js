import "./common.js"
import "@styles/common.less"
import Vue from "vue"
import shareLogin from "@page-components/externals/share-login.vue"

//element-ui 引入
import {
    Row,
    Col,
    Message,
    MessageBox,
    Input,
    Button,
    Checkbox,
    Form,
    FormItem,
    Alert,
    Dialog,
} from "element-ui"
Vue.use(Row)
Vue.use(Col)
Vue.use(Input)
Vue.use(Button)
Vue.use(Checkbox)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Alert)
Vue.use(Dialog)
Vue.prototype.$message = Message
Vue.prototype.$alert = MessageBox.alert

new Vue({
    el: "#app",
    template: "<shareLogin />",
    components: {
        shareLogin
    }
})