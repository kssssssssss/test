import imagesFullscreenPreview from "./images-fullscreen-preview.vue"

const KEY_ID = "data-big-image"

let idMap = {}
let Vue
let vm

function getRandomId(){
    return Math.floor((Math.random() * 10000000))
}

function clickFun(){
    let id = this.getAttribute(KEY_ID)
    vm.open(id, this)
}

function init(){
    let div = document.createElement("div")

    let PreviewVue = Vue.extend(imagesFullscreenPreview)
    vm = new PreviewVue()

    document.body.appendChild(div)
    vm.$mount(div)
}

export default {
    install(_vue){
        if (Vue) return
        Vue = _vue

        init()

        Vue.directive("fullscreen-preview", {
            bind (el, options) {
                let id = getRandomId()
               
                el.setAttribute(KEY_ID, id)
                idMap[id] = true
                vm.appendImage(id, options.value)
                if (options.modifiers.authPreview){
                    vm.source = "AUTH_PREVIEW"
                    el.addEventListener("click", clickFun)
                } else {
                    el.addEventListener("click", clickFun)
                }
            },
            update (el, options){
                let id = el.getAttribute(KEY_ID)
                vm.updateImage(id, options.value)
            },
            unbind(el){
                let id = el.getAttribute(KEY_ID)

                el.removeEventListener("click", clickFun)
                vm.removeImage(id)
                idMap[id] = false
                el.removeAttribute(KEY_ID)
            }
        })
    }
}