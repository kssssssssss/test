import '@commons/vue-easy-loading.less';

let loadingMap = {};

let VueEasyLoding = {
  install(Vue,options){
    Vue.directive('easy-loading', {
      bind (el, binding, vnode, oldVnode) {
        let val = binding.value;
        let modifiers = binding.modifiers;

        let key = Math.floor(Math.random() * 100000000);
        el.dataset.vueEasyLoadingKey = key;

        loadingMap[key] = new LoadingElement(val,{fixed:modifiers.fixed});

        if(val)showLoading(el,loadingMap[key].dom);
      },
      update(el, binding, vnode, oldVnode){
        let oldval = binding.oldValue;
        let val = binding.value;

        if(val === oldval)return ;

        let key = el.dataset.vueEasyLoadingKey;

        loadingMap[key].setText(val);

        if(!oldval)showLoading(el,loadingMap[key].dom);
        if(!val)hideLoading(el,loadingMap[key].dom);

      },
      unbind(el, binding, vnode, oldVnode){
        let key = el.dataset.vueEasyLoadingKey;
        if(binding.value)hideLoading(el,loadingMap[key].dom);
        delete loadingMap[key];
      }
    });

  }
};

function LoadingElement(val,options){
  let dom = window.document.createElement('div');
  if(options.fixed)dom.className = "vue-easy-loading-box-fixed";
  else dom.className = "vue-easy-loading-box";

  let loading = window.document.createElement('div');
  loading.className = "vue-easy-loading";
  dom.appendChild(loading);

  let animate = window.document.createElement('div');
  animate.className = "vue-easy-loading-animate";
  loading.appendChild(animate);

  animate.appendChild(window.document.createElement('div'));
  animate.appendChild(window.document.createElement('div'));
  animate.appendChild(window.document.createElement('div'));

  let text = window.document.createElement('p');
  text.className = "vue-easy-loading-text";
  loading.appendChild(text);

  text.innerHTML = val;

  this.dom = dom;
  this.textdom = text;
}

LoadingElement.prototype.setText = function(text){
  this.textdom.innerHTML = text;
};

function showLoading(el,dom){
  el.appendChild(dom);
  dom.style = "transition: opacity .5s;opacity:0";
  setTimeout(() => {
    dom.style.opacity = 1;
    setTimeout(() => {
      dom.style = "";
    },500);
  },1);
}

function hideLoading(el,dom){
  dom.style = "transition: opacity .5s;opacity:1";
  setTimeout(() => {
    dom.style.opacity = 0;
    setTimeout(() => {
      dom.style = "";
      el.removeChild(dom);
    },500);
  },1);
}



export default VueEasyLoding;
