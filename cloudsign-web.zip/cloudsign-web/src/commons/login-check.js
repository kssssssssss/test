import { getSessionData } from "@interfaces/user/sessions.js"
import { getUserAccounts, changeSession } from "@interfaces/user/user.js"

//检测用户是否已经登录，或者可以跳转到目标用户ID
//targetUserId 可选项 如果用户的账户下有该帐号，将自动切换
async function checkUserLoginStatusAndAutoChange(targetUserId){
    //判断是否有用户登录,且可以切换过来
    let isLogin = false

    try {
        //检查是否登录
        let res = await getSessionData()
        let session = res.data.data.session
        
        //免登陆状态不能进入系统
        if (session.sessionScopes && session.sessionScopes.length > 0){
            throw new Error("ERROR_CANT_USE_FREE_LOGIN")
        }

        if (!targetUserId){
            isLogin = true
        } else {
            let userId = session.userWsid
        
            if (targetUserId !== userId){
                //不相等检查账户是否包含
                let accouts = await getUserAccounts({
                    userWsid: userId,
                    limit: 10000
                }).then(res => {
                    return res.data.data.accounts
                })

                if (accouts.some(accout => accout.userWsid === targetUserId)){
                    //账户包含，进行账户切换
                    await changeSession({
                        userWsid: userId, 
                        destinationWsid: targetUserId
                    })
                    isLogin = true
                }
            } else {
                isLogin = true
            }
        }
    } catch (e) {
        //未登录
    }

    if (isLogin){
        return true
    } else {
        throw new Error("TARGET_USER_NOT_LOGIN")
    }
}

export {
    checkUserLoginStatusAndAutoChange
}