// navigator.onLine false标识没有连接上网卡    true标识连接上网卡  但是不一定有网
import { pingServer } from "@interfaces/ping.js"


class NetworkeWatcher{
    constructor(options = {}){
        let {
            onOnline,
            onOffline,
        } = options

        this.onLine = true
        this.onOnline = onOnline || null
        this.onOffline = onOffline || null
        this.lastCheck = 0

        window.addEventListener("online", e => this.checkNetwork(), true)
        window.addEventListener("unhandledrejection", e => this.checkNetwork(), true)
        window.addEventListener("offline", e => this._offline(), true)
        window.addEventListener("error", e => this.checkNetwork(), true)

        this.checkNetwork()
    }

    //主动检测网络
    checkNetwork(){

        //节流 0.5s内只检测一次
        if (Date.now() - this.lastCheck <= 500) return

        pingServer().then(_ => {
            this._online()
        }).catch(err => {
            this._offline()
        })
    }

    //通过一个简单请求来确认是否网络真正有效
    _ping(){
        
    }

    //上线
    _online(){
        if (this.onLine) return
        this.onLine = true
        this.onOnline && this.onOnline()
    }   

    //下线
    _offline(){
        if (!this.onLine) return
        this.onLine = false
        this.onOffline && this.onOffline()
    }
}


export default NetworkeWatcher