import { MessageBox } from "element-ui"
import { authFlow } from "@interfaces/openapi/enterprise-authentication.js"
function enterpriseAuthFlow(){
    authFlow({
        returnUrl:`${location.origin}/wesign`
    }).then(res =>{
        let actionUrl = res.data.data.actionUrl
        return location.href = actionUrl
    }).catch(err=>{
        console.error(err)
        if (err.response){
            let code = err.response.data.code
            if (code === 101){
                MessageBox.alert({
                    title: "提示",
                    message: "该企业已认证通过，请勿重复操作",
                    showConfirmButton: true,
                    confirmButtonText: "我知道了"
                }).then(_ => {}, _ => {}).then(_ => {
                    location.reload()
                })
            } else if(code === 102){
                let developerMessage = err.response.data.data.msg
                let erorInfo 
                if(developerMessage.indexOf("该企业已经注册认证") != -1){
                    erorInfo = `若是本人，请检查自己账号下是否已有该企业。若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600。`
                } else {
                    erorInfo =""
                }
                MessageBox.alert({
                    title: "提示",
                    message: `<p>${developerMessage}${erorInfo}</p>`,
                    showConfirmButton: true,
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: "我知道了"
                }).then(_ => {}, _ => {}).then(_ => {
                })
            }
        } else {
            MessageBox.alert("网络开小差了，请检查您的网络是否正或刷新页面重试")
        }
    })
}


export function checkEnterpriseAuthStatus(router, enterpriseIddtvStatus){
    if (enterpriseIddtvStatus !== "SENIOR_PASSED" && enterpriseIddtvStatus !== "SENIOR_NO_CERT"){
        if (enterpriseIddtvStatus === "WAITING" || enterpriseIddtvStatus === "WAITING_SUM"){
            MessageBox.alert("您的企业认证信息正在审核中，暂不能使用,请耐心等待或者联系客服 021-962600", "提示", {
                confirmButtonText: "我知道了",
                callback: action => {},
                type: "warning"
            })
        } else if (enterpriseIddtvStatus === "PRIMARY_PASSED" || enterpriseIddtvStatus === "WAITING_SUM_CHECK"){
            MessageBox.alert("您的企业认证未完成，请完善认证信息", "提示", {
                confirmButtonText: "前往认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        return enterpriseAuthFlow()
                    }
                },
                type: "warning"
            })
        } else if (enterpriseIddtvStatus === "PRIMARY_DENY" || enterpriseIddtvStatus === "SENIOR_UNPASSED"){
            MessageBox.alert("您的企业认证信息未通过审核，您可重新提交认证信息", "提示", {
                confirmButtonText: "重新认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        return enterpriseAuthFlow()
                    }
                },
                type: "warning"
            })
        } else if (enterpriseIddtvStatus === "EXPIRED"){
            MessageBox.alert("您的企业认证信息已过期，将影响功能的正常使用，请重新认证", "提示", {
                confirmButtonText: "重新认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        return enterpriseAuthFlow()
                    }
                },
                type: "warning"
            })
        } else {
            MessageBox.alert("您的企业未认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成企业认证", "提示", {
                confirmButtonText: "前往认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        return enterpriseAuthFlow()
                    }
                },
                type: "warning"
            })
        }
        return false
    }
    return true
}

export {
    enterpriseAuthFlow
}