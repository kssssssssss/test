import "@styles/system-loading.less"

let state = "CLOSE" //loading状态 OPEN CLOSE

let container = document.createElement("div")
container.className = "system-loading"
container.innerHTML = `
<div class="loading-content">
    <div class="lds-spinner">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
    <div class="loading-text">loading</div>
    <div class="reload-btn">刷新</div>
    <div class="cancle-btn">返回登录</div>
</div>`

let textDom = container.querySelector(".loading-text")
let cancleBtn = container.querySelector(".cancle-btn")
let btnDom = container.querySelector(".reload-btn")

function open(){
    if (state === "OPEN") return
    state = "OPEN"
    document.body.appendChild(container)
}

function setLoadingText(text){
    textDom.innerHTML = text
}

function stopWithCallback(continueFun, cancleFun){
    cancleBtn.style.display = "block"
    btnDom.style.display = "block"

    btnDom.onclick = function(){
        cancleBtn.style.display = "none"
        btnDom.style.display = "none"
        cancleBtn.onclick = null
        btnDom.onclick = null
        continueFun()
    }

    cancleBtn.onclick = function(){
        cancleBtn.style.display = "none"
        btnDom.style.display = "none"
        cancleBtn.onclick = null
        btnDom.onclick = null
        cancleFun()
    }
}

function close(){
    if (state === "CLOSE") return
    state = "CLOSE"
    document.body.removeChild(container)
}

export default {
    open,
    setLoadingText,
    stopWithCallback,
    close
}