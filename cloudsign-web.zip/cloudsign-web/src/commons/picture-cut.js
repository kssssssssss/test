
    var PicCut = function (config) {
        //图片base64
        this.imgSrc = config.imgSrc;
        //裁剪容器
        this.container = config.container;
        this.clipBox = document.createElement('div');
        //预览框
        this.preview = config.preview || null;
        this.imgRect = {};
        this.preRect = {};
        this.clipRect = {};
        this.previewBox = {};
        this.containerBox = {};
        this.direction = 0;         //图片方向 0：上，1：右，2：下，3：左
        this.diffScale = config.scale || 0.1;
        this.imgScale = 1;
        this.init();
    }

    PicCut.prototype.initBox = function () {
        var me = this;
        var cStyle = window.getComputedStyle ? window.getComputedStyle(me.container, null) : null || me.currentStyle;
        this.containerBox.width = parseInt(cStyle.width);
        this.containerBox.height = parseInt(cStyle.height);
        if (!me.preview)
            return;
        var pStyle = window.getComputedStyle ? window.getComputedStyle(me.preview, null) : null || me.preview.currentStyle;
        this.previewBox.width = parseInt(pStyle.width);
        this.previewBox.height = parseInt(pStyle.height);
    }
    PicCut.prototype.initImage = function () {
        var me = this;
        me.img = new Image();
        me.img.src = me.imgSrc;
        me.img.setAttribute('ondragstart', 'return false;');
        me.img.style.webkitUserSelect = 'none';
        if (me.preview) {
            me.previewImg = new Image();
            me.previewImg.src = me.imgSrc;
        }
        function imageLoaded() {
            if (me.img.width > 0 || me.img.height > 0) {
                clearInterval(t);
                me.naturalWidth = me.img.width;
                if (me.img.width > me.img.height) {
                    me.imgRect.width = me.containerBox.width;
                    me.imgRect.height = me.containerBox.width / me.img.width * me.img.height;
                    me.imgRect.top = (me.containerBox.height - me.imgRect.height) / 2;
                    me.imgRect.left = 0;
                    me.clipRect.width = me.imgRect.height;
                    me.clipRect.height = me.imgRect.height;
                    me.clipRect.top = me.imgRect.top;
                    me.clipRect.left = (me.containerBox.width - me.clipRect.width) / 2;

                } else {
                    me.imgRect.height = me.containerBox.height;
                    me.imgRect.width = me.containerBox.height / me.img.height * me.img.width;
                    me.imgRect.top = 0;
                    me.imgRect.left = (me.containerBox.width - me.imgRect.width) / 2;

                    me.clipRect.width = me.imgRect.width;
                    me.clipRect.height = me.imgRect.width;
                    me.clipRect.left = me.imgRect.left;
                    me.clipRect.top = (me.containerBox.height - me.clipRect.height) / 2;
                }
                console.log(me.imgRect.width, me.imgRect.height);
                if (me.imgRect.width === me.imgRect.height) {
                    console.log(11);
                    me.clipRect.width = me.imgRect.width / 2;
                    me.clipRect.height = me.imgRect.width / 2;
                    me.clipRect.left = (me.containerBox.width - me.clipRect.width) / 2;;
                    me.clipRect.top = (me.containerBox.height - me.clipRect.height) / 2;
                }


                me.initialImg = {
                    width: me.imgRect.width,
                    height: me.imgRect.height
                };
                me.calcStyle();
                me.container.appendChild(me.img);
                me.container.appendChild(me.clipBox);
                if (me.preview) {
                    me.preview.appendChild(me.previewImg);
                }
            }
        }
        var t = setInterval(imageLoaded, 40);
    }
    PicCut.prototype.initPreview = function () {
        var me = this;
        var scale = me.clipRect.width / this.previewBox.width;
        this.preRect = {
            width: me.imgRect.width / scale,
            height: me.imgRect.height / scale,
            top: (me.imgRect.top - me.clipRect.top) / scale,
            left: (me.imgRect.left - me.clipRect.left) / scale
        }
    }
    PicCut.prototype.calcStyle = function () {
        var me = this;
        me.img.style.cssText += 'position:absolute;width:' + me.imgRect.width + 'px;height:' +
            me.imgRect.height + 'px;left:' + me.imgRect.left + 'px;top:' + me.imgRect.top + 'px';
        me.clipBox.style.cssText += 'box-sizing:border-box;position:absolute;width:' + me.clipRect.width + 'px;height:' +
            me.clipRect.height + 'px;left:' + me.clipRect.left + 'px;top:' + me.clipRect.top + 'px;' + 'border:1px solid #3c9';
        if (!me.preview) {
            return;
        }
        this.initPreview();
        me.previewImg.style.cssText += 'position:absolute;width:' + me.preRect.width + 'px;height:' +
            me.preRect.height + 'px;left:' + me.preRect.left + 'px;top:' + me.preRect.top + 'px';
    }
    PicCut.prototype.init = function () {
        this.initBox();
        this.initImage();
        // this.clipMove();
        this.picMove();
    }
    PicCut.prototype.zoom = function (scale) {
        var me = this;
        me.imgScale += scale;
        if (me.imgScale === 0)
            me.imgScale === 0.1;
        var w = me.imgRect.width;
        var h = me.imgRect.height;
        me.imgRect.width = me.initialImg.width * me.imgScale;
        me.imgRect.height = me.initialImg.height * me.imgScale;
        me.imgRect.left -= (me.imgRect.width - w) / 2;
        me.imgRect.top -= (me.imgRect.height - h) / 2;
        me.calcStyle();
    }
    PicCut.prototype.rotate = function (d) {
        var me = this;
        if (d === 'r')
            me.direction = (me.direction + 1) % 4;
        else {
            me.direction = (me.direction + 3) % 4;
        }
        me.img.style.transform = 'rotate(' + (me.direction * 90) + 'deg)';
        if (me.preview)
            me.previewImg.style.transform = 'rotate(' + (me.direction * 90) + 'deg)';
    }

    PicCut.prototype.getImg = function (width) {
        var me = this;
        var imgR = me.img.getBoundingClientRect();
        var clipR = me.clipBox.getBoundingClientRect();
        var canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = width;
        var ctx = canvas.getContext('2d');

        var xPos = canvas.width / 2;
        var yPos = canvas.height / 2;
        ctx.clearRect(0, 0, width, width);
        ctx.save();
        ctx.translate(xPos, yPos);
        ctx.rotate(me.direction * 90 * Math.PI / 180);
        ctx.translate(-xPos, -yPos);

        var realScale = me.naturalWidth / me.imgRect.width;
        var l, t;

        switch (me.direction) {
            case 0:
                l = clipR.left - imgR.left;
                t = clipR.top - imgR.top;
                ctx.drawImage(me.img, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, canvas.width, canvas.height);
                break;
            case 1:
                l = clipR.top - imgR.top;
                t = imgR.right - clipR.right;
                ctx.drawImage(me.img, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, canvas.width, canvas.height);
                break;
            case 2:
                l = imgR.right - clipR.right;
                t = imgR.bottom - clipR.bottom;
                ctx.drawImage(me.img, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, canvas.width, canvas.height);
                break;
            case 3:
                l = imgR.bottom - clipR.bottom;
                t = clipR.left - imgR.left;
                ctx.drawImage(me.img, l * realScale, t * realScale, clipR.width * realScale, clipR.height * realScale, 0, 0, canvas.width, canvas.height);
                break;
        }
        ctx.restore();
        return canvas.toDataURL();
    }

    PicCut.prototype.clipMove = function () {
        var me = this;

        function change(dx, dy) {
            me.clipRect.left += dx;
            me.clipRect.top += dy;
            if (me.clipRect.left < 0)
                me.clipRect.left = 0;
            if (me.clipRect.top < 0)
                me.clipRect.top = 0;
            if (me.clipRect.left + me.clipRect.width > me.containerBox.width)
                me.clipRect.left = me.containerBox.width - me.clipRect.width;
            if (me.clipRect.top + me.clipRect.height > me.containerBox.height)
                me.clipRect.top = me.containerBox.height - me.clipRect.height;
            me.calcStyle();
        }


        me.clipBox.addEventListener('mousedown', function (event) {
            me.clipDown = true;
            var e = event || window.event;
            me.start = {
                x: e.clientX,
                y: e.clientY
            };
            window.addEventListener('mousemove', function (event) {
                if (!me.clipDown)
                    return;
                var e = event || window.event;
                var dx = e.clientX - me.start.x;
                var dy = e.clientY - me.start.y;
                me.start = {
                    x: e.clientX,
                    y: e.clientY
                };
                change(dx, dy);
            });
            window.addEventListener('mouseup', function () {
                me.clipDown = false;
            })
        })

        me.clipBox.addEventListener('touchstart',function(event){
            me.clipDown = true;
            var e = event || window.event;
            me.start = {
                x: e.changedTouches[0].clientX,
                y: e.changedTouches[0].clientY
            };
            window.addEventListener('touchmove', function (event) {
                if (!me.clipDown)
                    return;
                var e = event || window.event;
                var dx = e.changedTouches[0].clientX - me.start.x;
                var dy = e.changedTouches[0].clientY - me.start.y;
                me.start = {
                    x: e.changedTouches[0].clientX,
                    y: e.changedTouches[0].clientY
                };
                change(dx,dy);
            });
            window.addEventListener('touchend', function () {
                me.clipDown = false;
            })
        })

    }

    PicCut.prototype.picMove = function () {
        var me = this;
        function change(dx, dy) {
            me.imgRect.left += dx;
            me.imgRect.top += dy;
            if (me.direction % 2 == 0) {
                if (me.imgRect.left < -me.imgRect.width)
                    me.imgRect.left = -me.imgRect.width;
                if (me.imgRect.top < -me.imgRect.height)
                    me.imgRect.top = -me.imgRect.height;
                if (me.imgRect.left > me.containerBox.width)
                    me.imgRect.left = me.containerBox.width;
                if (me.imgRect.top > me.containerBox.height)
                    me.imgRect.top = me.containerBox.height;
            }
            else {
                if (me.imgRect.left < -(me.imgRect.width / 2 + me.imgRect.height / 2))
                    me.imgRect.left = -(me.imgRect.width / 2 + me.imgRect.height / 2);
                if (me.imgRect.top < -(me.imgRect.width + me.imgRect.height) / 2)
                    me.imgRect.top = -(me.imgRect.width + me.imgRect.height) / 2;
                if (me.imgRect.left > me.containerBox.width + me.imgRect.height / 2 - me.imgRect.width / 2)
                    me.imgRect.left = me.containerBox.width + me.imgRect.height / 2 - me.imgRect.width / 2;
                if (me.imgRect.top > me.containerBox.height - (me.imgRect.height - me.imgRect.width) / 2)
                    me.imgRect.top = me.containerBox.height - (me.imgRect.height - me.imgRect.width) / 2;
            }

            me.calcStyle();
        }


        me.container.addEventListener('mousedown', function (event) {
            me.imgDown = true;
            var e = event || window.event;
            me.start = {
                x: e.clientX,
                y: e.clientY
            };
            window.addEventListener('mousemove', function (event) {
                if (!me.imgDown)
                    return;
                var e = event || window.event;
                var dx = e.clientX - me.start.x;
                var dy = e.clientY - me.start.y;
                me.start = {
                    x: e.clientX,
                    y: e.clientY
                };
                change(dx,dy);
            });
            window.addEventListener('mouseup', function () {
                me.imgDown = false;
            })
        })


        me.container.addEventListener('touchstart',function(event){
            me.imgDown = true;
            var e = event || window.event;
            me.start = {
                x: e.changedTouches[0].clientX,
                y: e.changedTouches[0].clientY
            };
            window.addEventListener('touchmove', function (event) {
                if (!me.imgDown)
                    return;
                var e = event || window.event;
                var dx = e.changedTouches[0].clientX - me.start.x;
                var dy = e.changedTouches[0].clientY - me.start.y;
                me.start = {
                    x: e.changedTouches[0].clientX,
                    y: e.changedTouches[0].clientY
                };
                change(dx,dy);
            });
            window.addEventListener('touchend', function () {
                me.imgDown = false;
            })
        })


    }

    exports.PicCut = PicCut;

