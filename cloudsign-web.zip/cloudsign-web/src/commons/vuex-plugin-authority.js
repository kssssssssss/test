class Auth {

    constructor(options) {
        let {
            router, //vue-router 对象
            store, //vuex对象
            auths = {}, //权限表
            moduleName = "auths" //模块名称
        } = options

        if (!router && !store){
            throw new Error("must have router && store")
        }
        
        this.route = null//当前路由信息对象
        this.store = options.store
        this.router = options.router
        this.moduleName = moduleName

        //无权限时的重定向
        this.redirect = (options.pageError && options.pageError[403]) || "/"
        //没找到路由时的重定向
        this.notfound = (options.pageError && options.pageError[404]) || "/"

        //监听路由变化钩子
        this.router.beforeEach(async (to, from, next) => { //执行路由自己的钩子
            let matched = to.matched
            let beforeEachs = to.matched.filter(r => r.meta && r.meta.beforeEach).map(r => r.meta.beforeEach)
            for (let i = 0; i < beforeEachs.length; i++){
                let beforeEach = beforeEachs[i]
                let result = await new Promise((resolve, reject) => {
                    beforeEach(to, from, function(x){
                        resolve(x)
                    }, {
                        router: this.router,
                        store: this.store
                    })
                })
                if (result != null){
                    next(result)
                    return
                }
            }

            next()
        })

        this.router.beforeEach((to, from, next) => { //是否存在
            if (to.matched.length === 0 && this.notfound){
                next(this.notfound)
            } else {
                this.route = to
                next(this.checkNowRoute())//是否满足权限
            }
        })

        //构建VUEX模块并动态注入
        this.buildVuexModule(auths)
    }

    buildVuexModule(auths) {
        let store = this.store
        let moduleName = this.moduleName
        let authGetters = {}

        //模块的getters
        let getters = {}
        
        Object.keys(auths).forEach(key => {
            //构建getter函数
            getters[key] = (state, getters, rootState, rootGetters) => auths[key](rootGetters, getters)
        })

        //模块注册
        store.registerModule(moduleName, {
            namespaced: true,
            getters
        })

        Object.keys(auths).forEach(key => {
            //监听权限变动，触发router变化
            store.watch(() => store.getters[`${moduleName}/${key}`], () => {
                let redirect = this.checkNowRoute()
                if (redirect){
                    this.router.replace(redirect)
                }
            })

            //定义一个获取权限的对象，方便获取
            Object.defineProperty(authGetters, key, {
                get(){
                    return store.getters[`${moduleName}/${key}`]
                }
            })
        })

        this.auths = authGetters
    }

    //传入要求的权限，进行权限检测
    checkAuth(auths) {
        let store = this.store
        let authGetters = this.auths

        return Object.keys(auths).every(key => {
            if (authGetters[key] === auths[key]){
                return true
            }
        })
    }

    //检测现在的路由是否符合权限规范
    checkNowRoute(){
        let route = this.route
        let redirect = this.redirect

        //计算最终需要匹配的权限对象或函数
        let auths = route.matched.reduce((auths, route) => {
            if (route.meta["auth-redirect"])
                redirect = route.meta["auth-redirect"]

            if (route.meta.auths && typeof route.meta.auths === "object" && typeof auths === "object"){
                auths = Object.assign(auths || {}, route.meta.auths)
            } else if (typeof route.meta.auths === "function"){
                auths = route.meta.auths
            }
            return auths
        }, null)

        if (auths === null){
            return
        } else {
            if (typeof auths === "object" && this.checkAuth(auths)){
                return
            } else if (typeof auths === "function" && auths({auths: this.auths})) {
                return
            } else {
                return redirect
            }
        }
    }
}

export default Auth