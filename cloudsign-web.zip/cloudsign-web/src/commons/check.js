//检查是否为英文用户名
export function isEnglishName(str){
    return /^[a-zA-Z▪• \.]{1,40}$/.test(str)
}

//检查是否为用户名
export function isChineseName(str){
    return /^[\u4e00-\u9fa5]{1,10}$/.test(str)
}

//检查是否为用户名
export function isName(str){
    return isEnglishName(str) || isChineseName(str)
}

let password_length = function (str) {
    return /^[\S]{6,32}$/.test(str)
}
let password_allabc = function (str) { //全为字母
    return /^[a-zA-Z]+$/.test(str)
}
let password_allnumber = function (str) { //全为数字
    return /^[0-9]+$/.test(str)
}
let password_allspecichar = function (str) { //有特殊符号
    return /^[ !"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]+$/.test(str)
}

export {
    password_length,
    password_allabc,
    password_allnumber,
    password_allspecichar,
}
