<!--
    @id        me
    @desc      移动端个人信息页
    @level     system：系统组件
    @author    潘维， 陈曦源
    @date      2019-01-04 19:48:02
-->
<template> 
    <div class="wesign-mobile-main">
        <div class="user-info-title">
            <span class="title-user-name">{{activeAccount.name}}</span>
            <div class="change-user-btn" @click="changeUser">
                <span>切换<i class="icon-down"></i></span>
            </div>
            <mt-popup class="boom" v-model="isShow" position="top">
                <div class="mint-searchbar">
                        <div class="mint-searchbar-inner input-style">
                            <i class="search el-icon-search"></i> 
                            <input type="search" placeholder="请输入企业/组织名称" class="mint-searchbar-core input-style" @focus="search">
                        </div>
                    </div>
                    <div class="create-enterprise" @click="openCreateOrganization">
                        <i class="icon-enlarge"></i>
                        创建新企业
                    </div>
                    <div class="boom-list border normal" v-for="(account,index) in showResult" 
                        :key="account.id" @click="change(account)" 
                        :class="{active:account.now}">
                        <div style="flex:1;">
                            <i v-if="account.enterprise" class="icon icon-company"></i>
                            <i v-else class="icon icon-user"></i>
                            {{account.name}}
                        </div>
                        <i v-if="account.now" class="active el-icon-check"></i>
                        <!--<i v-if="account.memberStatus=== 'DISABLED'" class="icon-forbid forbid"></i>-->
                    </div>
                    <div class="boom-list more" v-if="accountJoined.length>4" @click="search">
                        <i class="icon icon-company"></i>
                        查看您的更多企业
                    </div>
            </mt-popup>
        </div>
        <div class="user-info wesign-color-backgroud-main">
            <div class="user-info-top">
                <avatar size="halfMiddle" class="user-img"></avatar>
                <div style="display: flex;align-items: center;">
                    <span class="user-name">{{userName}}</span>
                    <div class="user-msg-info">
                       <userTypeTag :userType="userType" v-if="userType==='ENTE_OWNER'"></userTypeTag>
                       <span class="user-status" @click="toAuth" v-else>
                            <authStatus :status="userAuthStatus"/>
                        </span>
                        <span class="title-user-edition" v-if="activeAccount.name!='个人版'">{{activeAccount.name}}</span>
                    </div>
                </div>
            </div>
           
            <div class="user-info-detail">
                <div class="form-list">
                    <i class="icon-user2"></i>
                    <p>
                        <span>真实姓名</span>
                        <span>{{userName}}</span>
                    </p>
                </div>
                <div class="form-list">
                    <i class="icon-phone"></i>
                    <p>
                        <span>手机号码</span>
                        <span>{{phone}}</span>
                    </p>
                </div>
                <div class="form-list">
                    <i class="icon-email"></i>
                     <p>
                        <span>邮箱</span>
                        <span>{{email}}</span>
                    </p>
                </div>
            </div>  
            <div class="log-out"><p class="btn" title="退出登录" @click="logout">退出登录</p></div>
        </div>
        <moreEnterprise ref="moreEnterprise" :data="accountJoined" @changeAccount="change"></moreEnterprise>
    </div>
</template>

<script>
import avatar from "@components/commons/avatar.vue"
import authStatus from "@components/auth/auth-status.vue"
import userTypeTag from "./common/user-type-tag.vue"
import moreEnterprise from "./common/more-enterprise.vue"
import { checkAuthStatus } from "@commons/check-status.js"

import { getUserData } from "@interfaces/user/user.js"
import { startPersonAuthProcess } from '@interfaces/openapi/person-authentication.js'

export default {
    data(){
        return {
            value: "退出登录",
            isShow: false,
            userAuthStatus: "NO"
        }
    },
    computed: {
        accounts() {
            let activeUserWsid = this.$store.getters.activeUserWsid
            return this.$store.getters.userAccounts.map(account => {
                let name
                let memberStatus

                if (account.enterpriseName) name = account.enterpriseName
                else name = "个人版"

                if (account.memberStatus) memberStatus = account.memberStatus
                let now = false
                if (account.userWsid === activeUserWsid)
                    now = true

                return {
                    name,
                    now,
                    enterprise: !!account.enterpriseName, //是否为企业
                    id: account.userWsid,
                    memberStatus
                }
            })
        },
        // accountsDisabled(){
        //     return this.accounts.filter(account => {
        //         if (account.memberStatus === "DISABLED"){
        //             return account
        //         }
        //     })
        // },
        accountJoined(){
            return this.accounts.filter(account => {
                if (account.memberStatus === undefined || account.memberStatus === "JOINED"){
                    return account
                }
            })
        },
        // accountsSort(){
        //     return this.accountJoined.concat(this.accountsDisabled)
        // },
        showResult(){
            let arr = this.accountJoined
            if (arr.length >= 4){
                return arr.slice(0, 4)
            } else {
                return this.accountJoined
            }
        },
        activeAccount() {
            return this.accounts.find(a => a.now)
        },
        userName(){
            return this.$store.getters.userName
        },
        phone(){
            return this.userData.phone
        },
        email(){
            return this.userData.email
        },
        userData(){
            return this.$store.state.userdata
        },
        userType(){
            return this.$store.getters.userType
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
    },
    created(){
        getUserData({
            userWsid: this.$store.getters.activeUserWsid
        }).then(res => {
            let userInfo = res.data.data.userInfo.user
            this.userAuthStatus = userInfo.idttvStatus
        }).catch(err => {
            console.error(err)
        })
    },
    methods: {
        openCreateOrganization() {
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            checkAuthStatus(this.$router, userIddtvStatus)
            if (userIddtvStatus == "PASSED"){
                this.$router.replace("crated-organizational")
            } 
        },
        changeUser(){
            this.isShow = !this.isShow
        },
        change(account) {
            if (account.memberStatus === "DISABLED"){
                return
            }
            let destinationWsid = account.id
            this.$store.dispatch("changeUserAccount", destinationWsid).then(_ => {
                this.$router.push("/me")
            })
            this.isShow = false
        },
        logout(){
            this.$store.dispatch("user_logout")
        },
        toAuth(){
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            if (userIddtvStatus != "PASSED"){
                startPersonAuthProcess({
                    authModes:[],
                    presetPersonAuthentications: [{
                        name: this.$store.getters.userName,
                        phone:this.$store.getters.userContact
                    }],
                    returnUrl: ''
                }).then(res =>{
                    let actionUrl = res.data.data.actionUrl
                    location.href = actionUrl
                }).catch(err=>{
                    console.error(err)
                    Toast("网络开小差了，请检查您的网络是否正或刷新页面重试")
                })
            }
        },
        search(){
            this.$refs.moreEnterprise.open()
        }
    },
    components: {
        avatar,
        authStatus,
        userTypeTag,
        moreEnterprise
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.user-info-title{
    position: absolute;
    display: block;
    width: 100%;
    padding: 0;
    white-space: nowrap;
    background: @color-main;
    height: 50*@px;
    text-align: center;
    font-size: 18*@px;
    .title-user-name{
        color: @color-white;
        line-height: 50*@px;
    }
}
.change-user-btn{
    display: inline-block;
    border: 1*@px solid #fff;
    border-radius: 10*@px;
    width: 45*@px;
    height: 15*@px;
    font-size: 12*@px;
    color: #fff;
    line-height: 15*@px;
    position: absolute;
    top: 18*@px;
    margin-left: 8*@px;
}
.user{
    position: absolute;;
    top:70*@px;
    left:0;
    right:0;
    text-align:center;
}
.user-img{
    position: relative;
    z-index: 99;
    margin-right: 0.1rem;
}
.user-info{
    position: absolute;
    top: 50*@px;
    left: 0;
    right: 0;
    bottom: 0;
}
.user-info-top{
    padding: 20*@px;
    background: #fff;
    display: flex;
    align-items: center;
}
.avatar{
    line-height: 65*@px;
    display: inline-block;
}
.title-user-edition{
    color: #999999;
    font-size:@font-size-regular;
    padding: 2px 0;
    display: block;
}
.user-name{
    color: #333333; 
    padding-right: 10*@px;
    font-size: @font-size-title;
}
.user-info-detail{
    position: relative;
    left: 0;
    width: 100%;
    top: 20*@px;
    bottom: 0;
    .form-list{
        display: flex;
        align-items: center;
        background-color: #fff;
        border-top:1*@px solid #e5e9ed;
        padding: 0.15rem 0.2rem;
        color: #333333;
        p{
            flex: 1;
            display: flex;
            justify-content: space-between;
            padding: 0 8*@px;
        }
        i{
            font-size: @font-size-title;
            color: #333333;
        }
        &:first-child{
            border: none;
        }
    }
}
.log-out{
    text-align: center;
    color:@color-danger;
    margin-top: 40*@px;
    width: 100%;
    background: @color-white;
    flex:1;
    .btn{
        line-height: 0.5rem;
        height: 0.5rem;
        font-size:@font-size-title;
    }
}
.boom{
    top: 50*@px;
    background: @color-white;
    width: 100%;
    overflow-y:hidden;
    white-space: nowrap;
    max-height: 260*@px;
    border-radius: 0 0 5*@px 5*@px;
    
    .icon{
        padding-right:10*@px;
    }

    .normal{
        &.active{
            color: @color-main;
        }
    }
}
.boom-list{
    color: #333;
    font-size: @font-size-primary;
    height: 40*@px !important;
    line-height: 40*@px !important;
    border-bottom: 1px solid #e5e9ed;
    display: flex;
    align-items: center;
    padding: 0 20*@px;
    text-align: left;
}

.gray{
    background:#dcdbdb;
    position:relative;
}
.forbid{
    position:absolute;
    top:12px;
    right:10px;
    color:#81878e;
}
.more{
    color: @color-main;
}
.input-style{
    font-size:@font-size-regular;
    background:rgb(247,247,249)
}
.search{
    padding: 0 5px;
    font-size: @font-size-primary;
    color: rgb(153,153,153);
}
.create-enterprise{
    color: @color-success;
    cursor:pointer;
    padding: 0 20*@px;
    height: 40*@px !important;
    line-height: 40*@px !important;
    font-size:@font-size-primary;
    border-bottom: 1px solid @color-border-segment;
    text-align: left;

    &:hover{
        background: @color-success;
        color: white;
    }
}
</style>
<style>
.mint-searchbar{
  padding: 2px 10px;
  height:0.4rem;
  background:#fff;
}
.user-info-title .v-modal{
    top: 0.5rem;
}
</style>