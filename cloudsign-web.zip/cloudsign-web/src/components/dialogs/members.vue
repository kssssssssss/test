<!--
    @id        ui-add-member
    @desc      ui组件
    @level     ui：系统组件
    @author    周雪梅
    @date      2019-03-27 20:03:34
-->
<template>  
    <div v-show="visible" class="dialog-content">
        <Tab :tabs="memberStatusTabs" :activeTab="activeTab"  @active-tab="chooseMembersStatus" class="member-list-border"></Tab>
        <div v-if="step == 0">
            <span class="explain">提示：向同事的手机或邮箱发送邀请链接，同事申请加入，管理员审核通过即可加入本企业</span><br>
            <label class="public-title">姓名:&nbsp;<span class="errorWarning">{{userNameErr}}</span></label>
            <el-input class="dialog-form-group" placeholder="请输入姓名(汉字或字母)" v-model.trim="userName" @blur="checkUserName"></el-input>
            <label class="public-title">帐号:&nbsp;<span class="errorWarning">{{accountErr}}</span></label>
            <el-input class="dialog-form-group" placeholder="请输入11位手机号或邮箱地址" v-model.trim="account" @blur="checkContactFormat()"></el-input>
            <label class="public-title">部门:&nbsp;</label>
            <el-input class="dialog-form-group" placeholder="可选择部门（选填）" :disabled="enterpriseName?true :false" :value="enterpriseName">
            </el-input>
        </div>
        <div v-if="step == 1">
            <p class="explain">提示：分享二维码邀请同事加入，同事申请加入，管理员审核通过即可加入本企业</p>
            <div class="public-center">
                <img class="qr-code" :src="qrCode">
                <p class="enterprise-name-title">扫码快速加入{{this.enterpriseName}}</p>
            </div>
            <div class="input-box">
                <el-input :readonly="true" class="dialog-form-group" :class="permission.MEMBER_INVITATION_SWITCH ?  'copy-button' : 'nomal-copy-button'" v-model.trim="linkUrl">
                    <el-button slot="append" @click="copeInvitaitonLinkUrl(linkUrl, $event)">复制链接</el-button>
                </el-input>
                <el-button v-if="permission.MEMBER_INVITATION_SWITCH" class="created-button" type="primary" :loading="createdLoading" @click="rebuildInvitaionLinkUrl">重新生成链接</el-button>
            </div>
            <p v-if="permission.MEMBER_INVITATION_SWITCH" class="text-right link-switch">关闭链接，链接将不能访问
                <el-switch v-model="linkSwitch" active-text="开" inactive-text="关" @change="changeLinkSwitch"></el-switch>
            </p>
        </div>
        <span v-if="step == 0" slot="footer" class="dialog-footer">
            <el-button @click="closeAddDepartmentMemberVisible">取 消</el-button>
            <el-button type="primary" :loading="inviteLoading" @click="sendInviteMember">发送邀请</el-button>
        </span>
    </div>
</template>
<script>
import {
    membersInvite, 
    invitationsLinkUrlSwitch, 
    generateInvitationLinkUrl, 
    getInvitationLinkUrl} from "@interfaces/enterprise/enterprise.js"
import {  
    getDepartments, 
  } from "@interfaces/enterprise/departments.js"

import { isPhone, isEmail, 
    isUserName } from "@wesign/check"
import Tab from "@components/commons/tabs/tab-default.vue"
import QRCode from "qrcode"
export default {
    props: {
        visible: {
            type: Boolean,
            default: true
        },
    },
    data(){
        return {
            userName: "", //姓名
            userNameErr: "", //姓名错误提示
            account: "", //帐号
            accountErr: "", //帐号错误提示
            password: "", //密码
            passwordErr: "", //密码错误提示
            addDepartmentMemberVisible: false, //控制添加部门成员成员模态框 
            step: 0,
            activeTab: 0,
            statuses: [
                {name: "邀请同事加入", type: "INVITEMEMBER"},
                {name: "通过链接邀请", type: "LINKINVITE"},
            ],
            qrCode: "",
            linkUrl: "",
            invitationsLinkUrlWsid: "",
            createdLoading: false,
            invitationLinkUrl: "",
            // showSelectDepartmentName: false, //控制部门列表的显示与隐藏
            defaultProps: {
                children: "children",
                name: "name"
            },
            inviteLoading: false,

            linkSwitch: false,
            linkSwitchChangeing: false, //邀请成员链接是否有效
            departments:[],
            departmentLoading:false,
            // isShowDisable:true
        }
    },
    computed: {
        memberStatusTabs(){
            return this.statuses.map(s => s.name)
        },
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        enterpriseAuthorWsid(){ //企业拥有者id
            return (this.$store.getters.enterpriseAuthorWsid)
        },
        permission(){
            return this.$store.getters
        },
        enterpriseName(){
            return this.$store.getters.enterpriseName
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        isShowDiabled(){
            if(this.userName&&this.phone){
                return false
            } else {
                return true
            }
        },
    },
    created(){
        this.getInvitationUrl()
    },
    methods: {
        chooseMembersStatus(index){
            this.activeTab = index
            let type = this.statuses[index].type
            if (type == "INVITEMEMBER"){
                this.step = 0
            } else {
                this.step = 1
            }
        },
        copeInvitaitonLinkUrl(text, event){
            let input = document.createElement("input")
            document.body.appendChild(input)
            input.value = text
            input.select()
            input.setSelectionRange(0, input.value.length), document.execCommand("Copy")
            this.$message.success("复制成功")
            document.body.removeChild(input)
        },
        rebuildInvitaionLinkUrl(){
            if (this.createdLoading) return
            if (this.invitationLinkUrl != undefined){
                this.$confirm("此操作将重新生成链接, 之前的链接将失效，是否继续?", "提示", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(() => {
                    this.createdLinkUrl()
                }).catch(() => {
                    this.$message({
                        type: "info",
                        message: "已取消生成链接"
                    })
                })
            } else {
                this.createdLinkUrl()
            }
        },
        createdLinkUrl(){
            this.createdLoading = true
            generateInvitationLinkUrl({
                enterpriseWsid: this.enterpriseWsid
            }).then(res => {
                let invitationsLinkUrl = res.data.data.linkData
                this.invitationsLinkUrlWsid = invitationsLinkUrl.invitationWsid
                this.linkUrl = invitationsLinkUrl.link
                this.linkSwitch = true
                this.qrCode = ""
                QRCode.toDataURL(invitationsLinkUrl.link, (err, url) => {
                    this.qrCode = url
                })
                // this.$message.success("生成邀请链接成功")
            }).catch(err => {
                this.$message.error("生成邀请链接失败")
            }).then(_ => {
                this.createdLoading = false
            })
        },
        getInvitationUrl(){
            getInvitationLinkUrl({
                enterpriseWsid: this.enterpriseWsid
            }).then(res => {
                let invitationsLinkUrl = res.data.data.linkData
                this.invitationLinkUrl = invitationsLinkUrl.link
                if (invitationsLinkUrl.link == "" || invitationsLinkUrl.link == undefined) {
                    this.rebuildInvitaionLinkUrl()
                } else {
                    this.invitationsLinkUrlWsid = invitationsLinkUrl.invitationWsid
                    this.linkUrl = invitationsLinkUrl.link
                    this.linkSwitch = invitationsLinkUrl.status === "OPEN" ? true : false
                    this.qrCode = ""
                    QRCode.toDataURL(invitationsLinkUrl.link, (err, url) => {
                        this.qrCode = url
                    })
                }
            }).catch(err => {
                console.error(err)
            })
        },
        changeLinkSwitch(val){
            if (this.linkSwitchChangeing) return
            this.linkSwitchChangeing = true

            invitationsLinkUrlSwitch({
                enterpriseWsid: this.enterpriseWsid,
                invitationWsid: this.invitationsLinkUrlWsid,
                status: val ? "open" : "off"
            }).then(res => {
                this.$message.success(`邀请链接已${val ? "打开" : "关闭"}`)
            }).catch(err => {
                this.linkSwitch = !this.linkSwitch
                if (err.response && err.response.status === 403){
                    this.$message.error(`邀请链接开关切换过于频繁！`)
                } else {
                    this.$message.error(`邀请链接开关切换失败`)
                }
            }).then(_ => {
                this.linkSwitchChangeing = false
            })
        },
        //关闭添加部门成员模态框
        closeAddDepartmentMemberVisible(){
            this.userName = ""
            this.account = ""
            this.password = ""
            this.$emit("close")
            this.userNameErr = ""
            this.accountErr = ""
            this.passwordErr = ""
        },
        //发送邀请链接
        sendInviteMember(){
            this.checkUserName(true) 
            this.checkContactFormat(true)

            if (this.userNameErr || this.accountErr) {
                return 
            }
            let inviteDepartment = []
            // if (this.selectDepartmentName == "" || this.selectDepartmentName == this.enterpriseName){
            //     inviteDepartment.push(this.enterpriseWsid)
            // } else {
                inviteDepartment.push(this.enterpriseWsid)
            // }
            this.inviteLoading = true
            membersInvite({
                enterpriseWsid: this.enterpriseWsid,
                name: this.userName,
                account: this.account,
                departmentWsids: inviteDepartment,
            }).then( res => {
                this.$message.success("邀请成功")
                this.inviteLoading = false
                this.closeAddDepartmentMemberVisible()
            }).catch(err => {
                this.inviteLoading = false
                if (err.response && err.response.data){
                    let code = err.response.data.code
                    if (code === 101){
                        this.$message.warning("该用户已经是该企业成员")
                    } else if (code === 102){
                        this.$message.warning("该用户已经是该企业成员,当前已被“禁用”，重新启用请联系企业管理员处理")
                    } else if (code === 103){
                        this.$message.warning("该用户已经申请加入企业，请耐心等待管理员处理")
                    } else {
                        this.$message.error("邀请成员失败")
                    }
                }
                this.closeAddDepartmentMemberVisible()
            })
        },
        // 检查帐号格式
        checkContactFormat(checkNull = false) {
            let val = this.$data.account
            if (val.length === 0){
                if (checkNull === true){
                    this.$data.accountErr = "请输入手机号或邮箱地址"
                    return false
                }
                else {
                    this.$data.accountErr = ""
                    return false
                }
            }

            if (!isEmail(val).result && !isPhone(val).result){
                this.$data.accountErr = "帐号输入错误"
                return false
            }
     
            this.$data.accountErr = ""
            return true 
        },
        // 检查姓名
        checkUserName(checkNull = false){
            if (!checkNull && this.userName === "") {
                this.userNameErr = ""
                return true
            }
            let val = this.userName
            let out = isUserName(val)
            switch (out.code) {
                case 100: this.userNameErr = "";break
                case 101: this.userNameErr = "请输入真实姓名";break
                default: this.userNameErr = "请输入有效的姓名"
            }
            return out.result
        },
    },
    components: {
        Tab
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.member-list-border{
    justify-content: center;
    top:-20px;
    padding:0;
}
.public-title{
    line-height:35px;
    display:inline-block;
    padding:0;
}
.dialog-content{
    position:relative;
    height: 390px;
}
.el-tree{
    position:absolute;
    left:0;
    right:0;
    width:100%;
    z-index:999;
    max-height:120px;
    height:auto;
    min-height:50px;
    overflow:auto;
    border: 1px solid #d7dbde;
    background:#fafafa;
}
.el-dialog__body{
    padding:30px 20px 0 20px;
}
.explain{
    color:#999;
    font-size:@font-size-info;
    text-align:center;
    display:block;
}
.text-right{
    text-align:right;
    padding-top:15px;
}
.public-center{
    text-align:center;
    font-size:12px;
    line-height:25px;
    img{
        width: 150px;
        height: 150px;
    }
}
.enterprise-name-title{
    text-align:center;
    font-size:14px;
    color:#E6A23C;
    padding-bottom:15px;
}
.input-box{
    position:relative;
    height:48px;
    max-width:500px;
    margin:0 auto;
    display: flex;
    .copy-button{
        width: 80%;
        max-width:350px;
        position:absolute;
        right:160px;
        left: 0;
    }
    .nomal-copy-button{
        width: 100%;
        max-width:350px;
        position:absolute;
        right:0;
        left: 0;
        margin:0 auto;
    }
    .created-button{
        position:absolute;
        right:0;
        top:0;
    }
}
.dialog-footer{
    padding: 30px 0;
    text-align: right;
    box-sizing: border-box;
    display:block;
}
.errorWarning{
    color:@color-danger;
    display:inline-block;
    font-size:@font-size-regular
}
</style>
<style lang="less">
.link-switch .el-switch.is-checked .el-switch__core:after {
    left: 100%;
    margin-left: -17px;
}
.link-switch .el-switch__core:after {
    content: "";
    position: absolute;
    top: 1px;
    left: 1px;
    border-radius: 100%;
    transition: all .3s;
    width: 16px;
    height: 16px;
    background-color: #fff;
}
.dialog-content .el-tree-node__content:hover,.dialog-content .el-tree-node__content:active{
    color: #0c7ffc;
    background: #d8ecff !important;
}
.member-list-border .tab{
    font-size: 18px;
}
.member-list-border .active{
    color:#0C7FFC;
    font-weight: 400 !important;
}
</style>