<!--
    @id        sysytem-choose-seals
    @desc      选择签名/印章组件
    @level     system：系统组件
    @functions 内部提供给外部的驱动函数
        open(types): 打开组件
        close():关闭组件
    @author    陈曦源
    @date      2018-12-12 09:36:47
-->
<template>
    <el-dialog :title="typesConfig[selectType] && typesConfig[selectType].name || '签名'" :visible.sync="dialogVisible"
        :close-on-click-modal="false" @close="close" width="600px">
        <!-- <div class="choose-seals-tabs">
            <el-radio-group v-model="selectType">
                <el-radio-button v-for="t in activeTypes" :key="t" :label="t">{{typesConfig[t].name}}</el-radio-button>
            </el-radio-group>
        </div>
        <hr> -->
        <component v-if="typesConfig[selectType]" :is="typesConfig[selectType].component" :seal="personSeal" :userWsid="activeUserWsid" :customStyles="customStyles" @upload-data="selectedData"></component>
    </el-dialog>
</template>

<script>
import { getPersonSeals, deletePersonalSeal} from "@interfaces/seals/seals.js"

import scanSignature from "./choose-seals-components/scan-signature.vue"

export default {
    props: {
        userWsid: String,
        customStyles:Object
    },
    data(){
        return {
            dialogVisible: false,
            personSeal: null,

            selectType: "",
            activeTypes: [],
            typesConfig: {
                SCAN_SIGNATURE: {name: "扫码签名", component: scanSignature}
            },

            resolveHandle: null,
            rejectHandle: null
        }
    },
    computed: {
        activeUserWsid(){
            return this.userWsid || this.$store.getters.activeUserWsid
        }
    },
    created(){
        this.getSealsData()
    },
    methods: {
        getSealsData(){
            getPersonSeals({
                authorWsid: this.activeUserWsid
            }).then(res => {
                let personSeals = res.data.data.personSeals
                let personSeal = personSeals[personSeals.length - 1]
                if (personSeal){
                    this.personSeal = {
                        id: personSeal.personSealWsid,
                        imageData: personSeal.link.href
                    }
                }
            })
        },
        async open(types, autoBack = true){
            if (!Array.isArray(types)) throw TypeError("not array")
            
            if (this.personSeal && autoBack){
                return {
                    id: this.personSeal.id,
                    imageData: this.personSeal.imageData
                }
            } else {
                this.activeTypes = types
                this.selectType = types[0]
                this.dialogVisible = true
    
                return new Promise((resolve, reject) => {
                    this.resolveHandle = resolve
                    this.rejectHandle = reject
                })            
            } 
            
        },
        deleteSealsData(id){
            deletePersonalSeal({
                personSealWsid: id
            })
        },
        selectedData(data){
            if (this.resolveHandle){
                if (this.personSeal){
                    this.deleteSealsData(this.personSeal.id)
                }
                this.resolveHandle(data)
            }
            this.personSeal = data
            this.resolveHandle = null
            this.dialogVisible = false
        },
        close(){
            this.cancle()
        },
        cancle(){
            if (this.resolveHandle){
                this.rejectHandle("cancle")
            }
            this.dialogVisible = false
        }
    }
}
</script>

<style lang="less" scoped>
.choose-seals-tabs{
    text-align: center;
}
</style>
