<!--
    @name   sys-user-auth-status
    @desc   当前用户个人实名认证状态
    @level  system
    @auther 陈曦源, 周雪梅
    @date   2018-02-02 10:46:13
-->

<template>
    <authStatus :status="userAuthStatus" linkType="PERSON"></authStatus>
</template>

<script>
import authStatus from "./auth-status.vue"

export default {
    computed: {
        userAuthStatus(){
            return this.$store.getters.userIddtvStatus
        }
    },
    components: {
        authStatus
    }
}
</script>