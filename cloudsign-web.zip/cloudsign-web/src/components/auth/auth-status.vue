<!--
    @name   ui-auth-state
    @desc   用户状态组件
    @level  ui
    @props
        status:String    认证状态
        linkType: String 启动跳转功能 PERSON 个人认证页面 ENTERPRISE 企业认证页面
    @author 陈曦源,周雪梅
    @date   2018-09-12 19:52:27
-->
<template>
    <span>
        <span class="auth-status-box" :class="color" :style="statusStyle" @click="jump" v-if="this.status!=='SENIOR_PASSED'&& this.status!='SENIOR_NO_CERT'">
            {{text}}
        </span>
        <span class="auth-status-box" v-else>
            <i class="icon icon-enterprise-auth"></i>
        </span>
    </span>
</template>

<script>
import { authFlow } from "@interfaces/openapi/enterprise-authentication.js"
import { startPersonAuthProcess } from '@interfaces/openapi/person-authentication.js'
export default {
    props: {
        /**
             * 个人认证状态：
             * INCOMPLETE-未认证
             * PASSED-已认证
             * WAITING-等待审核
             * DENY-认证未通过
             * 
             * 企业认证状态：
             * INCOMPLETE-未认证
             * WAITING-等待审核
             * PRIMARY_PASSED-初级认证
             * PRIMARY_DENY-认证未通过
             * WAITING_SUM-等待打款
             * WAITING_SUM_CHECK-确认打款(等待用户汇款信息确认)
             * SENIOR_PASSED-高级认证(用户汇款信息确认成功),
             * SENIOR_DENY-认证未通过(打款失败/汇款验证失败)
             * SENIOR_NO_CERT-高级认证(但颁发证书失败),
             */
        status: {
            default: "INCOMPLETE",
            required: true
        },
        linkType: {
            type: String, //PERSON 个人认证页面 ENTERPRISE 企业认证页面
            default: ""
        }
    },
    computed: {
        text () {
            switch (this.status) {
                case "INCOMPLETE": return "未认证"
                case "WAITING": return "审核中"
                case "PASSED": return "已认证"
                case "DENY": return "认证未通过"

                case "PRIMARY_PASSED": return "初级认证"
                case "PRIMARY_DENY": return "认证未通过"
                case "WAITING_SUM": return "等待打款"
                case "WAITING_SUM_CHECK":return "确认打款"
                case "SENIOR_PASSED":return "高级认证"
                case "SENIOR_DENY":return "认证未通过"
                case "SENIOR_DENY_NAME_REPEAT":return "认证未通过"
                case "SENIOR_NO_CERT":return "高级认证"
                default:
                    return "未认证"
            }
        },
        color () {
            switch (this.status) {
                case "PASSED": return "success"
                case "SENIOR_PASSED": return "success"
                case "SENIOR_NO_CERT":return "success"
                default : return "danger"
            }
        },
        statusStyle(){
            if (this.status === "PASSED" || this.status === "SENIOR_PASSED" || this.status === "SENIOR_NO_CERT") return //已认证的无需跳转
            if (this.linkType){
                return {
                    cursor: "pointer"
                }
            }
        }
    },
    methods: {
        jump(){
            if (this.status === "PASSED" || this.status === "SENIOR_PASSED" || this.status === "SENIOR_NO_CERT") return //已认证的无需跳转
            if (!this.linkType) return

            if (this.linkType === "PERSON"){
                startPersonAuthProcess({
                    authModes:[],
                    presetPersonAuthentications: [{
                        name: this.$store.getters.userName,
                        phone:this.$store.getters.userContact
                    }],
                    returnUrl: ''
                }).then(res =>{
                    let actionUrl = res.data.data.actionUrl
                    location.href = `${actionUrl}`
                }).catch(err=>{
                    console.error(err)
                })
            } else if (this.linkType === "ENTERPRISE"){
                authFlow({
                    returnUrl:`${location.origin}/wesign`
                }).then(res =>{
                    let actionUrl = res.data.data.actionUrl
                    location.href = actionUrl
                }).catch(err=>{
                    console.error(err)
                    if (err.response){
                        let code = err.response.data.code
                        if (code === 101){
                            this.$alert("该企业已认证通过，请勿重复操作", "提示", {
                                confirmButtonText: "知道了",
                                type: "warning",
                                callback: action => {
                                    this.$store.dispatch("updateModule")
                                },
                            })
                        }else if(code === 102){
                            let developerMessage = err.response.data.data.msg
                            let erorInfo 
                            if(developerMessage.indexOf("该企业已经注册认证") != -1){
                                erorInfo = `若是本人，请检查自己账号下是否已有该企业。若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600。`
                            } else {
                                erorInfo =""
                            }
                            this.$alert(`<p>${developerMessage}${erorInfo}</p>`, "提示", {
                                confirmButtonText: "知道了",
                                dangerouslyUseHTMLString: true,
                                type: "warning",
                            }).then(() => {}, () => {})
                        }
                    } else {
                        this.$message.error("网络开小差了，请检查您的网络是否正或刷新页面重试")
                    }
                })
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.auth-status-box{
    display:inline-block;
    padding: 0 3*@px;
    border-radius: 8*@px 0;
    height:14*@px;
    line-height: 14*@px;
    font-size: @font-size-info;
    vertical-align: middle;
    cursor: pointer;
    &.danger{
        color:@color-danger;
        border:1px solid @color-danger;

    }

    &.success{
        color:@color-success;
        border:1px solid @color-success;
    }
}
.icon{
    font-size: @font-size-title;
}
</style>