<!--
    @id        sys-find-password
    @desc      找回密码组件
    @level     system：系统组件
    @author    陈曦源,周雪梅
    @date      2019-03-29 16:06:59
-->
<template lang="html">
    <div @input="clearInfo" class="info">
        <div class="wesign-outside-error-box">
            <p v-if="infoText" :class="infoClass">
                <i :class="infoIcon"></i>
                {{infoText}}
            </p>
        </div>
        <template v-if="stage === 0">
            <el-input type="text" ref="account" class="wesign-outside-form-group" placeholder="请填写注册时用的手机号/邮箱地址" 
                v-model.trim="account" size="large" @input="accountCheck = false"></el-input>
            <el-row class="wesign-outside-form-group">
                <el-col :span="13">
                    <el-input type="text" size="large" :disabled="!isImport" :placeholder="!isImport ? '请点击右侧获取验证码' : '请输入验证码'" v-model.trim="verifyCode" 
                        @input="verifyCodeCheck = false" @blur="checkVerifycodeFormat()" @keyup.enter.native="next"/>
                </el-col>
                <el-col :span="10" :offset="1">
                    <captchaButton size="large" style="width:100%" :disabled="!accountCheck" :contact="account" :service="serviceName"
                        @sending="sending"
                        @error="sendVerifyCodeError" @sendsuccess="sendSuccess" @timeShow="isImport = true" :type="verifyCodeType"></captchaButton>
                </el-col>
                <el-col class="right placeholder">
                    <a v-show="showCodeExplain && showVoiceCode === true" class="right" @click="showModalCodeExplain">收不到验证码？</a>
                    <a class="center wesign-outside-unline" v-show="showCodeExplain && showVoiceCode === true && !publicCodeType" @click="setVerifyCodeType('VOICE')"><i class="icon-phone-volume phone"></i>试试语音</a>
                    <a v-show ="showCodeExplain && showVoiceCode === false && !publicCodeType">不方便接听电话？<span class="wesign-outside-unline" @click="setVerifyCodeType('SMS')"><i class="icon-email email"></i>返回短信验证码</span></a>
                </el-col>
            </el-row>
            <div>
                <el-button size="large" style="width:100%;" type="primary" :loading="nexting" @click="next">下一步</el-button>
                <div class="wesign-outside-public" style="display:flex">
                    <a href="/login" class="wesign-outside-unline center">返回登录</a>
                </div>			
            </div>
        </template>
        <template v-else-if="stage === 1">
            <el-input class="wesign-outside-form-group" size="large" placeholder="输入新密码(至少6位数字、字母或字符的组合)" 
                :type="newpasswordStatus ? 'text' : 'password'" v-model.trim="newpassword" @blur="checkPassword()">
                <i slot="append" class="view" :class="newpasswordStatus ? 'icon-eye eye' : 'icon-eye-blocked'" @click="newpasswordView()"></i> 
            </el-input>
            <el-input class="wesign-outside-form-group" size="large" placeholder="再次确认您的登录密码" 
                :type="repasswordStatus ? 'text' : 'password'" v-model.trim="repassword" @blur="checkRepassword()" @keyup.enter.native="completePassword">
                <i slot="append" class="view" :class="repasswordStatus ? 'icon-eye eye' : 'icon-eye-blocked'" @click="repasswordView()"></i> 
            </el-input>     
            <el-button class="wesign-outside-form-group" size="large" style="width:100%;" type="primary"
                :loading="complating" @click="completePassword">确认</el-button>
        </template>
        <template v-if="stage === 2">
            <div class="wesign-outside-form-group public-center">
                <p class="icon-pic"><i class="wesign-outside-right el-icon-success success"></i></p>
                <p class="regist-success">修改密码成功, {{countDown}}秒后自动登录</p>
            </div>
            <div class="wesign-outside-form-group public-center"><a href="/login" class="wesign-outside-unline">立即登录</a></div>
        </template>
        <codeExplain @close-modal="close" :msg="codeExplainTitle" :type="codeExplainType" :messages="codeExplainPublicMessage" :message="codeExplainMessage"  v-show="modalCodeExplain" @close-dialog="close"></codeExplain>
    </div>
</template>

<script>
import querystring from "querystring"
import { isPhone, isEmail, isPassword} from "@wesign/check"
import captchaButton from "@components/buttons/captcha-button.vue"
import { checkAccount, retrievePassword } from "@interfaces/user/user.js"
import { sessions_post } from "@interfaces/user/sessions.js"
import { opcode_post} from "@interfaces/auth/captcha.js"
import codeExplain from "@components/modal/code-explain.vue"
import { ERROR_CODES } from "@errors/code.js"
import { MessageBox } from "element-ui"

export default {
    data(){
        return {
            /* ERROR_ACOUNT_ISNULL             请输入手机号或邮箱帐号
             * ERROR_ACOUNT_NULL               该帐号尚未注册 
             * ERROR_ACOUNT                    帐号输入错误
             * ERROR_VERIFICATION_ISNULL       请输入验证码
             * ERROR_VERIFICATION_CODE         验证码错误
             * ERROR_VERIFICATION_CODE_BUSY    验证码获取频繁，今天已无法获取
             * ERROR_CONTACT                   联系人格式错误
             * ERROR_SEND_BUSY                 发送频繁
             * ERROR_SEND_FAILED               发送失败
             * ERROR_COMPLETE_INFO_ISNULL      请填写有效的完整信息
             *                 
             * ERROR_PASSWORD_ISNULL           请输入密码
             * ERROR_PASSWORD_BLANK            密码含有空格
             * ERROR_REPASSWORD_ISNULL         请输入确认密码      
             * ERROR_PASSWORD-LT               密码长度不能低于6位"
             * ERROR_PASSWORD-GT               密码长度不能超过32位
             * ERROR_NOT_ALL_ABC               密码不能全为字母
             * ERROR_NOT_ALL_NUMBER            密码不能全为数字
             * ERROR_NOT_ALL_CHAR              密码不能全为字符
             * ERROR_PASSWORD_ISWRONG          密码格式错误
             * ERROR_PASSWORD_AFFIRM           密码确认错误，请重新输入
             * ERROR_DETECTION                 检测失败
             * ERROR_RESET_PASSWORD            重置密码失败
             *
             * RIGHT_PHONE_VERIFICATION_SEND   验证码已发送，请注意查收短信
             * RIGHT_EMAIL_VERIFICATION_SEND   验证码已发送至指定邮箱，请查收
             */
            
            account: "",
            accountCheck: false,
            verifyCode: "", //验证码
            verifyCodeCheck: false, //验证码是否通过检测
            nexting: false,

            newpassword: "",
            repassword: "",
            complating: false,
            opcode: "", //操作码
            modalCodeExplain: false, //收不到验证码弹框
            showCodeExplain: false, //收不到验证码说明
            newpasswordStatus: false,
            repasswordStatus: false,
            toggle: false,
            
            priorityStatus: [
                {name: "accountStatus", status: ""},
                {name: "accountExist", status: ""},
                {name: "codeFormat", status: ""},
                {name: "passwordStatus", status: ""},
                {name: "verifyPasswordStatus", status: ""},
            ],
            commonStatus: "",
            
            stage: -1,
            countDown: 0,
            isImport: false,
            showVoiceCode: false,
            verifyCodeType: "SMS",
            publicCodeType: false,
            serviceName: "RESET_PWD"
        }
    },
    computed: {
        infoStatus(){
            let status = this.priorityStatus.find(item => {
                if (item.status){
                    return true
                }
            })

            return status && status.status || this.commonStatus
        },
        infoText(){
            let status = this.infoStatus
            switch (status){
                case "ERROR_LOGIN": return "登录失败";break
                case "ERROR_ACOUNT_ISNULL": return "请输入手机号或邮箱地址";break
                case "ERROR_ACOUNT_NULL": return "该帐号尚未注册";break
                case "ERROR_ACOUNT": return "帐号输入错误";break
                case "ERROR_VERIFICATION_ISNULL": return "请输入验证码";break
                case "ERROR_VERIFICATION_CODE":return "验证码错误";break
                case "ERROR_VERIFICATION_CODE_BUSY": return "验证码获取频繁，今天已无法获取";break 
                case "ERROR_CONTACT": return "联系人格式错误";break
                case "ERROR_SEND_BUSY": return "发送太频繁，请倒计时结束后再点击";break
                case "ERROR_SEND_FAILED": return "发送失败";break
                case "ERROR_SEND_TIMEOUT": return "发送请求超时";break
                case "ERROR_SEND_FREQUENTLY": return "发送请求过于频繁";break
                case "ERROR_SEND_AMOUNT_OUT_LIMIT": return "今日可接收验证码已达到上限";break
                case "ERROR_PASSWORD_ISNULL": return "请输入新密码";break
                case "ERROR_REPASSWORD_ISNULL": return "请输入确认密码";break
                case "ERROR_PASSWORD_BLANK": return "密码不能包含空格";break
                case "ERROR_PASSWORD-LT": return "密码长度至少6位";break
                case "ERROR_PASSWORD-GT": return "密码长度不能超过32位";break
                case "ERROR_NOT_ALL_ABC": return "密码不能全为字母";break
                case "ERROR_NOT_ALL_NUMBER": return "密码不能全为数字";break
                case "ERROR_NOT_ALL_CHAR": return "密码不能全为字符";break
                case "ERROR_PASSWORD_AFFIRM": return "密码确认错误，请重新输入";break
                case "ERROR_PASSWORD_ISWRONG": return "密码不合法";break
                case "ERROR_DETECTION": return "网络不稳定，请稍候再试";break
                case "ERROR_RESET_PASSWORD": return "重置密码失败";break
                case "RIGHT_PHONE_VERIFICATION_SEND":return "验证码已发送，请注意查收短信";break
                case "RIGHT_EMAIL_VERIFICATION_SEND":return "验证码已发送至指定邮箱，请查收";break
                case "RIGHT_VOICE_VERIFICATION_SEND": return "请求成功，请注意接听电话";break
            }
        },
        infoClass(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-errorWarning"
                
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-rightWarning"
            }
        },
        infoIcon(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-error el-icon-error"
                
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-right el-icon-success"
            }
        },
        codeExplainType(){
            let val = this.$data.account
            if (isPhone(val).result){
                this.showVoiceCode = true
                this.publicCodeType = false
                return "PHONE"
            } else if (isEmail(val).result){
                this.showVoiceCode = false
                this.publicCodeType = true
                return "EMAIL"
            }
        },
        codeExplainTitle(){
            let val = this.$data.account
            if (isPhone(val).result){
                return "检查短信是否被屏蔽"
            } else if (isEmail(val).result){
                return "查看是否进入垃圾信息或广告信息"
            }
        },
        codeExplainPublicMessage(){
            let val = this.$data.account
            if(isPhone(val).result){
                return "检查您的手机号是否正确"
            } else if(isEmail(val).result){
                return "检查您的邮箱号是否正确"
            }
        },
        codeExplainMessage(){
            let val = this.$data.account
            if (isPhone(val).result){
                return "若2分钟内未收到短信，可重新获取"
            } else if (isEmail(val).result){
                return "若2分钟内未收到邮件，可重新获取"
            }
        }
    },
    watch: {
        account(oldVal,newVal) {
            if(oldVal.length>0){
                if(!isEmail(oldVal).result && !isPhone(oldVal).result){
                    this.accountCheck = false
                    this.showCodeExplain = false
                } else {
                    if(oldVal!== newVal){
                        return this.checkAccountExist()
                    }
                }
            }
        }
    },
    created(){
        let query = querystring.parse(location.hash.slice(1))
        if (query.stage == 1){
            opcode_post({
                contact: query.account,
                captcha: query.captcha,
                service: "RESET_PWD"
            }).then(body => {
                let opcode = body.data.operationCodeInfo.opcode
                this.verifyCode = query.captcha
                this.account = query.account
                this.opcode = opcode
                this.stage = 1
            }).catch( err => {
                if (err.response.data){
                    let code = err.response.data.code
                    switch (code) {
                        case 101:
                            this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                            break 
                        case 102:
                            this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                            break 
                    }
                }
                this.account = query.account
                this.checkAccountExist()
                location.hash = ""
                this.stage = 0
            })
        } else if (query.stage == 2){
            this.stage = 2
        } else {
            this.stage = 0
            location.hash = ""
        }
    },
    methods: {
        setVerifyCodeType(val){
            if(val == "SMS"){
                this.showVoiceCode = true
                this.verifyCodeType = "SMS"
                this.serviceName = "RESET_PWD"
            } else {
                this.showVoiceCode = false
                this.verifyCodeType = "VOICE"
                this.serviceName = "VOICE_RESET_PWD"
            }
        },
        sending(){
            this.setInfoStatus("passwordStatus", "")
            this.setInfoStatus("accountExist", "")
            this.setInfoStatus("codeFormat", "")
            this.setInfoStatus("passwordStatus", "")
            this.setInfoStatus("verifyPasswordStatus", "")
        },
        setInfoStatus(name, status){
            let priorityStatus = this.priorityStatus
            priorityStatus.find((item, index) => {
                if (item.name === name){
                    item.status = status
                    if (status){
                        this.commonStatus = ""
                    }
                    priorityStatus.splice(index, 1)
                    priorityStatus.splice(0, 0, item)
                    return true
                }
            })
        },
        checkAccountFormat(checkNull = false) { //检测帐号格式
            let val = this.$data.account
            if (val.length === 0){
                if (!checkNull){
                    this.setInfoStatus("accountStatus", "")
                    return true
                } else {
                    this.setInfoStatus("accountStatus", "ERROR_ACOUNT_ISNULL")
                    return false
                }
            } else if (!isEmail(val).result && !isPhone(val).result){
                this.setInfoStatus("accountStatus", "ERROR_ACOUNT")
                return false
            }
            
            this.setInfoStatus("accountStatus", "")
            return true
        },
        checkAccountExist(checkNull = false) { //检测帐号是否存在
            if (!this.checkAccountFormat(checkNull)){
                return 
            } 
            let val = this.account
            if (!val) return

            return checkAccount({
                account: val
            }).then(res => {
                let body = res.data
                if (body.data.existed){
                    this.setInfoStatus("accountExist", "")
                    this.$data.accountCheck = true
                    this.showCodeExplain = true
                    return true
                } else {
                    this.setInfoStatus("accountExist", "ERROR_ACOUNT_NULL")
                    this.showCodeExplain = false
                    return false
                }
            }).catch(err => {
                if (err.response.data){
                    let code = err.response.data.code
                    if (code == 403) {
                        this.setInfoStatus("accountExist", "ERROR_SEND_FREQUENTLY")
                    } else {
                        this.setInfoStatus("accountExist", "ERROR_DETECTION")
                    }
                 }
                this.$data.accountCheck = false
                return false
            })
        },
        sendVerifyCodeError(msg) {
            switch (msg){
                case "ERROR_CONTACT": 
                    this.commonStatus = "ERROR_CONTACT"
                    break
                case "ERROR_SEND_BUSY": 
                    this.commonStatus = "ERROR_SEND_BUSY"
                    break
                case "ERROR_TIMEOUT":
                    this.commonStatus = "ERROR_SEND_TIMEOUT"
                    break
                case "ERROR_FREQUENTLY":
                    this.commonStatus = "ERROR_SEND_FREQUENTLY"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.commonStatus = "ERROR_SEND_AMOUNT_OUT_LIMIT"
                    break
                default:
                    this.commonStatus = "ERROR_SEND_FAILED"
            }
        },
        checkVerifycodeFormat(checkNull = false){ //验证码校验
            let val = this.verifyCode
            if (/^\d{6}$/.test(val)){
                this.verifyCodeCheck = true
                this.setInfoStatus("codeFormat", "")
                return true
            } else if (val === ""){
                if (!checkNull){
                    this.setInfoStatus("codeFormat", "")
                    return true
                } else {
                    this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_ISNULL")
                    this.verifyCodeCheck = false
                    return false
                }
            } else {
                this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                this.verifyCodeCheck = false
                return false
            }
        },
        sendSuccess(data){
            this.isImport = data
            if (isPhone(this.account).result){
                if(this.verifyCodeType === "SMS"){
                    this.commonStatus = "RIGHT_PHONE_VERIFICATION_SEND"
                } else {
                    this.commonStatus = "RIGHT_VOICE_VERIFICATION_SEND"
                }
            } else if (isEmail(this.account).result){
                this.commonStatus = "RIGHT_EMAIL_VERIFICATION_SEND"
            } 
        },
        showModalCodeExplain(){
            this.modalCodeExplain = true
        },
        close(){
            this.modalCodeExplain = false
        },
        async next(){ //下一步
            if (!(await this.checkAccountExist(true)) || !this.checkVerifycodeFormat(true)){
                return 
            }
            this.nexting = true
            opcode_post({
                captcha: this.verifyCode,
                contact: this.account,
                service: this.serviceName
            }).then(res => {
                let body = res.data
                let opcode = body.data.operationCodeInfo.opcode
                this.stage = this.stage + 1
                this.opcode = opcode
                let hash = querystring.stringify({
                    stage: this.stage,
                    account: this.account,
                    captcha: this.verifyCode
                })
                location.hash = hash
                this.$emit("findpasswordsuccess")
            }).catch( err => {
                if (err.response.data){
                    let code = err.response.data.code
                    switch (code) {
                        case 101:
                            this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                            break 
                        case 102:
                            this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                            break 
                    }
                }
            }).then(err => {
                this.nexting = false
            })
        },
        checkPassword(checkNull = false){ //密码校验
            if (!checkNull && this.newpassword === ""){
                this.setInfoStatus("passwordStatus", "")
                return true
            }
            let val = this.newpassword
            let out = isPassword(val)
            switch (out.code){
                case 100: this.setInfoStatus("passwordStatus", "");break
                case 101: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ISNULL");break
                case 201: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_BLANK");break
                case 204: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD-LT");break
                case 205: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD-GT");break
                case 202: this.setInfoStatus("passwordStatus", "ERROR_NOT_ALL_NUMBER");break
                case 203: this.setInfoStatus("passwordStatus", "ERROR_NOT_ALL_CHAR");break
                case 206: this.setInfoStatus("passwordStatus", "ERROR_NOT_ALL_ABC");break
                default: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ISWRONG")
            }
            return out.result
        },
        checkRepassword(checkNull = false){ //确认密码
            let val = this.newpassword,
                preval = this.repassword
            if (val === preval){
                this.setInfoStatus("verifyPasswordStatus", "")
                return true
            } else if (this.repassword === ""){
                if (!checkNull){
                    this.setInfoStatus("verifyPasswordStatus", "")
                    return true
                } else {
                    this.setInfoStatus("verifyPasswordStatus", "ERROR_REPASSWORD_ISNULL")
                    return false
                }
            } else {
                this.setInfoStatus("verifyPasswordStatus", "ERROR_PASSWORD_AFFIRM")
                return false
            }
            this.setInfoStatus("verifyPasswordStatus", "")
            return true
        },
        completePassword(){
            if (!this.checkPassword(true) || 
                !this.checkRepassword(true)){
                return
            }

            this.complating = true
            retrievePassword({
                opcode: this.opcode,
                newPassword: this.newpassword,
                account: this.account
            }).then(_ => {
                this.stage = 2
                let hash = querystring.stringify({
                    stage: this.stage,
                })
                location.hash = hash
                let startTime = Date.now()
                this.countDown = 3
                let intervalHandle = setInterval(_ => {
                    let countDown = 3 - Math.floor((Date.now() - startTime) / 1000)
                    this.countDown = countDown
                    if (countDown <= 0){
                        clearInterval(intervalHandle)
                        sessions_post({
                            accountNumber: this.account,
                            password: this.newpassword,
                            loginType: "WEB"
                        }).then(res => {
                            location.href = "/wesign"
                        }).catch(err => {
                            this.commonStatus = "ERROR_LOGIN"
                            location.href = "/login"
                        })
                    }
                }, 33)
            }).catch(_ => {
                this.setInfoStatus("passwordStatus", "ERROR_RESET_PASSWORD")
            }).then(_ => {
                this.complating = false
            })
        },
        clearInfo(){
            this.commonStatus = ""
        },
        newpasswordView(){
            this.newpasswordStatus = !this.newpasswordStatus
        },
        repasswordView(){
            this.repasswordStatus = !this.repasswordStatus
        }
    },
    components: {
        captchaButton,
        codeExplain
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.info{
    width:80%;
    margin:0 auto;
}
.left{
    display:inline-block;
    flex:1;
    text-align:left
}
.center{
    text-align:center;
    flex:1
}
.right{
    display:inline-block;
    flex:1;
    text-align:right
}
.success{
    font-size:24px;
    text-align:center;
    padding-bottom:25px;
    display:inline-block
}
.public-center{
    text-align:center;
}
.regist-success{
    font-size:@font-size-primary;
}
.view{
    font-size:@font-size-primary;
    display:inline-block;
    cursor:pointer;
}
.eye{
    color:@color-main;
}
.placeholder{
    height:20px;
    padding:15px 0;
}
.right{
    text-align:right
}
.email,.phone{
    margin-right:3px;
}
</style>
