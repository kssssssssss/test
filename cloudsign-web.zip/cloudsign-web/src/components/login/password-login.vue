<template>
    <el-form @keyup.enter.native="login" @submit="login">
        <h1 class="login-type">
            密码登录
            <span class="change-login-type outside-unline" @click="$emit('change-type', 'SMS')">手机验证码登录</span>
        </h1>
        <el-alert class="form-item" v-if="errorInfo" type="error">{{errorInfo}}</el-alert>
        <el-form-item prop="account" :error="accountError">
            <el-input :value="account" @input="$emit('update:account', arguments[0])" placeholder="请输入手机号或邮箱地址" @blur="checkContact"></el-input>
        </el-form-item>
        <el-form-item prop="password" :error="passwordError">
            <el-input label="活动名称" v-model="password" :type="passwordVisiable ? 'text' : 'password'" placeholder="请输入登录密码" @blur="checkPassword">
                <div slot="append" class="view">
                    <i :class="passwordVisiable ? 'icon-eye eye' : 'icon-eye-blocked'" @click="passwordVisiable = !passwordVisiable"></i> 
                </div>
            </el-input>
        </el-form-item>
        <el-row  v-if="showCaptcha">
            <el-col :span="13">
                <el-form-item :error="captchaCodeError">
                    <el-input type="text" size="large" placeholder="请输入图形验证码" v-model.trim="captchaCode" @blur="checkCaptchaCode"/>
                </el-form-item>
            </el-col>
            <el-col :span="8" :offset="3">
                <img class="verify-img" alt="点击刷新验证码" :src="captchaURL" @click="refreshCaptcha"/>
            </el-col>
        </el-row>
        <div class="form-item">
            <label for="_wesign-login-checknum" @click="$emit('update:rememberAccount', !rememberAccount)">
                <el-checkbox :value="rememberAccount" @input="$emit('update:rememberAccount', !rememberAccount)" @click.stop></el-checkbox>&nbsp;记住帐号
            </label>
        </div>
        <div class="form-item">
            <el-button size="large" style="width:100%;" type="primary" :loading="logining" @click.prevent="login">登录</el-button>
        </div>
        <div>
            <a class="outside-unline" target="_self" href="/find-password">忘记密码</a>
            <span class="to-regist">
                <a class="outside-unline" target="_self" href="/register">免费注册</a>
            </span>
        </div>
    </el-form>
</template>

<script>
import { isEmail, isPhone, isPassword } from "@wesign/check"
import { login } from "@interfaces/user/sessions.js"
import objectStorage from "@utils/storage.js"

const SHOW_CAPTCHA_STORAGE_KEY = "SHOW_CAPTCHA_STORAGE"
const REMEMBER_ACCOUNT_STORAGE_KEY = "REMEMBER_ACCOUNT_STORAGE"
const ACCOUNT_STORAGE_KEY = "ACCOUNT_STORAGE"

export default {
    props: {
        account: String, //联系方式
        rememberAccount: Boolean //是否记住密码
    },
    data(){
        let storedShowCaptcha = objectStorage.getItem(SHOW_CAPTCHA_STORAGE_KEY)

        return {
            password: "", //密码
            captchaCode: "", //图型验证码

            errorInfo: "", //登录错误信息
            accountError: "",
            passwordError: "",
            captchaCodeError: "", //登录验证码错误信息
            
            passwordVisiable: false, //密码是否可见

            showCaptcha: storedShowCaptcha ? true : false, //是否展示验证码
            captchaURL: "/api/captcha/image-code?service=LOGIN&flag=1", //验证码地址

            logining: false
        }
    },
    watch: {
        showCaptcha(nv){
            objectStorage.setItem(SHOW_CAPTCHA_STORAGE_KEY, nv)
        },
    },
    methods: {
        checkContact() {
            let account = this.account
            if (account.length === 0){
                this.accountError = "请输入您的帐号"
                return false
            }
            if (!isEmail(account).result && !isPhone(account).result){
                this.accountError = "请输入有效的账户"
                return false
            }
            this.accountError = ""
            return true
        },
        checkPassword(){
            let passwd = this.password
            if (passwd === "") {
                this.passwordError = "请输入登录密码"
                return false
            } else {
                this.passwordError = ""
                return true
            }
        },
        checkCaptchaCode() {
            if (this.showCaptcha === false) return true

            if (this.captchaCode === ""){
                this.captchaCodeError = "请输入图型验证码"
                return false
            } else if (!/^[\da-zA-Z]{4}$/.test(this.captchaCode)) {
                this.captchaCodeError = "请输入有效的验证码"
                return false
            } else {
                this.captchaCodeError = ""
                return true
            }
        },
        login(){
            if (!this.checkContact() || !this.checkPassword() || !this.checkCaptchaCode()) return
            
            this.logining = true
            login({
                accountNumber: this.account,
                password: this.password,
                verificationCode: this.captchaCode,
                loginType: "WEB"
            }).then(res => {
                this.errorInfo = ""
                this.showCaptcha = false
                this.$emit("login-success")
            }).catch(err => {
                if (err.response.data){
                    let code = err.response.data.code
                    switch (code) {
                        case 101:
                            this.errorInfo = "账户或密码错误，请输入正确的账户和密码"
                            break 
                        case 102:
                            this.password = ""
                            this.errorInfo = "账户或密码错误，请输入正确的账户和密码"
                            break
                        case 103:
                            this.showCaptcha = true
                            this.password = ""
                            this.errorInfo = "账户或密码错误，请输入正确的账户和密码"
                            break
                        case 104:
                            this.showCaptcha = true
                            this.captchaCode = ""
                            this.errorInfo = "验证码错误，请输入正确的验证码"
                            break
                        case 105:
                            this.errorInfo = "请求过于频繁，请稍后再试"
                            break
                        default:
                            this.errorInfo = "登录请求失败，请重试"
                    }
                }
                this.refreshCaptcha()
            }).then(_ => {
                this.logining = false
            })
        },
        refreshCaptcha(){
            this.captchaURL = this.captchaURL + "1"
        },
    }
}
</script>


<style lang="less" scoped>
@import "~@styles/variable.less";

.verify-img{
    cursor: pointer;
    box-sizing: border-box;
    line-height: 42px;
    height: 42px;
    min-width: 42px;
    float:right;
    border: 1px solid black;
}

.view{
    font-size:@font-size-primary;
    display:inline-block;
    cursor:pointer
}

.forget-password{
    float:right;
    display:block;
}

.right{
    float: right;
}

.to-regist{
    float: right;
}

.outside-unline{
    cursor: pointer;
    color:@color-main;
    text-decoration:none;
    font-size: @font-size-regular;

    &:hover{
        text-decoration: underline;
    }
}

.form-item{
    margin-bottom: 10px;
}

h1.login-type{
    position: relative;
    font-size: 18px;
    font-weight: 400;

    .change-login-type{
        position: absolute;
        display: inline-block;
        right: 0;
        bottom: 0;
    }
}
</style>
