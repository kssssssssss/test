<template>
    <el-form>
        <h1 class="login-type">
            验证码登录
            <span class="outside-unline change-login-type" @click="$emit('change-type', 'PASSWORD')">帐号密码登录</span>
        </h1>
        <el-alert class="form-item" v-if="errorInfo" type="error">{{errorInfo}}</el-alert>
        <el-alert class="form-item" v-if="successInfo" type="success">{{successInfo}}</el-alert>
        <el-form-item :error="accountError">
            <el-input :value="account" @input="$emit('update:account', arguments[0])" placeholder="请输入手机号" @blur="checkContact"></el-input>
        </el-form-item>
        <el-row>
            <el-col :span="13">
                <el-form-item prop="code" :error="verificationCodeError">
                    <el-input size="large" v-model.trim="verificationCode" :placeholder="codeSended ? '请输入验证码' : '请点击右侧获取验证码'"
                        @blur="checkVerificationCode"/>
                </el-form-item>
            </el-col>
            <el-col :span="10" :offset="1">
                <captchaButton  size="large" style="width:100%" :contact="account" :service="serviceName" :type="verifyCodeType" :disabled="disableSendButton"
                    @error="sendVerifyCodeError" @sendsuccess="sendSuccess"></captchaButton>
            </el-col>
        </el-row>
        <div class="form-item">
            <label for="_wesign-login-checknum" @click="$emit('update:rememberAccount', !rememberAccount)">
                <el-checkbox :value="rememberAccount" @input="$emit('update:rememberAccount', !rememberAccount)" @click.stop></el-checkbox>&nbsp;记住帐号
            </label>
            <span class="right">
                <span v-show="verifyCodeType === 'SMS'" >
                    收不到验证码？
                    <a class="outside-unline icon-phone-volume" @click="verifyCodeType = 'VOICE'">试试语音</a>
                </span>
                <span v-show="verifyCodeType === 'VOICE'" >
                    不方便接听电话？
                    <a class="outside-unline icon-email" @click="verifyCodeType = 'SMS'">试试短信</a>
                </span>
            </span>
        </div>
        <div class="form-item">
            <el-button size="large" style="width:100%;" type="primary" :loading="logining" @click.prevent="login">登录</el-button>
        </div>
        <div>
            <span class="to-regist">
                <a class="outside-unline" target="_self" href="/register">免费注册</a>
            </span>
        </div>
    </el-form>
</template>

<script>
import { isPhone } from "@wesign/check"
import captchaButton from "@components/buttons/captcha-button.vue"
import codeExplain from "@components/modal/code-explain.vue"
import { opcode_post } from "@interfaces/auth/captcha.js"
import { verificationCodeSession } from "@interfaces/user/sessions.js"

import objectStorage from "@utils/storage.js"
const REMEMBER_ACCOUNT_STORAGE_KEY = "REMEMBER_ACCOUNT_STORAGE"

export default {
    props: {
        account: String, //联系方式
        rememberAccount: Boolean //是否记住密码
    },
    data(){
        return {
            verificationCode: "",

            accountError: "",
            verificationCodeError: "",
            successInfo: "", //true
            errorInfo: "",

            codeSended: false, //是否发送了验证码
            passwordVisiable: false,
            
            logining: false,

            verifyCodeType: "SMS", //默认为短信验证码,

            disableSendButton: true, //禁用发送验证码按钮
        }
    },
    watch: {
        account(account){
            this.disableSendButton = !isPhone(account).result
        },
    },
    computed: {
        serviceName(){
            if(this.verifyCodeType === "VOICE"){
                return "VOICE_VERIFICATION_CODE_LOGIN"
            } else {
                return "LOGIN"
            }
        }
    },
    created(){
        this.disableSendButton = !isPhone(this.account).result
    },
    methods: {
        checkContact() {
            let account = this.account
            if (account.length === 0){
                this.accountError = "请输入您的手机号"
                return false
            }
            if (!isPhone(account).result){
                this.accountError = "请输入有效的手机号"
                return false
            }
            this.accountError = ""
            return true
        },
        checkVerificationCode(){
            let verificationCode = this.verificationCode
            if (verificationCode === "") {
                this.verificationCodeError = "请输入接收到的验证码"
                return false
            } else if (!/^\d{6}$/.test(verificationCode)){
                this.verificationCodeError = "请输入有效的六位数字验证码"
                return false
            } else {
                this.verificationCodeError = ""
                return true
            }
        },
        async login(){
            this.checkContact()
            this.checkVerificationCode()
            if (this.accountError || this.verificationCodeError) return

            this.logining = true
            this.clearInfo()
            let opcode = await opcode_post({
                captcha: this.verificationCode,
                contact: this.account,
                service: this.serviceName
            }).then(res => {
                return res.data.data.operationCodeInfo.opcode
            }).catch(err => {
                this.logining = false
                this.errorInfo = "验证码错误"
            })

            if (!opcode) return

            await verificationCodeSession({
                contact: this.account,
                opcode
            }).then(res => {
                this.errorInfo = ""
                this.$emit("login-success")
            }).catch(err => {
                if (err.response.data){
                    let code = err.response.data.code
                    switch (code) {
                        case 101:
                            this.errorInfo = "帐号未注册，请确认后再输入或注册"
                            break 
                        case 102:
                            this.errorInfo = "验证码错误"
                            break
                        case 105:
                            this.errorInfo = "请求过于频繁，请稍后再试"
                            break
                        default:
                            this.errorInfo = "登录失败"
                    }
                }
            }).then(_ => {
                this.logining = false
            })
        },
        sendVerifyCodeError(msg){
            switch (msg){
                case "ERROR_CONTACT": 
                    this.accountError = "请输入有效的手机号"
                    break
                case "ERROR_SEND_BUSY": 
                    this.errorInfo = "发送太频繁，请倒计时结束后再点击"
                    break
                case "ERROR_TIMEOUT":
                    this.errorInfo = "请求发送验证码超时"
                    break
                case "ERROR_FREQUENTLY":
                    this.errorInfo = "请求发送验证码过于频繁"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.errorInfo = "今日可接收验证码已达到上限"
                    break
                default:
                    this.errorInfo = "发送失败"
            }
        },
        sendSuccess(){
            this.clearInfo()
            this.successInfo = "验证码发送成功"
        },
        clearInfo(){
            this.successInfo = ""
            this.errorInfo = ""
        }
    },
    components: {
        captchaButton,
        codeExplain
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.view{
    font-size:@font-size-primary;
    display:inline-block;
    cursor:pointer
}

.forget-password{
    float:right;
    display:block;
}

.to-regist{
    float: right;
}

.right{
    float: right;
}

.outside-unline{
    cursor: pointer;
    color:@color-main;
    text-decoration:none;
    font-size: @font-size-regular;

    &:hover{
        text-decoration: underline;
    }
}

.form-item{
    margin-bottom: 10px;
}

h1.login-type{
    position: relative;
    font-size: 18px;
    font-weight: 400;

    .change-login-type{
        position: absolute;
        display: inline-block;
        right: 0;
        bottom: 0;
    }
}
</style>
