<!--
    @id        page-invite-register
    @desc      邀请注册页面
    @level     page：页面组件
    @author    周雪梅
    @date      2019-08-06 10:27:11
-->
<template>
    <div @input="clearInfo" class="info">
        <div class="wesign-outside-error-box">
            <p v-if="infoText" :class="infoClass">
                <i :class="infoIcon"></i>
                {{infoText}}
            </p>
        </div>
        <div v-if="stage === 0">
            <div class="wesign-outside-form-group">
                <el-input type="text" size="large" placeholder="请输入11位手机号或邮箱地址" v-model.trim="contact" 
                @input="contactCheck = false"></el-input>         
            </div>
            <el-row class="wesign-outside-form-group">
                <el-col :span="13">
                    <el-input size="large" v-model.trim="verifyCode" :disabled="!isImport" :placeholder="!isImport ? '请点击右侧获取验证码' : '请输入验证码'"
                        @input="verifyCodeCheck = false" @blur="checkVerifycodeFormat()"/>
                </el-col>
                <el-col :span="10" :offset="1">
                    <captchaButton size="large" style="width:100%" :disabled="!contactCheck" :contact="contact || ''" service="INVITE_MEMBERS_JOIN_ENTERPRISE"
                        @sending="sending"
                        @error="sendVerifyCodeError" @sendsuccess="sendSuccess" @timeShow="isImport = true" :type="verifyCodeType"></captchaButton>
                </el-col>
            </el-row>
            <div class="wesign-outside-form-group">
                <el-input type="text" class="info-input"  placeholder="请输入真实姓名" v-model.trim="userName" @blur="checkUserName()" 
                    @keyup.enter.native="inviteRegist"></el-input> 
                <el-input type="password" style="display: none;" disabled/>    
            </div>
            <div v-show="showPassword" class="wesign-outside-form-group">
                <el-input size="large" class="info-input" placeholder="设置登录密码(至少6位数字、字母和字符的组合)" :type="passwordStatus ? 'text' : 'password'"
                    v-model.trim="password" @blur="checkPassword()" @keyup.enter.native="inviteRegist">
                       <i slot="append" class="view" :class="passwordStatus ? 'icon-eye eye' : 'icon-eye-blocked'" @click="passwordView()"></i> 
                </el-input>        
            </div>
            <div class="wesign-outside-form-group">
                <el-button size="large" style="width:100%;" type="primary" :loading="inviteRegistLoading" @click="inviteRegist">立即加入</el-button>
            </div>
            <div v-show="showCodeExplain" class="wesign-outside-form-group" style="text-align:right">
                <a @click="showModalCodeExplain">收不到验证码？</a>
            </div>
        </div>
        <div v-if="stage === 1" class="register-success-info">
            <div class="invite-icon">
                <i class="icon el-icon-success wesign-outside-right right"></i>
            </div>
            <p class="tipMsg">您的申请已提交，需等待管理员审核</p>
            <!--<p class="regist-success">{{countDown}}秒后自动跳转到登录页面</p>
            div class="wesign-outside-form-group">
                <el-button class="btn" size="large" style="width:100%;" type="primary" @click="signDownload">下载大家签</el-button>
            </div>-->
            <a class="unline" href="/login">登录大家签查看</a>
        </div>
        <codeExplain @close-modal="close" :msg="codeExplainTitle" :type="codeExplainType" :message="codeExplainMessage" :messages="codeExplainPublicMessage" v-show="modalCodeExplain" @close-dialog="close"></codeExplain>
    </div>
</template>
<script>
import {isPassword, isUserName } from "@wesign/check"
import { isPhone, isEmail } from "@wesign/check"
import { checkAccount } from "@interfaces/user/user.js"
import { opcode_post } from "@interfaces/auth/captcha.js"
import {membersConfirm} from "@interfaces/enterprise/enterprise.js"
import captchaButton from "@components/buttons/captcha-button.vue"
import codeExplain from "@components/modal/code-explain.vue"
import querystring from "querystring"

export default {
    data(){
        return {
            /* ERROR_ACOUNT_ISNULL             请输入手机号或邮箱地址
             * ERROR_ACOUNT                    帐号输入错误
             * ERROR_VERIFICATION_ISNULL       请输入验证码/
             * ERROR_VERIFICATION_CODE_BUSY    验证码获取频繁，今天已无法获取
			 * ERROR_VERIFICATION_CODE		   验证码错误
             * ERROR_CONTACT                   联系人格式错误/
             * ERROR_SEND_BUSY                 发送频繁
             * ERROR_SEND_FAILED               发送失败/
             * ERROR_COMPLETE_INFO_ISNULL      请填写正确的完整信息
             *
             * ERROR_NAME_ISNULL               请输入您的真实姓名
             * ERROR_NAME                      请输入有效的姓名
             * ERROR_PASSWORD_ISNULL           请输入密码     
             * ERROR_PASSWORD-LT               密码长度不能低于6位"
             * ERROR_PASSWORD-GT               密码长度不能超过32位
             * ERROR_NOT_ALL_ABC               密码不能全为字母
             * ERROR_NOT_ALL_NUMBER            密码不能全为数字
             * ERROR_NOT_ALL_CHAR              密码不能全为字符
             * ERROR_PASSWORD_AFFIRM           密码确认错误，请重新输入
             * ERROR_DETECTION                 检测失败/
             * ERROR_REGISTER_FAILED           请求失败，请重试
             *
             * RIGHT_PHONE_VERIFICATION_SEND   验证码已发送，请注意查收短信
             * RIGHT_EMAIL_VERIFICATION_SEND   验证码已发送至指定邮箱，请查收  
             */

            opcode: "",
            contact: "",
            showPassword: false, //判断是否需要输入密码
            password: "",
            userName: "",
            verifyCode: "",
            contactCheck: false, //帐号是否通过检测
            verifyCodeCheck: false, //验证码是否通过检测
            stage: 0,
            invitationWsid: "",
            showCodeExplain: false, //收不到验证码说明
            modalCodeExplain: false,
            passwordStatus: false,

            priorityStatus: [
                {name: "accountStatus", status: ""},
                {name: "accountExist", status: ""},
                {name: "codeFormat", status: ""},
                {name: "userNameStatus", status: ""},
                {name: "passwordStatus", status: ""}
            ],
            commonStatus: "",
            invitationType: "",
            inviteRegistLoading: false,
            isImport: false,
            verifyCodeType: "SMS"
        }

    },
    computed: {
        infoStatus(){
            let status = this.priorityStatus.find(item => {
                if (item.status){
                    return true
                }
            })

            return status && status.status || this.commonStatus
        },
        infoText(){
            let status = this.infoStatus
            switch (status){
                case "ERROR_ACOUNT_ISNULL": return "请输入手机号或邮箱地址";break
                case "ERROR_ACOUNT": return "手机号或邮箱地址错误";break
                case "ERROR_VERIFICATION_ISNULL": return "请输入验证码";break
                case "ERROR_VERIFICATION_CODE": return "验证码错误";break
                case "ERROR_VERIFICATION_CODE_BUSY": return "验证码获取频繁，今天已无法获取" 
                case "ERROR_CONTACT": return "联系人格式错误";break
                case "ERROR_SEND_BUSY": return "发送太频繁，请倒计时结束后再点击";break
                case "ERROR_SEND_FAILED": return "发送失败";break
                case "ERROR_SEND_TIMEOUT": return "发送请求超时";break
                case "ERROR_SEND_FREQUENTLY": return "发送请求过于频繁";break
                case "ERROR_SEND_AMOUNT_OUT_LIMIT": return "今日可接收验证码已达到上限";break
                case "ERROR_NAME_ISNULL": return "请输入您的真实姓名";break
                case "ERROR_NAME": return "请输入有效的姓名";break
                case "ERROR_PASSWORD_ISNULL": return "请设置登录密码";break
                case "ERROR_PASSWORD_BLANK": return "密码不能包含空格";break
                case "ERROR_PASSWORD-LT": return "密码长度不能低于6位";break
                case "ERROR_PASSWORD-GT": return "密码长度不能超过32位";break
                case "ERROR_NOT_ALL_ABC": return "密码不能全为字母";break
                case "ERROR_NOT_ALL_NUMBER": return "密码不能全为数字";break
                case "ERROR_NOT_ALL_CHAR": return "密码不能全为字符";break
                case "ERROR_PASSWORD_ISWRONG": return "密码格式错误";break
                case "ERROR_PASSWORD_AFFIRM": return "密码确认错误，请重新输入";break
                case "ERROR_DETECTION": return "网络不稳定，请稍候再试";break
                case "ERROR_REGISTER_FAILED":return "请求失败，请重试";break
                case "ERROR_HAVE_APPLY":return "您已经申请加入企业，请耐心等待管理员处理";break
                case "ERROR_HAVE_JOINED":return "您已经是该企业成员";break
                case "ERROR_HAVE_JOINED_DISABLEENABLING":return "您已经是该企业成员，当前已被“禁用”，重新启用请联系管理员处理";break
                case "ERROR_NOT_LINK": return "邀请链接已不存在";break
                case "RIGHT_PHONE_VERIFICATION_SEND": return "验证码已发送，请注意查收短信";break
                case "RIGHT_EMAIL_VERIFICATION_SEND": return "验证码已发送至指定邮箱，请查收"
            }
        },
        infoClass(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-errorWarning"
                
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-rightWarning"
            }
        },
        infoIcon(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-error el-icon-error"
                
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-right el-icon-success"
            }
        },
        codeExplainType(){
            let val = this.$data.contact
            if (isPhone(val).result){
                return "PHONE"
            } else if (isEmail(val).result){
                return "EMAIL"
            }
        },
        codeExplainTitle(){
            let val = this.$data.contact
            if (isPhone(val).result){
                return "检查短信是否被屏蔽"
            } else if (isEmail(val).result){
                return "查看是否进入垃圾信息或广告信息"
            }
        },
        codeExplainPublicMessage(){
            let val = this.$data.contact
            if (isPhone(val).result){
                return "检查您的手机号是否正确"
            } else if (isEmail(val).result){
                return "检查您的邮箱号是否正确"
            }
        },
        codeExplainMessage(){
            let val = this.$data.contact
            if (isPhone(val).result){
                return "若2分钟内未收到短信，可重新获取"
            } else if (isEmail(val).result){
                return "若2分钟内未收到邮件，可重新获取"
            }
        }
    },
    watch: {
        contact(oldVal, newVal) {
            if (oldVal.length > 0){
                if (!isEmail(oldVal).result && !isPhone(oldVal).result){
                    return this.contactCheck = false
                } else {
                    if (oldVal !== newVal){
                        return this.checkContactExist()
                    }
                }
            }
        }
    },
    created: function(){	
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.invitationWsid = query.invitationWsid
        this.enterpriseWsid = query.enterpriseWsid
        this.userName = query.invitedName
        this.contact = query.invitedAccount
        this.invitationType = query.type
    },
    methods: {
        sending(){
            this.setInfoStatus("accountStatus", "")
            this.setInfoStatus("accountExist", "")
            this.setInfoStatus("codeFormat", "")
            this.setInfoStatus("userNameStatus", "")
            this.setInfoStatus("passwordStatus", "")
        },
        setInfoStatus(name, status){
            let priorityStatus = this.priorityStatus
            priorityStatus.find((item, index) => {
                if (item.name === name){
                    item.status = status
                    if (status){
                        this.commonStatus = ""
                    }
                    priorityStatus.splice(index, 1)
                    priorityStatus.splice(0, 0, item)
                    return true
                }
            })
        },
        checkContactFormat(checkNull = false) {
            let val = this.$data.contact
            if (val.length === 0){
                if (!checkNull){
                    this.setInfoStatus("accountStatus", "")
                    return true
                } else {
                    this.setInfoStatus("accountStatus", "ERROR_ACOUNT_ISNULL")
                    return false
                }
            }
            
            if (!isEmail(val).result && !isPhone(val).result){
                this.setInfoStatus("accountStatus", "ERROR_ACOUNT")
                return false
            }
            this.setInfoStatus("accountStatus", "")
            return true
        },
        showModalCodeExplain(){
            this.modalCodeExplain = true
        },
        close(){
            this.modalCodeExplain = false
        },
        //帐号校验
        checkContactExist(checkNull = false) {
            if (!this.checkContactFormat(checkNull)){
                return 
            }
            let val = this.$data.contact
            if (!val) return 

            return checkAccount({
                account: val
            }).then(res => {
                let body = res.data
                this.setInfoStatus("accountExist", "")
                if (body.data.existed){
                    this.$data.showPassword = false
                    this.$data.contactCheck = true
                } else {
                    this.$data.contactCheck = true
                    this.$data.showPassword = true
                }
                this.$data.showCodeExplain = true
                return true
            }).catch(err => {
                if (err.response.data){
                    let code = err.response.data.code
                    if (code == 403) {
                        this.setInfoStatus("accountExist", "ERROR_SEND_FREQUENTLY")
                    } else {
                        this.setInfoStatus("accountExist", "ERROR_DETECTION")
                    }
                }
                this.$data.contactCheck = false
                // this.$data.showPassword = true
                return false
            })
        },
        checkVerifycodeFormat(checkNull = false){ //验证码校验
            let val = this.verifyCode
            if (/^\d{6}$/.test(val)){
                this.verifyCodeCheck = true
                this.setInfoStatus("codeFormat", "")
                return true
            } else if (val === ""){
                if (!checkNull){
                    this.setInfoStatus("codeFormat", "")
                    return true
                } else {
                    this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_ISNULL")
                    this.verifyCodeCheck = false
                    return false
                }
            } else {
                this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                this.verifyCodeCheck = false
                return false
            }
        },
        sendVerifyCodeError(msg) {
            switch (msg){
                case "ERROR_CONTACT": 
                    this.commonStatus = "ERROR_CONTACT"
                    break
                case "ERROR_SEND_BUSY": 
                    this.commonStatus = "ERROR_SEND_BUSY"
                    break
                case "ERROR_TIMEOUT":
                    this.commonStatus = "ERROR_SEND_TIMEOUT"
                    break
                case "ERROR_FREQUENTLY":
                    this.commonStatus = "ERROR_SEND_FREQUENTLY"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.commonStatus = "ERROR_SEND_AMOUNT_OUT_LIMIT"
                    break
                default:
                    this.commonStatus = "ERROR_SEND_FAILED"
            }
        },
        sendSuccess(data){
            this.isImport = data
            if (isPhone(this.contact).result){
                this.commonStatus = "RIGHT_PHONE_VERIFICATION_SEND"
            } else if (isEmail(this.contact).result){
                this.commonStatus = "RIGHT_EMAIL_VERIFICATION_SEND"
            } 
        },
        checkUserName(checkNull = false){
            if (!checkNull && this.$data.userName === ""){
                this.setInfoStatus("userNameStatus", "")
                return true
            }
            let val = this.$data.userName
            let out = isUserName(val)
            //中文，字母，数字或其组合的形式
            switch (out.code) {
                case 100: this.setInfoStatus("userNameStatus", "");break
                case 101: this.setInfoStatus("userNameStatus", "ERROR_NAME_ISNULL");break
                default: this.setInfoStatus("userNameStatus", "ERROR_NAME")
            }
            return out.result
        },
        //密码校验
        checkPassword(checkNull = false){
            if (!checkNull && this.$data.password === ""){
                this.setInfoStatus("passwordStatus", "")
                return true
            }
            let val = this.$data.password
            let out = isPassword(val)
            switch (out.code) {
                case 100: this.setInfoStatus("passwordStatus", "");break
                case 101: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ISNULL");break
                case 201: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_BLANK");break
                case 204: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD-LT");break
                case 205: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD-GT");break
                case 202: this.setInfoStatus("passwordStatus", "ERROR_NOT_ALL_NUMBER");break
                case 203: this.setInfoStatus("passwordStatus", "ERROR_NOT_ALL_CHAR");break
                case 206: this.setInfoStatus("passwordStatus", "ERROR_NOT_ALL_ABC");break
                default: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ISWRONG")
            }
            return out.result
        },
        clearInfo(){
            this.commonStatus = ""
        },        
        // signDownload(){
        //     window.location.href = "https://www.signit.cn/appDownload"
        // },
        //邀请注册
        async inviteRegist(){
            if (!await this.checkContactExist(true) || 
                !this.checkVerifycodeFormat(true) || 
                !this.checkUserName(true)){
                return 
            }

            if (this.showPassword && !this.checkPassword(true)){
                return 
            }
            this.inviteRegistLoading = true
            let opcode = await opcode_post({
                captcha: this.verifyCode,
                contact: this.contact,
                service: "INVITE_MEMBERS_JOIN_ENTERPRISE"
            }).then(res => {
                let body = res.data
                this.$data.infoStatus = ""
                let opcode = body.data.operationCodeInfo.opcode
                return opcode
            }).catch(err => {
                this.inviteRegistLoading = false
                if (err.response.data){
                    let code = err.response.data.code
                    switch (code) {
                        case 101:
                            this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                            break 
                        case 102:
                            this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                            break 
                    }
                }
            })
            
            if (opcode != undefined) {
                membersConfirm({
                    enterpriseWsid: this.enterpriseWsid,
                    invitationWsid: this.invitationWsid, //
                    name: this.userName, //用户名
                    account: this.contact, //注册帐号名
                    type: this.invitationType,
                    password: this.password,
                    opcode: opcode
                }).then(data => {
                    this.$data.infoStatus = ""
                    this.stage = 1
                    this.inviteRegistLoading = false
                    // that.$emit('registsuccess')
                }).catch(err => {
                    this.inviteRegistLoading = false
                    if (err.response){
                        let code = err.response.data.code
                        if (code === 101){
                            this.setInfoStatus("codeFormat", "ERROR_REGISTER_FAILED")
                        } else if (code === 102) {
                            this.setInfoStatus("codeFormat", "ERROR_HAVE_APPLY")
                        } else if (code === 103) {
                            this.setInfoStatus("codeFormat", "ERROR_HAVE_JOINED")
                        } else if (code === 104) {
                            this.setInfoStatus("codeFormat", "ERROR_HAVE_JOINED_DISABLEENABLING")
                        } else if (code === 105){
                            this.setInfoStatus("codeFormat", "ERROR_NOT_LINK")
                        } else {
                            this.setInfoStatus("codeFormat", "ERROR_REGISTER_FAILED")
                        }
                    } else {
                        this.setInfoStatus("codeFormat", "ERROR_REGISTER_FAILED")
                    }
                })
            }
        },
        passwordView(){
            this.passwordStatus = !this.passwordStatus
        }
    },
    components: {
        captchaButton,
        codeExplain
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.info{
    width: 80%;
    margin:0 auto;
}
.register-success-info{
    width: 80%;
    margin:0 auto;
    text-align:center;
}
.invite-icon{
	padding-bottom:25px;
}
.tipMsg{
	font-size:@font-size-regular;
    padding-bottom:15px;
}
.btn{
	margin-top:20px; 
}
.right{
	font-size:24px;
    text-align:center;
    display:inline-block
}
.unline{
	font-size:@font-size-regular;
	color:@color-font-regular;
	text-decoration: underline;
}
.view{
    font-size:@font-size-regular;
    display:inline-block;
    cursor:pointer;
}
.eye{
    color:@color-main;
}
.regist-success{
    font-size:@font-size-regular;
    margin:10px 0;
}
</style>