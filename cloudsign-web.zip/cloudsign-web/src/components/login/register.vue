<!--
    @id     sys-register
    @desc   注册组件
    @level  system:系统组件
    @events
        registsuccess    注册成功
    @auther 陈曦源,周雪梅
    @date   2019-07-22 19:53:39
-->
<template lang='html'>
    <el-form>
        <h1 v-if="stage < 2" class="register-title">
            注册帐号
        </h1>
        <el-alert class="form-item" v-if="errorInfo" type="error">{{errorInfo}}</el-alert>
        <el-alert class="form-item" v-if="successInfo" type="success">{{successInfo}}</el-alert>
        <!-- 手机/邮箱验证阶段 -->
        <div v-if="stage === 0">
            <el-form-item prop="contact" :error="contactError">
                <el-input v-model="contact" placeholder="请输入11位手机号或邮箱地址" @blur="checkContactFormat"></el-input>
            </el-form-item>
            <el-row>
                <el-col :span="13">
                    <el-form-item prop="code" :error="verificationCodeError">
                        <el-input size="large" v-model.trim="verificationCode" :placeholder="codeSended ? '请输入验证码' : '请点击右侧获取验证码'"
                            @blur="checkVerificationCodeFormat"/>
                    </el-form-item>
                </el-col>
                <el-col :span="10" :offset="1">
                    <captchaButton  size="large" style="width:100%" :contact="contact" service="REGIST" type="SMS" :disabled="disableSendButton"
                        @error="sendVerifyCodeError" @sendsuccess="sendSuccess"></captchaButton>
                </el-col>
            </el-row>
            <div class="form-item">
                <el-button size="large" style="width:100%;" type="primary" :loading="checking" @click.prevent="registNextStep">下一步</el-button>
            </div>
            <div>
                <span class="to-login">
                    已有帐号，<a class="outside-unline" target="_self" href="/login">立即登录</a>
                </span>
            </div>
        </div>
        <div v-if="stage === 1">
            <el-form-item :error="usernameError">
                <el-input size="large" type="text" v-model.trim="username" auto-complete="name" placeholder="请输入姓名(汉字或字母)" @blur="checkUsernameFormat()"/>  
            </el-form-item>
            <el-form-item :error="passwordError">
                <el-input size="large" :type="passwordVisiable ?  'text': 'password'" v-model.trim="password" 
                    auto-complete="new-password" placeholder="设置登录密码(至少6位数字、字母和字符的组合)" value="" @blur="checkPasswordFormat()"> 
                   <i slot="append" class="view" :class="passwordVisiable ? 'icon-eye-blocked' : 'icon-eye eye' " @click="passwordVisiable = !passwordVisiable"></i>
                </el-input>
            </el-form-item>
            <!-- <div class="form-item">
                <el-checkbox v-model="accpetLayer" label=""><a href="https://www.signit.cn/layer/" target="_blank" class="outside-unline">《大家签服务条款》</a></el-checkbox>
            </div> -->
            <el-form-item>
                <el-button size="large" type="primary" style="width:100%" :loading="registing" @click="regist">立即注册</el-button>
            </el-form-item>
        </div>
        <div v-if="stage === 2">
            <div class="public-center">
                <div>
                    <i class="wesign-outside-right el-icon-success success"></i>
                </div>
                <p class="regist-success">注册成功， {{countDown}}秒后自动登录，或<a href="/login" class="outside-unline">立即前往登录</a></p>
            </div>
        </div>
    </el-form>
</template>
<script>
import qs from "qs"
import { isPhone, isEmail, isPassword, isUserName} from "@wesign/check"
import captchaButton from "@components/buttons/captcha-button.vue"
import { usersRegist, checkAccount } from "@interfaces/user/user.js"
import { opcode_post } from "@interfaces/auth/captcha.js"

export default {
    data(){
        return {
            //流程
            stage: -1,
            
            //step0===============================
            contact: "", //联系方式
            contactError: "", //联系方式错误
            verificationCode: "", //验证码
            verificationCodeError: "", //验证码错误信息
            disableSendButton: true, //禁用发送验证码按钮
            codeSended: false, //已经发送验证码
            checking: false, //检测中
            opcode: "", //注册操作码

            //step1===============================
            username: "", //联系方式
            usernameError: "", //联系方式错误信息
            password: "", //账户密码
            passwordError: "", //账户密码错误信息
            passwordVisiable: false, //账户密码是否可见
            accpetLayer: false, //接受条款
            layerError: "", //接受条款的情况
            registing: false, //注册中

            //step2===============================
            countDown: 0, //注册完成后倒计时

            errorInfo: "", //注册的错误信息
            successInfo: "", //成功的相关信息
        }
    },
    watch: {
        contact(oldVal, newVal) {
            this.disableSendButton = true
            if (isEmail(oldVal).result || isPhone(oldVal).result){
                this.checkContactExist()
            }
        },
        // accpetLayer(){
        //     this.layerError = ""
        // }
    },
    created(){
        let query = qs.parse(location.search.slice(1))
        switch (parseInt(query.stage)){
            case 0:
                break
            case 1:
                this.contact = query.contact
                opcode_post({
                    contact: query.contact,
                    captcha: query.captcha,
                    service: "REGIST"
                }).then(res => {
                    let opcode = res.data.data.operationCodeInfo.opcode
                    this.stage = 1
                    this.verificationCode = query.captcha
                    this.opcode = opcode
                }).catch(err => {
                    console.error(err)
                    this.stage = 0
                })
                break
            case 2:
                this.stage = 2
                this.countDown = 5
                let endTime = Date.now() + this.countDown * 1000
                let intervalHandle = setInterval(_ => {
                    let countDown = Math.ceil((endTime - Date.now()) / 1000)
                    this.countDown = countDown
                    if (countDown <= 0){
                        clearInterval(intervalHandle)
                        location.href = "/wesign"
                    }
                }, 33)
                break
            default:
                this.stage = 0
        }
    },
    methods: {
        //检测帐号格式
        checkContactFormat() {
            let val = this.contact

            if (val.length === 0){
                this.contactError = "请输入手机号或邮箱地址"
                return false
            }

            if (!isEmail(val).result && !isPhone(val).result){
                this.contactError = "手机号或邮箱地址格式错误"
                return false
            }

            this.contactError = ""
            return true
        },
        //检测帐号是否存在
        checkContactExist() {
            if (!this.checkContactFormat()){
                return
            }
            let val = this.contact
            return checkAccount({
                account: val
            }).then(res => {
                let body = res.data
                if (body.data.existed){
                    this.contactError = "该帐号已注册,请前往登录"
                } else {
                    this.contactError = ""
                    this.disableSendButton = false
                }
            }).catch(err => {
                if (err.response.data){
                    let code = err.response.data.code
                    if (code == 403) {
                        this.contactError = "帐号检测请求过于频繁"
                    } else {
                        this.contactError = "帐号检测请求失败"
                    }
                }
            })
        },
        checkVerificationCodeFormat(){
            let verificationCode = this.verificationCode
            if (verificationCode === "") {
                this.verificationCodeError = "请输入接收到的验证码"
                return false
            } else if (!/^\d{6}$/.test(verificationCode)){
                this.verificationCodeError = "请输入有效的六位数字验证码"
                return false
            } else {
                this.verificationCodeError = ""
                return true
            }
        },
        sendVerifyCodeError(msg){
            switch (msg){
                case "ERROR_CONTACT": 
                    this.contactError = "请输入有效的手机号"
                    break
                case "ERROR_SEND_BUSY": 
                    this.errorInfo = "发送太频繁，请倒计时结束后再点击"
                    break
                case "ERROR_TIMEOUT":
                    this.errorInfo = "请求发送验证码超时"
                    break
                case "ERROR_FREQUENTLY":
                    this.errorInfo = "请求发送验证码过于频繁"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.errorInfo = "今日可接收验证码已达到上限"
                    break
                default:
                    this.errorInfo = "发送失败"
            }
        },
        sendSuccess(){
            this.clearInfo()
            this.successInfo = "验证码发送成功"
        },
        clearInfo(){
            this.successInfo = ""
            this.errorInfo = ""
        },
        registNextStep(){ //尝试进入下一步
            if (!this.checkContactFormat() || !this.checkVerificationCodeFormat()) return
            this.clearInfo()
            this.checking = true
            opcode_post({
                captcha: this.verificationCode,
                contact: this.contact,
                service: "REGIST"
            }).then(res => {
                let body = res.data
                let opcode = body.data.operationCodeInfo.opcode
                this.stage = this.stage + 1
                let query = qs.stringify({
                    stage: this.stage,
                    contact: this.contact,
                    captcha: this.verificationCode
                })
                history.pushState(null, query, `?${query}`)
                this.opcode = opcode
            }).catch(err => {
                console.error(err)
                if (err.response){
                    this.errorInfo = "验证码错误"
                } else {
                    this.errorInfo = "验证码校验请求失败"
                }
            }).then(_ => {
                this.checking = false
            })            
        },
        //用户名校验
        checkUsernameFormat(){
            let val = this.username
            //中文，字母，数字或其组合的形式
            let out = isUserName(val)
            switch (out.code) {
                case 100: this.usernameError = "";break
                case 101: this.usernameError = "请输入您的姓名";break
                default: this.usernameError = "请输入有效的姓名"
            }
            return out.result
        },
        checkPasswordFormat(){ //密码校验
            let val = this.password
            let out = isPassword(val)
            switch (out.code){
                case 100: this.passwordError = "";break
                case 101: this.passwordError = "请初始化登录密码";break
                case 201: this.passwordError = "密码不能包含空格";break
                case 204: this.passwordError = "密码长度不能低于6位";break
                case 205: this.passwordError = "密码长度不能超过32位";break
                case 202: this.passwordError = "密码不能全为数字";break
                case 203: this.passwordError = "密码不能全为字符";break
                case 206: this.passwordError = "密码不能全为字母";break
                default: this.passwordError = "密码格式错误"
            }
            return out.result
        },
        // chechAcceptLayer(){
        //     if (!this.accpetLayer){
        //         this.layerError = "请勾选同意协议"
        //         return false
        //     } else {
        //         this.layerError = ""
        //         return true
        //     }
        // },
        regist(){ //注册
            this.checkUsernameFormat()
            this.checkPasswordFormat()
            // this.chechAcceptLayer()
            if (this.usernameError
                || this.passwordError){
                return 
            }

            this.clearInfo()
            this.registing = true
            usersRegist({
                account: this.contact, //联系方式
                password: this.password, //密码
                nickname: this.username, //用户名
                loginNow: true,
                registFrom: "WEB", //来源  当然是默认WEB啦~~~
                opcode: this.opcode //操作码
            }).then(body => {
                //百度注册来源统计回调
                window._agl&&window._agl.push(['track',['success',{t:3}]]); 

                this.stage = this.stage + 1
                let query = qs.stringify({
                    stage: this.stage,
                })
                history.pushState(null, query, `?${query}`)
                this.countDown = 5
                let endTime = Date.now() + this.countDown * 1000
                let intervalHandle = setInterval(_ => {
                    let countDown = Math.ceil((endTime - Date.now()) / 1000)
                    this.countDown = countDown
                    if (countDown <= 0){
                        clearInterval(intervalHandle)
                        location.href = "/wesign"
                    }
                }, 33)
            }).catch(err => {
                console.error(err)
                this.errorInfo = "注册失败"
            }).then(_ => {
                this.registing = false
            })
        },
    },
    components: {
        captchaButton,
    }
}

</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

h1.register-title{
    position: relative;
    font-size: 18px;
    font-weight: 400;
}

.form-item{
    margin-bottom: 10px;
}

.to-login{
    float: right;
}

.outside-unline{
    cursor: pointer;
    color:@color-main;
    text-decoration:none;

    &:hover{
        text-decoration: underline;
    }
}

.success{
    text-align:center;
	font-size:24px;
    padding-bottom:25px;
    display:inline-block;
    color: @color-success;
    font-size: 50px;
}

.regist-success{
    font-size:@font-size-primary;
}

.public-center{
    text-align:center;
}

.view{
    font-size:@font-size-primary;
    display:inline-block;
    cursor:pointer
}

.eye{
    color:@color-main;
}
</style>
