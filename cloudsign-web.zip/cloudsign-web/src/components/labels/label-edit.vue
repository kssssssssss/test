<template lang="html">
    <el-dialog v-model="showing" title="编辑" size="tiny" @close="cancle">
        <el-row>
            <el-input placeholder="请输入名称" v-model="name">
                <template slot="prepend">标签名称 :</template>
            </el-input>
        </el-row>
        <el-row>
            <el-input placeholder="请选择下列颜色或输入颜色代码(16进制）" v-model="color">
                <template slot="prepend">标签颜色 :</template>
                <template slot="append">
                    <span class="label-color-preview" :style="{backgroundColor:color}"></span>
                </template>
            </el-input>
        </el-row>
        <el-row class="label-defaul-colors-container">
            <span v-for="dcolor in colorList" class="label-defaul-color"
                :class="{
                    active:dcolor === color
                }"
                :style="{backgroundColor:dcolor}"
                @click="chooseColor(dcolor)"
                ></span>
        </el-row>
        <el-row style="text-align:right">
            <el-button @click="cancle">取消</el-button>
            <el-button @click="submit" type="primary">确定</el-button>
        </el-row>
    </el-dialog>
</template>

<script>
export default {
    props:{
        labelData:{
            type:Object
        }
    },
    data(){
        return {
            name:"",
            color:"#000000",
            showing:true,
            colorList:[
                '#ff6701',
                '#095db1',
                '#f87968',
                '#ff1800',
                '#616263',
                '#738ffe',
                '#54c1ff',
                '#c154ff',
                '#2fcf58',
                '#3d4ff5',
                '#f6b938',
                '#fe5494',
                '#21dcbb',
                '#45bf79'
            ]
        }
    },
    created(){
        if(this.labelData){
            this.name = this.labelData.labelName || "";
            this.color = this.labelData.labelColor || "";
        }
    },
    methods:{
        chooseColor(color){
            this.color = color;
        },
        cancle(){
            this.$emit('close');
        },
        submit(){
            this.name = this.name.trim();
            this.color = this.color.trim();
            if(!this.name){
                this.$message({
                    showClose: true,
                    message: '标签名称不能为空！',
                    type: 'warning'
                });
                return;
            }

            if(!/^#[\da-f]{6}$/i.test(this.color)){
                this.$message({
                    showClose: true,
                    message: '标签颜色格式错误！',
                    type: 'warning'
                });
                return;
            }

            this.$emit('success',this.name,this.color);
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.el-row{
    margin: 10px 0;
}

.label-color-preview{
    display: inline-block;
    width: 20px;
    height: 20px;
}

.label-defaul-colors-container{
    padding: 20px 10px;
}

.label-defaul-color{
    display: inline-block;
    cursor: pointer;
    width: 25px;
    height: 25px;
    background-color: #000000;
    margin: 15px;
    transition: border-radius .3s;
}

.label-defaul-color.active{
    border-radius: 13px;
}


</style>
