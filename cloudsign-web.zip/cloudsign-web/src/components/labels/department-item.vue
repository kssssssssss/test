<!--
    @id        ui-department-iten
    @desc      部门设置
    @level     UI组件
    @author    周雪梅
    @date      2019-01-05 18:47:48
-->
<template lang="html">
    <li class="department-item" @click="change">
        <el-popover
            ref="popover"
            placement="right-start"
            width="90"
            popper-class="wesign-popper-tree-list"
            v-model="popoverVisible"
            trigger="click">
            <ul style="text-align:left">
            <li>
                <span @click.stop="nodeAddSubdivision(node, data, store)" v-if="permission.DEPARTMENT_CREATE">添加子部门</span>
            </li>
            <hr>
            <li>
                <span @click.stop="nodeEditDepartment(node, data, store)" v-if="permission.DEPARTMENT_UPDATE">重命名</span>
            </li>
            <hr>
            <li>
                <span @click.stop="nodeDelDepartment(node, data, store)" v-if="permission.DEPARTMENT_DELETE">删除</span>
            </li>
            <hr>
            <li>
                <span @click.stop="nodeAddMDepartmentMember(node, data, store)">邀请成员加入</span>
            </li>
            </ul>
        </el-popover>
        <el-input v-focus autofocus class="edit" size="small"
            v-show="data.isEdit"
            v-model="data.name"
            :ref="'treeInput' + data.name"
            @keyup.enter.native="$event.target.blur"
            @blur.stop="nodeEditPassDepartment(node, data, store)">
        </el-input>
        <span style="width:100%;display:inline;" v-show="!data.isEdit">{{data.name}}</span>
        <i class="icon icon-list2 label-operation" v-popover:popover v-if="hasPerimission" @click.stop="change"></i>
    </li>
</template>
<script>

export default {
    props: ["node", "data", "store"],
    directives: {
        focus: {
            // 当绑定元素插入到 DOM 中。
            inserted: function (el) {
                // 聚焦元素
                el.focus()
            }
        }
    },
    data(){
        return {
            popoverVisible: false,
        }
    },
    computed: {
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        enterpriseAuthorWsid(){ //企业拥有者id
            return (this.$store.getters.enterpriseAuthorWsid)
        },
        permission(){
            return this.$store.getters
        },
        hasPerimission(){
            return this.permission.DEPARTMENT_CREATE && this.permission.DEPARTMENT_DELETE && this.permission.DEPARTMENT_UPDATE
        }
    },
    mounted(){
        let name = this.data.name
        if (this.data.isEdit) {
            this.$refs["treeInput" + name].focus()
        }
    },
    methods: {
        nodeCreateDepartment(node, data, store){
            this.popoverVisible = false
            this.$emit("nodeEditPassDepartment", node, data, store)
        },
        //添加子部门
        nodeAddSubdivision(node, data, store){
            this.$emit("nodeAddSubdivision", node, data, store)
            this.popoverVisible = false
        },
        //重命名部门名称
        nodeEditDepartment(node, data, store){
            data.isEdit = true
            this.$nextTick(() => {
                this.$refs["treeInput" + data.name].focus()
            })
            this.$emit("nodeEditDepartment", node, data, store)
            this.popoverVisible = false
        },
        //添加企业部门下的成员
        nodeAddMDepartmentMember(node, data, store){
            this.popoverVisible = false
            this.$emit("nodeAddMDepartmentMember", node, data, store)
        },
        // 删除部门
        nodeDelDepartment(node, data, store){
            this.$emit("nodeDelDepartment", node, data, store, this.popoverVisible = false)
        },
        //编辑/重命名名称完成
        nodeEditPassDepartment(node, data, store, event){
            this.popoverVisible = false
            if (data.name === ""){
                this.$message.warning("部门名称不能为空")
                return false
            }
            data.isEdit = false
            this.$emit("nodeEditPassDepartment", node, data, store)
        },
        change(){
            document.body.click()
        },
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

ul{
    margin:0;
    padding:0;
}
.label-container{
    height:36px;
    line-height:36px;
}
.department-item{
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  display:inline-block;
  line-height:36px;
  text-indent:5px;
  width:85%;
  cursor:pointer;
  padding-right: 10px;
  box-sizing: border-box;
}


// .merber-itme .active,
// .department-item:hover{
  
//   background-color:@color-list-choose;

//   &:hover .label-operation{
//       display: inline-block;
//   }
// }
input {
  
    border:0;
}

.el-tree-node__content .active,
.el-tree-node__content:hover {
    background-color:@color-list-choose;
    .label-operation{
        display: inline-block;
    }
}
.label-operation{
    position: absolute;
    right: 0px;
    line-height: 36px;
    display: none;
    width: 30px;
    text-align: center;
}

.label-operation:active{
    color: @color-add
}


</style>
<style lang="less">

.department-item .el-input{
    width:85%;
}
.department-item .el-input__inner{
    padding:0;
    text-indent:5px;
}
.wesign-popper-tree-list{
    min-width:50px !important;
}
.el-tree{
    background:#fafafa !important;
}
.wesign-popper-tree-list li:hover{
    cursor:pointer !important;
}
</style>