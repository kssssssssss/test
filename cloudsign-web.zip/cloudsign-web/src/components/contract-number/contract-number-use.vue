<template>
    <div style="display:inline-block">
        <!-- 使用规则 -->
        <div v-if="contractNumberStutas==='ENABLE' && ruleFrom==='SYSTEM_FIXED'" class="contract-number-use-block">
            <el-select :value="contractNumberData" @change="select"
                placeholder="请选择或输入检索条件" popper-class="select-style" class="input" filterable >
                <el-option
                v-for="item in enableLists"
                :key="item.ruleWsid"
                :label="item.content"
                :value="item.content">
                <div class="main">
                    <p class="content">{{item.content}}</p>
                    <p class="description">{{item.description}}</p>
                </div>
                <span class="example"> 示例：{{ item.example }}</span>
                </el-option>
            </el-select>
        </div>
        <!-- 自定义 -->
        <div class="contract-number-use-block" v-else>
            <el-input class="input wesign-input" 
                :class="{error:ruleError}" 
                :value="contractNumberData"
                @input="$emit('update:contractNumberData', arguments[0])"
                placeholder="请输入合同编号" 
                maxlength="51"
                @blur="checkRule"
                @focus="error=''">
            </el-input>
            <span class="input-warning">{{ruleError}}</span>
        </div> 
    </div>
</template>
<script>
import {searchRulesList, getEnableRuleLists} from "@interfaces/enterprise/contract-number-rules.js"
import { formatDate } from "@commons/util.js"
export default {
    props: {
        envelopeId: String,
        contractNumberData: String,
        ruleFrom: String,
        contractNumberStutas: String,
    },
    data(){
        return {
            ruleError: "",
            enableLists: [],
            enterpriseWsid: this.$store.getters.enterpriseWsid,
        }
    },
    created(){
        if (this.contractNumberStutas === "ENABLE"){
            this.getEnableRuleLists(this.contractNumberData)
        }
    },
    watch: {
        ruleFrom(nv){
            if (nv === "SYSTEM_FIXED" && this.contractNumberData === ""){
                this.$emit("update:contractNumberData", this.enableLists[0].content)
                this.select(this.enableLists[0].content)
            }
        }
    },
    methods: {
        getEnableRuleLists(searchValue){
            let keyword = searchValue || "YY"
            searchRulesList({
                enterpriseWsid: this.enterpriseWsid,
                keyword,
                limit: 100,
                offset: 0
            }).then(res => {
                this.enableLists = res.data.data.contractNumberRules.map(el => {
                    let rule = el.rule
                    let example = ""
                    let content = ""
                    rule.ruleElements.forEach((el, index) => {
                        if (el.type === "DATE") {
                            example = example + formatDate(new Date(), el.pattern)
                            content = example
                        } else if (el.type === "SERIAL_NUMBER"){
                            let arr = el.pattern.split("")
                            arr.splice(-2, 2, "XX")
                            content = content + arr.join("")
                            example = example + el.pattern
                        } else {
                            example = example + el.pattern
                            content = content + el.pattern
                        }
                    })

                    return {
                        content: rule.content,
                        ruleWsid: el.ruleWsid,
                        description: rule.description || "无",
                        example: example,
                    }
                })
            })
        },
        checkRule(){
            if (this.ruleFrom === "SYSTEM_FIXED") return true
            let reg = /^[A-Za-z0-9]+(-[A-Za-z0-9]+)*$/ig
            this.contractNumberData = this.contractNumberData.trim()
            if (this.contractNumberData && !reg.test(this.contractNumberData)){
                this.ruleError = "格式有误"
                return false
            } else if (this.contractNumberData && this.contractNumberData.length > 50){
                this.ruleError = "长度不能长于50个字符"
                return false
            } else {
                this.ruleError = ""
                return true
            }
        },
        select(contractNumberData){
            let ruleWsid = this.enableLists.find(el => el.content === contractNumberData).ruleWsid
            this.$emit("selectRule", {
                contractNumberData,
                ruleWsid
            })
        },
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.input{
    width: 300px;
}
.contract-number-use-block{
    margin-bottom: 5px;
    display: inline-block;

}
.search-input{
    width: 98% !important;
    text-align: center;
    left: 1% !important;
    margin-bottom: 10px;
    padding: 0;
}

.input-warning{
    color: @color-danger;
    font-size: @font-size-regular;
    line-height: 20px;
}
.out-line{
    font-size: @font-size-regular;
    line-height: 20px;
    margin-left: 10px;
    border-bottom: 1px solid;
    cursor: pointer;
}
.main{
    float: left;
    width:200px;
    margin-right: 20px;
}
.content{
    color: #333;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
}
.description{
    color: #8492a6; 
    font-size: @font-size-info;
}
.example{
    float: right; 
    color: #8492a6; 
    font-size: @font-size-info;
}
.select-style .el-select-dropdown__item{
    height: 50px !important;
    line-height: 23px !important;
    display: flex;
    &.hover{
        background: #eaeaea;
        
    }
}
</style>





