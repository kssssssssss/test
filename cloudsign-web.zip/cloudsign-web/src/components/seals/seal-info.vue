<template>

    <div class="user-info">
        <div class="seal-title">
            <span>签章使用记录</span>
            <a class="close" @click='close()'><i class="icon-no"></i></a>
        </div>
        <div class="seal-list">
            <div class="seal-list-con">
                <div class='seal-list-info' v-for="n in envelopeid.user"> 
                    <p><a class="user-title" href="#">{{n.title}}</a></p>
                    <ul>
                        <li><span>使用者：<em>{{n.name}}</em></span></li>
                        <li><span>时间：<em><format-date :date='n.date'  format='yyyy-mm-dd hh:mm:ss' mode='1'></format-date></em></span></li>
                    </ul> 
                </div>
            </div>
        </div>
         <pagination :nowPage = 'nowPage'
                :maxPage='maxPage' @changePage='changePage' @nextOrlast='changePage'></pagination>
    </div>
</template>
<script>
import pagination from '@components/commons/pagination.vue'
import newFormatDate from '@components/commons/format-date.vue'
    export default{
        props:{
            envelopeid:{
                type:String,
                required:true
            },
           items:[
               
           ]
          
           
        },
        data(){
            return {
            nowPage:1,
            maxPage:5,
              
            }
        },
        created:function(){
           
        },
        components:{pagination,formatDate},
        methods:{
            close:function(){
                this.$emit('close');
            },
        }
    }
</script>
<style scoped>
.user-info{
    width: 440px;
    height:100%;
    border: 1px solid #e3e8ee;
    position: absolute;
    background: #fff;
    right: 0;
    bottom: 0;
    top: 0;
    
    box-shadow: -1px 0 5px #e3e8ee;
    z-index:12
}
.seal-title{
    border-bottom:1px solid #e3e8ee;
    line-height:50px;
}
.seal-title span{
    padding-left:20px;
}
.seal-title .close{
    position:absolute;
    right:15px;
}
.pagination{
    width:100%;
    text-align: center;
    position: absolute;
    bottom: 0;
    right: 0;
    background: #eff2f5;
    height: 60px;
    line-height: 60px;
}
.seal-list{
    padding-left:15px;
    padding-right:15px;
    height:100%;
    margin-bottom:100px;
    overflow-y:auto;
}
.seal-list-info{
    padding:15px 0;
    border-bottom:1px solid #e3e8ee;
}
.seal-list-info p{
    padding-bottom:10px;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.seal-list-info a:hover{
    cursor:pointer;
    color:#095db1;
    text-decoration:underline
}
.seal-list-info li{
    display:inline-block;
    margin-right:30px;
  
}
.seal-list-con{
    padding-bottom:120px;
}
 em{
    font-style: normal;
    color:@color-subtitle;
    font-size:@font-size-regular;
    
}
</style>