<template>
    <ul class="list-container">
        <router-link v-for="(target,index) in list" 
            class="list-group" 
            active-class="list-group-item-active"
            tag="li"
            :key="index"
            :to="target.to"
            :exact="target.exact">
            <a class="list-group-item">
                <i class="icon" :class="'icon-' + target.icon"></i>
                <span class="list-group-item-cont">{{target.title}}</span>
            </a>
        </router-link>
    </ul>
</template>

<script>
    export default {
        props: {
            list: {
                type: Array,
                required: true
            }
        },
    }
</script>

<style scoped>
	.list-container{
		width: 100%;
		margin: auto;
		text-align: left;
	}
	.list-container li{
		margin-top: 0;
		font-size: 1em;
	}

	.list-group .list-group-item{
        display: inline-block;
        width: 100%;
        line-height: 60px;
        text-decoration: none;
        color: #1e1e1e;
        box-sizing: border-box;
        font-size:16px;
	}
	
	.list-group-item .icon{
		margin-left:45px;
	}

    .list-group-item-active,
    .list-group:hover{
        border-left: 3px #095db1 solid;
        background-color: #f0f3f5;
    }
</style>