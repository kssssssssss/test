<!-- 列表组件 -->
<template>
    <ul class="list-container">
        <li v-for="value,key in listItems" class="list-group" >
            <a :href="value" :class="{'list-group-item-active':key===listActive}" class="list-group-item" @click='changeActive($event)'>
                <span class="list-group-item-cont">{{key}}</span>
            </a>
        </li>
    </ul>
</template>

<script>
    export default{
        props: ['listActive'],
        data: function(){
            return {
                listItems: {
                }
            }
        },
        methods: {
            changeActive: function(event){
                let e = event || window.event
                this.listActive = e.target.parentNode.querySelector('.list-group-item-cont').innerHTML
            }
        }
    }
</script>

<style scoped>
	.list-container{
		width: 100%;
		margin: auto;
		text-align: left;
	}
	.list-container li{
		margin-top: 0;
		font-size: 1em;
	}
	.list-group .list-group-item{
		display: inline-block;
		width: 100%;
		line-height: 60px;
		text-decoration: none;
		color: #1e1e1e;
		border-left: 3px solid #fff;
		box-sizing: border-box;
		font-size:16px;
	}
	.list-group .list-group-item-active,
	.list-group a:hover{
		border-left: 3px #095db1 solid;
		background-color: #f0f3f5;
	}
	.list-group-item .icon{
		margin-left:45px;
	}
</style>