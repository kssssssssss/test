<!-- 我的中心左边列表组件 -->
<template>
	<div class="list-container">
		<ul>
			<li v-for="value,key,index in listItems" class="list-group" >
				<router-link :to="value" :class="{'list-group-item-active':index===listActive}" class="list-group-item">
					<i class="icon" :class='iconList[index]'></i>
					<span class="list-group-item-cont">{{key}}</span>
				</router-link>
			</li>
		</ul>
	</div>
</template>

<script>
	import list from './list.vue'
	export default{
	    extends: list,
	    data(){
	        return {
				
	            listItems: {
	                '帐号设置': '/user/info',
	                '印章管理': '/user/info/seals/seal-admin',
	                '我的证书': '/user/info/certificates',
	                '消费记录': '/user/info/payments/bill-records',
	                '升级': '/user/info/upgrade',
	                '成员管理': '/user/info/members/list',
	                '角色管理': '/user/info/roles',
	                '通讯录': '/user/info/personal-contacts',
	                '开放API': '/user/info/open-api',
	                '企业升级': '/user/info/org-upgrade',
	                '文件中心': '/user/info/files'
	            },
	            iconList: ['icon-user', 'icon-signature', 'icon-verified-user',
						  'icon-finance', 'icon-upgrade', 'icon-member',
						  'icon-role', 'icon-contact', 'icon-api', 'icon-upgrade', 'icon-document'
	            ]
	        }
	    },
		
		
	}
</script>
