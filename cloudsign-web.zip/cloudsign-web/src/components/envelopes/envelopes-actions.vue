<template>
     <div class="envelope-actions" @click.stop>
        <div v-if="actionConfig.editable" class="action" @click="$emit('editEnvelope')"><i class="color-black icon-sign"></i>编辑</div>
        <div v-if="actionConfig.canpreview" class="action" @click="$emit('preview')"><i class="color-black icon-view"></i>预览</div>
        <el-popover
            ref="popover"
            placement="right-start"
            width="80"
            popper-class="wesign-envelopes-list-item-popper-class"
            :value="popoverVisible"
            trigger="click">
            <ul style="text-align:left">
                <li>
                    <span @click="$emit('downloadDocument','false')">文件</span>
                </li>
                <hr>
                <li>
                    <span @click="$emit('downloadDocumentAudit')">出证</span>
                </li>
                <hr>
                <li>
                    <span @click="$emit('downloadDocument','true')">出证+文件</span>
                </li>
            </ul>
        </el-popover>
        <div v-if="actionConfig.copy && !multisendNum" class="action" @click="$emit('copy')"><i class="color-black icon-copy"></i>复制</div>
        <div v-if="actionConfig.downloadable" class="action" v-popover:popover @click="popover"><i class="color-black icon-download"></i>下载</div>
        <div v-if="actionConfig.canremind" class="action" @click="$emit('toNotify')"><i class="color-black icon-clock-warn"></i>催签</div>
        <div v-if="actionConfig.revokeable && envelopeFlowType!=='CANCEL_PROCESS'" class="action" @click="$emit('revoke')"><i class="color-black icon-revoke"></i>撤销</div>
        <div v-if="actionConfig.transferable&& userEdition==='e'" class="action" @click="$emit('transfer')"><i class="color-black el-icon-refresh"></i>转签</div>
        <div v-if="actionConfig.refusable" class="action" @click="$emit('reject')"><i class="color-black el-icon-circle-close"></i><span v-if="envelopeFlowType!=='CANCEL_PROCESS'">拒签</span><span v-else>拒绝作废</span></div>
        <div v-if="actionConfig.cannotpass" class="action" @click="$emit('notpass')"><i class="color-black icon-refuse"></i>拒审</div>
        <div v-if="actionConfig.deleteable" class="action" @click="$emit('delete')"><i class="color-black icon-delete"></i>删除</div>
        <div v-if="actionConfig.cancelAble && envelopeStatus!=='INVALIDATE' && envelopeFlowType!=='CANCEL_PROCESS'" class="action" @click="$emit('cancel')"><i class="color-black icon-file-cancel"></i>作废</div>
    </div>
</template>

<script>
import { EnvelopeStatus} from "@classes/envelopes/envelopes.js"
export default {
    props:{
        multisendNum:{
        },
        popoverVisible:{
        },
        downloadDocument:{
            type: Function,
            default: null
        },
        actionConfig:{
            type: Object,
            default: null
        },
        envelopeStatus:String,
        envelopeFlowType:String
    },
    computed:{
        userEdition(){
            return this.$store.getters.userEdition
        },
    },
    methods: {
        popover(){
            document.body.click()
        }
    },
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
@line-height:40px;
@line-padding:15px;
.envelope-actions{
    display: flex;
    margin-left: 50%;
    text-align: left;
    flex-wrap: wrap;
    .action, .more-actions{
        cursor: pointer;
        margin-right: 20px;
    }

    i{
        vertical-align: middle;
        margin-right: 5px;
        font-size: 16px;
    }
    .lg-devices({
        line-height: @line-height;
        width:350px;
        margin-left: 0;
    });
}
</style>