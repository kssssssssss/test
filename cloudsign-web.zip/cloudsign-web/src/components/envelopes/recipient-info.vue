<template lang="html">
  <div class="recipientInfo">
    <template v-if="orderstate">
      <span class="sortHandle iconImg" style="display: inline-block;" @mousedown="orderDrag($event)"></span>
      <input class="orderDisplay" type="text" readonly="readonly" :value="recipientdata.sequence">
    </template>
    <input type="text"
            class="recipientInput"
            placeholder="姓名（必填）"
            :disabled="infoDisable"
            :value="recipientdata.name"
            @input='editData("name",$event.currentTarget.value)'>
    <input type="text"
            class="recipientInput"
            placeholder="邮箱（必填）"
            :disabled="infoDisable"
            :value="recipientdata.contact"
            @input='editData("contact",$event.currentTarget.value)'>
    <select class="recipientType"
            v-model="recipientdata.recipientType"
            :style="selectWidth"
            :disabled="typeDisable">

      <option value="0" v-show="typeoptions.hasOwnProperty(0)">签名</option>
      <option value="1" v-show="typeoptions.hasOwnProperty(1)">接收文档</option>
      <option value="2" v-show="typeoptions.hasOwnProperty(2)">签名并接收文档</option>
    </select>
    <i v-if="recipientconfig.deleteable" class="icon-no-circle deleteRecipient" @click="deleteContact"></i>
  </div>
</template>

<script>
export default {
  props:{
    orderstate:{
      type:Boolean,
      require:true
    },
    recipientdata:{
      type:Object,
      require:true
    },
    recipientconfig:{
      type:Object,
      require:true
    }
  },
  watch:{
      'recipientdata.name':function(val,oldval){
          if(window.getBLength(val)>50){
              this.recipientdata.name=oldval;
              this.$notify({
                  title: '警告',
                  message: '姓名最长可输入50个字符',
                  type: 'warning'
                });
          }
      }
  },
  computed:{
    infoDisable(){
      return !this.recipientconfig.info.changeable;
    },
    typeDisable(){
      return !this.recipientconfig.type.changeable;
    },
    typeoptions(){
      let typeConfigRange=this.recipientconfig.type.range;
      let out={};
      let types={
        0:'签名',
        1:'接收文档',
        2:'签名并接收文档'
      };
      if(typeConfigRange){
        if(typeConfigRange.include){
          typeConfigRange.include.forEach((index)=>{
            out[index]=types[index];
          });
        }else{
          out=types;
          if(typeConfigRange.exclude){
            typeConfigRange.exclude.forEach((index)=>{
              delete out[index];
            });
          }
        }
      }else{
        out=types;
      }
      return out;
    },
    selectWidth(){
      let width=250;

      if(this.orderstate)width-=59;
      if(this.recipientconfig.deleteable)width-=30;

      return {
        'width':width+'px'
      }
    }
  },
  methods:{
    editData(key,val){
        if(this.infoDisable)return;
        this.recipientdata[key]=val;
    },
    deleteContact(){
      this.$emit('deleteContact',this.recipientdata);
    },
    orderDrag(e){
      let that=this;
      let y=e.clientY;
      let changed=0;
      document.addEventListener('mousemove',move);
      document.addEventListener('mouseup',up);
      document.onmousedown=function(){//阻止选中事件
        return false;
      }

      function move(e){
        let cy=e.clientY-y;
        if(cy>60){
          y=e.clientY;
          that.$emit('orderChange',that.recipientdata,changed,1);
          changed+=1;
        }else if(cy<-60){
          y=e.clientY;
          that.$emit('orderChange',that.recipientdata,changed,-1);
          changed-=1;
        }
      }

      function up(e){
        document.removeEventListener('mousemove',move);
        document.removeEventListener('mouseup',up);
        document.onmousedown=function(){
          return true;
        }
      }
    }
  }
}
</script>

<style lang="less" scoped>
 @import '../../styles/variable.less';

.recipientInfo {
  height: 60px;
  width: 900px;
  line-height: 60px;
  position: relative;
  border-top: 1px solid transparent;
}

.recipientInput{
    padding: 14px 10px;
    width: 285px;
    margin-right: 6px;
}
.recipientType {
    width: 236px;
    height: 49px;
    margin-right: 5px;
}

.deleteRecipient{
    font-size: 18px;
    color: @color-linktext;
    cursor: pointer;
}
.deleteRecipient:hover{
  color:@color-add;
}
.sortHandle {
    display: none;
    width: 12px;
    height: 18px;
    vertical-align: middle;
    margin-right: 5px;
    background: url(/img/sort.png) no-repeat;
    cursor: move;
}

.orderDisplay {
    width: 16px;
    padding: 14px 5px;
    margin-right: 6px;
    text-align: center;
}

</style>
