<!--
    @id        ui-envelope-list-item
    @desc      合同列表展示的每列
    @level     ui
    @props     外部属性
        envelope：文档对象
    @author    陈曦源 潘维
    @date      2018-12-24 17:24:40
-->
<template>
    <div class="envelope-col" @click="activeEnvelope">
        <div class="envelope-col-lg">
            <div class='checkbox' @click.stop v-if="!enterpriseAll">
                <el-checkbox :disabled="checkedDisabled" v-model="envelope.checked"></el-checkbox>
            </div>
            <div class="envelope-title">
                <div style="display:flex;">
                    <div class="title">{{envelope.title || "未命名"}}</div>
                    <div class="bulk-envelope" v-if="multisendNum">批量</div>
                </div>
                <div class="infos">
                    <div class="info-sender">
                        发起方： {{senderName}}
                    </div>
                </div>
            </div>
            <div class="envelope-status-icon"><i :class="iconClass"></i></div>
            <div class="envelope-status">
                <div style="width:102px;">
                <div class="status">
                    <span v-if="envelope.envelopeFlowType === 'CANCEL_PROCESS'">{{cancelProcessStatusName}}</span>
                    <span v-else>{{statusName}}</span>
                    </div>
                    <time class="time" >
                        {{statusDate}}
                    </time> 
                </div>
                <el-button v-if="actionConfig.signable&&envelope.envelopeFlowType === 'CANCEL_PROCESS'" class="btn" type="primary" plain size="mini" @click.stop="toSign">确认作废</el-button>
                <el-button v-else-if="actionConfig.signable" class="btn" type="primary" plain size="mini" @click.stop="toSign">签署</el-button>
                <el-button v-if="actionConfig.auditable" class="btn" type="primary" plain size="mini" @click.stop="toAudit">审核</el-button>
            </div>
            <EnvelopesActions class="envelopes-actions-sm" :multisendNum="multisendNum" :popoverVisible="popoverVisible" :actionConfig="actionConfig"
            :envelopeStatus="envelopeStatus"
            :envelopeFlowType="envelope.envelopeFlowType"
            @downloadDocument="downloadDocuments"  
            @downloadDocumentAudit="downloadDocumentAudit" 
            @revoke="$emit('revoke')"   @reject="$emit('reject')" 
            @notpass="$emit('notpass')" @copy="copy"  
            @toNotify="toNotify"        @preview="$emit('preview')"
            @delete="$emit('delete')"   @editEnvelope="editEnvelope"
            @transfer="$emit('transfer')"
            @cancel="$emit('cancel')"></EnvelopesActions>    
        </div>
        <EnvelopesActions class="envelopes-actions-lg" :actionConfig="actionConfig" :popoverVisible="popoverVisible" :multisendNum="multisendNum"
        :envelopeStatus="envelopeStatus"
        :envelopeFlowType="envelope.envelopeFlowType"
        @downloadDocument="downloadDocuments"  
        @downloadDocumentAudit="downloadDocumentAudit" 
        @revoke="$emit('revoke')" @reject="$emit('reject')" 
        @notpass="$emit('notpass')" @copy="copy"  @toNotify="toNotify"
        @preview="$emit('preview')" @delete="$emit('delete')" @editEnvelope="editEnvelope"
        @transfer="$emit('transfer')"
        @cancel="$emit('cancel')"></EnvelopesActions>
    </div>
</template>

<script>
import { newFormatDate } from "@commons/util.js"
import EnvelopesActions from "@components/envelopes/envelopes-actions.vue"
import { 
    EnvelopeStatus,
    ENVELOPE_STATUS_KEY_KEY,
    ENVELOPE_STATUS_KEY_CODE } from "@classes/envelopes/envelopes.js"

import { downloadEnvelope,
    notificationParticipants,
    downloadAudit,
    copyEnvelope } from "@interfaces/envelopes/envelope.js"

import { checkAuthStatus } from "@commons/check-status.js"
import { checkEnterpriseAuthStatus } from "@commons/check-enterprise-status.js"
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"

export default {
    props: {
        envelope: Object,
        envelopes: Array,
        enterpriseAll: { //来自查看企业全部文件
            type: Boolean,
            defalut: false
        }
    },
    data(){
        return {
            popoverVisible: false,
            type: ""
        }
       
    },
    computed: {
        envelopeWsid(){
            return this.envelope.envelopeWsid
        },
        multisendNum(){
            if (this.envelope.multisendNum){
                return true
            } else {
                return false
            }
        },
        statusName(){
            return EnvelopeStatus.getStatusNameByKey(this.envelopeStatus)
        },
        cancelProcessStatusName(){
            let envelopeStatus = this.envelopeStatus
            if(envelopeStatus === "WAITING_ME_SIGN"){
                return "待我确认作废"
            } else if(envelopeStatus === "WAITING_ME_CHECK"){
                return "待我审核作废"
            }else if(envelopeStatus === "WAITING_OTHERS_HANDLE"){
                return "待他人确认作废"
            } else {
                return EnvelopeStatus.getStatusNameByKey(this.envelopeStatus)
            }
        },
        senderName(){
            let nameArray = this.envelope.sender.username.split(",")
            if (nameArray.length === 1){
                return nameArray[0]
            } else {
                return (nameArray[1] + " (" + nameArray[0] + ")" )
            }
        },
        statusDate(){
            return newFormatDate(this.envelope.statusDatetime, "HH:mm")
        },
        envelopeStatus(){
            if (this.envelope.envelopeStatus){
                return this.envelope.envelopeStatus
            } else {
                return EnvelopeStatus.translateEnvelopeStatusFromEnd(this.envelope.status)
            }
        },
        iconClass(){
            let status = this.envelopeStatus
            let code = ENVELOPE_STATUS_KEY_CODE[status]

            if (code === 1){
                //草稿
                return "icon-draft color-info" 
            } else if ([2, 3, 101, 102, 103, 106, 108, 401].indexOf(code) >= 0){
                //无法操作
                //等待发送 挂起 投递中 流程处理中 流程结束系统处理中 待他人处理 待他人纠正
                return "icon-doing color-main" 
            } else if ([109].indexOf(code) >= 0){
                //等待加入企业
                return "icon-doing color-danger" 
            } else if ([104, 105, 107].indexOf(code) >= 0){
                //待我操作 
                //待我签 待我审核 待我纠正
                return "icon-wait2 color-main" 
            } else {
                switch (code){
                    case 201:return "icon-complete color-success" //已完成
                    case 202:return "icon-complete color-info" //已完成（作废）
                    case 203:return "icon-refuse2 color-info" //已被拒签
                    case 204:return "icon-refuse2 color-info" //审核未通过
                    case 205:return "icon-revoke2 color-info" //已被撤销
                    // case 206:return "icon-warning color-info" //超时未签
                    case 210:return "icon-warning color-info" //超时未签
                    case 207:return "icon-warning color-info" //废弃
                    case 402:return "icon-complete color-success" //（查看企业下所有文件中）已完成
                    default :return "el-icon-question color-info" //未知
                }
            }
        },
        activeUserParticipantWsid(){ //个人用PUSER 企业用EMEM
            if (this.$store.getters.userEdition === "p"){
                return this.$store.getters.activeUserWsid
            } else {
                return this.$store.getters.memberWsid
            }
        },
        actionConfig(){
            return EnvelopeStatus.getActionConfigByEnvelopeStatus(this.envelopeStatus, 
                this.activeUserParticipantWsid === this.envelope.sender.userWsid)
        },
        checkedDisabled(){
            if (this.envelope.envelopeStatus === "SUCCESS_COMPLETED"){
                return false
            } else {
                return true
            }
        },
    },
    methods: {
        editEnvelope(){
            if (this.multisendNum){ //批量发送
                this.$router.push({
                    name: "envelope-bulk-editor",
                    params: {
                        envelopeId: this.envelopeWsid
                    }
                })
                return  
            } else if (this.envelope.templateWsid){ //模板使用
                this.$router.push({
                    name: "template-use",
                    params: {
                        envelopeId: this.envelopeWsid
                    },
                    query: {
                        templateId: this.envelope.templateWsid
                    }
                })
                return 
            } else {
                this.$router.push({
                    name: "envelope-editor",
                    params: {
                        envelopeId: this.envelopeWsid
                    }
                })
                return
            }
        },
        //复制已完成的信封
        copy(){
            if (this.$store.getters.totalCharges === 0){
                this.$confirm("签署余额不足，请前往充值", "提示", {
                    confirmButtonText: "立即前往充值",
                    cancelButtonText: "取消",
                    callback: action => {
                        if (action === "confirm"){
                            if (this.$store.getters.userEditionEdition === "p"){
                                this.$router.push({
                                    name: "person-purchase"
                                })
                            } else {
                                this.$router.push({
                                    name: "enterprise-purchase"
                                })
                            }
                        }
                    },
                    type: "warning"
                })
                return
            }

            this.$confirm(`您将创建主题为《${this.envelope.title}》的副本？`, "创建副本", {
                confirmButtonText: "创建",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                this.$message.info("创建副本中...")
                return copyEnvelope({
                    envelopeWsid: this.envelopeWsid
                }).then(res => {
                    let envelope = res.data.data.envelope
                    let envelopeId = envelope.basicInfo.envelopeWsid
                    if (this.envelope.templateWsid){ //模板信封复制
                        this.$router.push({
                            name: "template-use",
                            params: {
                                envelopeId: envelopeId
                            },
                            query: {
                                templateId: this.envelope.templateWsid
                            }
                        })

                    } else {
                        this.$router.push({
                            name: "envelope-editor",
                            params: {
                                envelopeId: envelopeId
                            }
                        })
                    }
                }).catch(err => {
                    this.$message.error("创建副本失败！")
                })
            }, () => {})
        },
        activeEnvelope(){
            let status = this.envelopeStatus
            if (status === "DRAFT"){
                this.editEnvelope()
            } else {
                let path = this.$route.fullPath
                this.$store.dispatch("updatePathData", path)
                this.$router.push({
                    name: "envelope-detail",
                    params: {
                        envelopeId: this.envelope.envelopeWsid,
                    },
                })
            }
        },
        downloadDocuments(loadType){
            let title = this.envelope.title
        
            getEnvelopeDocuments({
                envelopeWsid: this.envelope.envelopeWsid,
            }).then(res => {
                let documents = res.data.data.documents
                if (documents.length > 1 || loadType == "true"){
                    this.type = "ZIP"
                } else {
                    this.type = "PDF"
                }    
                this.$confirm(`您确定下载文件《${title}》?`, "提示", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(() => {
                    return downloadEnvelope({
                        envelopeWsid: this.envelope.envelopeWsid,
                        name: title,
                        withAudit: loadType,
                        type: this.type
                    }).then(_ => {
                        this.$message.success("获取文件成功，正在下载")
                    }).catch(err => {
                        this.$message.error("获取文件失败")
                    })
                }, () => {})
            })
        },
        downloadDocumentAudit(){
            let title = this.envelope.title
            this.$confirm(`您确定下载文件《${title}》签署电子凭证?`, "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                return downloadAudit({
                    name: this.envelope.title,
                    envelopeWsid: this.envelope.envelopeWsid,
                }).then(_ => {
                    this.$message.success("获取凭证成功，正在下载")
                }).catch(err => {
                    this.$message.error("获取凭证失败")
                })
            }, () => {})
        },
        toNotify(){
            this.$confirm("大家签将向还未处理的接收方发送短信或邮件通知", "我要催签", {
                confirmButtonText: "催签",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                this.$message.info("催签中...")
                return notificationParticipants({
                    envelopeWsid: this.envelope.envelopeWsid
                }).then(_ => {
                    this.$message.success("催签成功")
                }).catch(err => {
                    if (err.response.data){
                        let code = err.response.data.code
                        switch (code) {
                            case 101:
                                this.$message.success("对方收到提醒啦,正前往签署")
                                break 
                            default:
                                this.$message.error("催签失败")
                        }
                    } else {
                        this.$message.error("催签失败")
                    }
                })
            }, _ => {})
        },
        async toSign(){
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            let enterpriseIddtvStatus = this.$store.getters.enterpriseIddtvStatus
            
            if (!await checkAuthStatus(this.$router, userIddtvStatus)){
                return 
            }
            
            if (this.userEdition === "e" && !await checkEnterpriseAuthStatus(this.$router, enterpriseIddtvStatus)){
                return 
            } 
            
            if (userIddtvStatus === "PASSED" || enterpriseIddtvStatus === "SENIOR_PASSED" || enterpriseIddtvStatus === "SENIOR_NO_CERT"){
                let path = this.$route.fullPath
                this.$store.dispatch("updatePathData", path)
                this.$router.push({
                    name: "envelope-signature",
                    params: {
                        envelopeId: this.envelope.envelopeWsid
                    }
                })
            }
        },
        async toAudit(){
            let userIddtvStatus = this.$store.getters.userIddtvStatus
            let enterpriseIddtvStatus = this.$store.getters.enterpriseIddtvStatus

            if (this.userEdition === "e" && !await checkEnterpriseAuthStatus(this.$router, enterpriseIddtvStatus) || !await checkAuthStatus(this.$router, userIddtvStatus)){
                return 
            } 
            if (this.userEdition === "p" && !await checkAuthStatus(this.$router, userIddtvStatus)){
                return 
            }

            if (userIddtvStatus === "PASSED" || enterpriseIddtvStatus === "SENIOR_PASSED" || enterpriseIddtvStatus === "SENIOR_NO_CERT"){
                let path = this.$route.fullPath
                this.$store.dispatch("updatePathData", path)
                this.$router.push({
                    name: "envelope-audit",
                    params: {
                        envelopeId: this.envelope.envelopeWsid
                    }
                })
            }
        },
        popover(){
            // this.popoverVisible = !this.popoverVisible
            document.body.click()
        }
    },
    components: {EnvelopesActions},
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

@line-height:40px;
@line-padding:15px;
.checkbox{
    width:20px;
    line-height:@line-height;
}

.envelope-col{
    display: block;
    height: 100px;
    border-bottom: 1px solid @color-border-segment;
    &:hover{
        background: @color-background;
    }
    .envelopes-actions-lg{
           .lg-devices({
        display: none;
    });
    }
    .envelope-actions-sm{
        display: flex;
        margin-left: 50%;
        text-align: left;
        flex-wrap: wrap;
        .action, .more-actions{
            cursor: pointer;
            margin-right: 20px;
        }

        i{
            vertical-align: middle;
            margin-right: 5px;
            font-size: 16px;
        }
        .lg-devices({
            display: none;
        });
    }
    .lg-devices({
        height: 70px;
    });
}

.envelope-col-lg{
    cursor: pointer;
    height: @line-height;
    display: flex;
    margin-left: 20px;
    padding-top: 15px;
    &:last-child{
        border-bottom: none;
    }
    .envelopes-actions-sm{
        display: none;
    }
    .envelope-status-icon{
        width: 40px;
        font-size: 24px;
        line-height: @line-height;
    }

    .envelope-title{
        flex:1;
        width: 150px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        .title{
            height: @line-height / 2;
            line-height: @line-height / 2;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .infos{
            display: flex;
            margin-top: 5px;
            font-size: @font-size-info;
            height: @line-height / 2;

            .info-sender{
                flex: 1;
                width: 100%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            .info-recipients{
                flex: 2;
                width: 100%;
            }
        }
    }

    .envelope-status{
        display:flex;
        align-items: center;
        flex:1;
        .status{
            height: @line-height / 2;
            line-height: @line-height / 2;

            .info{
                color:@color-danger;
            }
        }

        .time{
            margin-top: 5px;
            font-size: @font-size-info;
            height: @line-height / 2;
        }
        .btn{
            margin-left: 10px;
        }
    }

    .envelope-actions{
        width:375px;
        line-height: @line-height;
        text-align: left;
        display: none;
        flex-wrap: wrap;
        .lg-devices({
            display: flex;
        });
        .action, .more-actions{
            cursor: pointer;
            margin-right: 20px;
        }

        i{
            vertical-align: middle;
            margin-right: 5px;
            font-size: 16px;
        }
    }
}
.bulk-envelope{
    background: @color-main;
    width: 40px;
    height: 20px;
    border-radius: 4px;
    text-align: center;
    line-height: 20px;
    color: #fff;
    font-size:@font-size-info;
    margin: 0 10px;
}

.color-main{
    color:@color-main;
}

.color-success{
    color:@color-success;
}

.color-danger{
    color:@color-danger;
}

.color-info{
    color:@color-info;
}

.color-black{
    color:@color-black;
}
</style>

<style lang="less">
@import "~@styles/variable.less";

.wesign-envelopes-list-item-popper-class{
    padding: 0;
    min-width: 100px;
    width: 100px;
    line-height: 25px; 
    outline:none;
    ul{
        padding: 0 10px;
    }
    ul li{
    padding:0;
    cursor:pointer;
    }     
}
</style>

