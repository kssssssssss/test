<template lang="html">
  <div class="form" :class="{'active':active}" :style="formStyle"
    @mousedown.stop="mousedown"
    @click="chooseForm"
    @dblclick="signForm">
    <div v-if="moveable" class="handle_move" :style="handle_moveStyle"></div>
    <div v-if="resizeable" class="handle_resize" @mousedown="resizestart"></div>
    <div v-if="deleteable" class="handle_delete" :style="{'display':active?'block':''}" @click.stop="form_delete"></div>
    <template v-if="signable&&(data||signing)">
      <p v-if="formconfig.type===4&&!signing">{{timeData(data)}}</p>
      <span v-if="formconfig.type===3&&!signing" style="text-align:left" ref="writetext">{{data}}</span>
      <input v-show="formconfig.type===3&&signing" class="writesign" type="text" placeholder="输入文本"
        ref="writeinput"
        :value="data"
        @input="inputLimit"
        @click.stop=""
        @mousedown.stop="">
      <img v-if="(formconfig.type===1||formconfig.type===2)&&data" class="imgStyle" :src="data" :style="imgDataStyle">
    </template>
    <template v-else>
      {{formconfig.name}}
    </template>
  </div>
</template>

<script>
export default {
  props:{
    formdata:{
      type:Object,
      required:true
    },
    data:{
      default:''
    },
    formconfig:{
      type:Object,
      required:true
    },
    active:{
      type:Boolean,
      required:false
    }
  },
  data(){
    return {
      signing:false
    }
  },
  computed:{
    formStyle(){
      let postions=this.formdata.positions;
      let x=postions.ulX;
      let y=postions.ulY;
      let w=postions.lrX-postions.ulX;
      let h=postions.lrY-postions.ulY;

      return {
        'top':y+'px',
        'left':x+'px',
        'width':w+'px',
        'height':h+'px',
        'line-height':h+'px',
        'z-index':this.active?999:10
      }
    },
    imgDataStyle(){
      let img=new Image();
      img.src=this.formdata.data;
      let w=img.width;
      let h=img.height;

      let postions=this.formdata.positions;
      let divw=postions.lrX-postions.ulX;
      let divh=postions.lrY-postions.ulY;

      if(w/h>divw/divh){
        h=h*divw/w;
        w=divw;
      }else{
        w=w*divh/h;
        h=divh;
      }

      return {
        'width':w+'px',
        'height':h+'px',
      }

    },
    handle_moveStyle(){
      let postions=this.formdata.positions;
      let h=postions.lrY-postions.ulY;

      return {
        top:h/2-5+'px'
      }
    },
    moveable(){
      return this.formconfig.moveable;
    },
    resizeable(){
      if(this.formconfig.resizeable===false){
        return false;
      }else{
        return true;
      }
    },
    deleteable(){
      return this.formconfig.deleteable;
    },
    signable(){
      return this.formconfig.signable;
    }
  },
  created(){
    this.$parent.$parent.$on('signForm',(form)=>{
      if(form===this.formdata){
        setTimeout(()=>{//防止点击事件监听冲突
          this.signForm();
        },1)
      }
    });

  },
  methods:{
    mousedown:function(e){
      let that=this;

      if(e.button===0){

        if(this.moveable){
            this.movestart.call(this,e);
        }else if(this.signable){
            this.signForm.call(this);
        }
      }

    },
    chooseForm(){
      this.$emit('select-form',this.formdata);
    },
    signForm(){
      if(this.signable){
        if(this.formconfig.type===1||this.formconfig.type===2){
          this.$emit('sign-form',this.formdata);
        }

        if(this.formconfig.type===3){
          let that=this;
          this.signing=true;
          setTimeout(()=>{
            this.$refs.writeinput.focus();
          },1);
          window.document.body.addEventListener('click',stop);
          function stop(){
            that.signing=false;
            window.document.body.removeEventListener('click',stop);
          }
        }

        if(this.formconfig.type===4){
          this.formdata.data=new Date().getTime();
        }

      }
    },
    movestart:function(e){
      let that=this;
      let startX=e.clientX;
      let startY=e.clientY;
      let oldpositions=JSON.parse(JSON.stringify(that.formdata.positions));

      window.document.addEventListener('mousemove',mousemove);
      window.document.addEventListener('mouseup',mouseup);
      window.document.onmousemove=function(){return false;};
      window.document.body.style.cursor="move";

      function mousemove(e){
        let rect=that.$el.parentNode.getBoundingClientRect();
        let cx=e.clientX-startX;
        let cy=e.clientY-startY;

        let positions=oldpositions;
        if(positions.ulX+cx<0)cx=-positions.ulX;
        if(positions.lrX+cx>rect.right-rect.left)cx=rect.right-rect.left-positions.lrX;

        if(positions.ulY+cy<0)cy=-positions.ulY;
        if(positions.lrY+cy>rect.bottom-rect.top)cy=rect.bottom-rect.top-positions.lrY;

        let newpositions={
          ulX:oldpositions.ulX+cx,
          ulY:oldpositions.ulY+cy,
          lrX:oldpositions.lrX+cx,
          lrY:oldpositions.lrY+cy,
        }

        that.formdata.positions=newpositions;
      }

      function mouseup(e){
        window.document.removeEventListener('mousemove',mousemove);
        window.document.removeEventListener('mouseup',mouseup);
        window.document.onmousemove=null;
        window.document.body.style.cursor="";
      }
    },
    resizestart(e){
      let that=this;
      let startX=e.clientX;
      let startY=e.clientY;
      let oldpositions=JSON.parse(JSON.stringify(that.formdata.positions));

      let resizeconfig=that.formconfig.resizeable;
      let sizeconfig=that.formconfig.size;

      let minsize=sizeconfig.min;//最小尺寸
      if(!minsize)minsize={width:1,height:1};

      if(this.formconfig.type===3){
          console.log(this.$refs.writetext.offsetWidth)
          minsize.width=Math.max(minsize.width,this.$refs.writetext.offsetWidth);
      }

      let maxsize=sizeconfig.max;//最大尺寸
      if(!maxsize)maxsize={width:Infinity,height:Infinity};

      let proLock=sizeconfig.proLock;//尺寸比例是否锁定
      if(!proLock){
        proLock=false;
      }else{
        proLock=sizeconfig.default.height/sizeconfig.default.width;
      }

      window.document.addEventListener('mousemove',mousemove);
      window.document.addEventListener('mouseup',mouseup);
      window.document.onmousemove=function(){return false;};
      window.document.body.style.cursor="nwse-resize";

      e.stopPropagation();

      function mousemove(e){
        let rect=that.$el.parentNode.getBoundingClientRect();
        let cx=e.clientX-startX;
        let cy=e.clientY-startY;

        let positions=oldpositions;

        if(typeof resizeconfig === 'object'){
          cx*=resizeconfig.x;
          cy*=resizeconfig.y;
        }

        if(proLock){//放大   将比例放到最大进行检测
          if(Math.abs(cx)>Math.abs(cy)){
            cy=cx;
          }else{
            cx=cy;
          }
        }

        if(positions.lrX+cx<positions.ulX+minsize.width)cx=positions.ulX+minsize.width-positions.lrX;
        if(positions.lrY+cy<positions.ulY+minsize.height)cy=positions.ulY+minsize.height-positions.lrY;

        if(positions.lrX+cx>positions.ulX+maxsize.width)cx=positions.ulX+maxsize.width-positions.lrX;
        if(positions.lrY+cy>positions.ulY+maxsize.height)cy=positions.ulY+maxsize.height-positions.lrY;


        if(positions.lrX+cx>rect.right-rect.left)cx=rect.right-rect.left-positions.lrX;
        if(positions.lrY+cy>rect.bottom-rect.top)cy=rect.bottom-rect.top-positions.lrY;

        if(proLock){//缩小  将受限制的尺寸回收
          if(Math.abs(cx)>Math.abs(cy)){
            cx=cy;
          }else{
            cy=cx;
          }
        }

        let newpositions={
          ulX:oldpositions.ulX,
          ulY:oldpositions.ulY,
          lrX:oldpositions.lrX+cx,
          lrY:oldpositions.lrY+cy,
        }

        that.formdata.positions=newpositions;
      }

      function mouseup(e){
        window.document.removeEventListener('mousemove',mousemove);
        window.document.removeEventListener('mouseup',mouseup);
        window.document.onmousemove=null;
        window.document.body.style.cursor="";
      }
    },
    form_delete(){
      this.$emit('delete-form');
    },
    inputLimit(e){//限制文字输入数量
      let input=e.currentTarget;
      if(input.scrollWidth>input.clientWidth){
        input.value=this.formdata.data;
      }else{
        this.formdata.data=input.value;
      }
    },
    timeData(time){
      let date=new Date(time);
      return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
    }
  }
}
</script>

<style lang="less" scoped>
@import "../../styles/variable.less";

@color-warning-lt:lighten(@color-warning,40);

.form{
  cursor: pointer;
  box-sizing: border-box;
  position: absolute;

  border: 1px @color-warning dashed;
  border-radius: 2px;

  background: fade(@color-warning-lt,90);

  color:@color-warning;
  text-align: center;

  &:hover{
    color:@color-white;
    background: fade(@color-warning,90);
  }
}

.form.active{
  color:@color-white;
  background: fade(@color-warning,90);
}

.handle_move{
  cursor: move;
  position: absolute;
  left: -20px-10px;
  width: 10px;
  height: 10px;

  border: 1px @color-warning solid;
  border-radius: 5px;

  &::after{
    content: " ";
    position: absolute;
    top: 5px;
    right: -20px;
    width: 20px;
    height: 0px;
    border-top: 1px @color-warning dashed;
  }
}

.handle_resize{
  cursor: nwse-resize;
  position: absolute;
  right: -1px;
  bottom: -1px;
  width: 11px;
  height: 11px;

  &:hover{
    background: linear-gradient(135deg, fade(@color-black,0) 8px,fade(@color-black,50) 8px);
  }
}

.form:hover .handle_delete{
  display: block;
}

.handle_delete{
  display: none;
  position: absolute;
  width: 16px;
  height: 16px;
  top: -12px;
  right: -16px;

  background: url(/img/envelope/delete.png) no-repeat center;

  &:hover{
    border: 1px @color-warning-lt solid;
  }

}

.writesign{
  position: absolute;
  top:1.5px;
  bottom:1.5px;
  left: 0px;
  width: 100%;
  border: @color-main 1px solid;
}

.imgStyle{
  position: absolute;
  left:0;
  right:0;
  top:0;
  bottom:0;
  margin: auto;
}

</style>
