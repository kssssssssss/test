<template lang="html">
  <div>
    <div v-for="form,index in formlist" class="form" @click="chooseform(index,$event)">
      <img v-if="form.icon" :src="form.icon">
      <p>{{form.name}}</p>
    </div>
    <div v-if="puting" class="chooseform" :style="chooseFormStyle" @mouseup="mouseup">
      <img v-if="chooseForm.icon" :src="chooseForm.icon">
      <p>{{chooseForm.name}}</p>
    </div>
  </div>
</template>

<script>
export default {
  props:{
    formlist:{
      type:Array,
      required:true
    }
  },
  data(){
    return {
      puting:false,//放置表单项中
      chooseForm:{},
      mouseX:0,
      mouseY:0
    };
  },
  computed:{
    chooseFormStyle(){
      return {
        "top":this.mouseY-25+'px',
        "left":this.mouseX-85+'px'
      };
    }
  },
  methods:{
    chooseform(typeIndex,e){
      this.puting=true;
      this.chooseForm=this.formlist[typeIndex];
      this.mousemove(e);
      window.document.addEventListener('mousemove',this.mousemove);
      window.document.oncontextmenu=function(){return false;};//阻止右键菜单
    },
    mousemove(e){
      this.mouseX=e.clientX;
      this.mouseY=e.clientY;
    },
    mouseup(e){
      if(e.button===0){
        this.$emit('addform',e,this.chooseForm.type);
      }
      this.puting=false;
      window.document.removeEventListener('mousemove',this.mousemove);
      setTimeout(function(){
        window.document.oncontextmenu=null;//恢复右键菜单
      },100);
    },

  }

}
</script>

<style lang="less" scoped>
@import "../../styles/variable.less";

.form{
  cursor: pointer;
  text-align: center;
  position: relative;

  height: 50px;
  line-height: 50px;
  width: 170px;
  margin: 10px auto;
  background-color:@color-background-lt;
  border: @color-background-dark 1px solid;
  border-radius: 2px;

  text-align: left;

  &:hover{
    background-color:@color-background;
  }

  & img{
    position: absolute;
    left: 27px;
    top:(50px-22px)/2;
  }

  & p{
    margin-left: 75px;
  }

}

.chooseform{
  z-index: 100;
  cursor: pointer;
  position: fixed;
  text-align: center;

  height: 50px;
  line-height: 50px;
  width: 170px;
  margin: 10px auto;
  background-color:@color-background-lt;
  border: @color-background-dark 1px solid;
  border-radius: 2px;

  & img{
    position: absolute;
    left: 27px;
    top:(50px-22px)/2;
  }

  & p{
    margin-left: 75px;
  }

}

</style>
