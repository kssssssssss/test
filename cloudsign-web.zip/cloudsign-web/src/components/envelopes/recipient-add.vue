<template lang="html">
  <div class="">
    <div v-for="data in addData" class="addRecipient" @click="addrecipient(data.index)">
      <i class="icon icon-add addRecipientIcon"></i>
      <span>添加{{data.name}}(已添加{{count}}人)</span>
    </div>
  </div>
</template>

<script>
export default {
  props:{
    groupnumber:{
      type:Number,
      required:true
    },
    groupconfig:{
      type:Object,
      required:true
    },
    count:{
      type:Number,
      required:true
    }
  },
  computed:{
    addData(){
      let out=[];
      this.groupconfig.contacts.forEach((contactConfig,index)=>{
        if(contactConfig.recipientConfig.addable){
          out.push({
            name:contactConfig.name,
            index:index
          });
        }
      });
      return out;
    }
  },
  methods:{
    addrecipient(index){
      this.$emit('addcontact',{
        group:this.groupnumber,
        contact:index
      });
    }
  }
}
</script>

<style lang="less" scoped>
@color-main:#095db1;
@color-info:#e4e8ee;
.icon{
  color:@color-main;
}
.addRecipient{
    line-height: 48px;
    position: relative;
    width: 888px;
    height: 48px;
    margin-top: 5px;
    padding-left: 10px;
    border: 1px dashed @color-main;
    cursor: pointer;
    color: @color-main;
}

.addRecipient:hover {
    border-color: @color-main+#333;
    color: @color-main+#333;
    & .icon{
      color: @color-main+#333;
    }
}

</style>
