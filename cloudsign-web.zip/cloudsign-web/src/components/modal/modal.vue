<!-- 模态框组件 -->
<template>
   <div class="modal" @click.stop>
        <div class="modal-dialog" ref='main' :style='{width:width,height:height,top:top}'>
            <div class="modal-header" :style="{background:headerColor}"  v-on:mousedown='down($event)'>
                <span>{{title}}</span>
                <a>×</a>
            </div>
            <div class="modal-body" :style='autoStyle'>
                <slot>
                </slot>
            </div>
        </div>
  </div>
</template>

<script>
export default {
    props: {
        top: {
            type: String,
            default: "20px"
        },
        title: {
            type: String,
            default: "Modal"
        },
        headerColor: {
            type: String,
            default: "@color-top"
        },
        width: {
            type: String,
            default: "600px"
        },
        height: {
            type: String,
            default: ""
        },
        auto: {
            type: String,
            default: ""
        }
    },
    data: function() {
        return {
            start: {
                x: 0,
                y: 0
            },
            wndRect: {
                w: 0,
                h: 0
            },
            modalRect: {
                w: 0,
                h: 0,
                l: 0,
                t: 0
            }
        }
    },
    computed: {
        autoStyle: function(){
            if (!this.auto)
                return {}
            else
                return {
                    position: "absolute",
                    top: "35px",
                    width: "100%",
                    bottom: 0,
                    overflow: "auto"
                }
        }
    },
    methods: {
        closeModal: function(){
            this.$refs.main.style.margin = "auto"
            this.$refs.main.style.top = this.top || "20px"
            this.$emit("close-modal")
        },
        calcModal: function(){
            let rect = this.$refs.main.getBoundingClientRect()
            this.modalRect.w = rect.width
            this.modalRect.h = rect.height
            this.modalRect.l = rect.left
            this.modalRect.t = rect.top
            this.wndRect.w = document.documentElement.clientWidth
            this.wndRect.h = document.documentElement.clientHeight
        },
        down: function(event){
            if (event.target.tagName === "A"){
                this.closeModal()
            } else {
                this.calcModal()
                this.start.x = event.clientX
                this.start.y = event.clientY
                let me = this
                document.addEventListener("mousemove", move)
                document.addEventListener("mouseup", up)
                function move(event){
                    me.modalRect.l += event.clientX - me.start.x
                    me.modalRect.t += event.clientY - me.start.y
                    me.start.x = event.clientX
                    me.start.y = event.clientY
                    if (me.modalRect.l <= 0){
                        me.modalRect.l = 0
                    }
                    if (me.modalRect.l + me.modalRect.w >= me.wndRect.w){
                        me.modalRect.l = me.wndRect.w - me.modalRect.w
                    }
                    if (me.modalRect.t <= 0){
                        me.modalRect.t = 0
                    }
                    if (me.modalRect.t + me.modalRect.h >= me.wndRect.h){
                        me.modalRect.t = me.wndRect.h - me.modalRect.h
                    }
                    me.$refs.main.style.marginLeft = me.modalRect.l + "px"
                    me.$refs.main.style.top = me.modalRect.t + "px"
                }
                function up(){
                    document.removeEventListener("mousemove", move)
                    document.removeEventListener("mouseup", up)
                }
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
    .modal{
        position: fixed;
        left: 0;
        top: 0;
        background: @color-dialog-background ;
        width: 100%;
        height: 100%;
        z-index: 1000;
        -moz-user-select: none;
        user-select: none;
    }
    .modal-dialog{
        z-index: 101;
        margin: auto;
        background: #fff;
        box-shadow: 0 0 2px @color-line;
        position: relative;
        max-width:400px;
        border-radius:@border-radius-base;
    }
    .modal-header{
        display: inline-block;
        width: 100%;
        padding-top:15px;
        font-size:@font-size-primary;
        cursor: move;
        background:@color-white;
        position:relative;
    }
    .modal-header span{
        line-height: 35px;
        color: #303133;
        float: left;
        margin-left: 10px;
        user-select: none;
    }
    .modal-header a{
        font-size: 22px;
        width:15%;
        max-width:40px;
        text-align:center;
        color: #303133;
        cursor: pointer;
        line-height: 35px;
        position: absolute;
        right: 0;
        z-index: 99;
    }
    .modal-body{
        background:@color-nav-background;
    }
</style>
