<!-- 申请发票 -->
<template>
    <el-dialog title='申请发票'size="small" 
        :visible.sync="dialogInvoiceVisibel"
        :modal-append-to-body="false" @close='cancel'>
        <div class="invoice-info mt20">
            <p class="info-title">发票类型</p>
            <div class="content-group">
                <input type="radio"  name='invoice-type'  value='1' v-model='show'>普通发票
                <input type="radio"  name='invoice-type'  class="ml40" value='2' v-model='show'>增值税专用发票
            </div>
        </div>
        <div class="invoice-info">
            <p class="info-title">发票信息</p>
            <div class="info-content">
                <div class="content-group">
                    <label>发票抬头<span>&nbsp;*</span></label>
                    <input type="text" @blur='inputBlur(0)'  v-model='header.value'>
                    <p class="tips" v-if='header.tips!==""'>{{header.tips}}</p>
                </div>
                <div class="content-group">
                    <label>开票项目:</label>
                    技术服务费
                </div>
                <div v-show='show==2'>
                    <div  v-for='(t,index) in taxpayerInfo' class='content-group'>
                        <label>{{t.info}}<span>&nbsp;*</span></label>
                        <input type="text" @blur='inputBlur(index+5)' v-model='t.value' >
                        <p class="tips">{{t.tips}}</p>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="invoice-info">
            <p class="info-title">邮寄信息</p>
            <div class="info-content">
                <div v-for="(m, index) in mailInfo" class="content-group">
                    <label>{{m.info}}<span v-if='index!==3'>&nbsp;*</span></label>
                    <input type="text" @blur='inputBlur(index+1)' v-model='m.value' >
                    <p class="tips" v-if='index!==3'>{{m.tips}}</p>
                </div>
            </div>
        </div>
        <div class="invoice-info">
            <p class="info-title">请选择需要开具发票的消费记录</p>
            <div class="info-content none" v-if='costs===0'>暂无消费记录</div>
            <div class="info-content select-consume" v-else>
                <p>
                    <input type="checkbox" @change='allChoose()' v-model='all'>
                    <span>全选</span>
                </p>
                <p v-for='(p,index) in pays'>
                    <input type="checkbox" :value='index' v-model='selects' v-for='p in pays' name='cost'>
                    <span>{{getDate(p.payTime,'yyyy-MM-dd hh:mm')}}</span>
                    <span>{{p.cost}}</span>
                    <span>套餐购买</span>
                </p>
                
            </div>
        </div>
        <div class="apply-cont">
            <label>发票总金额&nbsp;:</label>
            <span class="apply-money mr25"><span>{{money}}</span>元</span>
            <span class="warn-icon">!</span>
            <span class="error mr35">注:单次发票申请金额不得少于500元</span>
            <span class="close-btn" @click='close()'>关闭</span>
            <span class="apply-btn" @click='apply()'>申请</span>
        </div>
    </el-dialog>
</template>
<script>
    // import Modal from './modal.vue'
    import {get_bill_pay, post_invoice} from "../../interfaces/payments/payments.js"
    import {isUserName, isPhone, isTaxName, isTaxID, isBankName, isAddress, isBankCode} from "@wesign/check"
    export default{
        props: {
            dialogInvoiceVisibel: {
                default: false
            }
        },
        data: function(){
            return {
                show: 1,
                header: {
                    value: "",
                    tips: ""
                },
                mailInfo: [
                    {info: "收件人姓名", tips: "", isTrue: false, value: ""},
                    {info: "收件人手机", tips: "", isTrue: false, value: ""},
                    {info: "邮寄地址", tips: "", isTrue: false, value: ""},
                    {info: "备注", value: "", tips: ""}
                ],
                taxpayerInfo: [
                    {info: "纳税人识别号", tips: "", isTrue: false, value: ""},
                    {info: "纳税人名称", tips: "", isTrue: false, value: ""},
                    {info: "注册电话", tips: "", isTrue: false, value: ""},
                    {info: "注册地址", tips: "", isTrue: false, value: ""},
                    {info: "银行名称", tips: "", isTrue: false, value: ""},
                    {info: "银行卡号", tips: "", isTrue: false, value: ""}
                ],
                costs: 0,
                pays: [],
                selects: [],
                all: false
            }
        },
        
        computed: {
            money: function(){
                if (this.selects.length === 0){
                    return "0.00"
                }
                let sum = 0
                this.selects.forEach((item) => {
                    sum = sum + this.pays[item].cost
                })
                return sum + ""
            },
            payBills: function(){
                
                if (this.selects.length === 0){
                    return []
                }
                let a = []
                this.selects.forEach((item) => {
                    a.push(this.pays[item].id)
                })
                return a
            }
        },
        created: function(){
            get_bill_pay({
                success: (json) => {
                    if (json.success){
                        let data = json.data
                        this.costs = data.costs
                        this.pays = data.pays.filter(function(item){
                            return item.cost > 0
                        })
                    }
                },
                error: (str) => {
                    console.log(str)
                }})
        },
        methods: {
            close: function(data){
                this.$emit("close-invoice", data)
            },
            cancel(){
                
                this.close()
            },
            getDate: function(date, str){
                return FORMATDATE(date, str)
            },
            allChoose: function(){
                if (!this.all){
                    this.selects = []
                    return
                }
                let me = this
                for (let i = 0, l = me.pays.length;i < l;i++){
                    me.selects.push(i)
                }
            },
            inputBlur: function(index){
                let me = this
                if (index === 0){
                    if (me.header.value === ""){
                        me.header.tips = "请输入发票抬头"
                        return 
                    }
                    me.header.tips = ""
                }
                else if (0 < index && index < 5){
                    index--
                    if (index < 3 && me.mailInfo[index].value === ""){
                        me.mailInfo[index].tips = "请输入" + me.mailInfo[index].info
                        return
                    }
                    switch (index){
                        case 0:
                            let usernameResult = isUserName(me.mailInfo[0].value)
                            switch (usernameResult.code){
                                case 100: me.mailInfo[0].tips = "";break
                                case 101: me.mailInfo[0].tips = "未输入用户名";break
                                default: me.mailInfo[0].tips = "用户名不合法"
                            }
                            break 
                            // var result = username(me.mailInfo[0].value)
                            // if (result.result){
                            //     me.mailInfo[0].tips = ""
                            // } else {
                            //     me.mailInfo[0].tips = result.tip
                            // };
                        case 1:
                            let phoneResult = isPhone(me.mailInfo[1].value) 
                            switch (phoneResult.code) {
                                case 100: me.mailInfo[1].tips = "";break
                                case 101: me.mailInfo[1].tips = "请输入合法的11位手机号码";break
                                default: me.mailInfo[1].tips = "请输入合法的手机号码"
                            }
                            break
                            // var result = phone(me.mailInfo[1].value)
                            // if (result){
                            //     me.mailInfo[1].tips = ""
                            // } else {
                            //     me.mailInfo[1].tips = "请输入合法的11位手机号码"
                            // };
                        case 2:
                            if (me.mailInfo[2].value.length < 6){
                                me.mailInfo[2].tips = "地址长度不能少于6位"
                            } else {
                                me.mailInfo[2].tips = ""
                            };
                            break
                    }
                }
                else {
                    index = index - 5
                    if (me.taxpayerInfo[index].value === ""){
                        me.taxpayerInfo[index].tips = "请输入" + me.taxpayerInfo[index].info
                        return
                    }
                    else {
                        switch (index){
                            case 0:
                                let taxIdResult = isTaxID(me.taxpayerInfo[0].value) 
                                switch (taxIdResult.code){
                                    case 100: me.taxpayerInfo[0].tips = "";break
                                    case 101: me.taxpayerInfo[0].tips = "请输入纳税人识别号";break
                                    case 703: me.taxpayerInfo[0].tips = "纳税人识别号长度是15/18/20位的数字";break
                                    case 704: me.taxpayerInfo[0].tips = "纳税人识别号地址码错误";break
                                    case 705: me.taxpayerInfo[0].tips = "纳税人识别号组织机构代码错误";break
                                    case 706: me.taxpayerInfo[0].tips = "纳税人识别号效验码错误";break
                                    case 707: me.taxpayerInfo[0].tips = "纳税人识别号包含空格";break
                                    case 708: me.taxpayerInfo[0].tips = "纳税人识别号包含其他符号";break
                                    default: me.taxpayerInfo[0].tips = "纳税人识别号不合法"
                                }
                                break
                                // var result = taxid(me.taxpayerInfo[0].value)
                                // if (result.result){
                                //     me.taxpayerInfo[0].tips = ""
                                // }
                                // else {
                                //     me.taxpayerInfo[0].tips = result.tip
                                // };
                            case 1:
                                let taxNameResult = isTaxName(me.taxpayerInfo[1].value)
                                switch (taxNameResult.code) {
                                    case 100: me.taxpayerInfo[1].tips = "";break
                                    case 101: me.taxpayerInfo[1].tips = "请输入纳税人名";break
                                    case 701: me.taxpayerInfo[1].tips = "纳税人名长度在1-50内";break
                                    case 702: me.taxpayerInfo[1].tips = "纳税人名字必须为中文";break
                                    default: me.taxpayerInfo[1].tips = "纳税人名字不合法" 
                                } 
                                break
                                // var result = taxname(me.taxpayerInfo[1].value)
                                // if (result.result){
                                //     me.taxpayerInfo[1].tips = ""
                                // }
                                // else {
                                //     me.taxpayerInfo[1].tips = result.tip
                                // };
                            case 2:
                                let phoneResult = isPhone(me.taxpayerInfo[2].value) 
                                switch (phoneResult.code) {
                                    case 100: me.taxpayerInfo[2].tips = "";break
                                    case 101: me.taxpayerInfo[2].tips = "请输入注册电话";break
                                    default: me.taxpayerInfo[2].tips = "请输入合法的注册电话"
                                }
                                break
                                // var result = phone(me.taxpayerInfo[2].value)
                                // if (result){
                                //     me.taxpayerInfo[2].tips = ""
                                // }
                                // else {
                                //     me.taxpayerInfo[2].tips = "请输入合法的注册电话"
                                // };
                            case 3:
                                let addressResult = isAddress(me.taxpayerInfo[3].value)
                                switch (addressResult.code){
                                    case 100: me.taxpayerInfo[3].tips = "";break
                                    case 101: me.taxpayerInfo[3].tips = "未输入地址";break
                                    case 801: me.taxpayerInfo[3].tips = "地址长度不能超过50位";break
                                    case 802: me.taxpayerInfo[3].tips = "地址长度不能小于6位";break
                                    case 803: me.taxpayerInfo[3].tips = "地址不能包含特殊字符";break
                                    case 804: me.taxpayerInfo[3].tips = "地址不能全为数字";break
                                    default: me.taxpayerInfo[3].tips = "地址不合法"
                                }
                                break
                                // var result = address(me.taxpayerInfo[3].value)
                                // if (result.result){
                                //     me.taxpayerInfo[3].tips = ""
                                // }
                                // else {
                                //     me.taxpayerInfo[3].tips = result.tip
                                // };
                                // break
                            case 4:
                                let bankNameResult = isBankName(me.taxpayerInfo[4].value)
                                switch (bankNameResult.code){
                                    case 100: me.taxpayerInfo[4].tips = "";break
                                    case 906: me.taxpayerInfo[4].tips = "银行名带有空格";break
                                    case 903: me.taxpayerInfo[4].tips = "银行名长度小于2";break
                                    case 904: me.taxpayerInfo[4].tips = "银行名长度大于30";break
                                    default: me.taxpayerInfo[4].tips = "银行名不合法"
                                }
                                break
                                // var result = bankname(me.taxpayerInfo[4].value)
                                // if (result.result){
                                //     me.taxpayerInfo[4].tips = ""
                                // }
                                // else {
                                //     me.taxpayerInfo[4].tips = result.tip
                                // };
                            case 5:
                                let bankCodeResult = isBankCode(me.taxpayerInfo[5].value)
                                switch (bankNameResult.code){
                                    case 100: me.taxpayerInfo[5].tips = "";break
                                    case 101: me.taxpayerInfo[5].tips = "请输入银行卡号";break
                                    default: me.taxpayerInfo[5].tips = "银行卡号不合法" 
                                }
                                break
                                // var result = bank_code(me.taxpayerInfo[5].value)
                                // if (result.result){
                                //     me.taxpayerInfo[5].tips = ""
                                // }
                                // else {
                                //     me.taxpayerInfo[5].tips = result.tip
                                // };
                                // break
                        }
                    }
                }
            },
            apply: function(){
                let me = this
                if (me.header.tips !== "")
                    return
                let data = {
                    invoice: {
                        header: me.header.value,
                        type: me.show === 1 ? "普通发票" : "增值税专用发票"
                    }
                }
                let p = me.mailInfo.some(function(item){
                    return item.tips !== ""
                })
                if (p){
                    me.$message.warning("请正确填写信息")
                    return
                }
                p = me.mailInfo.some(function(item){
                    return item.value === ""
                })
                if (p){
                    me.$message.warning("请将信息填写完整")
                    return
                }
                data.recipient = {
                    name: me.mailInfo[0].value,
                    phone: me.mailInfo[1].value,
                    address: me.mailInfo[2].value,
                    remarks: me.mailInfo[3].value
                }
                if (me.payBills.length === 0){
                    me.$message.warning("请选择消费记录")
                    return
                }
                data.payBills = me.payBills
                if (me.show === 1){
                    post_invoice({
                        data: data,
                        success: (json) => {
                            me.close(true)
                            if (json.success){
                                me.$message.success(json.data)
                            }
                            else {
                                me.$message.error(json.data)
                            }
                        },
                        error: (str) => {
                            console.log(str)
                        }
                    })
                    return 
                }
                p = me.taxpayerInfo.some(function(item){
                    return item.tips !== ""
                })
                if (p){
                    me.$message.warning("请正确填写信息")
                    return
                }
                p = me.taxpayerInfo.some(function(item){
                    return item.value === ""
                })
                if (p){
                    me.$message.warning("请将信息填写完整")
                    return
                }
                data.vatInfo = {
                    code: me.taxpayerInfo[0].value,
                    name: me.taxpayerInfo[1].value,
                    phone: me.taxpayerInfo[2].value,
                    address: me.taxpayerInfo[3].value,
                    bankName: me.taxpayerInfo[4].value,
                    bankCode: me.taxpayerInfo[5].value
                }
                post_invoice({
                    data: data,
                    success: (json) => {
                        me.close(true)
                        if (json.success){
                            me.$message.success(json.data)
                        }
                        else {
                            me.$message.error(json.data)
                        }
                    },
                    error: (str) => {
                        console.log(str)
                    }
                })
            }
        }
    }
</script>
<style scoped>
    .mt20{
        margin-top: 20px;
    }
    .ml40{
        margin-left: 40px;
    }
    .mr25{
        margin-right: 25px;
    }
    .mr35{
        margin-right: 35px;

    }
    .invoice-info{
        border-bottom: #ddd 1px solid;
        margin-bottom: 20px;
    }
    .invoice-info{
        margin-left: 30px;
        margin-bottom: 20px;
    }
    .invoice-info .info-title{
        border-left: 6px solid #66a3ff;
        padding-left: 10px;
    }
    .invoice-info .info-content label{
        width: 110px;
        display: inline-block;
    }
   .invoice-info .info-content label span{
        color: #ff9667;
    }
    .invoice-info  .content-group{
        margin: 20px 0;
    }
    .invoice-info  .content-group input[type='text']{
        width: 595px;
        height: 38px;
    }
    .invoice-info  .content-group input[type='radio']{
        width: 16px;
        height: auto;
    }
    .invoice-info  .content-group .tips{
        padding-left:112px;
        color:#ff9667;
    }
    .invoice-info .select-consume{
        max-height: 110px;
        overflow-y: auto;
        border: 1px solid #ddd;
        width: 708px;
        margin: 20px 0; 
    }
    .invoice-info .select-consume p{
        margin:10px;
    }
    .invoice-info .select-consume span{
        margin-left:35px;
    }
    .invoice-info .none{
        max-height: 110px;
        overflow-y: auto;
        border: 1px solid #ddd;
        width: 708px;
        margin: 20px 0;
        padding:10px 0;
        text-indent:10px;
    }
    .apply-cont{
        margin: 10px 0 30px;
        margin-left: 30px;
    }
    .apply-cont .apply-money{
        color: #ff6700;
        font-size: 26px;
    }
    .apply-cont .warn-icon{
        width: 16px;
        height: 16px;
        border-radius: 8px;
        -webkit-border-radius: 8px;
        -moz-border-radius: 8px;
        display: inline-block;
        text-align: center;
        color: #fff;
        font-size: 11px;
        background-color: #ff6700;
    }
    .apply-cont .error{
        color: #ff9667;
    }
    .apply-cont .close-btn{
        padding: 10px 30px;
        cursor: pointer;
        font-size: 16px;
        border: 1px #c1c7d4 solid;
        color: #91969d;
        margin-right: 50px;
    }
    .apply-cont .close-btn:hover{
        background-color: #c1c7d4;
        color: #505255;
    }
    .apply-cont .apply-btn{
        color: #fff;
        background-color: #ff6700;
        padding: 10px 30px;
        cursor: pointer;
        font-size: 16px;
    }
</style>