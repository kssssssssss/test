<!--
    @id        ui-picture-cut-preview
    @desc      图片裁剪用的展示组件
    @level     ui：UI组件
    @props     外部属性
        width：宽度
        height：高度
        imagePreviewInfo：图片信息
    @author    陈曦源
    @date      2018-09-20 20:25:58
-->
<template>
    <div class="picture-cut-preiview" :style="previewStyle">
        <div class="preiview-view" :style="clipStyle">
            <img :style="imageStyle" :src="imagePreviewInfo.imageSrc"/>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        width: {
            type: Number,
            default: 200
        },
        height: {
            type: Number,
            default: 200
        },
        imagePreviewInfo: {
            type: Object,
            required: true
        }
    },
    computed: {
        previewStyle(){
            return {
                width: this.width + "px",
                height: this.height + "px"
            }
        },
        clipStyle(){
            if (!this.imagePreviewInfo) return
            let data = this.imagePreviewInfo
            let scaleX = this.width / data.clip.width
            let scaleY = this.height / data.clip.height

            let scale = Math.min(scaleX, scaleY)
            return {
                width: data.clip.width * scale + "px",
                height: data.clip.height * scale + "px"
            }
        },
        imageStyle(){
            if (!this.imagePreviewInfo) return
            let data = this.imagePreviewInfo
            let scaleX = this.width / data.clip.width
            let scaleY = this.height / data.clip.height
            let scale = Math.min(scaleX, scaleY)

            return {
                top: data.image.top * scale + "px",
                left: data.image.left * scale + "px",
                width: data.image.width * scale + "px",
                height: data.image.height * scale + "px",
                transform: `rotate(${data.rotate}deg)`
            }
        }
    },
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.picture-cut-preiview{
    position: relative;
    margin:0 auto;
}

.preiview-view{
    position: absolute;
    top: 50%;
    left: 50%;
    overflow: hidden;
    transform: translate(-50%, -50%);

    img{
        position: absolute;
    }
}
</style>
