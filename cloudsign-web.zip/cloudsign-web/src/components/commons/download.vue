<template>
	<div>
		<ul class="download">
			<li class="download-item" v-for='dw in downways'>
				<a :href='dw["url"]'>
					<i class="lbar-download-item-android-img" :class='dw["icon"]'></i>
					<br>
					<span>{{dw["content"]}}</span>
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
	export default{
		data:function(){
			return{
				downways:[
					{
						'icon':'icon-android',
						'url':'#',
						'content':'android版'
					},
					{
						'icon':'icon-apple',
						'url':'#',
						'content':'ios版'
					},
					{
						'icon':'icon-qrcode',
						'url':'#',
						'content':'二维码'
					}
				]
			}
		}
	}
</script>

<style scoped>
	.download{
		list-style: none;
		width: 100%;
		position: absolute;
		bottom: 0;
		height: 50px;
		text-align: center;
	}
	.download .download-item{
		display: inline-block;
	}
	.download .download-item a{
		display: inline-block;
		text-decoration: none;
		color: #b3b3b3;
		margin: 0px 12px;
	}
	.download .download-item a:hover{
		color:#619af0;
	}
	.download .download-item a i{
		font-size:1.1em;
	}
	.download .download-item a span{
		font-size: 0.9em;
	}
</style>