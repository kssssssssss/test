<!--     
    @desc     图片全屏组件
    @level    ui：UI组件
    @author   周雪梅,陈曦源
    @date     2018-04-09 11:13:32
-->
<template>
    <div class="img-view" ref="view" :style="boxStyle">
        <div class="img" v-fullscreen-preview="{
            realsrc:realsrc
        }">
            <img v-if="realsrc" ref="img" :src="realsrc"/>
            <span class="mask-layer"></span>
            <i class="el-icon-zoom-in zoom"></i>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        src: String,
        width: Number,
        height: Number,
    },
    data(){
        return {
            realsrc: "",
            showBigImage: false,
        }
    },
    computed: {
        boxStyle(){
            return {
                width: this.width + "px",
                height: this.height + "px"
            }
        }
    },
    created(){
        this.realImageSize()
    },
    methods: {
        realImageSize(){
            setTimeout(_ => {
                this.realsrc = this.src
            })
        },
    }
}
</script>

<style lang="less" scoped>

.img-view {
    position: relative;
    width:100%;
    height:100%;
}

.img, .img>img{
    width:100%;
}
</style>
