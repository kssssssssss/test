<template>
	<div class="bomb">
		<!-- 上下左右四个角 -->
		<div class="bomb-arrow-t" v-if='direction==="top"' :style='tbArrow'></div>
		<div class="bomb-arrow-r" v-if='direction==="right"' :style='lrArrow'></div>
		<div class="bomb-arrow-b" v-if='direction==="bottom"' :style='tbArrow'></div>
		<div class="bomb-arrow-l" v-if='direction==="left"' :style='lrArrow'></div>
		<slot name='content'>
			<div class="bomb-content">
			</div>
		</slot>
	</div>
</template>

<script>
export default {
    props: {
        direction: {
            type: String,
            default: 'top'
        },
        dev: {
            type: String
        }
    },
    data: function(){
        return {
        }
    },
    computed: {
        tbArrow: function(){
            const me = this
            if (me.dev){
                if (me.dev.indexOf('%') !== -1){
                    return {
                        left: me.dev
                    }
                } else {
                    return {
                        left: 0,
                        marginLeft: me.dev
                    }
                }
            }
            else {
                return {}
            }
        },
        lrArrow: function(){
            let me = this
            if (me.dev){
                if (me.dev.indexOf('%') !== -1){
                    return {
                        top: me.dev
                    }
                } else {
                    return {
                        top: 0,
                        marginTop: me.dev
                    }
                }
            }
            else {
                return {}
            }
        }
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
/*边框*/
.bomb{
    padding:10px;
    background: #fff;
    z-index: 999;
    height: auto;
    width: auto;
    border: 1px solid @color-main;
    border-radius:10px;
}
/*上边角样式*/
.bomb-arrow-t {
    position: absolute;
    left: 50%;
    margin-left: -10px;
    top: -10px;
    width: 0;
    height: 0;
    border-width: 10px;
    border-top-width: 0px;
    border-color: transparent;
    border-style: solid;	
    border-bottom-color: @color-line;
}
.bomb-arrow-t::before {
    position: absolute;
    width: 0;
    height: 0;
    left: -9px;
    border-color: transparent;
    border-style: solid;
    content: "";
    border-width: 9px;
    top: 1px;
    border-top-width: 0;
    border-bottom-color: #fff;
}
/*右边角样式*/
.bomb-arrow-r {
    position: absolute;
    right: -12px;
    width: 0;
    height: 0;
    border-width: 12px;
    border-right-width: 0px;
    border-color: transparent;
    border-style: solid;
    border-left-color: #0c7ffc;
    top: 20px;
}
.bomb-arrow-r::before {
    position: absolute;
    width: 0;
    height: 0;
    top: -11px;
    border-color: transparent;
    border-style: solid;
    content: "";
    border-width: 12px;
    right: 3px;
    border-right-width: 0;
    border-left-color: #fff
}
/*下边角样式*/
.bomb-arrow-b {
    position: absolute;
    left: 50%;
    margin-left: -10px;
    bottom: -10px;
    width: 0;
    height: 0;
    border-width: 10px;
    border-bottom-width: 0px;
    border-color: transparent;
    border-style: solid;	
    border-top-color: @color-line;
}
.bomb-arrow-b::before {
    position: absolute;
    width: 0;
    height: 0;
    right: -9px;
    border-color: transparent;
    border-style: solid;
    content: "";
    border-width: 9px;
    top: -10px;
    border-bottom-width: 0;
    border-top-color: #fff;
}
/*左边角样式*/
.bomb-arrow-l {
    position: absolute;
    left: -10px;
    width: 0;
    height: 0;
    border-width: 10px;
    border-left-width: 0px;
    border-color: transparent;
    border-style: solid;	
    border-right-color: @color-line;
}
.bomb-arrow-l::before {
    position: absolute;
    width: 0;
    height: 0;
    top: -9px;
    border-color: transparent;
    border-style: solid;
    content: "";
    border-width: 9px;
    right: -10px;
    border-left-width: 0;
    border-right-color: #fff;
}
</style>