<template>
    <div class="change-type" :style="dateTypePickerStyle">
          <div :class="formToBottom?'rect-top':'rect-bottom'">
              <div :class="formToBottom?'outside-rect-top':'outside-rect-bottom'"></div>
          </div>
           <p v-for="item in dateType" :key="item.type" @click="changeDateType(item)" class="type-item" :class="activeType===item.type?'active':''" :style="flex">
              <span class="text">{{item.value}}</span>
              <i class="icon el-icon-date" @click="openTimePicker" v-if="formData.revisable"></i>
            </p>
      </div>
</template>
<script>
const defaultType = "yyyy-MM-dd"
export default {
    props: {
        formData: {
            type: Object,
            required: true
        },
        scale: {
            type: Number
        },
        formToBottom: {
            type: Boolean,
        },
        active: {
            type: Boolean,
            default: false
        },
    },
    data(){
        return {
            dateType: [
                {
                    type: "yyyy-MM-dd",
                    value: "年-月-日"
                },
                {
                    type: "yyyy-MM-dd HH:mm",
                    value: "年-月-日  时:分"
                    
                },
                {
                    type: "yyyy-MM-dd HH:mm:ss",
                    value: "年-月-日  时:分:秒"
                },
            ]
        }
    },
    computed: {
        dateTypePickerStyle(){
            let position = this.formData.position
            let w = position.lrx - position.ulx
            let h = position.lry - position.uly
            
            return {
                width: w * this.scale + "px",
                left: 0 + "px",
                top: this.formToBottom ? "" : (h + 6) * this.scale + "px",
                bottom: this.formToBottom ? (h + 6) * this.scale + "px" : ""
            }
        },
        activeType(){
            return this.formData.format || defaultType
        },
        flex(){
            if (this.formData.revisable){
                return {
                    display: "flex",
                    alignItems: "center",
                }
            }
        }
    },
    methods: {
        changeDateType(value){
            this.$emit("changeDateType", value.type)
        },
        openTimePicker(){
            this.$emit("open")
        }
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.change-type{
    position: absolute;
    color: #878d99;
    box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
    border-radius:4px;
    border: 1px dashed #0c7ffc;
    background: #fff;
    font-size: 12px;
    z-index: 99;
    .active{
        color: #0c7ffc;
    }
    p{
        line-height: 24px;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        border-bottom: 1px solid #0c7ffc;
        &:last-child{
            border: none;
        }
        cursor: pointer;
        &:hover {
            color: #0c7ffc;
            background: #d8ecff;
        }
    }
}
.rect-bottom{
    width: 100%;
    position: absolute;
    top:-5px;
    z-index: -1;
}
.outside-rect-bottom{
    height: 8px;
    width: 8px;
    background: #fff;
    transform: rotate(45deg);
    margin: 0 auto;
    border-top: 1px dashed @color-main;
    border-left: 1px dashed @color-main;
    .active{
        background: @color-main;
    }
  
}
.rect-top{
    width: 100%;
    position: absolute;
    bottom:-5px;
    z-index: -1;
}
.outside-rect-top{
    height: 8px;
    width: 8px;
    background: #fff;
    transform: rotate(45deg);
    margin: 0 auto;
    border-bottom: 1px dashed @color-main;
    border-right: 1px dashed @color-main;
    .active{
        background: @color-main;
    }
  
}
.type-item{
  padding: 0 10px;
  .notice{
    width:70px;
  }
  .text{
    flex:1;
    text-align: left;
  }
  .icon{
    font-size: 18px;
    width: 30px;
    cursor: pointer;
  }
}
</style>
