<!--     
    @desc     图片自动伸缩大小组件
    @level    ui：UI组件
    @author   潘维,陈曦源,谭文斌
    @date     2019-09-24 16:21:07
    @notic    SVG在IE下展示存在问题
-->
<template>
    <div ref="img-box" 
        class="autoresize-img-box" 
        :style="boxStyle">
        <div ref="resize-big" 
            class="autoresize-resize-event-helper" 
            @scroll="sizeBig">
            <div :style="{width: this.maxSize + 'px', height: this.maxSize + 'px'}"></div>
        </div>
        <div ref="resize-small" 
            class="autoresize-resize-event-helper" 
            @scroll="sizeSmall">
            <div style="width: 200%;height: 200%;"></div>
        </div>
        <img class="autoresize-img" :style="imageStyle" :src="src">
    </div>
</template>

<script>
const MAX_SIZE = 1000 * 1000 //默认1,000,000  ie最大为2e

export default {
    props: {
        width: {},
        height: {},
        src: String,
        maxSize: {
            type:Number,
            default: MAX_SIZE
        }
    },
    data(){
        return {
            imageSize: {
                width: 1,
                height: 1
            },
            boxSize: {
                width: 1,
                height: 1
            }
        }
    },
    computed: {
        boxStyle(){
            let width = this.width
            let height = this.height
            if(typeof width === "number") width = width + "px"
            if(typeof height === "number") height = height + "px"

            return {
                width,
                height
            }
        },
        imageStyle() {
            if (this.imageDirection) {
                return {
                    width: "100%"
                }
            } else {
                return {
                    height: "100%"
                }
            }
        },
        imageDirection(){
            let imageSize = this.imageSize
            let boxSize = this.boxSize
            if (imageSize.width / imageSize.height > boxSize.width / boxSize.height) {
                return true
            } else {
                return false
            }
        }
    },
    watch: {
        src(){
            this.updateImg()
        },
    },
    mounted(){
        let insideBig = this.$refs["resize-small"]
        let insideSmall = this.$refs["resize-big"]
        //让内容在最下面
        insideBig.scrollTop = this.maxSize
        insideBig.scrollLeft = this.maxSize
        insideSmall.scrollTop = this.maxSize
        insideSmall.scrollLeft = this.maxSize
        this.updateImg()
        this.updateBoxSize()
    },
    methods: {
        updateImg() {
            let image = document.createElement("img")
            image.src = this.src

            //兼容IE 不放入dom无法获取的BUG
            image.style.position = "absolute"
            image.style.opacity = "0"
            document.body.appendChild(image)
            
            image.onload = _ => {
                this.imageSize.width = image.width
                this.imageSize.height = image.height

                document.body.removeChild(image)
            }
        },
        updateBoxSize(){
            let outside = this.$refs["img-box"]
            let rect = outside.getBoundingClientRect()
            this.boxSize.height = rect.height
            this.boxSize.width = rect.width
        },
        sizeBig(){
            let insideSmall = this.$refs["resize-small"]
            if(insideSmall){
                insideSmall.scrollTop = this.maxSize
                insideSmall.scrollLeft = this.maxSize
                this.updateBoxSize()
            }
        },
        sizeSmall(){
            let insideBig = this.$refs["resize-big"]
            if(insideBig){
                insideBig.scrollTop = this.maxSize
                insideBig.scrollLeft = this.maxSize
                this.updateBoxSize()
            }
        },
    }
}
</script>

<style lang="less" scoped>
.autoresize-img-box{
    position: relative;
    margin: 0 auto;
}
.autoresize-img{
    pointer-events: none;
    position: absolute;
    top:50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.autoresize-resize-event-helper{
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    right: 0;
    overflow: scroll; //IE 需要scroll
    visibility: hidden;
}
</style>
