//防抖函数
export default function debounce(fun, time = 1000){
    let handle = null
    return function(){
        let args = arguments
        if (handle) clearTimeout(handle)
        handle = setTimeout(_ => fun.apply(this, args), time)
    }
}