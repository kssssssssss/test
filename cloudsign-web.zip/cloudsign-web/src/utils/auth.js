import { MessageBox } from "element-ui"

export function checkAuthStatus(router, userIddtvStatus){
    if (userIddtvStatus !== "PASSED"){
        if (userIddtvStatus === "WAITING"){
            MessageBox.alert("您的实名认证信息正在审核中，暂时不能进行该操作，请耐心等待或者联系客服 021-962600", "提示", {
                confirmButtonText: "我知道了",
                callback: action => {},
                type: "warning"
            })
        } else if (userIddtvStatus === "DENY"){
            MessageBox.alert("您的实名认证信息未通过审核，你可重新提交认证信息", "提示", {
                confirmButtonText: "重新认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        router.push({
                            name: "person-auth"
                        })
                    }
                },
                type: "warning"
            })
        } else if (userIddtvStatus === "EXPIRED"){
            MessageBox.alert("您的实名认证信息已过期，将影响功能的正常使用，请重新认证", "提示", {
                confirmButtonText: "重新认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        router.push({
                            name: "person-auth"
                        })
                    }
                },
                type: "warning"
            })
        } else {
            MessageBox.alert("您尚未进行实名认证，签署的文件不具备法律效力，暂时不能进行该操作，请完成实名认证", "提示", {
                confirmButtonText: "前往认证",
                cancelButtonText: "取消",
                callback: action => {
                    if (action === "confirm"){
                        router.push({
                            name: "person-auth"
                        })
                    }
                },
                type: "warning"
            })
        }
        return false
    }
    return true
}