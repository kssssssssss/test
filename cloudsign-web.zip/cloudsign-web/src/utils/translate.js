//cm2px
//1in = 25.4mm
//72pt = 1in
export function cm2pt(cm){
    return cm / 25.4 * 72
}