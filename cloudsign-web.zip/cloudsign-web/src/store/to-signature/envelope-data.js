import { translateParticipantDatasFromEnd } from "@classes/envelopes/participants.js"

import { getEnvelopeData } from "@interfaces/envelopes/index.js"
import { getEnvelopeParticipants } from "@interfaces/envelopes/participants.js"

const moduleSignatureData = {
    state() {
        return {
            envelopeWsid: "", //信封ID

            //信封相关数据========
            basicInfo: null,
            participants: [],
            currentParticipant: null,
            participantEnterpriseRole: null, //参与者在企业中的角色
            //==================
        }
    },
    getters: {
        currentParticipant(state){
            return state.currentParticipant
        }
    },
    mutations: {
        setEnvelopeWsid(state, envelopeWsid){
            state.envelopeWsid = envelopeWsid
        },
        setEnvelopeBasicInfo(state, basicInfo){
            state.basicInfo = basicInfo
        },
        setParticipants(state, participants){
            state.participants = participants
        },
        setCurrentParticipant(state, currentParticipant){
            state.currentParticipant = currentParticipant
        },
        setParticipantEnterpriseRole(state, participantEnterpriseRole){
            state.participantEnterpriseRole = participantEnterpriseRole
        },
    },
    actions: {
        async initEnvelopeData({dispatch}){
            return Promise.all([
                dispatch("loadBasicInfo"),
                dispatch("loadParticipants")
            ])
        },
        async loadBasicInfo({rootState, commit}){
            let envelopeWsid = rootState.envelopeWsid
            try {
                let basicInfo = await getEnvelopeData({ envelopeWsid }).then(res => res.data.data.envelope.basicInfo)
                commit("setEnvelopeBasicInfo", basicInfo)
            } catch (err){
                if (err.response && err.response.data.code === 101){
                    throw new Error("ERROR_NOT_IN_ENVELOPE_FLOW")
                } else {
                    throw err
                }
            }
        },
        async loadParticipants({rootState, commit}){
            let envelopeWsid = rootState.envelopeWsid
            let participants = await getEnvelopeParticipants({
                envelopeWsid
            }).then(res => {
                return translateParticipantDatasFromEnd(res.data.data.participants)
            })
            commit("setParticipants", participants)
        }
    }
}

export default moduleSignatureData