import userDataMoudle from "./user-data.js" //用户数据
import envelopeDataMoudle from "./envelope-data.js" //用户数据

import { getSessionData } from "@interfaces/user/sessions.js"
import { USER_EDITION } from "@utils/users.js"

export default {
    state: {
        userWsid: ""
    },
    getters: {
        activeUserWsid(state){
            return state.userWsid
        },
        userWsid(state){
            return state.userWsid
        },
        userEdition(state){
            return USER_EDITION.getUserEditionByUserWsid(state.userWsid)
        },
        userAuthorWsidInEnvelope(state, getters){
            if (USER_EDITION.getUserEditionByUserWsid(state.userWsid) === USER_EDITION.ENTERPRISE){
                return getters.memberWsid
            } else {
                return getters.userWsid
            }
        }
    },
    mutations: {
        setEnvelopeWsid(state, envelopeWsid){
            state.envelopeWsid = envelopeWsid
        },
        setUserWsid(state, userWsid){
            state.userWsid = userWsid
        }
    },
    actions: {
        async init({commit, getters, dispatch}, { envelopeWsid }){
            let session = await getSessionData().then(res => res.data.data.session)
            let activeUserWsid = session.userWsid

            commit("setEnvelopeWsid", envelopeWsid)
            commit("setUserWsid", activeUserWsid)
            await dispatch("initUserData")
        }
    },
    modules: {
        userData: userDataMoudle,
        envelopeData: envelopeDataMoudle
    }
}