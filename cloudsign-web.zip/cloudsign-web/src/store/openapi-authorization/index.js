
// import { LoginLocalStatus } from "@classes/login/login-info.js"
import { AUTH_STATUS} from "@classes/openapi-authorization/index.js"
import { getVerifications, getVerificationInfo, personAuth } from '@interfaces/auth/auth.js'
import { _assignObjectWithSrcProperties } from '@commons/util.js'
const ACTIVE_TIME = 1000 * 60 * 30//活动时间 半小时
import { MessageBox } from "element-ui"
export default {
    state: {
        ctivity: true, //是否处于活动状态
        authType: "",
        bank: "",
        bankBranch: "",
        bankCardNo: "",
        businessLicenceImageCode: "",
        businessLicenceImageName: "",
        businessLicenceImageUrl: "",
        businessLicenceImageFileWsid: "",
        idCardNo: "",
        idCardType: "",
        name: "",
        phone: "",
        trustInstrumentImageCode: "",
        trustInstrumentImageFileWsid: "",
        trustInstrumentImageName: "",
        trustInstrumentImageUrl: "",
        unifiedSocialCode: "",
        enterpriseName: "",
        returnUrl: "",
        developerEnterpriseName: "",
        developerEnterpriseWsid: "",
        invokeNo: "",
        imageName: [],
        imageCode: [],
        imageFileWsid: [],
        imageUrl: [],
        authModes: [],
        authStatus: AUTH_STATUS.INCOMPLETE,
        description: "",
        idttvWsid: "",
        currentAuthMethod:"",
        idcardUperUrl:"",
        idcardLowerUrl:"",
        userWsid:"",
        activeUserWsid:""
    },
    mutations: {
        check_user_active(state, getters){
            let nowDate = Date.now()
            if (getters.login && nowDate - getters.lastActiveTime > ACTIVE_TIME) { //30分钟超时
                state.activity = false
            } else {
                state.activity = true
            }
        },
        user_logout: (state, autoJump = true) => {
            //清除session数据
            sessionStorage.clear()
            state.loginLocalStatus.setLogin(false)
            state.loginLocalStatus.setUserWsid("")
            state.loginLocalStatus.setActiveUserWsid("")
        },
        setUserWsid(state, userWsid){
            state.userWsid = userWsid
        },
        setActiveUserWsid(state, activeUserWsid){
            state.activeUserWsid = activeUserWsid
        },
        setAuthStatus(state, authStatus){
            state.authStatus = authStatus
        },
        setAuthIdttvWsid(state,idttvWsid){
            state.idttvWsid = idttvWsid
        },
        setDescription(state, description){
            state.description = description
        },
        setCurrentAuthMethod(state,currentAuthMethod){
            state.currentAuthMethod = currentAuthMethod
        },
        loadURLData(state, data){
            state.authType = data.authType
            state.bank = data.bank
            state.bankBranch = data.bankBranch
            state.bankCardNo = data.bankCardNo
            state.businessLicenceImageCode = data.businessLicenceImageCode
            state.businessLicenceImageName = data.businessLicenceImageName
            state.businessLicenceImageUrl = data.businessLicenceImageUrl
            state.businessLicenceImageFileWsid = data.businessLicenceImageFileWsid
            state.idCardNo = data.idCardNo
            state.idCardType = data.idCardType
            state.name = data.name
            state.phone = data.phone
            state.trustInstrumentImageCode = data.trustInstrumentImageCode
            state.trustInstrumentImageFileWsid = data.trustInstrumentImageFileWsid
            state.trustInstrumentImageName = data.trustInstrumentImageName
            state.trustInstrumentImageUrl = data.trustInstrumentImageUrl
            state.unifiedSocialCode = data.unifiedSocialCode || data.registCode
            state.enterpriseName = data.enterpriseName
            state.returnUrl = data.returnUrl
            state.developerEnterpriseName = data.developerEnterpriseName
            state.developerEnterpriseWsid = data.developerEnterpriseWsid,
            state.invokeNo = data.invokeNo,
            state.imageName = data.imageName,
            state.imageCode = data.imageCode,
            state.imageFileWsid = data.imageFileWsid,
            state.imageUrl = data.imageUrl
            if(data.authModes!==undefined ){
                if(data.authModes.indexOf(",")!= -1 ){ 
                    state.authModes = data.authModes.split(",")
                } else {
                    state.authModes.push(data.authModes) 
                }
            } else {
                state.authModes.push("PHONE_AUTH") 
            }
        }
    },
    actions: {
        async updateModule({commit,state, dispatch}) {
            return dispatch("updateAuthData")
        },
        updateAuthData({commit,state, getters, dispatch}) {
            let userWsid = state.userWsid
            return getVerifications({
                filters: `author_wsid=${userWsid}` //FIXME: 后端目前只支持下划线
            }).then(body => {
                if (body.data.data.identities[0]){
                    commit("setAuthIdttvWsid", body.data.data.identities[0].wsid)
                    commit("setAuthStatus", body.data.data.identities[0].status)
                    return dispatch("updateAuthInfo")
                } else {
                    return dispatch("createUserAuth")
                }
            })
        },
        updateAuthInfo({commit,getters,state}) {
            let idttvWsid = state.idttvWsid
            return getVerificationInfo({
                identityWsid:idttvWsid
            }).then(body => {
                let identity = body.data.data.identity
                commit("setAuthStatus", identity.status)
                if(identity.status!== "INCOMPLETE"){
                    state.currentAuthMethod = identity.authMode
                    state.name = identity.info.name
                    state.idCardNo = identity.info.idCardNo
                    state.phone = identity.info.phone
                    state.description = identity.description
                }
                state.idcardUperUrl = identity.info.idcardUperUrl
                state.idcardLowerUrl = identity.info.idcardLowerUrl
                // commit("setCurrentAuthMethod", body.data.data.identity.authMode)
                _assignObjectWithSrcProperties(state, body.data.data.identity, 1)
            })
        },
        createUserAuth({state, getters, dispatch}) {
            let userWsid = state.userWsid
            return personAuth({
                authorWsid:userWsid,
                fromTag: state.developerEnterpriseWsid,
                invokeNo: state.invokeNo
            }).then(body => {
                let idttvWsid =  body.data.data.identity.wsid
                state.idttvWsid =  idttvWsid
                return dispatch("updateAuthInfo")
            })
        },
        updateUserActive({ state, dispatch}){
            state.loginLocalStatus.updateLastActiveTime()
            dispatch("checkUserActive")
        },
        checkUserActive({ state, dispatch }){ //循环检测是否长时间未活动
            if (state.activeCheckHandle) clearTimeout(state.activeCheckHandle)
            state.activeCheckHandle = setTimeout(() => {
                dispatch("userNotActive")
            }, ACTIVE_TIME)
        },
        userNotActive({commit, state}){
            state.activity = false
            MessageBox.alert("由于长时间无操作，为了您的帐号安全，与服务器的连接已断开，请重新登录", "断开连接", {
                confirmButtonText: "确定",
                type: "warning"
            })
        }
    }
}

// export default storeConfig