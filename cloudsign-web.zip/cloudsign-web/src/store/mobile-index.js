import moudle_userData from "@store/modules/userdata.js" //用户数据
import moudle_userEnterprise from "@store/modules/userenterprise.js" //用户企业数据
import moudle_userAuth from "@store/modules/userauth.js" //认证状态
import moudle_userAccounts from "@store/modules/useraccounts.js" //用户账户
import moudle_localStorage from "@store/modules/localstorage.js" //本地存储
import module_userPermissionData from "@store/modules/userpermission.js"

import { getSessionData, session_logout } from "@interfaces/user/sessions.js"
import { LoginLocalStatus } from "@classes/login/login-info.js"

import { MessageBox } from "mint-ui"

const ACTIVE_TIME = 1000 * 60 * 50//活动时间 半小时
const LOOP_TIME = 1000 * 2//循环检测/存储时间

export default {
    state: {
        loginLocalStatus: new LoginLocalStatus(),
        activity: true //是否处于活动状态
    },
    getters: {
        userWsid(state) {
            return state.loginLocalStatus.userWsid
        },
        activeUserWsid(state) {
            return state.loginLocalStatus.activeUserWsid || state.loginLocalStatus.userWsid
        },
        lastActiveTime(state){
            return state.loginLocalStatus.lastActiveTime
        },
        login(state) {
            return state.loginLocalStatus.login
        },
        userEdition(state, getters) { //用户所处版本  'p' 个人版 'e'企业版
            if (/^WSID_PUSR/.test(getters.activeUserWsid)){
                return "p"
            } else {
                return "e"
            }
        }
    },
    mutations: {
        setActiveUserWsid (state, id){
            state.loginLocalStatus.setActiveUserWsid(id)
        },
        user_login: (state, userWsid ) => {
            state.loginLocalStatus.setLogin(true)
            if (userWsid) state.loginLocalStatus.setUserWsid(userWsid)
        },
        user_logout: state => {
            state.loginLocalStatus.setLogin(false)
            state.loginLocalStatus.setUserWsid("")
            state.loginLocalStatus.setActiveUserWsid("")
            //清除session数据
            sessionStorage.clear()
            location.href = "/login"
        },
        update_user_active: state => {
            state.lastActiveTime = Date.now()
        },
        check_user_active(state, getters){
            let nowDate = Date.now()
            if (getters.login && nowDate - getters.lastActiveTime > ACTIVE_TIME) { //30分钟超时
                state.activity = false
            } else {
                state.activity = true
            }
        }
    },
    actions: {
        async init({ state, commit, dispatch, getters }){ //状态树初始化
            await getSessionData().then(res => {
                let session = res.data.data.session
                //免登陆状态不能进入系统
                if (session.sessionScopes && session.sessionScopes.length > 0){
                    throw new Error("ERROR_CANT_USE_FREE_LOGIN")
                }
                commit("setActiveUserWsid", res.data.data.session.userWsid)
                return true
            }).catch(_ => {
                commit("user_logout", false)
                throw new Error("ERROR_NOT_LOGIN")
            })
            
            //检测数据是否正确
            await dispatch("updateModule").then(_ => {
                commit("user_login")
                return true
            }).catch(err => {
                commit("user_logout")
                throw new Error("ERROR_LOAD_DATA")
            })

            //检测是否在目前这个企业当中
            let userAccounts = getters.userAccounts
            let userWsid = getters.activeUserWsid
            let userAccount = userAccounts.find(acount => acount.userWsid === userWsid)
            if (!userAccount || userAccount.memberStatus === "DISABLED"){
                await dispatch("changeUserAccount", getters.puserWsid)
                MessageBox.alert("您已经被企业管理员从该企业移除，无法进入该企业内部,将返回个人主页", "提醒", {
                }).then(_ => {}, _ => {}).then(_ => {
                    //TODO: 跳转
                    location.href = "/wesign"
                })
            }

            //检测是否处于活动状态
            dispatch("checkUserActive")
        },
        async user_login({ state, commit, dispatch }, {
                accountNumber,
                password,
                verificationCode = ""
            }){
            
            return sessions_post({
                accountNumber,
                password,
                verificationCode,
                loginType: "WEB"
            }).then(body => {
                let data = body.data
                state.login = true
                commit("user_login")
                commit("setUserWsid", data.session.userWsid)
                return dispatch("updateModule")
            }).catch(err => {
                console.error(err)
                return Promise.reject(err)
            })
        },
        async user_logout({ state, commit, dispatch }){
            return session_logout().then(data => {
                commit("user_logout")
                commit("setUserWsid", "")
            }).catch(err => {
                console.error(err)
                commit("user_logout")
                commit("setUserWsid", "")
            })
        },
        checkUserActive({ state, commit, getters, dispatch }){ //循环检测是否长时间未活动
            setInterval(() => {
                if (!state.activity){
                    return
                }
                commit("check_user_active", getters)
                if (!state.activity){
                    MessageBox.alert("由于长时间无操作，与服务器的连接已断开，请重新登录", "断开连接", {
                        confirmButtonText: "确定",
                        callback: action => {
                            commit("user_logout")
                        },
                        type: "warning"
                    })
                }
            }, LOOP_TIME)

        },
       
    },
    modules: {
        userdata: moudle_userData,
        userenterprise: moudle_userEnterprise,
        // userauth: moudle_userAuth,
        useraccounts: moudle_userAccounts,
        localstorage: moudle_localStorage,
        userPermission: module_userPermissionData
    }
}