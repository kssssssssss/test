import { getUserData, setSignPassword, resetSignPassword } from "@interfaces/user/user.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"

function initData(){
    return {
        accountStatus: "INACTIVE", //用户激活状态
        userWsid: "", //用户PUSERID
        nickname: "", //用户昵称
        realName: "", //用户真实姓名
        idttvStatus: "NO", //认证状态 INCOMPLETE-未完善；PASSED-认证通过；WAITING-等待认证；DENY-认证未通过；EXPIRED-过期"
        phone: "",
        email: "",
        wechat: "",
        avatarHref: {
            href: ""
        },
        userType: "", //PERSON 个人账户，ENTE_OWNER 企业拥有者 ；ENTE_MEMBER 企业成员 ；ADMIN 系统用户
        sex: "", //性别
        registDatetime: 0, //注册时间
        lastLoginIp: "0.0.0.0", //上次登录IP
        lastLoginDatetime: 0, //上次登录时间
        modifiedDatetime: 0, //上次修改时间
        existSignPassword: false, //是否存在签署密码
        userEnterpriseWsid: "",
        enterpriseRoles: [],
    }
}

const module_userData = {
    state: initData(),
    getters: {
        userType(state) {
            return state.userType 
        },
        userName(state) {
            if (state.idttvStatus === "PASSED"){
                return state.realName
            }
            return state.nickname || state.phone || state.email
        },
        userContact(state){
            return state.phone || state.email
        },
        userPhone(state){
            return state.phone
        },
        userEmail(state){
            return state.email
        },
        puserWsid(state) {
            return state.userWsid
        },
        userIdttvWsid(state) {
            return state.idttvWsid
        },
        userIddtvStatus(state) {
            return state.idttvStatus || "NO"
        },
        userNeedAuth(state) {
            if (state.idttvStatus === "PASSED"
                || state.idttvStatus === "WAITING"){
                return false
            } else {
                return true
            }
        }
    },
    mutations: {
        updateUserAvatar(state, userData) { //更新用户头像
            state.avatarHref.href = userData
        },
        setSignPasswordSuccess(state){
            state.existSignPassword = true
        }
    },
    actions: {
        async updateModule ({dispatch}){
            await dispatch("updateUserData")
            return dispatch("updateUserCharge")
        },
        async updateUserData({ state, dispatch, getters, commit }){
            let userWsid = getters.activeUserWsid
            let userEdition = getters.userEdition
            
            let userInfo = await getUserData({
                userWsid
            }).then(res => res.data.data.userInfo)

            commit("user_login", userInfo.user.userWsid)
            commit("setEnterpriseData", userInfo || {})
            await dispatch("getEnterpriseContractNumberStutas")

            Object.assign(state, initData(), userInfo.user)
            
            if (userEdition === "e"){
                let enterpriseRoles = await getUserRoles({ authorWsid: userWsid }).then(res => res.data.data.enterpriseRoles)
                state.enterpriseRoles = enterpriseRoles
            }

            return dispatch("getUserPermissions")
        },
        updateSignPassword({state, commit}, data){
            let userWsid = state.userWsid
            if (state.existSignPassword){
                return resetSignPassword({
                    userWsid,
                    oldSignPassword: data.oldSignPassword,
                    newSignPassword: data.newSignPassword
                }).then(_ => {
                    commit("setSignPasswordSuccess")
                })
            } else {
                return setSignPassword({
                    userWsid,
                    signPassword: data.newSignPassword
                }).then(_ => {
                    commit("setSignPasswordSuccess")
                })
            }
        }
    }
}

export default module_userData
