import { labels_get,
         specificLabel_delete,
         specificLabel_put,
         labels_post } from '@interfaces/labels/labels.js'
import { getLabels,
         delLabels,
         putLabels,
         postLabels } from '@interfaces/labels/labels.js'

const module_userLabels = {
    state: {
        labels: []
    },
    actions: {
        // async updateModule ({dispatch}){
        //     return dispatch("updateData")
        // },
        updateData({state}){
            labels_get({}).then(res => {
                state.labels = res.labels
            }).catch(err => {
                console.error(err)
            })
        },
        'labels-delete'({state}, {labelWsid}){      //TODO: 1.等待mock数据或实际微服务; 2.将标签从所有信封中删除
            return specificLabel_delete({
                labelWsid
            }).then(() => {
                let index = state.labels.findIndex(data => data.labelWsid === labelWsid)
                state.labels.splice(index, 1)
            })
        },
        'labels-update'({state}, {label}){
            return putLabels({label}).then(() => {
                let index = state.labels.findIndex(data => data.labelId === label.labelId)
                Object.assign(state.labels[index], label)
            })
        },
        'labels-create'({state}, {label}){
            return postLabels({label}).then(data => {
                state.labels = state.labels.concat(data.labels)
            })
        }
    }
}

export default module_userLabels
