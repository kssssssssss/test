import { getUserAccounts, changeSession } from "@interfaces/user/user.js"
import { MessageBox, Message } from "element-ui"

const module_userAuth = {
    state: {
        accounts: [],
        loading: false, //加载账户中
    },
    getters: {
        userAccounts(state) {
            return state.accounts
        },
        userAccountsCount(state) {
            return state.accounts.length
        },
        userAccountsLoading(state) {
            return state.loading
        },
        selectUserAccount(state, getters) {
            let userWsid = getters.userWsid
            let accounts = state.accounts

            return accounts.find(account => {
                return account.userWsid === userWsid
            })
        }
    },
    mutations: {
        setUserAccounts(state, accounts) {
            state.accounts = accounts
        },
    },
    actions: {
        async updateModule ({dispatch}){
            return dispatch("updateUserAccounts")
        },
        updateUserAccounts: ({dispatch, commit, getters, state }) => {
            let userWsid = getters.activeUserWsid
            return getUserAccounts({
                userWsid,
                limit: 10000
            }).then(res => {
                let body = res.data
                if (body.data.accounts.length === 1){ //只有个人账户
                    commit("setActiveUserWsid", userWsid)
                }
                let accounts = body.data.accounts
                if (accounts.every(account => account.defaultLogin === false)){ //后台在全部企业不是defaultLogin的时候，个人也是false，将个人设为true
                    accounts.find(account => account.userType === "PERSON").defaultLogin = true
                }
                commit("setUserAccounts", accounts)
                // dispatch("loadAllAcount", body.data.page.totalElements - 5)
            }).catch(err => {
                console.error(err)
                return Promise.reject(err)
            })
        },
        async changeUserAccount({ commit, getters, dispatch }, destinationWsid){
            let userWsid = getters.activeUserWsid
            if (userWsid === destinationWsid) {
                return
            }
            await changeSession({
                userWsid,
                destinationWsid
            })
            commit("setActiveUserWsid", destinationWsid)
            await dispatch("updateUserData")
            await dispatch("updateUserCharge")
        },
        // async loadAllAcount({commit, getters, state }, number){
        //     let userWsid = getters.activeUserWsid
        //     let offset = 0
        //     state.loading = true
        //     while (number > 0){
        //         let limit = number > 5 ? 5 : number
        //         number -= 5
        //         offset += 5

        //         await getUserAccounts({
        //             userWsid,
        //             limit: limit,
        //             offset: offset
        //         }).then(res => {
        //             let body = res.data
        //             commit("setUserAccounts", state.accounts.concat(body.data.accounts))
        //         })
        //     }
        //     state.loading = false
        // }
    }
}

export default module_userAuth