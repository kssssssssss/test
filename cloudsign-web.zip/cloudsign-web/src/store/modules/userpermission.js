import {getPermissionLists} from "@interfaces/policy/permission.js"

//前端权限对象
class FrontPermissions{
    //传入后端的权限列表,和用户版本(个人,企业)
    constructor(permissionsList, userEdition, enterpriseOwner){
        this.permissionsList = permissionsList
        this.userEdition = userEdition
        this.enterpriseOwner = enterpriseOwner
        
        let map = {}
        permissionsList.forEach(el => {
            map[el.permissions] = el
        })
        this.permissionsMap = map
    }

    //获取全部信封的页面
    get PAGE_ENTERPRISE_ENVELOPE_ALL(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:envelopes:view"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //业务模板页面
    get PAGE_TEMPLATES(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if ((map["businessScenarioTemplates:use"] || map["businessScenarioTemplates:manage"]) && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //已启用模板页面
    get PAGE_TEMPLATES_ENABLE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:use"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //未启用模板页面
    get PAGE_TEMPLATES_UNABLE(){ //未启用场景
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:manage"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //已停用场景模板页面
    get PAGE_TEMPLATES_DISABLE(){ 
        return this.PAGE_TEMPLATES_UNABLE
    } 

    //使用模板功能
    get TEMPLATE_USE(){ 
        return this.PAGE_TEMPLATES_ENABLE
    }

    //创建模板功能
    get TEMPLATE_CREATE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:create"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //编辑模板功能
    get TEMPLATE_EDIT(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:{wsid}:update"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //模板重命名功能
    get TEMPLATE_RENAME(){
        return this.TEMPLATE_EDIT
    }

    //模板删除功能
    get TEMPLATE_DELETE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:{wsid}:recycled"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    
    //模板停用功能
    get TEMPLATE_DISABLE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:{wsid}:disable"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //模板启用功能
    get TEMPLATE_ENABLE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["businessScenarioTemplates:{wsid}:enable"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //管理员公章管理页面
    get PAGE_SEALS_MANAGEMENT(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:manage"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    
    //创建公章功能
    get SEAL_CREATE(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:formUpload"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章重命名
    get SEAL_NAME_MODIFY(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:{wsid}:name:update"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章废弃
    get SEAL_ABANDON(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:{wsid}:abandon"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章转移（单个公章转移、分组转移）
    get SEAL_TRANSLATE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:groups:{wsid}:move"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章编辑功能
    get SEAL_EDIT(){ //公章编辑(废弃、转移、重命名)
        return this.SEAL_NAME_MODIFY || this. SEAL_ABANDON || this.SEAL_TRANSLATE
    }

    //公章分组创建
    get SEAL_GROUP_CREATE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:groups:create"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    
    //公章分组重命名
    get SEAL_GROUP_NAME_MODIFY(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:groups:{wsid}:name:update"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    //公章分组删除
    get SEAL_GROUP_DELETE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:groups:{wsid}:delete"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章分组操作功能
    get SEAL_GROUP_OPERATION(){ 
        return this.SEAL_GROUP_CREATE || this.SEAL_GROUP_NAME_MODIFY || this.SEAL_TRANSLATE || this.SEAL_GROUP_DELETE
    }

    //公章授权功能
    get SEAL_AUTHORIZE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:{wsid}:authorize"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //查看公章所有使用记录功能
    get SEAL_USE_ALL_LOGS(){
        return this.PAGE_SEALS_MANAGEMENT
    }

    //申请使用公章功能
    get SEAL_APPLY(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:apply"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章审批页面
    get PAGE_SEALS_AUDIT(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:applications:approve:view"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章授权撤销
    get SEALS_AUDIT_CANCEL(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:{wsid}:authorize:cancel"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //公章申请处理（通过、不通过）
    get SEALS_APPLICATIONS_HANDLE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["officeSeals:applications:handle"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //创建部门
    get DEPARTMENT_CREATE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:departments:create"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    //修改部门名称等
    get DEPARTMENT_UPDATE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:departments:{wsid}:update"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    } 

    //删除部门
    get DEPARTMENT_DELETE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:departments:{wsid}:delete"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    //邀请成员(单个成员邀请为通用权限)
    // get MEMBER_INVITE(){
    //     let map = this.permissionsMap
    //     let userEdition = this.userEdition

    //     if (map["enterprises:{wsid}:members:invite"] && userEdition === "e"){
    //         return true
    //     } else {
    //         return false
    //     }
    // }
   
    //部门成员转移(单个、批量)
    get DEPARTMENT_MEMBER_TRANSFER(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if ((map["enterprises:{wsid}:departments:{wsid}:members:{wsid}:transfer"] 
        || map["enterprises:{wsid}:departments:{wsid}:members:transfer"] 
        || map["enterprises:{wsid}:departments:{wsid}:members:transfer"]) && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //批量成员导出
    get MEMBER_BATCH_EXPORT(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:batchExport"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    ///批量成员导入
    get MEMBER_BATCH_IMPORT(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:batchImport"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //批量导入/导出模板下载
    get MEMBER_TEMPLATE_DOWNLOAD(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:batchTemplates:download"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    
    //批量成员更新(成员启用、禁用、信息修改)
    get MEMBER_INFO_UPDATE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:update"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //成员邀请信息审核
    get MEMBER_APPLICATION_HANDLE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:applications:handle"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //成员邀请信息删除
    get MEMBER_INVITATION_DELETE(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:invitations:{wsid}:delete"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    
    //邀请链接开关
    get MEMBER_INVITATION_SWITCH(){
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterprises:{wsid}:members:invitations:{wsid}:links:switch"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //成员管理——企业成员页面 
    // get PAGE_ENTERPRISE_MEMBERS(){ 
    //     let map = this.permissionsMap
    //     let userEdition = this.userEdition

    //     if (map["enterprises:{wsid}:departments:{wsid}:members:view"] && userEdition === "e"){
    //         return true
    //     } else {
    //         return false
    //     }
    // }

    //具有企业管理权限 
    get ENTERPRISE_MEMBERS_MANAGEMENT(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["members:manage"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //成员管理——待审核成员页面 
    get PAGE_ENTERPRISE_MEMBERS_INVITATION(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (this.MEMBER_APPLICATION_HANDLE && userEdition === "e"){
            return true
        } else {
            return false
        }
       
    }
    //成员管理——禁用成员页面 
    get PAGE_ENTERPRISE_MEMBERS_FORBIDDEN(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (this.MEMBER_INFO_UPDATE && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    
    //角色与权限页面
    get PAGE_ROLES_MANAGEMENT(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["privileges:manage"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    //角色绑定
    get ROLES_AUTHORS_BLIND(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterpriseRoles:{wsid}:authors:bind"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    //角色解绑
    get ROLES_AUTHORS_UNBLIND(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["enterpriseRoles:{wsid}:authors:delete"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }

    //合同编号页面
    get PAGE_CONTRACT_NUMBER_SETTING(){
        let map = this.permissionsMap
        let userEdition = this.userEdition
        if (map["enterprises:{wsid}:contractNumbers:set"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
    //应用管理页面
    get PAGE_APPLICATIONS_MANAGEMENT(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition
        let enterpriseOwner = this.enterpriseOwner

        if (map["applications:manage"] && userEdition === "e" && enterpriseOwner){
            return true
        } else {
            return false
        }
    }

    //账单管理
    get PAGE_FINANCE_MANAGEMENT(){ 
        let map = this.permissionsMap
        let userEdition = this.userEdition

        if (map["bills:manage"] && userEdition === "e"){
            return true
        } else {
            return false
        }
    }
}


//用户权限相关
const module_userPermissionData = {
    state(){
        return {
            permissions: new FrontPermissions([], "p", false),
        }
    },
    getters: {
        PAGE_ENTERPRISE_ENVELOPE_ALL(state, getters){ //全部文件页
            return state.permissions.PAGE_ENTERPRISE_ENVELOPE_ALL
        },
        PAGE_TEMPLATES(state, getters){ //模板页面
            return state.permissions.PAGE_TEMPLATES
        },
        PAGE_TEMPLATES_ENABLE(state, getters){ //已启用场景 
            return state.permissions.PAGE_TEMPLATES_ENABLE
        },
        PAGE_TEMPLATES_UNABLE(state, getters){ //未启用场景
            return state.permissions.PAGE_TEMPLATES_UNABLE
        },
        PAGE_TEMPLATES_DISABLE(state, getters){ //已停用场景
            return state.permissions.PAGE_TEMPLATES_DISABLE
        },
        TEMPLATE_USE(state, getters){ //使用模板
            return state.permissions.TEMPLATE_USE
        },
        TEMPLATE_CREATE(state, getters){ //创建模板
            return state.permissions.TEMPLATE_CREATE
        },
        TEMPLATE_EDIT(state, getters){ //编辑模板
            return state.permissions.TEMPLATE_EDIT
        },
        TEMPLATE_RENAME(state, getters){ //模板重命名
            return state.permissions.TEMPLATE_RENAME
        },
        TEMPLATE_DELETE(state, getters){ //模板删除
            return state.permissions.TEMPLATE_DELETE
        },
        TEMPLATE_DISABLE(state, getters){ //模板停用
            return state.permissions.TEMPLATE_DISABLE
        },
        TEMPLATE_ENABLE(state, getters){ //模板启用
            return state.permissions.TEMPLATE_ENABLE
        },
        PAGE_SEALS_MANAGEMENT(state, getters){ //管理员公章管理页面
            return state.permissions.PAGE_SEALS_MANAGEMENT
        },
        SEAL_CREATE(state, getters){ //创建公章
            return state.permissions.SEAL_CREATE
        },
        SEAL_NAME_MODIFY(state, getters){ //公章重命名
            return state.permissions.SEAL_NAME_MODIFY
        },
        SEAL_ABANDON(state, getters){ //公章废弃
            return state.permissions.SEAL_ABANDON
        },
        SEAL_TRANSLATE(state, getters){ //公章转移
            return state.permissions.SEAL_TRANSLATE
        },
        SEAL_EDIT(state, getters){ //公章编辑(废弃、转移、重命名等)
            return state.permissions.SEAL_EDIT
        },
        SEAL_GROUP_CREATE(state, getters){ //公章分组创建
            return state.permissions.SEAL_GROUP_CREATE
        },
        SEAL_GROUP_NAME_MODIFY(state, getters){ //公章分组名称修改
            return state.permissions.SEAL_GROUP_NAME_MODIFY
        },
        SEAL_GROUP_DELETE(state, getters){ //公章分组删除
            return state.permissions.SEAL_GROUP_DELETE
        },
        SEAL_GROUP_OPERATION(state, getters){ //公章分组操作
            return state.permissions.SEAL_GROUP_OPERATION
        },
        SEAL_AUTHORIZE(state, getters){ //公章授权
            return state.permissions.SEAL_AUTHORIZE
        },
        SEAL_USE_ALL_LOGS(state, getters){ //查看公章所有使用记录
            return state.permissions.SEAL_USE_ALL_LOGS
        },
        SEAL_APPLY(state, getters){ //申请使用公章
            return state.permissions.SEAL_APPLY
        },
        PAGE_SEALS_AUDIT(state, getters){ //公章审批页面
            return state.permissions.PAGE_SEALS_AUDIT
        },
        SEALS_AUDIT_CANCEL(state, getters){ //公章授权撤销
            return state.permissions.SEALS_AUDIT_CANCEL
        },
        SEALS_APPLICATIONS_HANDLE(state, getters){ //公章申请处理（通过、不通过）
            return state.permissions.SEALS_APPLICATIONS_HANDLE
        },
        DEPARTMENT_CREATE(state, getters){ //部门创建
            return state.permissions.DEPARTMENT_CREATE
        },
        DEPARTMENT_UPDATE(state, getters){ //修改部门名称等
            return state.permissions.DEPARTMENT_UPDATE
        },
        DEPARTMENT_DELETE(state, getters){ //删除部门名称等
            return state.permissions.DEPARTMENT_DELETE
        },
        MEMBER_INVITE(state, getters){ //邀请成员
            return state.permissions.MEMBER_INVITE
        },
        DEPARTMENT_MEMBER_TRANSFER(state, getters){ //成员转移
            return state.permissions.DEPARTMENT_MEMBER_TRANSFER
        },
        MEMBER_BATCH_EXPORT(state, getters){ //批量导入成员
            return state.permissions.MEMBER_BATCH_EXPORT
        },
        MEMBER_BATCH_IMPORT(state, getters){ //批量导出成员
            return state.permissions.MEMBER_BATCH_IMPORT
        },
        MEMBER_TEMPLATE_DOWNLOAD(state, getters){ //下载模板
            return state.permissions.MEMBER_TEMPLATE_DOWNLOAD
        },
        MEMBER_INFO_UPDATE(state, getters){ //成员信息更新
            return state.permissions.MEMBER_INFO_UPDATE
        },
        MEMBER_APPLICATION_HANDLE(state, getters){ //成员邀请信息审核
            return state.permissions.MEMBER_APPLICATION_HANDLE
        },
        MEMBER_INVITATION_DELETE(state, getters){ //成员邀请信息删除
            return state.permissions.MEMBER_INVITATION_DELETE
        },
        MEMBER_INVITATION_SWITCH(state, getters){ //邀请链接开关
            return state.permissions.MEMBER_INVITATION_SWITCH
        },
        PAGE_ENTERPRISE_MEMBERS(state, getters){ //企业成员页面
            return state.permissions.PAGE_ENTERPRISE_MEMBERS
        },
        PAGE_ENTERPRISE_MEMBERS_INVITATION(state, getters){ //待审核成员页面
            return state.permissions.PAGE_ENTERPRISE_MEMBERS_INVITATION
        },
        PAGE_ENTERPRISE_MEMBERS_FORBIDDEN(state, getters){ //禁用成员页面
            return state.permissions.PAGE_ENTERPRISE_MEMBERS_FORBIDDEN
        }, 
        ENTERPRISE_MEMBERS_MANAGEMENT(state, getters){ //成员管理页面 
            return state.permissions.ENTERPRISE_MEMBERS_MANAGEMENT
        },
        PAGE_ROLES_MANAGEMENT(state, getters){ //角色与权限页面
            return state.permissions.PAGE_ROLES_MANAGEMENT
        },
        ROLES_AUTHORS_BLIND(state, getters){ //角色绑定
            return state.permissions.ROLES_AUTHORS_BLIND
        },
        ROLES_AUTHORS_UNBLIND(state, getters){ //角色解绑
            return state.permissions.ROLES_AUTHORS_UNBLIND
        },
        PAGE_CONTRACT_NUMBER_SETTING(state, getters){
            return state.permissions.PAGE_CONTRACT_NUMBER_SETTING
        },
        PAGE_APPLICATIONS_MANAGEMENT(state, getters){ //应用管理
            return state.permissions.PAGE_APPLICATIONS_MANAGEMENT
        },
        PAGE_FINANCE_MANAGEMENT(state, getters){ //账单管理
            return state.permissions.PAGE_FINANCE_MANAGEMENT
        },
    },
    actions: {
        async getUserPermissions({dispatch, commit, getters, state, rootState }){
            let userEdition = getters.userEdition
            let enterpriseOwner = false
            if (rootState.userdata.enterpriseRoles.findIndex(el => el.alias === "SUPER_ADMINISTRATOR") > -1){
                enterpriseOwner = true
            }
            if (userEdition === "e"){
                let userWsid = getters.activeUserWsid
                let permissionLists = await getPermissionLists({ userWsid }).then(res => res.data.data.privilegeList)
                state.permissions = new FrontPermissions(permissionLists, userEdition, enterpriseOwner)
            } else {
                state.permissions = new FrontPermissions([], userEdition, enterpriseOwner)
            }
        }
    }

}

export default module_userPermissionData