const STORAGE_NAME = "wesign_state"

const module_localstorage = {
    actions: {
        async saveToLocalStorage({ rootState }) { //保存数据
            let ls = window.localStorage
            let data = {
                login: rootState.login,
                userWsid: rootState.userWsid,
                lastActiveTime: rootState.lastActiveTime,
                activity: rootState.activity
            }
            ls && ls.setItem(STORAGE_NAME, JSON.stringify(data)) //把state里面的数据存入ls.wesignstate
        },
        async loadFromLocalStorage({ rootState }) { //加载数据
            let ls = window.localStorage
            let data = null

            if (ls){
                data = ls.getItem(STORAGE_NAME)
                try {
                    data = JSON.parse(data)
                } catch (e) {
                    data = null
                }
            } 
            
            return data
        }
    }
}

export default module_localstorage