
const module_envelopeDetailPath = {
    state: {
        sorcePath: ""
    },
    actions: {
        updatePathData({state}, path){
            state.sorcePath = path
        },
    }
}

export default module_envelopeDetailPath