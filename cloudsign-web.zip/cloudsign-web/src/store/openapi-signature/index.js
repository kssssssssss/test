let storeConfig = {
    state: {
        username: "",
        account: "",
        roleType: "", //ENTERPRISE_MEMBER ENTERPRISE_ROLE PERSON
        title: "",
        type: "", // SIGN CHECK VIEW
        envelopeWsid: "",
        enterpriseName: "",
        targetUserWsid: "",
        pageCallback: "",
        senderName: "",
        senderEnterpriseName: "",
        enableNoAppearance:"",  
        enableSimpleDisplay:"",
        appId:""
    },
    getters: {
        activeUserWsid(state){
            return state.targetUserWsid
        }
    },
    mutations: {
        loadURLData(state, data){
            state.username = data.username
            state.account = data.account
            state.roleType = data.roleType
            state.title = data.title
            state.type = data.type
            state.envelopeWsid = data.envelopeWsid
            state.enterpriseName = data.enterpriseName
            state.targetUserWsid = data.targetUserWsid
            state.senderName = data.senderName
            state.senderEnterpriseName = data.senderEnterpriseName
            state.pageCallback = data.pageCallback
            state.enableNoAppearance = data.enableNoAppearance
            state.enableSimpleDisplay = data.enableSimpleDisplay
            state.appId = data.appId
        }
    }
}

export default storeConfig