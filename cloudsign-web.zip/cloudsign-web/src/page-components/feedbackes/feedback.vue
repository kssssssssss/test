<template>
    <div class="sys-container-content">
		<div class="route">
			<div class="header-title">
				<i class="edit icon-edit"></i>
				<span>意见反馈</span>
			</div>
        </div>
        <div class="feedback">
            <P>反馈类型</p>
            <form>
                <label> <input type="radio" name="type" checked="checked">产品建议</label>
                <label> <input type="radio"  name="type">程序错误</label>
                <label> <input type="radio"  name="type">技术问题</label>
                <label><input type="radio"  name="type">其他</label>
                <p>详细描述</p>
                <textarea rows="10" cols="30"  @blur="feedbackInfo()" v-model="str" contenteditable="true" placeholder="详细说明你的意见和反馈，你的反馈将帮助我们更快的成长"></textarea>
            </form>
            <el-button type="info">发送</el-button>
        </div>
    </div>
</template>


<script>
export default{
	data:function(){
		return{
            str:''
        }
	},
    methods:{
        feedbackInfo:function(){
            let val = this.$data.str
        }
    }
}
</script>


<style lang="less" scoped>
@import '~@styles/user/feedback.less';
</style>