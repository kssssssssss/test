<template>
    <div class="purchase">
        <div class="route">
            <span class="header-title">购买支付</span>
        </div>
        <div class="purchase-content">
            <p class="con-title">购买文件数量</P>
            <div class="count">
                <ul class="file-count">
                    <li  v-for="(item,index) in items" v-on:click="change(item, index)" :class="{'active':flag ==index,'item.active':acitve}">{{item.part}}份/年<span class="momeny">{{item.price.toFixed(2)}}<em class="unit">元</em></span><i v-show="item.active" class="commend icon-commend"></i><i v-show="item.active"  class="selected icon-selected"></i></li>
                </ul>
                 
                 <div class="modified-count">
                   <span class="pub-title public">购买文件数量:</span>
                     <div class="el-number">
                        <el-input-number v-model="number" size="small" @change="handleChange" type="number" :max="1000" :min="1"></el-input-number>
                     </div>
                     <span>份</span>
                </div>
            </div>
           
            <div class="purchase-foot">
                <div class="payments">
                    <ul class="payment">
                        <li><span class="public">费用总计：</span><span class="momeny mount">{{total.toFixed(2)}}<em class="unit">元</em></span></li>
                        <li><span class="public">使用优惠码：</span><span>XCVBNMD<em class="unit">({{0.8}}折优惠)</em></span></li>
                        <li><span class="public">需支付：</span><span class="momeny">{{amount.toFixed(2)}}<em class="unit">元</em></span></li>
                    </ul>
                </div>
                <div class="way">
                    <p class="public">支付方式</p>
                    <ul>
                        <li v-bind:class="{active:zhifubaoActive}" @click="change_display('zhifubao')"><a href="#"><i class="zhifubao icon-zhifubao"></i><span>支付宝<em>ALIPAY</em></span></a><i v-show="zhifubaoActive" class="selected icon-selected"></i></li>
                        <li v-bind:class="{active:weixinActive}" @click="change_display('weixin')"><a class="weixin-buy" href="#"><i class="weixin icon-weixin"></i><span>微信支付</span></a><i v-show="weixinActive" class="selected icon-selected"></i></li>
                    </ul>
                    
                    <div class="btn"><a href="#">立即支付</a></div>
                </div>
                
            </div>
            
        </div>
        
    </div>
    
</template>


<script>
export default{
     data: function(){
           return{
            flag:0,
            num1: 5,
            zhifubaoActive:true,
            weixinActive:false,
            show:true,
            val:0.8,
            number:0,
            items:[
                {  
                    part:1,
                    price: 5, 
                    active:true
                } ,
                {   
                    part:5,
                    price: 25,
                    active:false
                },
                {   
                    part:10,
                    price: 50,
                    active:false
                },
                {   
                    part:50,
                    price: 250,
                    active:false
                },
                {   
                    part:100,
                    price: 500,
                    active:false
                }
            ]
           }
           
        },
    computed:{
        total(){
            return this.number * this.num1;
        },
        amount(){
            return this.number * this.num1 * this.val
        }
    },
   
    methods:{
      change_display:function(val){
            if(val == "zhifubao"){
                this.$data.zhifubaoActive = true
                this.$data.weixinActive = false
                this.$data.show=true
            }
            else if(val == "weixin"){
                this.$data.weixinActive = true
                this.$data.zhifubaoActive = false
                this.$data.show=true
            }
      },
      change: function(item, index){ 
          
                this.flag = index
                this.number = item.part;
                let total=0
                
                for(let i=0; i<this.items.length;i++){ //使用传入的当前的v-for循环的遍历项和当前索引
                    this.items[i].active = false;//将所有item设置为false
                    
                }
               
                this.items[index].active = true; //然后单独设;置选中的item为true
                 total=this.items[index].part * this.num1;
                 this.total = total
                },
            
    }
}
</script>


<style lang="less" scoped>
@import '~@styles/user/purchase-file.less';
</style>