<template>
    <div @click="cancleActiveForm">
        <div class="envelope-signature-header">
            <div class="documents-info-toolbar">
                <div class="tools-container">
                    <div class="documents-select">
                        <el-select :value="activeDocumentId" size="mini" @change="gotoDocument">
                            <el-option v-for="document in documents" :key="document.id" :value="document.id" :label="document.name"></el-option>
                        </el-select>
                    </div>
                    <div class="document-progress">
                        <span>
                            <el-input-number style="width:50px;" size="mini" :value="activePage" :min="1" :max="activeDocumentData.pagesCount"
                                :controls="false" @change="gotoPage"></el-input-number>
                        </span>
                        <span>/{{activeDocumentData.pagesCount}}</span>
                    </div>
                    <div class="documents-scale">
                        <i class="icon icon-reduce" style="margin-right:5px" @click="zoomOut"></i>
                        <el-select :value="documentPreviewScale" @input="scaleChange" style="width: 100px;" size="mini" placeholder="">
                            <el-option v-for="s in scaleList" :key="s" :value="s" :label="(s * 100 / CSS_UNITS).toFixed(0) + '%'"></el-option>
                        </el-select>
                        <i class="icon icon-enlarge" style="margin-left:5px" @click="zoomIn"></i>
                    </div>
                    <div v-if="userEdition === 'e'&&enableNoAppearance === 'false'">
                        <el-switch
                            :value="settingPagingSeal"
                            @input="changePagingSealStatus"
                            inactive-text="单页签章模式"
                            active-text="骑缝章模式">
                        </el-switch>
                    </div>
                </div>
            </div>
            <div class="envelope-signature-help" @click="signatureHelp">
                <i class="el-icon-question"></i>
                帮助
            </div> 
        </div>
        <div class="envelope-signature-container" element-loading-text="跳转中">
            <div class="left-container" v-if="enableNoAppearance === 'false'" :style="leftNormalContainerStyle">
                <div style="width: 200px">
                    <el-button class="btn-fast-find-signature" :style="customStyles" type="primary" @click="fastJump">快速定位签名域</el-button>
                    <div class="selectable-forms">
                        <div>拖拽签署项到文档区域</div>
                        <div class="form" @mousedown.stop="startDragForm('TEXT', $event)">文本框</div>
                        <div class="form" @mousedown.stop="startDragForm('DATE', $event)">日期框</div>
                    </div>
                    <div class="signatures-seals">
                        <div class="personal-sign">
                            <!-- <div class="title">
                                我的签名
                            </div> -->
                            <div v-if="personalSeal" class="signature" @mousedown="startDragSignature(personalSeal, $event)">
                                <imgBox :width="160" :height="60" :src="personalSeal.imageData"/>
                            </div>
                            <div v-else class="signature" @click="createSignature">
                                <i class="el-icon-plus"></i>点击添加签名
                            </div>
                        </div>
                        <div v-if="userEdition === 'e'" class="offical-seals">
                            <!-- <div class="title">
                                可用印章
                            </div> -->
                            <officalSealsList :enterpriseUserWsid="activeUserWsid" :sealScale="documentPreviewScale" 
                                :enterpriseWsid="enterpriseWsid"
                                @apply="applySeal" @place-paging-seal="placePagingSeal" :customStyles="customStyles">
                                <template slot="apply-text">前往管理系统申请印章</template>
                            </officalSealsList>
                        </div>
                    </div>
                </div>
            </div>
            <div class="fast-jump-container" :style="fastJumpContainerStyle">
                 <div class="view-box">
                    <div class="header">
                        <i class="el-icon-close close-nav" @click="fastJumpNavOpen = false"></i>
                    </div>
                    <div class="forms-info">
                        共<span class="count">{{allFormsCount}}</span>处签名项
                    </div>
                    <div class="documents-forms">
                        <collapse>
                            <collapseItem v-for="document in documents" :title="document.name" :key="document.key">
                                <template v-if="docFormsMapForJump[document.id].count">
                                    <div class="info-block" v-if="docFormsMapForJump[document.id].SIGN">
                                        <div class="info-title">
                                            签名位置：
                                        </div>
                                        <div class="info" v-for="form in docFormsMapForJump[document.id].SIGN" :key="form.random">
                                            <div class="page">第{{form.page}}页</div>
                                            <div class="jump" @click.stop="jumpToForm(form)">移动到</div>
                                            <div class="status" :class="{signed:form.data}">
                                                <span>{{form.data?'已':'未'}}签署</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-block" v-if="docFormsMapForJump[document.id].SEAL">
                                        <div class="info-title">
                                            盖章位置：
                                        </div>
                                        <div class="info" v-for="form in docFormsMapForJump[document.id].SEAL" :key="form.random">
                                            <div class="page">第{{form.page}}页</div>
                                            <div class="jump" @click.stop="jumpToForm(form)">移动到</div>
                                            <div class="status" :class="{signed:form.data}">
                                                <span>{{form.data?'已':'未'}}签署</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-block" v-if="docFormsMapForJump[document.id].MULTI_CHECK_MARK">
                                        <div class="info-title">
                                            骑缝章：
                                        </div>
                                        <div class="info" v-for="form in docFormsMapForJump[document.id].MULTI_CHECK_MARK" :key="form.random">
                                            <div class="page">右侧</div>
                                            <div class="jump" @click.stop="jumpToForm(form)">移动到</div>
                                            <div class="status" :class="{signed:form.sealData}">
                                                <span>{{form.sealData?'已':'未'}}签署</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-block" v-if="docFormsMapForJump[document.id].TEXT">
                                        <div class="info-title">
                                            文本：
                                        </div>
                                        <div class="info" v-for="form in docFormsMapForJump[document.id].TEXT" :key="form.random">
                                            <div class="page">第{{form.page}}页</div>
                                            <div class="jump" @click.stop="jumpToForm(form)">移动到</div>
                                            <div class="status" :class="{signed:form.data}">
                                                <span>{{form.data?'已':'未'}}签署</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-block" v-if="docFormsMapForJump[document.id].DATE">
                                        <div class="info-title">
                                            日期：
                                        </div>
                                        <div class="info" v-for="form in docFormsMapForJump[document.id].DATE" :key="form.random">
                                            <div class="page">第{{form.page}}页</div>
                                            <div class="jump" @click.stop="jumpToForm(form)">移动到</div>
                                            <div class="status" :class="{signed:form.data}">
                                                <span>{{form.data?'已':'未'}}签署</span>
                                            </div>
                                        </div>
                                    </div>
                                </template>
                                <div v-else style="text-align:center; height: 30px; line-height: 30px">
                                    暂无签署项
                                </div>
                            </collapseItem>
                        </collapse>
                    </div>
                    <div v-if="formsType['SIGN']" class="forms-bottom">
                        <el-button :style="customStyles" type="primary" @click="allSignForm">一键签名</el-button>
                        <el-tooltip placement="top">
                            <div slot="content">一键完成文档中所有签名
                            </div>
                        <i class="el-icon-question"></i>
                        </el-tooltip>
                    </div>
                </div>
            </div>
            <envelopePreview ref="preview" class="document-container" :style="documentContainerStyle"
                :envelopeWsid="envelopeWsid"
                :documents="documents" :scale="documentPreviewScale" :showType="settingPagingSeal? 'PAGING_SEAL' : 'NORMAL'"
                @loaded="documentsLoaded" @view-update="documentsViewUpdate" :maxWidth="100">
                <!-- 页面区域 -->
                <template v-for="documentsPageArea in documentsPageAreas" :slot="documentsPageArea.slot">
                    <div ref="formContainers" class="page-form-container" :key="documentsPageArea.slot"
                        :data-doc="documentsPageArea.docId" :data-page="documentsPageArea.page">
                    </div>
                </template>

                <!-- 骑缝章区域 -->
                <template v-if="settingPagingSeal">
                    <template v-for="documentsPagingSealsArea in documentsPagingSealsAreas" :slot="documentsPagingSealsArea.slot">
                        <div ref="pagingSealsContainers" class="paging-seal-container" :key="documentsPagingSealsArea.slot"  
                            :data-doc="documentsPagingSealsArea.docId">
                            <pagingSeal v-for="seal in pagingSealsMap[documentsPagingSealsArea.docId]" :scale="documentPreviewScale" :sealData="seal" 
                                :active="activeFormRandom === seal.random" :signable="true" :key="seal.random"
                                @delete="deleteForm(seal.random)" @activate="activateForm(seal.random)" @sign="signPaginSeal(seal)"
                            ></pagingSeal>
                        </div>
                    </template>
                </template>
                <!-- 骑缝章分割展示模式 -->
                <template v-else>
                    <template v-for="sealData in splittedPagingSealsArr" :slot="sealData.slot">
                        <splittedPagingSeal :scale="documentPreviewScale" :sealData="sealData.seal" :key="sealData.seal.id"
                            :page="sealData.page" :totalPages="sealData.totalPages"></splittedPagingSeal>
                    </template>
                </template>

                <!-- 表单项(正常模式) -->
                <template v-if="!settingPagingSeal">
                    <template v-for="(forms,key) in formsMap" :slot="key">
                        <formRender ref="forms" v-for="form in forms" :key="form.random" :formData="form" :active="activeFormRandom === form.random" 
                                :scale="documentPreviewScale" :signing="signingFormRandom === form.random"
                                :deleteable="form.revisable" :moveable="form.revisable" :resizeable="form.revisable" :signable="true"
                                @delete="deleteForm(form.random)" @activate="activateForm(form.random)" @sign="signForm(form)" :customStyles="customStyles"></formRender>
                    </template>
                </template>
                <!-- 表单项(骑缝章模式) -->
                <template v-else>
                    <template v-for="(forms,key) in formsMap" :slot="key">
                        <formRender ref="forms" v-for="form in forms" :key="form.random" :formData="form"
                                :deleteable="false" :moveable="false" :resizeable="false"
                                :scale="documentPreviewScale" :customStyles="customStyles"></formRender>
                    </template>
                </template>
            </envelopePreview>
            <div class="right-container" :style="{width:rightNavOpen?'120px':0}">
                <div class="right-container-switch" :class="{open:rightNavOpen, close:!rightNavOpen}" @click="rightNavOpen = !rightNavOpen">
                    <svg width="20" height="60">
                        <polyline points="7,10 13,30 7,50" class="line"/>
                    </svg>
                </div>
                <div class="right-box">
                    <div class="documents-preview-nav">
                        <div class="title">文档列表</div>
                        <documentsPreviewBar class="documents-preview" ref="previewbar" :documents="documents" 
                            :activeData="{
                                docId: activeDocumentId,
                                page: activePage
                            }" @select-docpage="prevewNavSelect"></documentsPreviewBar>
                    </div>
                </div>
            </div>
            <div v-if="userEdition === 'e'" class="right-paging-seal-container" :style="rightPagingSealContainerStyle">
                <div class="right-paging-seal-box">
                    <div class="selectable-forms">
                        <div>拖拽签章到骑缝章区域（蓝色框）</div>
                        <div class="offical-paggingseals">
                            <officalSealsList :enterpriseUserWsid="activeUserWsid" :sealScale="documentPreviewScale" 
                                :enterpriseWsid="enterpriseWsid"
                                @apply="applySeal" @place-paging-seal="placePagingSeal" :customStyles="customStyles">
                                <template slot="apply-text">前往管理系统申请印章</template>
                            </officalSealsList>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="envelope-signature-footer">
            <span class="forms-count">
                <template v-if="allFormsCount">
                    签名域 {{allSignedFormsCount}}/{{allFormsCount}}
                </template>
            </span>
            <el-button v-if="isEnvelopeSender" plain class="btn-danger" type="danger" @click="revokeDialogOpen = true">撤销</el-button>
            <el-button plain class="btn-danger" type="danger" @click="rejectDialogOpen = true">拒签</el-button>
            <el-button :style="customStyles" plain class="btn-complete" :disabled="allFormsCount > 0 && allSignedFormsCount !== allFormsCount" :loading="confirming"
                :type="(allSignedFormsCount === allFormsCount)?'primary':''" @click="confirmEnvelope">确认签署</el-button>
            
            <!-- 撤销弹框 -->
            <el-dialog title="撤销文件" :visible.sync="revokeDialogOpen" :close-on-click-modal="false" :append-to-body="true" width="500px" top="30vh" @close="revokeDialogOpen = false">
                <div style="font-size:16px;margin-bottom: 20px;">告知其他人撤销该文件的原因：</div>
                <el-input type="textarea" v-model="revokeMessage" placeholder="请输入撤销文件的理由"></el-input>
                <div style="text-align:right;margin-top:30px">
                    <el-button @click="revokeDialogOpen = false">取消</el-button>
                    <el-button type="primary" :style="customStyles" :loading="revoking" @click="revokeEnvelope">撤销</el-button>
                </div>
            </el-dialog>


            <!-- 拒签弹框 -->
            <el-dialog title="拒绝签署" :visible.sync="rejectDialogOpen" :append-to-body="true" :close-on-click-modal="false" width="500px" top="30vh" @close="rejectDialogOpen = false">
                <div style="font-size:16px;margin-bottom: 20px;">告知其他人拒绝签署该文件的原因：</div>
                <el-input type="textarea" v-model="rejectMessage" placeholder="请输入拒绝签署的理由"></el-input>
                <div style="text-align:right;margin-top:30px">
                    <el-button @click="rejectDialogOpen = false">取消</el-button>
                    <el-button  type="primary" :style="customStyles" :loading="rejecting" @click="rejectEnvelope">拒绝签署</el-button>
                </div>
            </el-dialog>
            
            <el-dialog title="签署验证" :visible.sync="signConfirmDialogVisible" :append-to-body="true" @close="signConfirmDialogClose" width="500px">
                <signatureConfirmVerify @confirm="confirmSign" @cancel="signConfirmDialogClose" :authTypes="authTypes" :customStyles="customStyles" @forgetSignPassword="forgetSignPassword"/>
            </el-dialog> 
            <el-dialog title="找回签署密码" :visible.sync="signDialogVisible" :append-to-body="true" @close="closesignDialog" width="500px">
                <signPasswordRetrieve ref="signPassword" @confirm="closesignDialog" @cancel="closesignDialog" :customStyles="customStyles"></signPasswordRetrieve>
            </el-dialog> 
        </div>
        <chooseOfficalSeals v-if="userEdition === 'e'" 
            ref="chooseOfficalSeals"
            :enterpriseUserWsid="activeUserWsid" @apply="applySeal" :customStyles="customStyles" />
        <chooseSeals :userWsid="userWsid" ref="chooseSeals" :customStyles="customStyles"></chooseSeals>
        <carousel class="signature-help" v-if="signatureHelpDialog" :images="helpImages" @closeHelp="closeHelp"></carousel>
        <div v-show="dragingSeal" ref="dragingSeal" class="drag-seal">
            <imgBox v-if="dragingSeal" :width="dragingSeal.width" :height="dragingSeal.height" :src="dragingSeal.seal.imageData"/>
        </div>

        <!-- 首次签署完成未设置签署密码，提示设置 -->
        <el-dialog width="500px" title="设置签署密码" v-if="setSignPassWordVisible" :visible.sync="setSignPassWordVisible" :close-on-click-modal="false" :show-close="false">
            <div class="dialog-content">
                <template>
                    <setSignPassword :visible="setSignPassWordVisible" ref="setSignPassWord" @close="closeSetSignPasswordDialog" :customStyles="customStyles"></setSignPassword>
                </template>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import { ifRectIntersect } from "@commons/util.js"
import wesignSignatureSDK from "@commons/wesign-signature-sdk-child.js"
import { FORMS_CONFIG_TYPE_MAP, EnvelopeBaseForm, EnvelopeFormPosition, PagingSeal } from "@classes/envelopes/forms.js"
import { USER_EDITION } from "@utils/users.js"
import { ACTIONS, gotoOpenSignatureReturnURL } from "@classes/openapi/sign-callback.js"

import { FormsManager } from "@components/envelopes/envelop-signature/utils/forms.js"

import revokeDialog from "@components/envelopes/dialogs/revoke-dialog.vue"
import { rejectEnvelope } from "@interfaces/envelopes/envelope.js"
import { confirmEnvelope, getAuthTypes } from "@interfaces/envelopes/envelope.js"
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"
import { getPersonSeals, getAuthorizeSeals } from "@interfaces/seals/seals.js"
import { revokeEnvelope } from "@interfaces/envelopes/envelope.js"

import imgBox from "@components/commons/img-box.vue"
import chooseSeals from "@components/dialogs/choose-seals.vue"
import chooseOfficalSeals from "@components/dialogs/choose-offical-seals.vue"

//签署页面相关组件
import leftFastJumpContainer from "@components/envelopes/envelop-signature/left-fast-jump-container.vue"
import officalSealsList from "@components/envelopes/envelop-signature/offical-seals.vue"
import headerToolBar from "@components/envelopes/envelop-signature/header-tool-bar.vue"
import footerToolBar from "@components/envelopes/envelop-signature/footer-tool-bar.vue"

import envelopePreview from "@components/commons/documents/envelope-preview.vue"
import documentsPreviewBar from "@components/commons/documents/documents-preview-bar.vue"
import carousel from "@components/commons/carousel.vue"
import signatureConfirmVerify from "@components/envelopes/signature-confirm-verify/index.vue"
import signPasswordRetrieve from "@components/envelopes/signature-confirm-verify/retrieve-signpassword/index.vue"

import setSignPassword from "@components/envelopes/signature-confirm-verify/set-signPassword.vue"

import { Loading } from "element-ui"

import collapse from "@components/commons/collapse/collapse.vue"
import collapseItem from "@components/commons/collapse/collapse-item.vue"
import formRender from "@components/envelopes/forms/form-render.js"
import pagingSeal from "@components/envelopes/paging-seals/paging-seal.vue"
import splittedPagingSeal from "@components/envelopes/paging-seals/splitted-paging-seal.vue"
import { LoginComponentLocalInfo} from "@classes/login/login-info.js"
import { cm2pt } from "@utils/translate.js"
import { viewEnvelope } from "@interfaces/envelopes/envelope.js"

//帮助动图
import helpOne from "@images/help/signature1.gif"
import helpTwo from "@images/help/signature2.gif"
import helpThere from "@images/help/signature3.gif"

const CSS_UNITS = 96.0 / 72.0

export default {
    data(){
        return {
            pageCallback: "", //操作完成的回调页面

            participant: null,

            activeFormRandom: -1,
            signingFormRandom: -1,

            rightNavOpen: false,
            fastJumpNavOpen: false,

            
            localInfo: new LoginComponentLocalInfo(),

            //文档
            documents: [],
            documentsData: [], //文档加载完成后的数据
            documentPreviewScale: 1 * CSS_UNITS,
            scaleList: [
                0.75 * CSS_UNITS,
                1 * CSS_UNITS,
                1.25 * CSS_UNITS,
                1.5 * CSS_UNITS
            ],
            CSS_UNITS: CSS_UNITS,

            //表单项管理
            formsManager: new FormsManager(),
            
            personalSeal: null, //私章
            dragingSeal: null, //正在拖拽公章
        
            //骑缝章模式
            settingPagingSeal: false,

            //激活的
            activeDocumentId: "",
            activePage: 1,

            //帮助
            signatureHelpDialog: false,
            helpImages: [
                helpOne,
                helpTwo,
                helpThere
            ],


            confirming: false, //确认签署中
            signConfirmDialogVisible: false, //确认签署框

            rejectDialogOpen: false, //拒签弹框
            rejectMessage: "文件内容不符合要求", //拒签信息
            rejecting: false, //拒签中
        
            revokeDialogOpen: false, //撤销弹框
            revokeMessage: "文件内容有误", //撤销消息
            revoking: false, //撤销中

            authTypes: null,
            setSignPassWordVisible: false,
            signDialogVisible:false,
            enableNoAppearance:this.$route.query.enableNoAppearance || "false"
        }
    },
    computed: {
        user(){
            return this.$store.state.userdata || this.$store.state.userData
        },
        activeUserWsid(){
            return this.$store.state.userWsid
        },
        isEnvelopeSender(state){
            return this.$store.getters.userAuthorWsidInEnvelope === this.$store.state.envelopeData.basicInfo.senderWsid
        },
        userWsid(){
            return this.$store.state.userWsid
        },
        enterpriseWsid(){
            return this.$store.state.userData.enterpriseWsid
        },
        isEnterpriseAuthor(){
            return this.$store.getters.isEnterpriseAuthor
        },
        envelopeWsid(){
            return this.$store.state.envelopeData.envelopeWsid
        },
        participantEnterpriseRole(){
            return this.$store.getters.participantEnterpriseRole
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
        currentParticipant(){
            return this.$store.state.envelopeData.currentParticipant
        },
        forms(){
            return this.formsManager.getForms()
        },
        pagingSeals(){
            return this.formsManager.getPagingSeals()
        },
        //全部表单项数量
        allFormsCount(){
            return this.forms.length + this.pagingSeals.length
        },
        allSignedFormsCount(){
            let numOfSignedForms = this.forms.filter(form => form.data).length
            let numOfSignedPagingSeals = this.pagingSeals.filter(seal => seal.sealData).length

            return numOfSignedForms + numOfSignedPagingSeals
        },
        activeDocumentData(){
            let index = this.documents.findIndex(doc => doc.id === this.activeDocumentId)
            if (this.documentsData[index]){
                return this.documentsData[index]
            } else {
                return {
                    pagesCount: 0
                }
            }
        },
        docFormsMapForJump(){
            let map = {}
            this.documents.forEach(doc => {
                map[doc.id] = {count: 0}
            })

            this.forms.forEach(form => {
                let doc = map[form.docId]
                if (!doc) return
                if (!doc[form.type]) doc[form.type] = []
                doc[form.type].push(form)
                doc.count++
            })

            this.pagingSeals.forEach(form => {
                let doc = map[form.docId]
                if (!doc) return
                if (!doc[form.type]) doc[form.type] = []
                doc[form.type].push(form)
                doc.count++
            })

            return map
        },
        formsMap(){
            let formsMap = {}
            this.forms.forEach(form => {
                let slot = `${form.docId}_${form.page}`
                if (!formsMap[slot])formsMap[slot] = []
                formsMap[slot].push(form)
            })
            return formsMap
        },
        formsType(){
            let formsType = {}
            this.forms.forEach((item, index) => {
                if (!formsType[this.forms[index].type]){
                    formsType[this.forms[index].type] = []
                }
                formsType[this.forms[index].type].push(this.forms[index])
            })
            if (this.pagingSeals.length > 0){
                formsType.MULTI_CHECK_MARK = this.pagingSeals.slice()
            }
            
            return formsType
        },
        documentsPageAreas(){
            let documentsData = this.documentsData
            let documents = this.documents
            let areas = []
            documentsData.forEach((documentData, index) => {
                let docId = documents[index].id
                for (let i = 1; i <= documentData.pagesCount; i++){
                    areas.push({
                        slot: `${docId}_${i}`,
                        docId: docId,
                        page: i
                    })
                }
            })
            return areas
        },
        pagingSealsMap(){
            let pagingSealsMap = {}
            let documents = this.documents
            documents.forEach(doc => pagingSealsMap[doc.id] = [])

            this.pagingSeals.forEach(pagingSeal => {
                pagingSealsMap[pagingSeal.docId].push(pagingSeal)
            })

            return pagingSealsMap
        },
        splittedPagingSealsArr(){
            let documentsData = this.documentsData
            let documents = this.documents
            let documentsDataPagesCountMap = {}
            documentsData.forEach((documentData, index) => {
                documentsDataPagesCountMap[documents[index].id] = documentData.pagesCount
            })

            let splittedPagingSealsArr = []
            this.pagingSeals.forEach(pagingSeal => {
                splittedPagingSealsArr.push(
                    ...(new Array(documentsDataPagesCountMap[pagingSeal.docId])
                        .fill(0)
                        .map((_, index) => {
                            return {
                                seal: pagingSeal,
                                docId: pagingSeal.docId,
                                page: index + 1,
                                totalPages: documentsDataPagesCountMap[pagingSeal.docId],
                                slot: `${pagingSeal.docId}_${index + 1}_splitted_seals_area`
                            }
                        }))
                )
            })
            return splittedPagingSealsArr
        },
        documentsPagingSealsAreas(){
            let documentsData = this.documentsData
            let documents = this.documents
            let areas = []
            documentsData.forEach((documentData, index) => {
                let docId = documents[index].id
                areas.push({
                    slot: `${docId}_paging_seal_area`,
                    docId: docId,
                })
            })
            return areas
        },
        leftNormalContainerStyle(){
            let width = 200
            if (this.settingPagingSeal){
                width = 0
            }
            return {
                width: width + "px"
            }
        },
        fastJumpContainerStyle(){
            let width = 200
            let left = 200
            if (this.settingPagingSeal || !this.fastJumpNavOpen){
                width = 0
            }

            if (this.settingPagingSeal){
                left = 0
            }

            return {
                width: width + "px",
                left: left + "px"
            }
        },
        documentContainerStyle(){
            let left = 200
            let right = 0

            if (this.rightNavOpen){
                right = 120
            }

            if (this.settingPagingSeal || this.enableNoAppearance==="true"){
                left = 0
                if(this.enableNoAppearance === "true"){
                   right = 0 
                } else {
                    right = 200
                }
            }

            return {
                left: left + "px",
                right: right + "px"
            }
        },
        rightPagingSealContainerStyle(){
            let width = 0
            if (this.settingPagingSeal){
                width = 200
            }
            return {
                width: width + "px"
            }
        },
        customStyles(){
            let themeColor = this.$route.query.themeColor
            let circleAngle = this.$route.query.circleAngle
            if(themeColor){
                if (themeColor === "#ffffff"){
                    return {
                        background: themeColor,
                        color: "#000000",
                        borderRadius: circleAngle + "px"
                    }
                } else {
                    return {
                        background: themeColor,
                        color: "#FFFFFF",
                        borderRadius: circleAngle + "px"
                    }
                }
            }
        },
    },
    watch: {
        personalSeal(newVal, oldVal){
            if (newVal && oldVal && newVal !== oldVal){
                this.allSignForm()
            }
        }
    },
    created(){
        let query = this.$route.query
        this.loadDocuments()
        this.loadPersonalSeal()

        this.loadAuthType()
        if(this.enableNoAppearance && this.enableNoAppearance === "true"){
            this.loadAuthType().then(_ => {
                this.signConfirmDialogVisible = true
            })
        } else {
            this.loadAuthType()
            this.formsManager.load(this.envelopeWsid, this.currentParticipant.participantWsid).then(_ => {
                if (this.allFormsCount > 0){
                    this.fastJumpNavOpen = true
                }
            })
        } 

        //更新预览时间
        viewEnvelope({
            envelopeWsid: this.envelopeWsid,
            participantWsid: this.currentParticipant.participantWsid
        }).then(_ => _, _ => _)

        //页面回调

        if (query.pageCallback){
            this.pageCallback = query.pageCallback
        } else {
            this.pageCallback = localStorage.getItem(`pageCallback:${this.envelopeWsid}`) || ""
        }
        if (localStorage){
            localStorage.setItem(`pageCallback:${this.envelopeWsid}`, this.pageCallback)
        }

        //展示指引
        if (this.localInfo.showEnvelopeSignature === false){
            this.signatureHelpDialog = true
        } else {
            this.signatureHelpDialog = false
        }
    },
    methods: {
        //加载
        loadDocuments(){
            getEnvelopeDocuments({
                envelopeWsid: this.envelopeWsid
            }).then(res => {
                let documents = res.data.data.documents
                documents = documents.map(document => {
                    let metadata = {}
                    if (document.fileTagId){
                        metadata = JSON.parse(document.fileTagId)
                    }
                    return {
                        id: document.fileWsid,
                        pdfSrc: document.fileHref.href,
                        name: document.fileName,
                        sequece: metadata.sequece != undefined ? metadata.sequece : null,
                    }
                })
                if (documents.every(_ => _.sequece != null)){
                    documents.sort((a, b) => a.sequece - b.sequece)
                }
                this.documents = documents
                this.activeDocumentId = this.documents[0] && this.documents[0].id
            }).catch(err => {
                console.error(err)
            })
        },
        loadPersonalSeal(){
            let userWsid = this.$store.state.userWsid
            return getPersonSeals({
                authorWsid: userWsid
            }).then(res => {
                let personSeals = res.data.data.personSeals
                let personSeal = personSeals[personSeals.length - 1]
                if (personSeal){
                    this.personalSeal = {
                        id: personSeal.personSealWsid,
                        imageData: personSeal.link.href
                    }
                }
            })
        },
        loadAuthType(){
            return getAuthTypes({
                envelopeWsid: this.envelopeWsid,
                participantWsid: this.currentParticipant.participantWsid,
            }).then(res => {
                let data = res.data.data
                if (data.selectedAuthTypes && data.selectedAuthTypes.length > 0){
                    this.authTypes = data.selectedAuthTypes
                } else if (data.authTypes.length > 0){
                    this.authTypes = data.authTypes
                } else {
                    this.authTypes = ["SIGN_PIN"]
                }
            })
        },

        //header相关
        changePagingSealStatus(){
            if (this.documentsData.some(doc => doc.pagesCount > 1)){
                this.settingPagingSeal = !this.settingPagingSeal
            } else {
                this.$alert("加盖骑缝章要求文件页数至少2页", "提醒", {
                    confirmButtonText: "我知道了"
                })
            }
        },
        scaleChange(scale){
            this.documentPreviewScale = scale
        },
        zoomIn(){
            let biggerScale = this.scaleList.find(scale => scale > this.documentPreviewScale)
            if (biggerScale){
                this.documentPreviewScale = biggerScale
            }
        },
        zoomOut(){
            let index = this.scaleList.findIndex(scale => scale >= this.documentPreviewScale)
            if (index == undefined) index = this.scaleList.length
            if (index > 0) index--
            this.documentPreviewScale = this.scaleList[index]
        },
        signatureHelp(){
            this.signatureHelpDialog = true
        },
        closeHelp(){
            this.signatureHelpDialog = false
            this.localInfo.setShowEnvelopeSignature(true)
        },

        //左侧边栏
        fastJump(){
            if (this.allFormsCount === 0){
                this.$confirm("该文档未预设签名项，您可以拖动签名框进行文档签名设置", "提示", {
                    confirmButtonText: "知道了",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(_ => {}, _ => {})
            } else {
                this.fastJumpNavOpen = !this.fastJumpNavOpen
            }
        },
        appendForm(formRect, type, data){
            let formContainers = this.$refs.formContainers
            if (!formContainers) return
            let container
            for (let i = 0; i < formContainers.length; i++){
                let rect = formContainers[i].getBoundingClientRect()
                if (ifRectIntersect(formRect, rect)){
                    container = formContainers[i]
                    break
                }
            }
            if (!container) return

            let scale = this.documentPreviewScale
            let top, left, width, height
            let containerRect = container.getBoundingClientRect()

            if (formRect.width > containerRect.width){
                width = containerRect.width
            } else {
                width = formRect.width
            }

            if (formRect.height > containerRect.height){
                height = containerRect.height
            } else {
                height = formRect.height
            }

            left = formRect.left - containerRect.left
            if (left < 0) left = 0
            if (left > containerRect.width - width) left = containerRect.width - width

            top = formRect.top - containerRect.top
            if (top < 0) top = 0
            if (top > containerRect.height - height) top = containerRect.height - height

            let newForm = new EnvelopeBaseForm()
            newForm.type = type
            newForm.participantWsid = this.currentParticipant.participantWsid
            newForm.docId = container.getAttribute("data-doc")
            newForm.page = parseInt(container.getAttribute("data-page"))
            newForm.required = false //是否必填
            newForm.scale = 1 //缩放比例
            newForm.position = EnvelopeFormPosition.formRect(top / scale, left / scale, width / scale, height / scale)

            if (data) newForm.data = data
            this.formsManager.appendForm(newForm)
            this.activeFormRandom = newForm.random
        },
        appendPagingSeal(formRect, data){
            let pagingSealsContainers = this.$refs.pagingSealsContainers
            if (!pagingSealsContainers) return
            let container
            for (let i = 0; i < pagingSealsContainers.length; i++){
                let rect = pagingSealsContainers[i].getBoundingClientRect()
                if (ifRectIntersect(formRect, rect)){
                    container = pagingSealsContainers[i]
                    break
                }
            }
            if (!container) return

            let offset = 0 //位置进度
            let containerRect = container.getBoundingClientRect()

            offset = formRect.top - containerRect.top

            if (offset < 0) offset = 0
            if (offset > containerRect.height - formRect.height) offset = containerRect.height - formRect.height

            let seal = new PagingSeal()
            seal.participantWsid = this.currentParticipant.participantWsid
            seal.docId = container.getAttribute("data-doc")
            seal.offset = offset / this.documentPreviewScale
            if (data){
                seal.sealWsid = data.id
                seal.sealData = data.imageData
                seal.resizeWidth = data.width
                seal.resizeHeight = data.height
            }

            this.formsManager.appendForm(seal)
        },
        startDragForm(type, e){
            let currentTarget = e.currentTarget
            let formConfig = FORMS_CONFIG_TYPE_MAP.get(type)
            if (!formConfig) throw new Error("无效的签署项类型")

            let scale = this.documentPreviewScale
            let defaultSize = formConfig.defaultSize
            let startX = e.clientX
            let startY = e.clientY
            let width = defaultSize.width
            let height = defaultSize.height

            let dragForm = document.createElement("div")
            dragForm.innerHTML = formConfig.name
            dragForm.className = "wesign-envelopes-drag-form"
            dragForm.style.width = width * scale + "px"
            dragForm.style.height = height * scale + "px"
            dragForm.style.lineHeight = height * scale + "px"
            dragForm.style.left = startX - width / 2 + "px"
            dragForm.style.top = startY - height / 2 + "px"
            document.body.style.cursor = "move"
            currentTarget.parentNode.appendChild(dragForm)

            let moveHandle = e => {
                dragForm.style.top = e.clientY - height / 2 + "px"
                dragForm.style.left = e.clientX - width / 2 + "px"
                e.stopPropagation()
            }

            let upHandle = e => {
                this.appendForm(dragForm.getBoundingClientRect(), type)
                document.body.style.cursor = ""
                currentTarget.parentNode.removeChild(dragForm)
                document.removeEventListener("selectstart", disSelect)
                document.removeEventListener("mouseup", upHandle)
                document.removeEventListener("mousemove", moveHandle)
            }

            let disSelect = function(e){
                e.returnValue = false
            }

            document.addEventListener("mousemove", moveHandle)
            document.addEventListener("mouseup", upHandle)
            document.addEventListener("selectstart", disSelect)
        },
        startDragSeal(seal, e){
            let dragingSealEl = this.$refs.dragingSeal
            let currentTarget = e.currentTarget
            let currentTargetRect = currentTarget.getBoundingClientRect()
            let sealDefaultSize = FORMS_CONFIG_TYPE_MAP.get("SEAL").defaultSize

            let scale = this.documentPreviewScale
            let startX = e.clientX
            let startY = e.clientY
            let width = seal.width * scale || sealDefaultSize.width * scale
            let height = seal.height * scale || sealDefaultSize.height * scale
            let startTop = e.clientY - height / 2
            let startLeft = e.clientX - width / 2

            let dragingSeal = {
                seal: seal,
                width: width,
                height: height
            }
            this.dragingSeal = dragingSeal
            dragingSealEl.style.top = startTop + "px"
            dragingSealEl.style.left = startLeft + "px"


            document.body.style.cursor = "move"
            let moveHandle = e => {
                let dx = e.clientX - startX
                let dy = e.clientY - startY

                dragingSealEl.style.top = startTop + dy + "px"
                dragingSealEl.style.left = startLeft + dx + "px"
                e.stopPropagation()
            }

            let upHandle = e => {
                let formRect = dragingSealEl.getBoundingClientRect()
                let sealData = {
                    id: seal.id,
                    imageData: seal.imageData,
                    width: seal.width,
                    height: seal.height
                }

                if (this.settingPagingSeal){
                    this.appendPagingSeal(formRect, sealData)
                } else {
                    this.appendForm(formRect, "SEAL", sealData)
                }


                this.dragingSeal = null
                document.body.style.cursor = ""
                document.removeEventListener("selectstart", disSelect)
                document.removeEventListener("mouseup", upHandle)
                document.removeEventListener("mousemove", moveHandle)
            }

            let disSelect = function(e){
                e.returnValue = false
            }

            document.addEventListener("mousemove", moveHandle)
            document.addEventListener("mouseup", upHandle)
            document.addEventListener("selectstart", disSelect)
        },
        startDragSignature(signature, e){
            let currentTarget = e.currentTarget
            let currentTargetRect = currentTarget.getBoundingClientRect()

            let startX = e.clientX
            let startY = e.clientY
            let width = currentTargetRect.width
            let height = currentTargetRect.height

            let dragForm = currentTarget.cloneNode(true)
            dragForm.style.zIndex = "10000"
            dragForm.style.margin = "0"
            dragForm.style.position = "fixed"
            dragForm.style.width = width + "px"
            dragForm.style.height = height + "px"
            dragForm.style.left = currentTargetRect.left + "px"
            dragForm.style.top = currentTargetRect.top + "px"
            document.body.style.cursor = "move"
            currentTarget.parentNode.appendChild(dragForm)

            let moveHandle = e => {
                let dx = e.clientX - startX
                let dy = e.clientY - startY

                dragForm.style.top = currentTargetRect.top + dy + "px"
                dragForm.style.left = currentTargetRect.left + dx + "px"
                e.stopPropagation()
            }

            let upHandle = e => {
                this.appendForm(dragForm.getBoundingClientRect(), "SIGN", {
                    id: signature.id,
                    imageData: signature.imageData
                })
                document.body.style.cursor = ""
                dragForm.parentNode.removeChild(dragForm)
                document.removeEventListener("selectstart", disSelect)
                document.removeEventListener("mouseup", upHandle)
                document.removeEventListener("mousemove", moveHandle)
            }

            let disSelect = function(e){
                e.returnValue = false
            }

            document.addEventListener("mousemove", moveHandle)
            document.addEventListener("mouseup", upHandle)
            document.addEventListener("selectstart", disSelect)
        },
        deleteForm(formRandom){
            this.formsManager.deleteForm(formRandom)
        },
        activateForm(formRandom){
            this.activeFormRandom = formRandom
        },
        signForm(form){
            switch (form.type){
                case "SIGN":
                    this.$refs.chooseSeals.open(["SCAN_SIGNATURE"], !form.data).then(data => {
                        let {
                            id,
                            imageData
                        } = data

                        if (id && imageData){
                            form.data = {
                                id,
                                imageData
                            }
                        } else {
                            form.data = null
                        }
                        this.personalSeal = data
                    }, _ => {})
                    break
                case "SEAL":
                    this.$refs.chooseOfficalSeals.open().then(data => {
                        let {
                            id,
                            imageData,
                            width,
                            height
                        } = data

                        form.position.lrx = form.position.ulx + width
                        form.position.lry = form.position.uly + height

                        if (id && imageData){
                            form.data = {
                                id,
                                imageData
                            }
                        } else {
                            form.data = null
                        }

                        this.$nextTick(_ => {
                            let formEs = this.$refs.forms
                            let formE = formEs.find(fE => fE.formData === form)
                            if (formE) {
                                formE.checkPosition()
                            }
                        })
                    }, _ => {})
                    break
                case "TEXT":
                    this.signingFormRandom = form.random
                    break
                case "DATE":
                    if (!form.data) form.data = Date.now()
                    break
            }
        },
        signPaginSeal(seal){
            this.$refs.chooseOfficalSeals.open().then(data => {
                let {
                    id,
                    imageData,
                    width,
                    height
                } = data

                seal.resizeWidth = width
                seal.resizeHeight = height

                if (id && imageData){
                    seal.sealWsid = id
                    seal.sealData = imageData
                } else {
                    seal.sealWsid = undefined
                    seal.sealData = undefined
                }
            }, _ => {})
        },
        cancleActiveForm(){
            this.activeFormRandom = -1
            this.signingFormRandom = -1
        },


        //footer
        confirmEnvelope(){
            //检查是否有设置签署项
            let query = this.$route.query
            if(this.enableNoAppearance === "false"){
                if (this.allFormsCount === 0){
                    this.$confirm("该文档未预设签名项，您可以拖动签名框进行文档签名设置", "提示", {
                        confirmButtonText: "知道了",
                        cancelButtonText: "取消",
                        type: "warning"
                    }).then(_ => {}, _ => {})
                    return
                }
            }

            //如果角色是签章管理员必须盖章
            if (this.participantEnterpriseRole 
                && this.participantEnterpriseRole.name === "印章管理员" //FIXME: 后期后台可能会进行配置
                && this.forms.filter(form => form.type === "SEAL").length === 0
                && this.pagingSeals.length === 0){
                this.$confirm("该文档要求您盖章，请拖动可用印章进行盖章操作。如果没有可用印章，可以点击印章申请", "提示", {
                    confirmButtonText: "知道了",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(_ => {}, _ => {})
                return
            }

            this.confirming = true

            this.formsManager.uploadFormsData().then(_ => {
                this.signConfirmDialogVisible = true
                return
            }).catch(err => {
                this.$message.error("保存信息失败")
            })
        },
        signConfirmDialogClose(){
            this.signConfirmDialogVisible = false
            this.confirming = false
        },
        confirmSign(opcode){
            this.signConfirmDialogVisible = false
            if(this.enableNoAppearance&&this.enableNoAppearance == "true"){
                this.formsManager.noappearanceParticipantEnvelopeFroms(this.envelopeWsid, this.currentParticipant.participantWsid,true).then(_ => {
                    this.confirm(opcode)
                }).catch(err =>{
                    console.error(err)
                })
            } else {
                this.confirm(opcode)
            }
        },
        confirm(opcode){
            let loadingInstance = Loading.service({
                fullscreen: true
            })
            confirmEnvelope({
                envelopeWsid: this.envelopeWsid,
                participantWsid: this.currentParticipant.participantWsid,
                opcode: opcode
            }).then(_ => {
                this.completed()
            }).catch(err => {
                if (err.response){
                    let code = err.response.data.code
                    if (code == 101){
                        this.$message.warning("您的印章使用次数不足,请重新申请印章")
                    } else if (code == 102) {
                        this.$message.warning("该印章不在使用期内")
                    } else if (code == 103){
                        this.$message.warning("您的印章，暂无印章使用权限")
                    } else if (code == 104){
                        this.$alert("对不起,信封状态在您签署的过程中已经发生改变,请返回签署详情页面进行查看", "错误", {
                            type: "error"
                        }).then(_ => {}, _ => {}).then(_ => {
                            location.reload()
                        })
                    } else {
                        this.$message.error("签署失败")
                    }
                } else {
                    this.$message.error("签署失败")
                }
            }).then( _ => {
                loadingInstance.close()
                this.confirming = false //按钮loading
            })
        },
        completed(){
            wesignSignatureSDK.operationComplete("SIGN")
            this.$alert("签署成功!", "提醒", {
                type: "success"
            }).then(_ => {}, _ => {}).then(_ => {
                if (!this.user.existSignPassword){
                    this.setSignPassWordVisible = true
                } else {
                    this.openAPIEnvelopCompleteJump(ACTIONS.SIGNED)
                }
            })
        },
        closeSetSignPasswordDialog(){
            this.openAPIEnvelopCompleteJump(ACTIONS.SIGNED)
        },
        rejectEnvelope(){
            this.rejecting = true
            rejectEnvelope({
                envelopeWsid: this.envelopeWsid,
                participantWsid: this.currentParticipant.participantWsid,
                rejectReason: this.rejectMessage
            }).then(err => {
                this.rejected()
            }).catch(err => {
                this.$message.error("拒绝签署失败")
            }).then(_ => {
                this.rejecting = false
            })
        },
        rejected(){
            wesignSignatureSDK.operationComplete("REJECTE")
            this.$alert("拒签成功!", "提醒", {
                type: "success"
            }).then(_ => {}, _ => {}).then(_ => {
                this.openAPIEnvelopCompleteJump(ACTIONS.REJECTED)
            })
        },
        revokeEnvelope(){
            this.revoking = true
            revokeEnvelope({
                envelopeWsid: this.envelopeWsid,
                revokeReason: this.revokeMessage
            }).then(err => {
                this.revoked()
            }).catch(err => {
                this.$message.error("撤销文件失败")
            }).then(_ => {
                this.revoking = false
            })
        },
        revoked(){
            wesignSignatureSDK.operationComplete("REVOKE")
            this.$alert("撤销成功!", "提醒", {
                type: "success"
            }).then(_ => {}, _ => {}).then(_ => {
                this.openAPIEnvelopCompleteJump(ACTIONS.REVOKED)
            })
        },
        documentsLoaded(documentsData){
            this.documentsData = documentsData
        },
        documentsViewUpdate(updateInfo){
            this.activeDocumentId = updateInfo.docId
            this.activePage = updateInfo.page
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, this.activePage)
        },
        gotoDocument(docId){ //选择文档
            this.$refs.preview.gotoDocumentPage(docId, 1)
            this.$refs.previewbar.gotoDocumentPage(docId, 1)
        },
        gotoPage(page){
            this.$refs.preview.gotoDocumentPage(this.activeDocumentId, page)
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, page)
        },
        prevewNavSelect(docId, page){
            this.$refs.preview.gotoDocumentPage(docId, page)
        },
        createSignature(){
            this.$refs.chooseSeals.open(["SCAN_SIGNATURE"]).then(data => {
                this.personalSeal = data
                this.allSignForm()
            }, _ => {})
        },
        jumpToForm(form){
            if (form.type === "MULTI_CHECK_MARK"){
                this.settingPagingSeal = true
            } else {
                this.$refs.preview.scrollToDocPageRectView(form.docId, form.page, {
                    top: form.position.uly
                })
            }
            this.activeFormRandom = form.random
        },
        openAPIEnvelopCompleteJump(action){ //开放平台来的页面进行跳转
            if (!this.pageCallback || this.pageCallback === "DEFAULT"){
                this.$router.replace({
                    path: "/result",
                    query: {
                        result: action
                    }
                })
            } else {
                gotoOpenSignatureReturnURL(this.pageCallback, action, {
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.currentParticipant.participantWsid
                })
            }
        },
        placePagingSeal(data){
            if (this.settingPagingSeal){
                if (data.type !== "SEAL") return
                this.appendPagingSeal(data.formRect, data.data)
            } else {
                this.appendForm(data.formRect, data.type, data.data)
            }
        },
        applySeal(){
            this.$confirm("即将前往印章管理页面对印章进行管理，您确定进行该操作吗？", "印章管理", {
                type: "warning",
                confirmButtonText: "立即前往",
                cancelButtonText: "取消"
            }).then(_ => {
                window.open("/wesign/enterprise/seals/official")
            }).catch(_ => {})
        },
        allSignForm(){
            let forms = this.forms.filter(item => item.type === "SIGN")
            if (this.personalSeal){
                forms.map(item => item.data = this.personalSeal)
            } else {
                this.createSignature()
            }

            let docId = forms[0].docId
            let page = forms[0].page
            this.$nextTick(_ => {
                this.prevewNavSelect(docId, page)
            })
        },
        forgetSignPassword(){
            this.signConfirmDialogVisible = false
            this.signDialogVisible = true
        },
        closesignDialog(){
            this.signDialogVisible = false
        }
    },
    components: {
        envelopePreview,
        documentsPreviewBar,
        formRender,
        pagingSeal,
        splittedPagingSeal,
        imgBox,
        chooseSeals,
        chooseOfficalSeals,
        carousel,
        officalSealsList,
        leftFastJumpContainer,
        headerToolBar,
        footerToolBar,
        collapse,
        collapseItem,
        signatureConfirmVerify,
        revokeDialog,
        setSignPassword,
        signPasswordRetrieve
    }
}
</script>

<style lang="less" scoped>
@import '~@styles/variable.less';
//==================头部样式====================
.envelope-signature-header{
    z-index: 10;
    position: absolute;
    top:0;
    left: 0;
    width: 100%;
    height: @length-top-nav-height;
    line-height: @length-top-nav-height;
    background: @color-nav-background;
    box-shadow: @shadow-default;
    font-size: @font-size-primary;
    color:@color-list-font;


    .envelope-editor-back{
        cursor: pointer;
        float: left;
        margin-left: 20px;
    }

    .documents-info-toolbar{
        position: absolute;
        top:0;
        bottom: 0;
        left: 200px;
        right: 100px;
    }

    .envelope-signature-help{
        cursor: pointer;
        float: right;
        margin-right: 20px;

        i{
            font-size: 20px;
            vertical-align: middle;
        }
    }
}



.tools-container{
    display: flex;
    justify-content: center;

    & > div{
        margin-right: 50px;
    }

    .documents-select{
        width: 200px;
    }

    .document-progress{
        width: 100px;
    }

    .documents-scale{
        display: flex;
        align-items: center;
        width: 200px;

        i{
            width: 20px;
            text-align: center;
            cursor: pointer;
            font-size: @font-size-large;
        }
    }
}



.envelope-signature-footer{
    position: absolute;
    z-index: 10;
    height: @length-top-nav-height;
    line-height: @length-top-nav-height;
    left: 0;
    width: 100%;
    bottom: 0;
    text-align: center;
    overflow: hidden;
    background: @color-nav-background;
    box-shadow: @shadow-default;
}

.envelope-signature-container{
    z-index: 9;
    position: absolute;
    top:@length-top-nav-height;
    left: 0;
    width: 100%;
    bottom: @length-top-nav-height;

    .left-container{
        z-index:101;
        position: absolute;
        top:0;
        left: 0;
        bottom: 0;
        background: @color-nav-background;
        box-shadow: @shadow-default;
        font-size: @font-size-regular;
        transition: width .3s;
        overflow: auto;

        // .signatures-seals{
        //     position: absolute;
        //     left: 0;
        //     top:250px;
        //     bottom: 0;
        //     width: 100%;
        //     overflow: auto;
            
        // }

        .btn-fast-find-signature{
            display: block;
            width: 145px;
            height: 40px;
            margin: 20px auto;
        }

        .selectable-forms{
            margin: 20px 0;
            padding: 20px;
            font-size: @font-size-regular;
            text-align: center;
            border-bottom: 1px solid @color-border-segment;

            .form{
                cursor: pointer;
                box-sizing: border-box;
                margin: 10px;
                width: 140px;
                height: 40px;
                line-height: 40px;
                text-align: center;
                color: @color-main;
                border: 1px solid @color-main;
                border-radius: 5px;
            }
        }

        .personal-sign{
            border-bottom: 1px solid @color-border-segment;

            .title{
                padding: 10px 20px 0;
            }

            .signature{
                cursor: pointer;
                height: 60px;
                width: 160px;
                margin: 10px auto;
                border: 1px solid @color-border-segment;
                border-radius: 5px;
                line-height: 60px;
                text-align: center;
                font-size: @font-size-regular;

                &:hover{
                    color: @color-main;
                    border-color: @color-main;
                }
            }
        }
    }

    .fast-jump-container{
        z-index:100;
        position: absolute;
        top:0;
        bottom: 0;
        background: @color-nav-background;
        box-shadow: @shadow-default;
        transition: width .3s, left .3s;
        overflow: hidden;
    }

    .right-container{
        position: absolute;
        top:0;
        right: 0;
        bottom: 0;
        transition:  width .3s;

        .right-box{
            position: absolute;
            top:0;
            width: 100%;
            left: 0;
            bottom: 0;
            overflow: hidden;
        }

        .documents-preview-nav{
            position: absolute;
            top:0;
            width: 120px;
            left: 0;
            bottom: 0;
            background: @color-nav-background;
            box-shadow: @shadow-default;

            .title{
                font-size: @font-size-regular;
                text-align: center;
                height: 50px;
                line-height: 50px;
            }
            
            .documents-preview{
                position: absolute;
                top:50px;
                bottom: 0;
                left: 0;
                right: 0;
            }
        }

        .right-container-switch{
            cursor:pointer;
            z-index: 10;
            position: absolute;
            top:50%;
            left:0;
            height: 60px;
            width: 20px;
            text-align: center;
            transform: translate(-100%, -50%);
            background: rgba(0,0,0,0.1);
            transition: all .3s;

            &.open{
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
                transform: translate(0, -50%);
            }

            &.close{
                border-top-left-radius: 5px;
                border-bottom-left-radius: 5px;
                transform: translate(-100%, -50%);

                .line{
                    transform-origin: 50% 50%;
                    transform: rotateY(180deg);
                }
            }

            &:hover{
                background: @color-main;

                .line{
                    stroke:@color-white;
                }
            }

            .line{
                fill:transparent;
                stroke:@color-info;
                stroke-width:2;
                transition: all .3s;
            }
        }
    }

    .right-paging-seal-container{
        position: absolute;
        top:0;
        right: 0;
        bottom: 0;
        transition: width .3s;
        overflow: hidden;
        z-index: 11;
        background: @color-nav-background;
        box-shadow: @shadow-default;
    }

    .offical-seals{
        padding: 0 10px;

        .title{
            padding: 0 10px;

            .apply-seal{
                cursor: pointer;
                float: right;
                color:@color-main;
            }
        }
    }
    .document-container{
        position: absolute;
        top:0;
        left: 200px;
        bottom: 0;
        z-index: 10;
        transition:  right .3s;
    }
}

.page-form-container, .paging-seal-container{
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height: 100%;
}

.close-help{
    width:40px;
    height:40px;
    position:absolute;
    right:15px;
    top:5px;
    z-index:100;
    cursor:pointer;
}
</style>
<style lang="less">
.signature-help .el-carousel__container{
    .el-carousel__item, .el-carousel__mask{
        z-index:99
    }
    .carousel-img{
        width: 100%;
        height: inherit;
        min-height: 360px;
        min-width: 800px;
    }
        .el-carousel__item h3 {
        color: #475669;
        font-size: 18px;
        opacity: 0.75;
        line-height: 300px;
        margin: 0;
        z-index:99
    }
    .el-icon-arrow-left,.el-icon-arrow-right{
        font-size:30px;
    }
}
.signature-help .el-carousel__arrow{
    width:50px;
    height:50px;
    z-index:100;
}
.signature-help .el-carousel__indicators{
    z-index:99;
}
</style>

<style lang="less" scoped>
@import '~@styles/variable.less';

.seals-container{
    display: flex;
    flex-wrap: wrap;
    height: 420px;
    overflow: auto;
}

.seal-item{
    cursor: pointer;
    box-sizing: border-box;
    width: 80px;
    height: 80px;
    padding: 10px;
    margin-right: 10px;
    margin-bottom: 10px;
    border: 1px solid @color-border-segment;

    &:hover{
        border: 1px solid @color-main;
    }
}
</style>
<style lang="less">
.show-seal-contanier .el-dialog__body{
    padding:0 20px 20px 20px ;
}
</style>

<style lang="less" scoped>
@import '~@styles/variable.less';

.view-box{
    width: 200px;
    height: 100%;
    overflow: auto;

    .header{
        margin: 10px;
        text-align: right;
        font-size: @font-size-title;
        line-height: 20px;

        .close-nav{
            cursor: pointer;
        }
    }

    .forms-info{
        font-size: @font-size-primary;
        text-align: center;

        .count{
            color:@color-main;
        }
    }

    .documents-forms{
        position: absolute;
        box-sizing: border-box;
        top: 80px;
        left: 0;
        width: 200px;
        bottom:40px;
        overflow: auto;

        .info-block{
            padding: 10px;
        }

        .info{
            display: flex;
            margin: 5px 0;
            text-align: center;

            .page{
                flex:1;
            }

            .jump{
                cursor: pointer;
                color:@color-main;
                flex:1;
            }

            .status{
                flex:1;
                text-align: center;

                span{
                    padding: 1px 3px;
                    font-size: 12px;
                    background: rgb(153, 173, 206);
                    border-radius: 5px;
                    color: @color-white;
                }

                &.signed{
                    span{
                        background: @color-success;
                    }
                }
            }
        }
    }
}
</style>
<style lang="less" scoped>
@import '~@styles/variable.less';

.seal{
    display: flex;
    margin: 10px auto;
    align-items:center;
    min-height:70px;

    .seal-image{
        cursor: pointer;
        margin-right: 6px;
        border: 1px solid @color-border-segment;
    }

    .seal-text{
        flex:1;
        font-size: @font-size-info;
        line-height:25px;
        white-space: nowrap;
        overflow: hidden;

        .name{
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    }
}
.no-seal-info{
    padding: 10px 20px;
    text-align: center;

    .apply{
        display: inline-block;
        cursor: pointer;
        border: 1px solid @color-main;
        color: @color-main;
        border-radius: 3px;
        min-width: 80px;
        padding: 5px;
    }
}
.drag-seal{
    z-index: 999;
    position: fixed;
    border: 1px solid @color-border-segment;
}
</style>
<style lang="less" scoped>
@import '~@styles/variable.less';

.right-paging-seal-box{
    width: 200px;
    height: 100%;

    .selectable-forms{
        margin: 0 0 20px 0;
        padding: 20px;
        font-size: @font-size-regular;
        text-align: center;
    }
}

.offical-paggingseals{
    position: absolute;
    padding: 0 10px;
    left: 0;
    top: 70px;
    right: 0;
    bottom: 0;
    overflow: auto;
    border-top: 1px solid @color-border-segment;
}
</style>

<style lang="less" scoped>
@import '~@styles/variable.less';

.forms-count{
    display: inline-block;
    margin-right: 60px;
    width: 120px;
    text-align: center;
    font-size: @font-size-primary;
}

.btn-complete{
    height: 40px;
    width: 120px;
    margin-right: 60px;
}

.btn-danger{
    height: 40px;
    width: 80px;
    margin-right: 30px;
}
.forms-bottom{
    position: absolute;
    bottom: 10px;
    left: 0;
    right: 0;
    text-align: center;
}
</style>