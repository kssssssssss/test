<template>
    <div>
        <div class="title">您收到一封签约文件</div>
        <div class="login-container">
            <div class="tab-box" v-if="accountExist">
                <Tab :tabs="loginTabs" :activeTab="activeTypeIndex" @active-tab="chooseType" class="login-tab-nav invite-login-tab"></Tab>
            </div>
            <div class="tab-box" v-if="!accountExist">
                <p class="regisger">注册</p>
            </div>
            <div class="info-container">
                <p class="sub-title icon-paper-plane">来自"{{stateData.senderEnterpriseName || stateData.senderName}}"的签约文件</p>
                <p class="public-height info-name-box">
                    您好！<span class="info-name">{{stateData.username}}({{stateData.account}})</span> ：
                </p>
                <div>
                    <template v-if="stateData.roleType === 'ENTERPRISE_MEMBER' || stateData.roleType === 'ENTERPRISE_ROLE'">
                        <p class="public-height enterprise-name">接收方:<span class="envelope-name">{{stateData.enterpriseName || stateData.username}}</span></p>
                    </template>
                    <p class="public-height">
                        请&nbsp;<span class="info-type">{{typeName}}</span>&nbsp;文件<span class="info-title">《{{stateData.title}}》</span>
                    </p>
                    <div class="wesign-outside-error-box">
                        <p v-if="infoText" :class="infoClass">
                            <i :class="infoIcon"></i>
                            {{infoText}}
                        </p>
                    </div>
                </div>
            </div>
            <div style="width:80%;margin:0px auto;" v-if="activeTypeIndex === 0">
                <el-input v-if="!accountExist" class="wesign-outside-form-group" type="password" 
                    v-model="password" placeholder="请设置您在大家签的登录密码" @blur="checkPassword"/>
                <el-row class="wesign-outside-form-group">
                    <el-col :span="13">
                        <el-input size="large" v-model="verifyCode" :disabled="!isImport" :placeholder="!isImport ? '请点击右侧获取验证码' : '请输入验证码'"
                            @input="verifyCodeCheck = false" @blur="checkVerifycodeFormat()"/>
                    </el-col>
                    <el-col :span="10" :offset="1" style="font-size:14px">
                        <captchaButton ref="captchaButton" size="large" style="width:100%" :contact="account" :service="accountExist?'SIGNATURE_FILE_ACCESS':'REGIST'"
                            @sending="sending"
                            @error="sendVerifyCodeError" @sendsuccess="sendVerifyCodeSuccess" @timeShow="isImport = true" :type="verifyCodeType"></captchaButton>
                        <span style="cursor:pointer;margin-top:10px;float:right" v-show="showCodeExplainBtn" @click="showCodeExplain = true">收不到验证码？</span>
                    </el-col>
                </el-row>
                <div>
                    <el-button size="large" style="width:100%;" type="primary" :loading="nexting" @click="next">下一步</el-button>
                </div>
                <!-- <p class="tips" v-if="!accountExist">
                    提醒：您尚未是大家签用户，点击下一步，将自动注册且默认您已经同意<a href="https://www.signit.cn/layer/" target="_blank" class="wesign-outside-unline">大家签服务条款</a>
                </p> -->
            </div>
            <div style="width:80%;margin:0px auto;" v-if="activeTypeIndex === 1">
                <el-input class="wesign-outside-form-group" type="password" 
                    v-model="loginPassword" placeholder="请输入您的登录密码" @blur="checkPassword"/>
                <el-row v-if="showCaptcha" class="wesign-outside-form-group">
                    <el-col :span="13">
                        <el-input type="text" size="large" placeholder="请输入图形验证码" v-model.trim="captcha" @blur="checkCaptcha()" @keyup.enter.native="login"/>
                    </el-col>
                    <el-col :span="8" :offset="3">
                        <img class="verify-img" alt="点击刷新验证码" :src="captchaURL" @click="refreshCaptcha"/>
                    </el-col>
                </el-row>
                <div>
                    <el-button size="large" style="width:100%;" type="primary" :loading="logining" @click="login">登录</el-button>
                </div>
            </div>
        </div>
        <div class="signit">
            <img :src="require('@images/openapi-authorization/logo-ico.png')" style="width:20px">由大家签提供技术支持
        </div>
        <codeExplain v-show="showCodeExplain" @close-modal="showCodeExplain = false" :type="codeExplainType" :messages="codeExplainPublicMessage" :msg="codeExplainTitle" :message="codeExplainMessage" @close-dialog="showCodeExplain = false"></codeExplain>
    </div>
</template>

<script>
import { isPhone, isEmail, isPassword } from "@wesign/check"

import externalFrame from "@page-components/frames/external-frame.vue"
import captchaButton from "@components/buttons/captcha-button.vue"
import codeExplain from "@components/modal/code-explain.vue"
import Tab from "@components/commons/tabs/tab-default.vue"

import { userAccountInEnterprise } from "@utils/users.js"
import { verificationCodeSession, sessions_post } from "@interfaces/user/sessions.js"
import { usersRegist, 
    checkAccount,
    changeSession } from "@interfaces/user/user.js"
import { opcode_post } from "@interfaces/auth/captcha.js"
import { LoginLocalStatus, LoginComponentLocalInfo } from "@classes/login/login-info.js"

export default {
    data(){
        return {
            /** 
             * ERROR_LOGIN                      登录失败
             * ERROR_REGIST                     注册失败
             * 
             * ERROR_PASSWORD_LENGTH             密码长度应在6-32个字符之间
             * ERROR_PASSWORD_ALL_ENGLISH_LETTER 密码不能全是英文
             * ERROR_PASSWORD_ALL_NUMBER         密码不能全是数字
             * 
             * ERROR_VERIFICATION_ISNULL       请输入验证码
             * ERROR_VERIFICATION_CODE_FORMAT  请输入正确的验证码格式
             * ERROR_VERIFICATION_CODE_NOT_PASS验证码校验未通过
             * ERROR_SEND_BUSY                 发送频繁
             * ERROR_SEND_FAILED               发送失败
             * ERROR_CONTACT                   联系人格式错误
             *                 
             * RIGHT_SEND_LODING               发送中...
             * RIGHT_PHONE_VERIFICATION_SEND   手机发送成功
             * RIGHT_EMAIL_VERIFICATION_SEND   邮箱发送成功
             */

            accountExist: true, //账户是否存在
            password: "",
            verifyCode: "", //验证码
            passwordCheck: false,
            verifyCodeCheck: false,
            showCodeExplainBtn: false, //接收验证码说明按钮
            showCodeExplain: false, //接收验证码说明

            nexting: false,
            isImport: false,
            loginTypeTabs: [
                { name: "验证码登录", code: "CODE" },
                { name: "帐密登录", code: "PASSSWORD"},
            ],
            priorityStatus: [
                {name: "accountStatus", status: ""},
                {name: "captchaStatus", status: ""},
                {name: "codeFormat", status: ""},
                {name: "passwordStatus", status: ""},
            ],
            loginPassword: "",
            captcha: "", //验证码
            captchaURL: "/api/captcha/image-code?service=LOGIN&flag=1", //验证码地址
            localInfo: new LoginComponentLocalInfo(),
            commonStatus: "",
            logining: false,
            activeTypeIndex: -1,
            verifyCodeType: "SMS"
        }
    },
    computed: {
        stateData(){
            return this.$store.state
        },
        account(){
            return this.stateData.account
        },
        typeName(){
            if (!this.stateData) return
            switch (this.stateData.type) {
                case "CHECK":
                    return "审核"
                case "SIGN":
                    return "签署"
                case "VIEW":
                    return "查阅"
            }
        },
        infoText(){
            let status = this.infoStatus
            switch (status){
                case "ERROR_LOGIN": return "登录失败";break
                case "ERROR_REGIST": return "注册失败";break
                case "ERROR_ACOUNT_PASSWORD": return "账户或密码错误";break
                case "ERROR_MULTIPLE_ACOUNT_PASSWORD": return "帐号或密码错误";break
                case "ERROR_PASSWORD_LENGTH": return "密码长度应在6-32个字符之间";break
                case "ERROR_PASSWORD_ALL_ENGLISH_LETTER": return "密码不能全是英文";break
                case "ERROR_PASSWORD_ALL_NUMBER": return "密码不能全是数字";break
                case "ERROR_ACOUNT_NULL": return "帐号不存在，请确认后再输入";break
                case "ERROR_PASSWORD_ISNULL": return this.accountExist ? "请输入登录密码" : "请设置登录密码";break
                case "ERROR_VERIFICATION_ISNULL": return "请输入验证码";break
                case "ERROR_VERIFICATION_CODE": return "验证码错误";break
                case "ERROR_VERIFICATION_CODE_FORMAT":return "请输入正确的验证码格式";break
                case "ERROR_VERIFICATION_CODE_NOT_PASS" :return "验证码校验未通过";break
                case "ERROR_CONTACT": return "联系人格式错误";break
                case "ERROR_SEND_BUSY": return "发送太频繁，请倒计时结束后再点击"
                case "ERROR_SEND_FAILED": return "发送失败";break
                case "ERROR_SEND_TIMEOUT": return "发送请求超时";break
                case "ERROR_SEND_FREQUENTLY": return "发送请求过于频繁";break
                case "ERROR_SEND_AMOUNT_OUT_LIMIT": return "今日可接收验证码已达到上限";break
                case "RIGHT_SEND_LODING": return "发送中...";break
                case "RIGHT_LODING": return "登录中...";break
                case "RIGHT_PHONE_VERIFICATION_SEND": return "验证码已发送，请注意查收短信";break
                case "RIGHT_EMAIL_VERIFICATION_SEND": return "验证码已发送至指定邮箱，请查收";break
            }
        },
        infoClass(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-errorWarning"
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-rightWarning"
            }
        },
        infoIcon(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-color-danger icon-refuse2"
            } else if (status.match(/^RIGHT/)) {
                return "wesign-color-success icon-doing"
            }
        },
        codeExplainType(){
            let val = this.$data.account
            if (isPhone(val).result){
                return "PHONE"
            } else if (isEmail(val).result){
                return "EMAIL"
            }
        },
        codeExplainTitle(){
            let val = this.stateData.account
            if (isPhone(val).result){
                return "检查短信是否被屏蔽"
            } else if (isEmail(val).result){
                return "查看是否进入垃圾信息或广告信息"
            }
        },
        codeExplainPublicMessage(){
            let val = this.stateData.account
            if (isPhone(val).result){
                return "检查您的手机号是否正确"
            } else if (isEmail(val).result){
                return "检查您的邮箱号是否正确"
            }
        },
        codeExplainMessage(){
            let val = this.stateData.account
            if (isPhone(val).result){
                return "若2分钟内未收到短信，可重新获取"
            } else if (isEmail(val).result){
                return "若2分钟内未收到邮件，可重新获取"
            }
        },
        loginTabs(){
            return this.loginTypeTabs.map(t => t.name)
        },
        infoStatus(){
            let status = this.priorityStatus.find(item => {
                if (item.status){
                    return true
                }
            })

            return status && status.status || this.commonStatus
        },
    },
    watch: {
        showCaptcha(nv){
            this.localInfo.setShowCaptcha(nv)
        },
    },
    mounted(){
        this.showCaptcha = this.localInfo.showCaptcha
    },
    created(){
        this.checkAccountExist().then(exist => {
            this.accountExist = exist
        })
        this.activeTypeIndex = 0
    },
    methods: {
        chooseType(activeTypeIndex){
            this.activeTypeIndex = activeTypeIndex
            this.sending()
        },
        sending(){
            this.setInfoStatus("passwordStatus", "")
            this.setInfoStatus("codeFormat", "")
            this.setInfoStatus("captchaStatus", "")
        },
        setInfoStatus(name, status){
            let priorityStatus = this.priorityStatus
            priorityStatus.find((item, index) => {
                if (item.name === name){
                    item.status = status
                    if (status){
                        this.commonStatus = ""
                    }
                    priorityStatus.splice(index, 1)
                    priorityStatus.splice(0, 0, item)
                    return true
                }
            })
        },
        checkCaptcha(chekNull = false) {
            if (!this.showCaptcha) return true

            if (this.captcha === ""){
                if (!chekNull){
                    this.setInfoStatus("captchaStatus", "")
                    return true
                } else {
                    this.setInfoStatus("captchaStatus", "ERROR_VERIFICATION_ISNULL")
                    return false
                }
            } else if (!/^[\da-zA-Z]{4}$/.test(this.captcha)) {
                this.setInfoStatus("captchaStatus", "ERROR_VERIFICATION_CODE")
                return false
            } else {
                this.setInfoStatus("captchaStatus", "")
                return true
            }
        },
        checkAccountExist(){ //检测账户是否存在
            let account = this.stateData.account
            return checkAccount({
                account
            }).then(res => {
                return res.data.data.existed
            })
        },
        checkPassword(checkNull = false){
            if (!checkNull && this.$data.password === "" || !checkNull && this.loginPassword === ""){
                this.setInfoStatus("passwordStatus", "")
                return true
            }

            let password = this.password || this.loginPassword
            let checkData = isPassword(password)
            switch (checkData.code) {
                case 100: this.setInfoStatus("passwordStatus", "");break
                case 101: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ISNULL");break
                case 204: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_LENGTH");break
                case 205: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_LENGTH");break
                case 202: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ALL_NUMBER");break
                case 206: this.setInfoStatus("passwordStatus", "ERROR_PASSWORD_ALL_ENGLISH_LETTER");break 
            }
            this.passwordCheck = checkData.result
            return checkData.result
        },
        sendVerifyCodeError(msg) {
            switch (msg){
                case "ERROR_CONTACT": 
                    this.commonStatus = "ERROR_CONTACT"
                    break
                case "ERROR_SEND_BUSY": 
                    this.commonStatus = "ERROR_SEND_BUSY"
                    break
                case "ERROR_TIMEOUT":
                    this.commonStatus = "ERROR_SEND_TIMEOUT"
                    break
                case "ERROR_FREQUENTLY":
                    this.commonStatus = "ERROR_SEND_FREQUENTLY"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.commonStatus = "ERROR_SEND_AMOUNT_OUT_LIMIT"
                    break
                default:
                    this.commonStatus = "ERROR_SEND_FAILED"
            }
        },
        sendVerifyCodeSuccess(data){
            this.showCodeExplainBtn = true
            this.isImport = data
            if (isPhone(this.stateData.account).result){
                this.commonStatus = "RIGHT_PHONE_VERIFICATION_SEND"
            } else if (isEmail(this.stateData.account).result){
                this.commonStatus = "RIGHT_EMAIL_VERIFICATION_SEND"
            }
        },
        checkVerifycodeFormat(checkNull = false){ //验证码校验
            let val = this.verifyCode
            if (/^\d{6}$/.test(val)){
                this.verifyCodeCheck = true
                this.setInfoStatus("codeFormat", "")
                return true
            } else if (val === ""){
                if (!checkNull){
                    this.setInfoStatus("codeFormat", "")
                    return true
                } else {
                    this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_ISNULL")
                    this.verifyCodeCheck = false
                    return false
                }
            } else {
                this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                this.verifyCodeCheck = false
                return false
            }
        },
        refreshCaptcha(){
            this.captchaURL = this.captchaURL + "1"
        },
        async next(){
            if (!this.accountExist){
                if (!this.checkPassword(true) || !this.checkVerifycodeFormat(true)){
                    return
                }
            }

            if (!this.checkVerifycodeFormat(true)){
                return
            }
            this.nexting = true
            this.commonStatus = "RIGHT_LODING"
            let opcode = await opcode_post({
                captcha: this.verifyCode,
                contact: this.account,
                service: this.accountExist ? "SIGNATURE_FILE_ACCESS" : "REGIST"
            }).then(res => {
                return res.data.data.operationCodeInfo.opcode
            }).catch( err => {
                this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE_NOT_PASS")
                this.nexting = false
            })

            if (!opcode){
                this.nexting = false
                return
            }

            if (this.accountExist){
                await verificationCodeSession({
                    contact: this.account,
                    destinationWsid: this.stateData.targetUserWsid || undefined,
                    opcode
                }).then(async res => {
                    let session = res.data.data.session
                    let userPersonWsid = session.userPersonWsid
                    let userWsid = session.userWsid
                    let targetUserWsid = this.stateData.targetUserWsid

                    //有企业名称但是没有targetWsid
                    if (this.stateData.enterpriseName && !targetUserWsid){
                        let session = res.data.data.session
                        let account = await userAccountInEnterprise(session.userWsid, this.stateData.enterpriseName)
                        if (account){
                            targetUserWsid = account.userWsid
                        } else {
                            //没加入企业
                            targetUserWsid = userPersonWsid
                        }
                    }

                    if (!targetUserWsid){
                        targetUserWsid = userPersonWsid
                    }

                    if (userWsid !== targetUserWsid){
                        await changeSession({
                            userWsid: userWsid,
                            destinationWsid: targetUserWsid
                        })
                    }

                    this.nexting = false

                    let envelopeWsid = this.$store.state.envelopeWsid
                    let pageCallback = decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")
                    let selectedAuthTypes = this.$route.query.selectedAuthTypes
                    let enableNoAppearance = this.$route.query.enableNoAppearance
                    let enableSimpleDisplay =  this.$route.query.enableSimpleDisplay
                    let appId = this.$route.query.appId
                    if (this.$store.state.type === "SIGN"){
                        location.href = `/to-signature?envelopeWsid=${envelopeWsid}&action=SIGN&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&username=${this.stateData.username}&phone=${this.$route.query.phone}&appId=${appId}&pageCallback=${pageCallback}`
                    } else if (this.$store.state.type === "CHECK"){
                        location.href = `/to-signature?envelopeWsid=${envelopeWsid}&action=CHECK&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&username=${this.stateData.username}&phone=${this.$route.query.phone}&appId=${appId}&pageCallback=${pageCallback}`
                    }

                    // if (this.$store.state.type === "SIGN"){
                    //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/signature?pageCallback=${decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")}`
                    // } else if (this.$store.state.type === "CHECK"){
                    //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/audit?pageCallback=${decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")}`
                    // } else if (this.$store.state.type === "VIEW"){
                    //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/detail`
                    // }
                }).catch(err => {
                    this.nexting = false
                    this.commonStatus = "ERROR_LOGIN"
                    console.error(err)
                })
            } else {
                await usersRegist({
                    nickname: this.account, //用户名
                    account: this.account, //联系方式
                    password: this.password,
                    registFrom: "WEB", //来源  当然是默认WEB啦~~~
                    loginNow: true,
                    opcode //操作码
                }).then(res => {
                    this.nexting = false

                    let envelopeWsid = this.$store.state.envelopeWsid
                    let selectedAuthTypes = this.$route.query.selectedAuthTypes
                    let enableNoAppearance = this.$route.query.enableNoAppearance
                    let enableSimpleDisplay =  this.$route.query.enableSimpleDisplay
                    let appId = this.$route.query.appId
                    let pageCallback = decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")
                    if (this.$store.state.type === "SIGN"){
                        location.href = `/to-signature?envelopeWsid=${envelopeWsid}&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&username=${this.stateData.username}&phone=${this.$route.query.phone}&appId=${appId}&action=SIGN&pageCallback=${pageCallback}`
                    } else if (this.$store.state.type === "CHECK"){
                        location.href = `/to-signature?envelopeWsid=${envelopeWsid}&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&username=${this.stateData.username}&phone=${this.$route.query.phone}&appId=${appId}&action=CHECK&pageCallback=${pageCallback}`
                    }

                    // if (this.$store.state.type === "SIGN"){
                    //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/signature?pageCallback=${decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")}`
                    // } else if (this.$store.state.type === "CHECK"){
                    //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/audit?pageCallback=${decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")}`
                    // } else if (this.$store.state.type === "VIEW"){
                    //     location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/detail`
                    // }
                }).catch(err => {
                    this.commonStatus = "ERROR_REGIST"
                    this.nexting = false
                })
                // await sessions_post({
                //     accountNumber: this.account,
                //     password: this.password,
                //     loginType: "WEB"
                // }).then(res => {
                //     //判断签署还是审核
                //     if (this.$store.state.type === "SIGN"){
                //         location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/signature?pageCallback=${decodeURIComponent(this.$store.state.pageCallback)}`
                //     } else {
                //         location.href = `/wesign/envelopes/${this.$store.state.envelopeWsid}/audit?pageCallback=${decodeURIComponent(this.$store.state.pageCallback)}`
                //     }
                // }).catch(err => {
                //     this.infoStatus = "ERROR_LOGIN"
                // })
            }
        },
        async login(){
            if (!this.checkPassword(true)){
                return
            }
            
            if (!this.checkCaptcha(true)){
                return
            }
            this.logining = true
            sessions_post({
                accountNumber: this.account,
                password: this.password || this.loginPassword,
                verificationCode: this.captcha,
                loginType: "WEB"
            }).then(async res => {
                let session = res.data.data.session
                let userPersonWsid = session.userPersonWsid
                let userWsid = session.userWsid
                let targetUserWsid = this.stateData.targetUserWsid

                //有企业名称但是没有targetWsid
                if (this.stateData.enterpriseName && !targetUserWsid){
                    let session = res.data.data.session
                    let account = await userAccountInEnterprise(session.userWsid, this.stateData.enterpriseName)
                    if (account){
                        targetUserWsid = account.userWsid
                    } else {
                        //没加入企业
                        targetUserWsid = userPersonWsid
                    }
                }

                if (!targetUserWsid){
                    targetUserWsid = userPersonWsid
                }

                if (userWsid !== targetUserWsid){
                    await changeSession({
                        userWsid: userWsid,
                        destinationWsid: targetUserWsid
                    })
                }

                this.logining = false
                let envelopeWsid = this.$store.state.envelopeWsid
                let pageCallback = decodeURIComponent(this.$store.state.pageCallback || "DEFAULT")
                let selectedAuthTypes = this.$route.query.selectedAuthTypes
                let enableNoAppearance = this.$route.query.enableNoAppearance
                let enableSimpleDisplay =  this.$route.query.enableSimpleDisplay
                let appId = this.$route.query.appId
                if (this.$store.state.type === "SIGN"){
                    location.href = `/to-signature?envelopeWsid=${envelopeWsid}&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&username=${this.stateData.username}&phone=${this.$route.query.phone}&appId=${appId}&action=SIGN&pageCallback=${pageCallback}`
                } else if (this.$store.state.type === "CHECK"){
                    location.href = `/to-signature?envelopeWsid=${envelopeWsid}&enableNoAppearance=${enableNoAppearance}&enableSimpleDisplay=${enableSimpleDisplay}&selectedAuthTypes=${selectedAuthTypes}&username=${this.stateData.username}&phone=${this.$route.query.phone}&appId=${appId}&action=CHECK&pageCallback=${pageCallback}`
                }
            }).catch(err => {
                console.log(err)
                if (err.response && err.response.data){
                    let code = err.response.data.code
                    switch (code) {
                        case 101:
                            this.setInfoStatus("accountStatus", "ERROR_ACOUNT_NULL")
                            break 
                        case 102:
                            this.password = ""
                            this.loginPassword = ""
                            this.$data.commonStatus = "ERROR_ACOUNT_PASSWORD"
                            break
                        case 103:
                            this.showCaptcha = true
                            this.password = ""
                            this.loginPassword = ""
                            this.$data.commonStatus = "ERROR_MULTIPLE_ACOUNT_PASSWORD"
                            break
                        case 104:
                            this.showCaptcha = true
                            this.setInfoStatus("captchaStatus", "ERROR_VERIFICATION_CODE")
                            break
                        default:
                            this.$data.commonStatus = "ERROR_LOGIN"
                    }
                }
                this.refreshCaptcha()
                this.captcha = ""
                this.logining = false
                console.log(err)
            })
        },
    },
    components: { 
        externalFrame, 
        captchaButton,
        codeExplain,
        Tab
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.title{
    margin: 3.5% 0;
    font-size: @font-size-primary;
    height:40px;
    line-height:40px;
    text-align:center;
}

.sub-title{
    font-size: @font-size-regular;
    height:30px;
    line-height:30px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}

.login-container{
    width: 96%;
    max-width:400*@px;
    min-width: 280px;
    height: auto;
    min-height:400*@px;
    margin:0 auto;
    background:@color-white;
    box-shadow:@shadow-default;
    border-radius: 6px;
    z-index:99;
}
.tab-box{
    border-bottom:1px solid @color-border
}
.login-tab-nav{
    justify-content: center;
    padding-top: 15px !important;
}
.verify-img{
    cursor: pointer;
    box-sizing: border-box;
    line-height: 42px;
    height: 42px;
    min-width: 42px;
    float: right;
    border: 1px solid #000;
}
.info-name, .info-title, .info-type{
    color:@color-main;
}

.info-container{
    text-align: left;
    font-size: @font-size-regular;
    width:80%;
    margin:10px auto 0 auto;
    .public-height{
        height:25px;
        line-height:25px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
}
.enterprise-name,.info-name-box{
    font-size:@font-size-regular;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap
}
.tips{
    margin-top: 10px;
    font-size: @font-size-regular;
    padding-bottom:10px;
}
.signit{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    text-align:center;
}
.regisger{
    text-align:center;
    padding:10px 0;
}
</style>
<style lang="less">
.invite-login-tab .tab{
    width:50%;
    margin-right:0 !important;
    justify-content: center;
}
</style>

