<template lang="html">
    <externalFrame>
        <div style="padding: 20px">
            <register></register>
        </div>
    </externalFrame>
</template>

<script>
import externalFrame from "@page-components/frames/external-frame.vue"
import register from "@components/login/register.vue"

export default {
    components: { register, externalFrame }
}
</script>