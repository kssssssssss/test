<!--
    @id        page-signature-pad
    @desc      扫码签名页面
    @level     page：页面组件
    @author    周雪梅,陈曦源
    @date      2018-09-04 16:56:18
-->

<template>
    <div>
        <div class="link-error" v-if="pageStatus === 'LINK_ERROR'">
            <p class="danger-icon">
                <i class="icon-refuse2"></i>
            </p>
            <p>页面识别失败</p>
            <p>请尝试重新生成二维码并扫描</p>
        </div>
        <div class="link-error" v-if="pageStatus === 'UPLOAD_ERROR'">
            <p class="danger-icon">
                <i class="icon-refuse2"></i>
            </p>
            <p>上传签名失败</p>
            <p>请尝试刷新页面或者重新签署</p>
            <div class="close" @click="resign">
                重新签署
            </div>
        </div>
        <div class="upload-success" v-if="pageStatus === 'UPLOAD_SUCCESS'">
            <p class="success-icon">
                <i class="icon-complete"></i>
            </p>
            <p>上传签名成功</p>
            <p>请在网页查看您的签名</p>
            <div class="resign" @click="resign">
                重新签署
            </div>
        </div>
    </div>
</template>

<script>
import SignaturePad from "signature_pad"

import "@wesign/yqq-signature-pad"

import SystemLoading from "@commons/system-loading.js"

import { 
    joinRoom,
    uploadData
} from "@interfaces/web-socket/scan-upload.js"

export default {
    data() {
        return {
            /**
             * LINKING 连接中
             * LINK_ERROR 连接失败
             * SIGNING 签署中
             * UPLOAD_SUCCESS 上传成功
             * UPLOAD_ERROR 上传失败
             */
            pageStatus: "LINKING",
            
            key: window.location.href.split("key=")[1],
            roomHandle: null,
        }
    },
    watch: {
        pageStatus(nv){
            if (nv === "LINKING"){
                SystemLoading.open()
            } else if (nv === "SIGNING"){
                SystemLoading.close()
                let that = this
                let signature = new YQQSignaturePad({
                    showBackOption: false,
                    saveSignImage: function(imageData){
                        that.signComplete(imageData)
                        signature.close()
                    },
                })
            } else {
                SystemLoading.close()
            }
        }
    },
    created(){
        let roomHandle = joinRoom({
            roomkey: this.key
        }, err => {
            if (err){
                this.pageStatus = "LINK_ERROR"
            } else {
                this.pageStatus = "SIGNING"
            }
        })

        SystemLoading.open()
        SystemLoading.setLoadingText("正在与网页构建连接")
    },
    methods: {
        signComplete(data){
            SystemLoading.open()
            SystemLoading.setLoadingText("正在上传签名数据")
            
            uploadData({
                roomkey: this.key,
                imageData: data
            }, err => {
                if (err){
                    this.pageStatus = "UPLOAD_ERROR"
                } else {
                    this.pageStatus = "UPLOAD_SUCCESS"
                }
                SystemLoading.close()
            })
        },
        resign(){
            this.pageStatus = "SIGNING"
        },
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

html,body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
}

.link-error{
    position: absolute;
    top:50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 250px;
    height: 200px;
    border: 1px solid @color-danger;
    border-radius: 5px;
    text-align: center;
    color: @color-danger;

    .danger-icon{
        margin: 30px;
    }

    .close{
        position: absolute;
        bottom: -60px;
        height: 40px;
        line-height: 40px;
        left: 0;
        right: 0;
        border: 1px solid @color-info;
        border-radius: 5px;
        color:@color-info;
    }

    i{
        color: @color-danger;
        font-size: 70px;
    }
}

.upload-success{
    position: absolute;
    top:50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 2.5rem;
    // height: 200px;
    border: 1px solid  @color-success;
    border-radius: 5px;
    text-align: center;
    color: @color-success;

    .success-icon{
        margin: 30px;
    }

    .resign{
        position: absolute;
        bottom: -60px;
        height: 40px;
        line-height: 40px;
        left: 0;
        right: 0;
        border: 1px solid @color-info;
        border-radius: 5px;
        color:@color-info;
    }

    i{
        color: @color-success;
        font-size: 70px;
    }
}

.pad-container{
    position: fixed;
    top: 50%;
    left: 50%;
}
</style>