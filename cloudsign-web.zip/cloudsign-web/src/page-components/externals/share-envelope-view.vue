<!--
    @id        page-envelope-audit
    @desc      信封预览页面
    @level     page
    @props     外部属性
    @author    陈曦源
    @date      2019-03-27 18:32:34
-->
<template>
  <div>
    <div class="envelope-signature-header">
      <div class="envelope-editor-back">
                <!-- <i class="el-icon-arrow-left"></i> -->
                文件预览
      </div>
      <div class="documents-info-toolbar">
        <div class="documents-select">
          <el-select :value="activeDocumentId" size="mini" @change="gotoDocument">
            <el-option
              v-for="document in documents"
              :key="document.id"
              :value="document.id"
              :label="document.name"
            ></el-option>
          </el-select>
        </div>
        <div class="document-progress">
          <span>
            <el-input-number
              style="width:50px;"
              size="mini"
              :value="activePage"
              :min="1"
              :max="activeDocumentData.pagesCount"
              :controls="false"
              @change="gotoPage"
            ></el-input-number>
          </span>
          <span>/{{activeDocumentData.pagesCount}}</span>
        </div>
        <div class="documents-scale">
          <el-select v-model="scale" style="width: 100px;" size="mini" placeholder>
            <el-option
              v-for="s in scaleList"
              :key="s"
              :value="s"
              :label="(s * 100 / CSS_UNITS).toFixed(0) + '%'"
            ></el-option>
          </el-select>
          <i class="el-icon-zoom-in" @click="zoomIn"></i>
          <i class="el-icon-zoom-out" @click="zoomOut"></i>
        </div>
      </div>
      <div class="download" v-if="envelopeData.status === 'ED_SUCCESS' || envelopeData.envelopeShownStatus === 'SUCCESS_COMPLETED'">
        <span class="wesign-color-main download" @click="downloadDocuments"><i class="icon-download wesign-color-main"></i>下载</span>
      </div>
    </div>
    <div class="envelope-signature-container">
      <envelopePreview
        ref="preview"
        :linkKey="linkKey"
        class="document-container"
        :style="{right:rightNavOpen?'120px':0}"
        :envelopeWsid="envelopeWsid"
        :scale="scale"
        @loaded="documentsLoaded"
        @view-update="documentsViewUpdate"
      ></envelopePreview>
      <div class="right-container" :style="{width:rightNavOpen?'120px':0}">
        <div
          class="right-container-switch"
          :class="{open:rightNavOpen, close:!rightNavOpen}"
          @click="rightNavOpen = !rightNavOpen"
        >
          <svg width="20" height="60">
            <polyline points="7,10 13,30 7,50" class="line" />
          </svg>
        </div>
        <div class="right-box">
          <div class="documents-preview-nav">
            <div class="title">文档列表</div>
            <documentsPreviewBar
              class="documents-preview"
              ref="previewbar"
              :documents="documents"
              :activeData="{
                                docId: activeDocumentId,
                                page: activePage
                            }"
              @select-docpage="prevewNavSelect"
            ></documentsPreviewBar>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { formatDate } from "@commons/util.js"
import querystring from "querystring"
import { getSessionData } from "@interfaces/user/sessions.js"
import { getUserData } from "@interfaces/user/user.js"
import { getEnvelopeData } from "@interfaces/envelopes/index.js"
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"
import { verifyEnvelopByWsid } from "@interfaces/verifiers.js"
import {
  getShareEnvelopeContents,
  getShareEnvelope,
  downloadShareEnvelope
} from "@interfaces/envelopes/share/index.js"


import envelopePreview from "@components/commons/share/envelope-preview.vue"
import documentsPreviewBar from "@components/commons/share/documents-preview-bar.vue"
import signBlock from "@components/envelopes/envelope-preview/sign-block.vue"

const CSS_UNITS = 96.0 / 72.0

export default {
    data(){
        return {
            verifyState: 0, //验证状态  0未验证 1验证中 2验证完成
            envelopeWsid: "",
            envelopeData: null,

            activeDocumentId: "", //当前浏览活跃的文档
            activePage: 1,
            documents: [],
            documentsData: [],
            enterpriseRoles: [], //当前人的企业角色

            scale: 1 * CSS_UNITS,
            scaleList: [
                0.75 * CSS_UNITS,
                1 * CSS_UNITS,
                1.25 * CSS_UNITS,
                1.5 * CSS_UNITS
            ],
            CSS_UNITS: CSS_UNITS,

            rightNavOpen: true,

            signedFields: 0,
            validSignedFields: 0,
            verifiers: [],
            verified: false,
            verifyStatus: "",
            signData: {
                certInfo: {
                    tsaResult: {
                        timeStampDate: {}
                    }
                },
                signInfo: {}
            },
            signDataDialog: false,
            showPdfVerifyDialog: false,
            verifyResult: [],
            expands: [],
            linkKey:"",
            // loading:false
        }
    },
    computed: {
        activeDocumentData(){
            let index = this.documents.findIndex(doc => doc.id === this.activeDocumentId)
            if (this.documentsData[index]){
                return this.documentsData[index]
            } else {
                return {
                    pagesCount: 0
                }
            }
        },
        signBlockMap(){
            let verifiers = this.verifiers
            let map = {}

            verifiers.forEach(verifier => {
                let verifyResult = verifier.verifyResult
                let docId = verifier.fileWsid
                verifyResult.forEach(data => {
                    let page = data.signInfo.page
                    let slot = `${docId}_${page}`
                    if (!map[slot]) map[slot] = []
                    map[slot].push(data)
                })
            })

            return map
        },
        activeUserParticipantWsid(){ //个人用PUSER 企业用EMEM
            if (this.$store.getters.userEdition === "p"){
                return this.$store.getters.activeUserWsid
            } else {
                return this.$store.getters.memberWsid
            }
        },
        isSender(){
            if (this.envelopeData){
                return this.activeUserParticipantWsid === this.envelopeData.senderWsid
            } else {
                return false
            }
        }
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.linkKey = query.token.split("&")[0] || query.token
        this.envelopeWsid = query.envelopeWsid
        this.activePage = 1
        this.init()
        // this.shareLoading = true
    },
    methods: {
        init(){
            getShareEnvelope({
                envelopeWsid: this.envelopeWsid,
                linkKey:this.linkKey
            }).then(res => {
                let envelope = res.data.data.envelope
                this.envelopeData = envelope.basicInfo
                if (envelope.basicInfo.envelopeShownStatus === "SUCCESS_COMPLETED" //只有完成或者完成后作废才会有表单项渲染进PDF
                    || envelope.basicInfo.envelopeShownStatus === "INVALIDATE"
                    || envelope.basicInfo.status === "ED_SUCCESS") {
                        return 
                    } else {
                        location.href = `/share-login?senderName=${this.envelopeData.senderName}&envelopeWsid=${this.envelopeWsid}&linkKey=${this.linkKey}`
                    }
            }).catch(err => {
                console.error(err)
                this.$message.error("加载文件详情失败")
            })

            getShareEnvelopeContents({
                envelopeWsid: this.envelopeWsid,
                linkKey:this.linkKey
            }).then(res => {
                let documents = res.data.data.contents
                documents = documents.map(document => {
                    return {
                        id: document.fileWsid,
                        pdfSrc: `/api/envelopes/share/${this.envelopeWsid}/contents/files/${document.fileWsid}?linkKey=${this.linkKey}`,
                        name: document.fileName
                    }
                })
                this.documents = documents
                this.activeDocumentId = this.documents[0].id
                
            }).catch(err => {
                this.$message.error("加载文件文档数据失败")
                console.error(err)
            })
        },
        // back(){
        //   window.history.back(-1)
        // },
        documentsLoaded(documentsData){
            this.documentsData = documentsData
        },
        documentsViewUpdate(updateInfo){
            this.activeDocumentId = updateInfo.docId
            this.activePage = updateInfo.page
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, this.activePage)
        },
        zoomIn(){
            let biggerScale = this.scaleList.find(scale => scale > this.scale)
            if (biggerScale){
                this.scale = biggerScale
            }
        },
        zoomOut(){
            let index = this.scaleList.findIndex(scale => scale >= this.scale)
            if (index == undefined) index = this.scaleList.length
            if (index > 0) index--
            this.scale = this.scaleList[index]
        },
        gotoDocument(docId){ //选择文档
            this.$refs.preview.gotoDocumentPage(docId, 1)
            this.$refs.previewbar.gotoDocumentPage(docId, 1)
        },
        gotoPage(page){
            this.$refs.preview.gotoDocumentPage(this.activeDocumentId, page)
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, page)
        },
        prevewNavSelect(docId, page){
            this.$refs.preview.gotoDocumentPage(docId, page)
        },
        verifyEnvelope(){
            if (this.verifyState > 0) return
            this.verifyState = 1
            let files = this.documents.map(doc => {
                return {
                    fileWsid: doc.id,
                    expectScaleResult: 1
                }
            })
            
            verifyEnvelopByWsid({
                files
            }).then(res => {
                this.showPdfVerifyDialog = true
                let verifiers = res.data.data.verifiers
                let signedFields = 0
                let validSignedFields = 0
                verifiers.forEach(verifier => {
                    signedFields += verifier.signedFields
                    validSignedFields += verifier.validSignedFields
                    this.verifyResult = verifier.verifyResult
                })
                this.signedFields = signedFields
                this.validSignedFields = validSignedFields
                this.verifiers = verifiers
                this.verified = true
                this.verifyState = 2
            }).catch(err => {
                this.verifyState = 0
                this.$message.error("获取文件签名信息失败")
            })
        },
        viewSignData(data){
            this.signData = data
            this.signDataDialog = true
        },
        translateTime(time){
            return formatDate(time, "YYYY-MM-dd HH:mm:ss")
        },
        downloadDocuments(){
          this.$confirm(`您确定下载文件《${this.envelopeData.title}》?`, "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                return  downloadShareEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    linkKey:this.linkKey,
                  }).then(res =>{
                    this.$message.success("下载文件成功")
                  }).catch(err=>{
                    console.error(err)
                    this.$message.error("下载文件失败")
                  })
            }, () => {})
        }
    },
    components: {
        envelopePreview,
        documentsPreviewBar,
        signBlock
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

.envelope-signature-header {
  z-index: 10;
  position: absolute;
  display: flex;
  top: 0;
  left: 0;
  width: 100%;
  height: @length-top-nav-height;
  line-height: @length-top-nav-height;
  background: @color-nav-background;
  box-shadow: @shadow-default;
  font-size: @font-size-primary;
  color: @color-main;

  .envelope-editor-back {
    cursor: pointer;
    width: 100px;
    margin-left: 20px;
  }

  .documents-info-toolbar {
    display: flex;
    flex: 1;
    justify-content: center;

    & > div {
      margin-right: 50px;
    }

    .documents-select {
      width: 200px;
    }

    .document-progress {
      width: 100px;
    }

    .documents-scale {
      width: 180px;

      i {
        width: 20px;
        text-align: center;
        cursor: pointer;
        font-size: @font-size-large;
      }
    }
  }

  .envelope-signature-verify {
    cursor: pointer;
    width: 200px;
    margin-right: 20px;
    text-align: right;

    i {
      font-size: 20px;
      vertical-align: middle;
    }
  }
}

.envelope-signature-container {
  z-index: 9;
  position: absolute;
  top: @length-top-nav-height;
  left: 0;
  width: 100%;
  bottom: 0;

  .envelope-verify-result {
    z-index: 10000;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    min-height: 30px;
    line-height: 30px;
    text-align: center;
    background: fade(@color-success, 90);
    color: @color-white;
    transition: right 0.3s;
    p {
      display: inline-block;
    }
  }

  .right-container {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    transition: width 0.3s;

    .right-box {
      position: absolute;
      top: 0;
      width: 100%;
      left: 0;
      bottom: 0;
      overflow: hidden;
    }

    .documents-preview-nav {
      position: absolute;
      top: 0;
      width: 120px;
      left: 0;
      bottom: 0;
      background: @color-nav-background;
      box-shadow: @shadow-default;

      .title {
        font-size: @font-size-regular;
        text-align: center;
        height: 50px;
        line-height: 50px;
      }

      .documents-preview {
        position: absolute;
        top: 50px;
        bottom: 0;
        left: 0;
        right: 0;
      }
    }

    .right-container-switch {
      cursor: pointer;
      z-index: 10;
      position: absolute;
      top: 50%;
      left: 0;
      height: 60px;
      width: 20px;
      text-align: center;
      transform: translate(-100%, -50%);
      background: rgba(0, 0, 0, 0.1);
      transition: all 0.3s;

      &.open {
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
        transform: translate(0, -50%);
      }

      &.close {
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
        transform: translate(-100%, -50%);

        .line {
          transform-origin: 50% 50%;
          transform: rotateY(180deg);
        }
      }

      &:hover {
        background: @color-main;

        .line {
          stroke: @color-white;
        }
      }

      .line {
        fill: transparent;
        stroke: @color-info;
        stroke-width: 2;
        transition: all 0.3s;
      }
    }
  }

  .document-container {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    transition: right 0.3s;
  }
}

.statue-icon {
  text-align: center;
  margin-bottom: 20px;

  p.title {
    font-size: @font-size-primary;
    font-weight: bold;
  }

  p.info {
    font-size: @font-size-info;
  }

  i {
    font-size: 60px;
  }

  .success {
    color: @color-success;
  }

  .danger {
    color: @color-danger;
  }
}

.infos {
  padding: 20px 30px;
  width: 460px;
  margin: auto;
  box-sizing: border-box;
  background: #f4f8f9;
  font-size: @font-size-info;

  .title {
    color: @color-success;
    font-size: @font-size-regular;
    font-weight: bold;
    margin-top: 10px;
  }
  .signature-info {
    p {
      word-wrap: break-word;
    }
  }
}

.colse-btn {
  width: 180px;
}
.complete {
  color: #51c78a;
  font-size: 28px;
}
.warning {
  color: #ffc34d;
  font-size: 28px;
}
.danger {
  color: #fe4f3d;
  font-size: 28px;
}
.min-width {
  min-width: 260px;
}

.publisher {
  min-height: 50px;
}

.pdf-verify-header {
  text-align: center;
  line-height: 25px;
  padding-bottom: 15px;
}
.verify-result {
  text-align: center;
}
.info {
  font-size: 14px !important;
  font-weight: bold;
}
.dialog-footer {
  text-align: center;
}
.download{
  width: 90px;
  span{
    margin-right: 20px;
    cursor: pointer;
  }
}
</style>
<style>
.paf-verify-dialog .el-dialog {
  width: 100%;
  max-width: 1000px;
  position: relative;
}
@media screen and (max-width: 375px) {
  .dialog-title {
    width: 100%;
    max-width: 200px;
  }
}
.dialog-title {
  width: 80%;
  color: #1f2d3d;
  font-weight: bold;
  position: absolute;
  top: 18px;
  left: 50%;
  right: 50%;
  font-size: 16px;
  transform: translateX(-50%);
}
.paf-verify-dialog .el-dialog__footer {
  text-align: center;
}
.paf-verify-dialog .el-form-item {
  display: block !important;
}
.paf-verify-dialog .el-table__expand-icon:after {
  content: "查看详情";
  color: #0c7ffc;
  cursor: pointer;
}
.paf-verify-dialog .el-table__expand-icon {
  line-height: 40px;
  height: 40px !important;
}
.paf-verify-dialog .el-table__expand-icon--expanded {
  transform: rotate(0);
}
.paf-verify-dialog .el-table__expand-icon > i {
  display: none !important;
}
.paf-verify-dialog .el-table__expanded-cell {
  padding: 20px !important;
}
.paf-verify-dialog .el-table__body-wrapper {
  max-height: 300px;
  overflow-y: auto;
}
.paf-verify-dialog .el-table__header-wrapper .el-table__header th {
  text-align: center;
}
.paf-verify-dialog .el-table .cell {
  text-align: center;
}
.paf-verify-dialog .el-form-item {
  margin-bottom: 0 !important;
}
.demo-table-expand {
  font-size: 0;
}
</style>
