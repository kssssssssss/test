<!--
    @id        signature
    @desc      签名页面
    @level     system：系统组件
    @author    潘维,陈曦源
    @date      2019-04-17 16:46:56
-->
<template>
  <div>
    <div class="container" ref="envelopeContainer">
        <div class="title">
            <p>文件详情</p>
            <p v-if="actionConfig.revokeable"  @click="toRevoke" class="remoke">撤销</p>
        </div>
        <div class="envelope-container">
            <envelopePreview ref="preview" style="z-index: 0;" :scale="resizeScale" :envelopeWsid="envelopeWsid"
                @loaded="documentsLoaded" @view-update="documentsViewUpdate" class="doc-container">
            </envelopePreview> 
            <div class="left-container" :style="{width:leftNavOpen?'0.6rem':0}">
                <div class="open" @click="leftNavOpen = !leftNavOpen">
                    <i v-if="!leftNavOpen" class="icon-right"></i>
                    <i v-else class="icon-left"></i>
                </div>
                <div class="left-box">
                    <div class="documents-preview-nav">
                        <documentsPreviewBar class="documents-preview" ref="previewbar" :documents="documents" 
                            :activeData="{
                                docId: activeDocumentId,
                                page: activePage
                            }" @select-docpage="prevewNavSelect">
                        </documentsPreviewBar>
                    </div>
                </div>
            </div>
        </div>
        <div class="envelope-info">
            <mt-button v-if="actionConfig.cannotpass" plain type="primary" class="reject btn" @click="refuseCheck">不通过</mt-button>
            <mt-button v-if="actionConfig.auditable" type="primary" size="normal" class="confirm btn" @click="checkPass">通过</mt-button>
        </div>
    </div>
  </div>
</template>

<script>
import { MessageBox } from "mint-ui"
import { Toast } from "mint-ui"
import { Indicator } from "mint-ui"

import wesignSignatureSDK from "@commons/wesign-signature-sdk-child.js"
import { translateParticipantDatasFromEnd } from "@classes/envelopes/participants.js"
import documentsPreviewBar from "@components/mobile/envelopes/envelope-preview-bar.vue"
import formRender from "@components/mobile/forms/form-render.js"
import envelopePreview from "@components/commons/documents/envelope-preview.vue"
import { EnvelopeStatus} from "@classes/mobile/envelopes.js"
import ParticipantsClasses from "@classes/envelopes/participants.js"
import { ACTIONS, gotoOpenSignatureReturnURL } from "@classes/openapi/sign-callback.js"

import { getPersonSeals, uploadPersonalSeals } from "@interfaces/seals/seals.js" 
import { getEnvelopeData } from "@interfaces/envelopes/index.js"
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"
import {getEnvelopeParticipants } from "@interfaces/envelopes/participants.js"
import {rejectEnvelope, checkEnvelope, revokeEnvelope} from "@interfaces/envelopes/envelope.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import { viewEnvelope } from "@interfaces/envelopes/envelope.js"
import { startPersonAuthProcess } from '@interfaces/openapi/person-authentication.js'

export default {
    data(){
        return {
            pageCallback: "", //回调链接

            forms: [],
            envelopeWsid: this.$store.state.envelopeWsid,
            currentSequence: -1,
            documents: [],
            documentsData: [],
            enterpriseRoles: [], //当前人的企业角色
            scale: 1,
            activeDocumentId: "", //当前浏览的文档
            activePage: 1,
            leftNavOpen: false,
            
            senderWsid: "",
		 }
    },
    computed: {
        activeUserParticipantWsid(){
            return this.$store.getters.userAuthorWsidInEnvelope
        },
        envelopeData(){
            return this.$store.state.envelopeData.basicInfo
        },
        actionConfig(){
            return EnvelopeStatus.getActionConfigByEnvelopeStatus(this.envelopeData.envelopeShownStatus, 
                this.activeUserParticipantWsid === this.envelopeData.senderWsid)
        },
        activeDocumentData(){
            let index = this.documents.findIndex(doc => doc.id === this.activeDocumentId)
            if (this.documentsData[index]){
                return this.documentsData[index]
            } else {
                return {
                    pagesCount: 0
                }
            }
        },
        resizeScale(){
            return document.documentElement.clientWidth / 595
        },
        participantWsid(){
            return this.$store.state.envelopeData.currentParticipant.participantWsid
        }
    },
    created(){
        this.currentSequence = this.envelopeData.currentSequence || -1

        //签署页面回调
        let query = this.$route.query
        if (query.pageCallback){
            this.pageCallback = query.pageCallback
        } else {
            this.pageCallback = localStorage.getItem(`pageCallback:${this.envelopeWsid}`) || ""
        }
        if (localStorage){
            localStorage.setItem(`pageCallback:${this.envelopeWsid}`, this.pageCallback)
        }

        this.activePage = 1
        getEnvelopeDocuments({
            envelopeWsid: this.envelopeWsid
        }).then(res => {
            let documents = res.data.data.documents
            documents = documents.map(document => {
                let metadata = {}
                if (document.fileTagId){
                    metadata = JSON.parse(document.fileTagId)
                }
                return {
                    id: document.fileWsid,
                    pdfSrc: document.fileHref.href,
                    name: document.fileName,
                    sequece: metadata.sequece != undefined ? metadata.sequece : null,
                    fileType:document.fileType
                }
            })
            if (documents.every(_ => _.sequece != null)){
                documents.sort((a, b) => a.sequece - b.sequece)
            }
            this.documents = documents
            this.activeDocumentId = this.documents[0].id
        }).catch(err => {
            console.error(err)
        })

        //更新预览时间
        viewEnvelope({
            envelopeWsid: this.envelopeWsid,
            participantWsid: this.participantWsid
        }).then(_ => _, _ => _)
    },
    methods: {
        documentsLoaded(documentsData){
            this.documentsData = documentsData
        },
        documentsViewUpdate(updateInfo){
            this.activeDocumentId = updateInfo.docId
            this.activePage = updateInfo.page
            this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, this.activePage)
        },
        prevewNavSelect(docId, page){
            this.$refs.preview.gotoDocumentPage(docId, page)
        },
        checkPass(){
            MessageBox.confirm("您确认通过该文件的内容？").then(action => {
                Indicator.open()
                return checkEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participantWsid,
                    checkPass: true,
                    revokeReason: "审核通过"
                }).then(res => {
                    wesignSignatureSDK.operationComplete("AUDIT_PASS")
                    this.openAPIEnvelopCompleteJump(ACTIONS.PASSED)
                }).catch(err => {
                    if (err.response){
                        let code = err.response.data.code
                        if (code == 104){
                            MessageBox.alert("对不起,信封状态在您审核的过程中已经发生改变,请返回签署详情页面进行查看", "错误").then(_ => {}, _ => {}).then(_ => {
                                location.reload()
                            })
                        } else {
                            Toast({
                                message: "操作失败",
                                iconClass: "icon icon-refuse"
                            })
                        }
                    } else {
                        Toast({
                            message: "操作失败",
                            iconClass: "icon icon-refuse"
                        })
                    }
                }).then(_ => {
                    Indicator.close()
                })
            })
        },
        refuseCheck(){ //审核不通过
            MessageBox.prompt("", {
                title: "审核",
                message: "请告知他人审核不通过的理由",
                confirmButtonText: "确定"
            }).then(({ value, action }) => {
                Indicator.open()
                return checkEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participantWsid,
                    checkPass: false,
                    revokeReason: value || ""
                }).then(res => {
                    wesignSignatureSDK.operationComplete("AUDIT_NOTPASS")
                    this.openAPIEnvelopCompleteJump(ACTIONS.NOT_PASSED)
                }).catch(err => {
                    if (err.response){
                        let code = err.response.data.code
                        if (code == 104){
                            MessageBox.alert("对不起,信封状态在您审核的过程中已经发生改变,请返回签署详情页面进行查看", "错误").then(_ => {}, _ => {}).then(_ => {
                                location.reload()
                            })
                        } else {
                            Toast({
                                message: "操作失败",
                                iconClass: "icon icon-refuse"
                            })
                        }
                    } else {
                        Toast({
                            message: "操作失败",
                            iconClass: "icon icon-refuse"
                        })
                    }
                }).then(_ => {
                    Indicator.close()
                })
            })
        },
        toRevoke(){ //撤销
            MessageBox.prompt("", {
                title: "撤销",
                message: "请告知他人撤销的理由",
                confirmButtonText: "撤销"
            }).then(({value, action}) => {
                Indicator.open()
                return revokeEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    revokeReason: value || ""
                }).then(_ => {
                    wesignSignatureSDK.operationComplete("REVOKE")
                    this.openAPIEnvelopCompleteJump(ACTIONS.REVOKED)
                }).catch(_ => {
                    Toast({
                        message: "操作失败",
                        iconClass: "icon icon-refuse"
                    })
                }).then(_ => {
                    Indicator.close()
                })
            })
        },
        openAPIEnvelopCompleteJump(action){ //开放平台来的页面进行跳转
            if (!this.pageCallback || this.pageCallback === "DEFAULT"){
                this.$router.replace({
                    path: "/result",
                    query: {
                        result: action
                    }
                })
            } else {
                gotoOpenSignatureReturnURL(this.pageCallback, action, {
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participantWsid
                })
            }
        },
    },
    components: {envelopePreview, formRender, documentsPreviewBar}
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.container{
     position: absolute;
     left: 0;
     right: 0;
     top: 0;
     bottom: 0;
}
.cover{
    opacity: 0.5;
}
.title{
    background: @color-main;
    height: 50*@px;
    text-align: center;
    color:@color-white; 
    p{
        line-height: 50*@px; 
        font-size: @font-size-title;
        display: inline-block;
    }
    .icon-back{
        position: absolute;
        font-size:@font-size-large;
        left: 0;
        padding: 15*@px;
    }
    .remoke{
        position: absolute;
        right: 10px;
    }
}
.envelope-info{
    display: flex;
    justify-content: space-around;
    align-content: center;
    line-height: 50*@px;
    color:@color-main;
    font-size: @font-size-primary;
    border-bottom: 1px solid #f0f0f0;
    text-align: center;
    position: absolute;
    border-top:1px solid #e1e1e1;
    bottom: 0;
    width:100%;
    background: #fff;
}
.envelope-container{
    position: absolute;
    left: 0;
    width: 100%;
    top: 50*@px;
    overflow: scroll;
    bottom: 50*@px;
}
.left-container{
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    transition:  width .3s;
    z-index: 20;

    .left-box{
            position: absolute;
            top:0;
            width: 100%;
            left: 0;
            bottom: 0;
            overflow: hidden;
        }
      .documents-preview-nav{
            position: absolute;
            top:0;
            width: 54*@px;
            left: 0;
            bottom: 0;
            background: #000;
            // box-shadow: #bbb 0*@px 0*@px 8*@px 1*@px;
            border-bottom: 2*@px solid #ddd;
            opacity: 0.7;
            .documents-preview{
                position: absolute;
                top:0;
                bottom: 0;
                left: 0;
                right: 0;
            }
        }
    .left-switch{
            position: absolute;
            top:50%;
            line-height: 50*@px;
            font-size: 20*@px;
            text-align: center;
            background: #000;
            opacity: 0.7;
            border-radius: 0 5*@px 5*@px 0;
        }
        .open{
            .left-switch;
            left:90%;
            color:#fff
        }
}
.container .doc-container{
    padding:0;
    position:absolute;
    top:0;
    bottom:0;
    right:0;
    left: 0;
    overflow:auto;
}
.page-form-container{
    position:absolute;
    left:0;
    right:0;
    top:0;
    bottom:0; 
}
.btn{
    flex:1;
    width: 100*@px;
    margin: 10*@px 40*@px;
    font-size:@font-size-regular
}
.reject{
    color:@color-main;
    border:1px solid @color-main;
}
.confirm{
    background-color:@color-main;
}
</style>


