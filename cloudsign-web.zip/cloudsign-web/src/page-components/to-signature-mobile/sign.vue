<!--
    @id        signature
    @desc      签名页面
    @level     system：系统组件
    @author    潘维,陈曦源
    @date      2019-04-18 15:44:57
-->
<template>
  <div>
    <div class="container" ref="envelopeContainer" @touchstart.stop='cancelActive'>
        <div class="title">
            <p>文件详情</p>
        </div>
        <div class="envelope-container">
            <envelopePreview ref="preview" style="z-index: 10;" :envelopeWsid="envelopeWsid" :scale="scale"
                :paddingTop="10" :paddingBottom="10" :paddingLeft="10" :paddingRight="10"
                @loaded="documentsLoaded" @view-update="documentsViewUpdate" class="doc-container">
                <template v-for="(docData,index) in documentsData"> 
                    <template v-for="page in docData.pagesCount">
                        <!-- 遍历页数，在每一页上附上一个div-->
                        <div class="page-form-container" ref="formContainers" :key="`doc_${documents[index].id}_${page}`" :slot="`${documents[index].id}_${page}`" 
                            :data-doc="documents[index].id" :data-page="page">
                            <template v-if="formsGroupMap[`${documents[index].id}_${page}`]">
                                <template v-for="form in formsGroupMap[`${documents[index].id}_${page}`]">
                                     <formRender ref="forms" :key="form.random" :formData="form"
                                        :customStyles="customStyles"
                                        :moveable="form.revisable"
                                        :deleteable="form.revisable"
                                        :active="activeFormRandom === form.random"
                                        :scale="scale"
                                        @delete="deleteForm(form.random)" 
                                        @sign="signForm(form)"
                                        @closePicker="closePickernpm" 
                                        @activeForm = "activeForm(form)"
                                        @longPress="longPress(arguments[0], form)"></formRender>      
                                </template>
                            </template>
                        </div>
                    </template>
                </template>

                <!-- 骑缝章分割展示模式 -->
                <template>
                    <template v-for="sealData in splittedPagingSealsArr" :slot="sealData.slot">
                        <splittedPagingSeal :scale="scale" :sealData="sealData.seal"
                            :page="sealData.page" :totalPages="sealData.totalPages"></splittedPagingSeal>
                    </template>
                </template>
            </envelopePreview>
            <!-- <div class="left-container" :style="{width:leftNavOpen?'0.6rem':0}">
                <div class="open" @click="leftNavOpen = !leftNavOpen">
                    <i v-if="!leftNavOpen" class="icon-right"></i>
                    <i v-else class="icon-left"></i>
                </div>
                <div class="left-box">
                    <div class="documents-preview-nav">
                        <documentsPreviewBar class="documents-preview" ref="previewbar" :documents="documents" 
                            :activeData="{
                                docId: activeDocumentId,
                                page: activePage
                            }" @select-docpage="prevewNavSelect">
                        </documentsPreviewBar>
                    </div>
                </div>
            </div> -->
        </div>
        <template v-if="showControls">
            <template v-if="!isShowEnableNoAppearance">
                <div class="envelope-signature-btn" v-if="!formAddFooter && !formFoote">
                    <div class="reject-sign" @click.stop="rejectEnvelope">拒签</div>
                    <div v-if="signedFormsCount != formsCount" :style="customStyles" class="sign-btn search-sign-location" @click.stop="toSign">签署</div>
                    <div v-else-if="formsCount===0" :style="customStyles" class="sign-btn search-sign-location" @click.stop="addToSign">签署</div>
                    <!-- <div v-else class="sign-btn sign-envelope" @click.stop="confirmEnvelope">提交</div> -->
                    <div v-else class="sign-btn sign-envelope" :style="customStyles" @click.stop="toSign">提交</div>
                </div>
                <div class="envelope-signature-btn" v-if="formAddFooter && !formFoote">
                    <div class="form-type">
                        <div class="form-option" @click="chooseForm('TEXT')">
                            <div class="icon-signature icon-text"></div>
                            <div class="option-text">文本</div>
                        </div>
                    </div>
                    <div class="form-type">
                        <div class="form-option" @click="chooseForm('DATE')">
                            <div class="icon-signature icon-calendar"></div>
                            <div class="option-text">日期</div>
                        </div>
                    </div>
                    <div class="form-type">
                        <div class="form-option" @click="chooseForm('SIGN')">
                            <div class="icon-signature icon-sign"></div>
                            <div class="option-text">签名</div>
                        </div>
                    </div>
                    <div class="form-type" v-if="userEdition === 'e'">
                        <div class="form-option" @click="chooseForm('SEAL')">
                            <div class="icon-signature icon-seal"></div>
                            <div class="option-text">印章</div>
                        </div>
                    </div>
                    <div v-if="signedFormsCount != formsCount" :style="customStyles" class="sign-btn search-sign-location" @click.stop="toSign">签署</div>
                    <div v-else-if="formsCount!=0" :style="customStyles" class="sign-btn sign-envelope" @click.stop="toSign">提交</div>
                    <div v-else :style="customStyles" class="sign-btn sign-envelope" @click.stop="confirmEnvelope">提交</div>
                </div>
            </template>
            <template v-else>
                <div class="envelope-signature-btn">
                    <div :style="customStyles" class="confirm" @click="confirmEnvelope">确认</div>
                </div>
            </template>
        </template>
        <mt-popup v-model="popupVisible" class="signature-popup-box">
            <template v-if="formsCount>0">
                <p  v-if="signedFormsCount != formsCount">您共有{{formsCount}}处指定位置需要签署</p>
                <p v-else-if="!allFormRevisable">文件所有签署项已设置完成</p>
                <p v-else>
                    <span>您设置的{{formsCount}}处签署项已完成</span>
                    <span>是否直接提交？</span>
                </p>
                <div class="signature-popup-box-content">
                    <div class="form-text" v-if="formsType['SIGN']">
                        <span>签名项</span>
                        <span>共{{formsType["SIGN"].length}}处</span>
                        <!-- <span v-if="formsType['SIGN'].some(f => !f.data)" @click.stop="findUnsignedForm(formsType['SIGN'])" style="color:#0c7ffc"><i class="icon-warning" style="margin-right:5px;"></i>点击签署</span> -->
                        <span v-if="formsType['SIGN'].some(f => !f.data)" @click.stop="allSignForm(formsType['SIGN'])" style="color:#0c7ffc"><i class="icon-warning" style="margin-right:5px;"></i>一键签名</span>
                        <span v-else style="color:#51c78a" @click.stop="findSignedform(formsType['SIGN'])"><i class="icon-complete" style="margin-right:5px;"></i>点击查看</span>
                    </div>
                    <div class="form-text" v-if="formsType['SEAL']">
                        <span>签章项</span>
                        <span>共{{formsType["SEAL"].length}}处</span>
                        <span v-if="formsType['SEAL'].some(f => !f.data)" @click.stop="findUnsignedForm(formsType['SEAL'])" style="color:#0c7ffc"><i class="icon-warning" style="margin-right:5px;"></i>点击签署</span>
                        <span v-else style="color:#51c78a" @click.stop="findSignedform(formsType['SEAL'])"><i class="icon-complete" style="margin-right:5px;"></i>点击查看</span>
                    </div>
                    <div class="form-text" v-if="formsType.MULTI_CHECK_MARK">
                        <span>骑缝章</span>
                        <span>共{{formsType.MULTI_CHECK_MARK.length}}处</span>
                        <span v-if="formsType.MULTI_CHECK_MARK.some(f => !f.sealData)" @click.stop="signPaddingSeals" style="color:#0c7ffc"><i class="icon-warning" style="margin-right:5px;"></i>点击签署</span>
                        <span v-else style="color:#51c78a"><i class="icon-complete" style="margin-right:5px;"></i>已经签署</span>
                    </div>
                    <div class="form-text" v-if="formsType['TEXT']">
                        <span>文本项</span>
                        <span>共{{formsType["TEXT"].length}}处</span>
                        <span v-if="formsType['TEXT'].some(f => !f.data)" @click.stop="findUnsignedForm(formsType['TEXT'])" style="color:#0c7ffc"><i class="icon-warning" style="margin-right:5px;"></i>点击签署</span>
                        <span v-else style="color:#51c78a" @click.stop="findSignedform(formsType['TEXT'])"><i class="icon-complete" style="margin-right:5px;"></i>点击查看</span>
                    </div>
                    <div class="form-text" v-if="formsType['DATE']">
                        <span>日期项</span>
                        <span>共{{formsType["DATE"].length}}处</span>
                        <span v-if="formsType['DATE'].some(f => !f.data)" @click.stop="findUnsignedForm(formsType['DATE'])" style="color:#0c7ffc"><i class="icon-warning" style="margin-right:5px;"></i>点击签署</span>
                        <span v-else style="color:#51c78a" @click.stop="findSignedform(formsType['DATE'])"><i class="icon-complete" style="margin-right:5px;"></i>点击查看</span>
                    </div>
                </div>
                <div class="signature-popup-box-footer-btn" @click="popupVisible = false" v-if="signedFormsCount != formsCount">取消</div>
                <div class="signature-popup-box-footer-btn-group" v-else>
                    <div @click="continueToAdd" v-if="allFormRevisable">继续添加</div>
                    <div @click="popupVisible = false" v-else>取消</div>
                    <div @click.stop="confirmEnvelope" :style="customStyles">点击提交</div>
                </div>
            </template>
            <div v-else style="text-align:center; height: 30px; line-height: 30px">
                暂无签暑项
            </div>
        </mt-popup>
    </div>
    <chooseSignBox ref="chooseSignBox" :signingFrom ="signingFrom" :customStyles="customStyles"></chooseSignBox>
    <chooseSealsBox ref="chooseSealBox" v-if="userEdition === 'e'" 
        :userWsid="activeUserWsid"
        :enterpriseWsid="enterpriseWsid"
        :sealManagePermission="sealManagePermission"
        @apply="applySeal" :customStyles="customStyles"></chooseSealsBox>
    <inputTextBox ref="inputTextBox" :signingFrom ="signingFrom" :customStyles="customStyles"></inputTextBox>
    <signatureConfirmVerify v-if="signatureConfirmDialogVisible" :visible="signatureConfirmDialogVisible" @confirm="confirmSign" :customStyles="customStyles" @cancel="cancelSignatureConfirm" :authTypes="authTypes" @forgetSignPassword="forgetSignPassword"></signatureConfirmVerify>
    <signPasswordRetrieve ref="signPassword" :customStyles="customStyles" v-if="signDialogVisible" :visible="signDialogVisible" @confirm="closesignDialog" @cancel="closesignDialog"></signPasswordRetrieve>
    <setSignPassWord ref="setSignPassWord" :customStyles="customStyles"></setSignPassWord>
    <mt-datetime-picker
            style="display:none"
            ref="picker"
            :type="datetimePickerType"
            :startDate="new Date('1900-01-01')"
            :endDate="new Date('2100-01-01')"
            :closeOnClickModal="false"
            @cancel="cancelSelect"
            @confirm="selectTime"
            v-model="date">
    </mt-datetime-picker>
  </div>
</template>
<script>

import { Toast, Indicator, MessageBox, Popup} from "mint-ui"
import wesignSignatureSDK from "@commons/wesign-signature-sdk-child.js"
import { ACTIONS, gotoOpenSignatureReturnURL } from "@classes/openapi/sign-callback.js"

import { FormsManager } from "@components/envelopes/envelop-signature/utils/forms.js"
import bomb from "@components/commons/bomb-box.vue"
import chooseSealsBox from "@components/mobile/common/choose-seal.vue"
import chooseSignBox from "@components/mobile/common/choose-sign.vue"
import inputTextBox from "@components/mobile/common/input-text.vue"
import documentsPreviewBar from "@components/mobile/envelopes/envelope-preview-bar.vue"
import envelopePreview from "@components/commons/documents/envelope-preview.vue"
import signatureConfirmVerify from "@components/mobile/envelopes/signature-confirm-verify/index.vue"
import signPasswordRetrieve from "@components/mobile/envelopes/signature-confirm-verify/retrieve-signpassword/index.vue"
import setSignPassWord from "@components/mobile/envelopes/signature-confirm-verify/set-signPassword.vue"

import { translateParticipantDatasFromEnd } from "@classes/envelopes/participants.js"
import formRender from "@components/mobile/forms/form-render.js"
import splittedPagingSeal from "@components/envelopes/paging-seals/splitted-paging-seal.vue"
import { FORMS_CONFIG_TYPE_MAP, EnvelopeBaseForm, EnvelopeFormPosition } from "@classes/envelopes/forms.js"
import { ifRectIntersect } from "@commons/util.js"


import { confirmEnvelope, 
    rejectEnvelope,
    revokeEnvelope,
    getAuthTypes } from "@interfaces/envelopes/envelope.js"
import { getEnvelopeData } from "@interfaces/envelopes/index.js"
import { getEnvelopeParticipants } from "@interfaces/envelopes/participants.js"
import { getEnvelopeDocuments } from "@interfaces/envelopes/documents.js"
import { getUserRoles } from "@interfaces/policy/enterprise-roles.js"
import { viewEnvelope } from "@interfaces/envelopes/envelope.js"

export default {
    data(){
        return {
            pageCallback: "", //操作完成的回调页面
            documents: [],
            
            signs: [],
            documentsData: [],

            scale: 1,
            activeFormRandom: -1,
            activeDocumentId: "", //当前浏览的文档
            activePage: 1,
       
            isShow: false,
            formAddFooter: false,
            formOption: "",
            sealsBox: false, //上传印章弹框
            signBox: false, //上传签名弹框
            //showOptionDetail: false,
            leftNavOpen: false,
            signingFrom: null,

            popupVisible: false,
            showControls: false,

            signatureConfirmDialogVisible: false,
            formFoote: false,

            formsManager: new FormsManager(),

            date: new Date(),
            datePickerCallback: null,
            datetimePickerType: "datetime",
            authTypes: null,
            signDialogVisible:false,
            isShowEnableNoAppearance:false,
            enableNoAppearance:this.$route.query.enableNoAppearance || "false"
        }
    },
    computed: {
        envelopeWsid(){
            return this.$store.state.envelopeData.envelopeWsid
        },
        activeDocumentData(){
            let index = this.documents.findIndex(doc => doc.id === this.activeDocumentId)
            if (this.documentsData[index]){
                return this.documentsData[index]
            } else {
                return {
                    pagesCount: 0
                }
            }
        },
        formsGroupMap(){
            let map = {}
            this.forms.forEach(form => {
                let arr = map[`${form.docId}_${form.page}`]
                if (!arr) {
                    arr = []
                    map[`${form.docId}_${form.page}`] = arr
                }
                arr.push(form)
            })
            return map
        },
        activeUserWsid(){
            return this.$store.state.userWsid
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        forms(){
            return this.formsManager.getForms()
        },
        pagingSeals(){
            return this.formsManager.getPagingSeals()
        },
        splittedPagingSealsArr(){
            let documentsData = this.documentsData
            let documents = this.documents
            let documentsDataPagesCountMap = {}
            documentsData.forEach((documentData, index) => {
                documentsDataPagesCountMap[documents[index].id] = documentData.pagesCount
            })

            let splittedPagingSealsArr = []
            this.pagingSeals.forEach(pagingSeal => {
                splittedPagingSealsArr.push(
                    ...(new Array(documentsDataPagesCountMap[pagingSeal.docId])
                        .fill(0)
                        .map((_, index) => {
                            return {
                                seal: pagingSeal,
                                docId: pagingSeal.docId,
                                page: index + 1,
                                totalPages: documentsDataPagesCountMap[pagingSeal.docId],
                                slot: `${pagingSeal.docId}_${index + 1}_splitted_seals_area`
                            }
                        }))
                )
            })
            return splittedPagingSealsArr
        },
        formsCount(){
            return this.forms.length + this.pagingSeals.length
        },
        allFormRevisable(){ //非预设模式
            if (this.forms.every(form => form.revisable === true) 
                && this.pagingSeals.every(form => form.revisable === true)
                || this.formsCount === 0 ){
                return true
            } else {
                return false
            }
        },
        formsType(){
            let formsType = {}
            this.forms.forEach((item, index) => {
                if (!formsType[this.forms[index].type]){
                    formsType[this.forms[index].type] = []
                }
                formsType[this.forms[index].type].push(this.forms[index])
            })
            if (this.pagingSeals.length > 0){
                formsType.MULTI_CHECK_MARK = this.pagingSeals.slice()
            }
            return formsType
        },
        signedFormsCount(){
            return this.forms.filter(_ => _.data).length + this.pagingSeals.filter(_ => _.sealData).length
        },
        isSender(state){
            return this.$store.getters.userAuthorWsidInEnvelope === this.$store.state.envelopeData.basicInfo.senderWsid
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
        participantEnterpriseRole(){
            return this.$store.getters.participantEnterpriseRole
        },
        participant(){
            return this.$store.state.envelopeData.currentParticipant
        },
        user(){
            return this.$store.state.userdata || this.$store.state.userData
        },
        personalSeal(){
            return this.$store.state.personalSeal
        },
        sealManagePermission(){
            return this.$store.getters.PAGE_SEALS_MANAGEMENT
        },
        customStyles(){
            let themeColor = this.$route.query.themeColor
            let circleAngle = this.$route.query.circleAngle
            if(themeColor){
                if (themeColor === "#ffffff"){
                    return {
                        background: themeColor,
                        color: "#000000",
                        borderRadius: circleAngle + "px"
                    }
                } else {
                    return {
                        background: themeColor,
                        color: "#FFFFFF",
                        borderRadius: circleAngle + "px"
                    }
                }
            }
        },
    },
    created(){
        let query = this.$route.query
        getEnvelopeDocuments({
            envelopeWsid: this.envelopeWsid
        }).then(res => {
            let documents = res.data.data.documents
            documents = documents.map(document => {
                let metadata = {}
                if (document.fileTagId){
                    metadata = JSON.parse(document.fileTagId)
                }
                return {
                    id: document.fileWsid,
                    pdfSrc: document.fileHref.href,
                    name: document.fileName,
                    sequece: metadata.sequece != undefined ? metadata.sequece : null,
                    fileType:document.fileType
                }
            })
            if (documents.every(_ => _.sequece != null)){
                documents.sort((a, b) => a.sequece - b.sequece)
            }
            this.documents = documents
            this.activeDocumentId = this.documents[0] && this.documents[0].id
        }).catch(err => {
            console.error(err)
        })
        
        this.resizeScale()
        if(this.enableNoAppearance&&this.enableNoAppearance === "true"){
            this.loadAuthType().then(_ => {
                this.signatureConfirmDialogVisible = true
            })
            this.showControls = true
            this.isShowEnableNoAppearance = true
        } else {
            this.loadAuthType()
            this.formsManager.load(this.envelopeWsid, this.participant.participantWsid).then(_ => {
                if (this.formsCount > 0){
                    this.popupVisible = true
                }
                this.showControls = true
            })
        } 

        //更新预览时间
        viewEnvelope({
            envelopeWsid: this.envelopeWsid,
            participantWsid: this.participant.participantWsid
        }).then(_ => _, _ => _)

        //页面回调
        if (query.pageCallback){
            this.pageCallback = query.pageCallback
        } else {
            this.pageCallback = localStorage.getItem(`pageCallback:${this.envelopeWsid}`) || ""
        }
        if (localStorage){
            localStorage.setItem(`pageCallback:${this.envelopeWsid}`, this.pageCallback)
        }
    },
    methods: {
        loadAuthType(){
            return getAuthTypes({
                envelopeWsid: this.envelopeWsid,
                participantWsid: this.participant.participantWsid,
            }).then(res => {
                let data = res.data.data
                if (data.selectedAuthTypes && data.selectedAuthTypes.length > 0){
                    this.authTypes = data.selectedAuthTypes
                } else if (data.authTypes.length > 0){
                    this.authTypes = data.authTypes
                } else {
                    this.authTypes = ["SIGN_PIN"]
                }
            })
        },
        closePickernpm(boolean){
            this.formFoote = boolean
        },
        documentsLoaded(documentsData){
            this.documentsData = documentsData
        },
        documentsViewUpdate(updateInfo){
            this.activeDocumentId = updateInfo.docId
            this.activePage = updateInfo.page
            // this.$refs.previewbar.gotoDocumentPage(this.activeDocumentId, this.activePage)
        },
        showFormList(){
            this.isShow = true
            this.formOption = ""
        },
        hideFormList(){
            this.isShow = false
        },
        getFormPosition(formRect, formData){ //返回form的left、top、width、height 和新的formdata
            let formContainers = this.$refs.formContainers //每一页的div
            if (!formContainers) return
            
            let scale = this.scale
            let container
            //判断两个矩形区域是否相交
            for (let i = 0; i < formContainers.length; i++){
                let rect = formContainers[i].getBoundingClientRect()
                if (ifRectIntersect(formRect, rect)){
                    container = formContainers[i]
                    break
                }
            }
            
            if (!container) return
            
            let top, left, width, height
            let containerRect = container.getBoundingClientRect()

            if (formRect.width > containerRect.width){
                width = containerRect.width
            } else {
                width = formRect.width
            }

            if (formRect.height > containerRect.height){
                height = containerRect.height
            } else {
                height = formRect.height
            }
   
            top = formRect.top - containerRect.top
            if (top < 0 ){
                top = 0
            }
            if (top > containerRect.height - formRect.height ){
                top = containerRect.height - formRect.height
            }
            
            left = formRect.left - containerRect.left
            if (left < 0 ){
                left = 0
            }
            if (left > containerRect.width - formRect.width){
                left = containerRect.width - formRect.width
            }
            formData.docId = container.getAttribute("data-doc")
            formData.page = parseInt(container.getAttribute("data-page"))
            formData.position = EnvelopeFormPosition.formRect(top / scale, left / scale, width / scale, height / scale)
            formData.participantWsid = this.participant.participantWsid
            formData.required = false //是否必填
            formData.scale = 1 //缩放比例
            
            this.formsManager.appendForm(formData)
            this.activeFormRandom = formData.random
        },
        longPress(e, formData){
            this.activeFormRandom = formData.random
            if (!formData.revisable) return
            let forms = this.$refs.forms
            let formDom = forms.find(form => form.formData === formData)
            
            let startX = e.changedTouches[0].clientX //触屏起始位置x坐标
            let startY = e.changedTouches[0].clientY //触屏起始位置y坐标
            let scale = this.scale
            let formPosition = formDom.formData.position
            let width = (formPosition.lrx - formPosition.ulx) * scale
            let height = (formPosition.lry - formPosition.uly) * scale
            let form = {
                x: formPosition.ulx * scale,
                y: formPosition.uly * scale
            }
            let container = this.$refs.preview.$el
            let containerRect = container.getBoundingClientRect()
            //开始移动
            let touchmove = event => {
                let dx = 0, dy = 0, endX = 0, endY = 0
                dx = event.changedTouches[0].clientX - startX
                dy = event.changedTouches[0].clientY - startY
                endX = form.x + dx
                endY = form.y + dy
                formPosition.ulx = endX / scale
                formPosition.uly = endY / scale
                formPosition.lrx = (endX + width) / scale
                formPosition.lry = (endY + height) / scale
            }
            let touchend = event => {
                this.jugementFormPosition(formDom)
                document.body.removeEventListener("touchmove", touchmove)
                document.body.removeEventListener("touchend", touchend)
            }
            document.body.addEventListener("touchmove", touchmove) 
            document.body.addEventListener("touchend", touchend)

            e.preventDefault()
        },
        jugementFormPosition(formDom){
            let formData = formDom.formData
            let formPosition = formData.position

            let width = formPosition.lrx - formPosition.ulx
            let height = formPosition.lry - formPosition.uly
            
            let formContainers = this.$refs.formContainers //每一页的div
            if (!formContainers) return
            let scale = this.scale
            let container
            let formRect = (formDom.$refs.formBox).getBoundingClientRect()
            for (let i = 0; i < formContainers.length; i++){
                let rect = formContainers[i].getBoundingClientRect()
                if (rect.bottom - formRect.top > 0) { //在某一页的内部
                    container = formContainers[i]
                    break
                } 
            }
            if (!container){ //表单没有在任何一页超出了文档区域
                container = formContainers[formContainers.length - 1]
            }
            let containerRect = container.getBoundingClientRect()
            
            let top, left, bottom
            top = formRect.top - containerRect.top
            if (top < 0 ){
                top = 0
            }
            if (top > containerRect.height - formRect.height ){
                top = containerRect.height - formRect.height
            }
            
            
            left = formRect.left - containerRect.left
            if (left < 0 ){
                left = 0
            }
            if (left > containerRect.width - formRect.width){
                left = containerRect.width - formRect.width
            }

            bottom = formRect.top + formRect.height
            if (bottom > containerRect.bottom){
                bottom = containerRect.bottom - formRect.height
            }
            formData.docId = container.getAttribute("data-doc")
            formData.page = parseInt(container.getAttribute("data-page"))
            formData.position = EnvelopeFormPosition.formRect(top / scale, left / scale, width, height)
            formData.participantWsid = this.participant.participantWsid
            formData.required = false //是否必填
            formData.scale = 1 //缩放比例
        },
        prevewNavSelect(docId, page){
            this.$refs.preview.gotoDocumentPage(docId, page)
        },
        resizeScale(){
            this.scale = (document.documentElement.clientWidth - 20) / 595
        },
        async chooseForm(option){ 
            this.formOption = option
            let formConfig = FORMS_CONFIG_TYPE_MAP.get(option)
            let scale = this.scale
            let defaultSize = formConfig.defaultSize

            let clientRect = {
                top: window.screen.height / 2 - defaultSize.height * scale / 2,
                left: window.screen.width / 2 - defaultSize.width * scale / 2,
                width: defaultSize.width * scale,
                height: defaultSize.height * scale,
                bottom: window.screen.height / 2 - defaultSize.height * scale / 2 + defaultSize.height * scale,
                right: window.screen.width / 2 - defaultSize.width * scale / 2 + defaultSize.width * scale,
            }
        
            let newForm = new EnvelopeBaseForm()
            newForm.type = option
            newForm.page = 0
            newForm.required = false //是否必填
            newForm.scale = 1 //缩放比例
            newForm.position = EnvelopeFormPosition.formRect(clientRect.top / scale, clientRect.left / scale, clientRect.width / scale, clientRect.height / scale)

            if (option !== "TEXT") await this.signForm(newForm)
        
            if (!newForm.data && (option === "SEAL" || option === "SIGN")) return
            
            this.getFormPosition(clientRect, newForm)
        },
        activeForm(form){
            this.signingFrom = form
            this.activeFormRandom = form.random
        },
        signForm(form){
            this.signingFrom = form
            this.activeFormRandom = form.random
            this.hideFormList()
            switch (form.type){
                case "SIGN":
                    let noSignData = form.data
                    return new Promise((resolve, reject) => {
                        this.$refs.chooseSignBox.chooseSign(data => {
                            form.data = data
                            //如果重传签名，则更新当前文档所有数据
                            if (noSignData){
                                this.updateAllSign(data) 
                            }
                            resolve()
                        }, !form.data)
                    })
                    break
                case "SEAL":
                    return new Promise((resolve, reject) => {
                        this.$refs.chooseSealBox.open(data => {
                            form.data = data
                            resolve()
                        })
                    })
                    break
                case "TEXT":
                    return new Promise((resolve, reject) => {
                        this.$refs.inputTextBox.inputText(data => {
                            form.data = data
                            resolve()
                        })
                    })
                    break
                case "DATE":
                    if (!form.data) form.data = Date.now()
                    if (form.format === "yyyy-MM-dd"){
                        this.datetimePickerType = "date"
                    } else {
                        this.datetimePickerType = "datetime"
                    }
                    return new Promise((resolve, reject) => {
                        this.timePickerOpen(date => {
                            form.data = date.getTime()
                            resolve()
                        })
                    })
            }
        },
        signPaddingSeals(){
            this.popupVisible = false
            this.$refs.chooseSealBox.open(data => {
                this.pagingSeals.filter(_ => !_.sealData).forEach(_ => {
                    _.sealData = data.imageData
                    _.sealWsid = data.id
                })
            })
        },
        updateAllSign(data){
            if (data){
                this.forms.forEach(form => {
                    if (form.type === "SIGN"){
                        form.data.imageData = data.imageData
                    }
                })
            }
        },
        deleteForm(formRandom){
            this.formsManager.deleteForm(formRandom)
        },
        toSign(){
            this.popupVisible = true
        },
        addToSign(){
            this.formAddFooter = true
        },
        continueToAdd(){
            this.addToSign()
            this.popupVisible = false
        },
        findUnsignedForm(forms){
            let rawPlaces = forms.map(f => {
                return {
                    docId: f.docId,
                    page: f.page,
                    top: f.position.uly,
                    docId: f.docId,
                    formId: f.random
                }
            })

            let result = this.$refs.preview.scrollToPlaceAuto(rawPlaces, (before, center, after) => {
                if (after[0]) return after [0]
                if (before[0]) return before [0]
                if (center[1]) return center[1]
                return center[0]
            })
            this.activeFormRandom = result.raw.formId
            this.popupVisible = false
        },
        allSignForm(form){
            let forms = this.forms.filter(item => item.type === "SIGN")
            if (this.personalSeal){
                forms.map(item => item.data = this.personalSeal)
            } else {
                this.popupVisible = false
                this.$refs.chooseSignBox.chooseSign(data => {
                    forms.map(item => item.data = data)
                    //如果重传签名，则更新当前文档所有数据
                    if (this.personalSeal){
                        this.updateAllSign(data) 
                    }
                })
            }

            let docId = forms[0].docId
            let page = forms[0].page
            this.$nextTick(_ => {
                this.prevewNavSelect(docId, page)
            })
        },
        findSignedform(forms){
            let rawPlaces = forms.map(f => {
                return {
                    docId: f.docId,
                    page: f.page,
                    top: f.position.uly,
                    docId: f.docId,
                    formId: f.random
                }
            })

            let result = this.$refs.preview.scrollToPlaceAuto(rawPlaces, (before, center, after) => {
                if (after[0]) return after[0]
                if (before[0]) return before [0]
                if (center[1]) return center[1]
                return center[0]
            })
            this.activeFormRandom = result.raw.formId
            this.popupVisible = false
        },
        confirmEnvelope(){
            let query = this.$route.query
            if(this.enableNoAppearance === "false"){
                if (this.formsCount === 0){
                    MessageBox.alert("该文档未预设签名项，请选择签名框进行文档签名设置")
                    return
                }
            }

            //如果角色是签章管理员必须盖章
            if (this.participantEnterpriseRole 
                && this.participantEnterpriseRole.name === "印章管理员" //FIXME: 后期后台可能会进行配置
                && this.forms.filter(form => form.type === "SEAL").length === 0
                && this.pagingSeals.length === 0){
                MessageBox.alert("该文档要求您盖章，请点击印章进行盖章操作")
                return
            }

            this.popupVisible = false
            Indicator.open()
            this.formsManager.uploadFormsData().then(_ => {
                this.signatureConfirmDialogVisible = true
            }).catch(err => {
                Toast({
                    message: "保存信息失败",
                    iconClass: "icon icon-refuse"
                })
            }).then(_ => {
                this.$nextTick(_ => {
                    Indicator.close()
                })
            })
        },
        confirmSign(opcode){
            this.signatureConfirmDialogVisible = false
            let query = this.$route.query
            if(this.enableNoAppearance&&this.enableNoAppearance === "true"){
                this.formsManager.noappearanceParticipantEnvelopeFroms(this.envelopeWsid, this.participant.participantWsid,true).then(_ => {
                    this.confirm(opcode)
                })
            } else {
                this.confirm(opcode)
            }
        },
        confirm(opcode){
            Indicator.open()
            confirmEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participant.participantWsid,
                    opcode: opcode
                }).then(_ => {
                    wesignSignatureSDK.operationComplete("SIGN")
                    if (!this.user.existSignPassword){
                        this.$refs.setSignPassWord.open(callback => {
                            this.openAPIEnvelopCompleteJump(ACTIONS.SIGNED)
                        })
                    } else {
                        this.openAPIEnvelopCompleteJump(ACTIONS.SIGNED)
                    }
                }).catch(err => {
                    if (err.response){
                        let code = err.response.data.code
                        if (code == 101){
                            Toast({
                                message: "您的印章使用次数不足,请重新申请印章",
                                iconClass: "icon icon-refuse"
                            })
                        } else if (code == 102) {
                            Toast({
                                message: "该印章不在使用期内",
                                iconClass: "icon icon-refuse"
                            })
                        } else if (code == 103) {
                            Toast({
                                message: "您的印章，暂无使用权限",
                                iconClass: "icon icon-refuse"
                            })
                        } else if (code == 104){
                            MessageBox.alert("对不起,信封状态在您签署的过程中已经发生改变,请返回签署详情页面进行查看", "错误").then(_ => {}, _ => {}).then(_ => {
                                location.reload()
                            })
                        } else {
                            Toast({
                                message: "签署失败",
                                iconClass: "icon icon-refuse"
                            })
                        }
                    } else {
                        Toast({
                            message: "签署失败",
                            iconClass: "icon icon-refuse"
                        })
                    }
                }).then(_ => {
                    Indicator.close()
                })
        },
        cancelSignatureConfirm(){
            this.signatureConfirmDialogVisible = false
        },
        rejectEnvelope(){
            MessageBox.prompt("", {
                title: "拒签",
                message: "请告知他人拒签的理由",
                confirmButtonText: "拒签"
            }).then(({value, action}) => {
                Indicator.open()
                return rejectEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participant.participantWsid,
                    rejectReason: value || ""
                }).then(_ => {
                    wesignSignatureSDK.operationComplete("REJECTE")
                    this.openAPIEnvelopCompleteJump(ACTIONS.REJECTED)
                }).catch(_ => {
                    Toast({
                        message: "操作失败",
                        iconClass: "icon icon-refuse"
                    })
                }).then(_ => {
                    Indicator.close()
                })
            })
        },
        revokeEnvelope(){
            MessageBox.prompt("", {
                title: "撤销",
                message: "请告知他人撤销的理由",
                confirmButtonText: "撤销"
            }).then(({value, action}) => {
                Indicator.open()
                return revokeEnvelope({
                    envelopeWsid: this.envelopeWsid,
                    revokeReason: value || ""
                }).then(_ => {
                    wesignSignatureSDK.operationComplete("REVOKE")
                    this.openAPIEnvelopCompleteJump(ACTIONS.REVOKED)
                }).catch(_ => {
                    Toast({
                        message: "操作失败",
                        iconClass: "icon icon-refuse"
                    })
                }).then(_ => {
                    Indicator.close()
                })
            })
        },
        cancelActive(e){
            let body = document.documentElement
            let touch = e.touches[0]
            let startX = touch.clientX
            let startY = touch.clientY
            let flag = 0
            let touchtime = setTimeout(_ => {
                flag = 1
            }, 333)

            let touchmove = e => {
                let touch = e.touches[0]
                if (Math.abs(touch.clientX - startX) > 10 ||
                    Math.abs(touch.clientY - startY) > 10 ){
                    clearTimeout(touchtime)
                    flag = 1
                    body.removeEventListener("touchmove", touchmove)
                }
            }

            let touchend = e => {
                if (flag === 0) {
                    this.activeFormRandom = -1
                    this.signingFrom = null
                }
                clearTimeout(touchtime)
                body.removeEventListener("touchend", touchend)
            }
            body.addEventListener("touchmove", touchmove) 
            body.addEventListener("touchend", touchend)
        },
        openAPIEnvelopCompleteJump(action){ //开放平台来的页面进行跳转
            if (!this.pageCallback || this.pageCallback === "DEFAULT"){
                this.$router.replace({
                    path: "/result",
                    query: {
                        result: action
                    }
                })
            } else {
                gotoOpenSignatureReturnURL(this.pageCallback, action, {
                    envelopeWsid: this.envelopeWsid,
                    participantWsid: this.participant.participantWsid
                })
            }
        },
        timePickerOpen(callback){
            this.datePickerCallback = callback
            this.$refs.picker.open()
        },
        cancelSelect(){
            this.$refs.picker.close()
            this.datePickerCallback = null
        },
        selectTime(){
            this.datePickerCallback(this.date)
            this.$refs.picker.close()
            this.datePickerCallback = null
        },
        applySeal(){
            MessageBox.confirm("", {
                title: "印章管理",
                confirmButtonText: "立即前往",
                cancelButtonText: "取消",
                message: "即将前往印章管理页面对印章进行管理，您确定进行该操作吗？",
            }).then(_ => {
                window.open("/wesign/enterprise/seals/official")
            }).catch(_ => {})
        },
        forgetSignPassword(){
            this.signatureConfirmDialogVisible = false
            this.signDialogVisible = true
        },
        closesignDialog(){
            this.signDialogVisible = false
        }
    },
    components: {
        bomb, 
        envelopePreview, 
        formRender, 
        chooseSealsBox, 
        documentsPreviewBar, 
        chooseSignBox,
        inputTextBox,
        signatureConfirmVerify,
        setSignPassWord,
        splittedPagingSeal,
        signPasswordRetrieve
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.container{
     position: absolute;
     left: 0;
     right: 0;
     top: 0;
     bottom: 0;
}
.cover{
    opacity: 0.5;
}
.title{
    background:#fff;
    height: 50*@px;
    text-align: center;
    color:#1a1a1a; 
    box-shadow: rgba(0, 0, 0, 0.06) 0 0.02rem 0 0.01rem;
    p{
        line-height: 50*@px; 
        font-size: @font-size-title;
        display: inline-block;
    }
    .icon-back{
        position: absolute;
        font-size:@font-size-large;
        left: 0;
        padding: 15*@px;
    }
    .icon-sign2{
        position: absolute;
        font-size:@font-size-large;
        right: 0;
        padding: 15*@px;
    }
    .refuse-sign{
        position: absolute;
        right: 10*@px;
        top: 12*@px;
        font-size: @font-size-title;
    } 
}
.envelope-container{
    position: absolute;
    left: 0;
    width: 100%;
    top: 51*@px;
    overflow: scroll;
    bottom: 50*@px;
}
.left-container{
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    transition:  width .3s;
    z-index: 20;

    .left-box{
            position: absolute;
            top:0;
            width: 100%;
            left: 0;
            bottom: 0;
            overflow: hidden;
        }
     .documents-preview-nav{
            position: absolute;
            top:0;
            width: 54*@px;
            left: 0;
            bottom: 0;
            background: #000;
            // box-shadow: #bbb 0*@px 0*@px 8*@px 1*@px;
            border-bottom: 2*@px solid #ddd;
            opacity: 0.7;
            .documents-preview{
                position: absolute;
                top:0;
                bottom: 0;
                left: 0;
                right: 0;
            }
        }
    .left-switch{
            position: absolute;
            top:50%;
            line-height: 50*@px;
            font-size: 20*@px;
            text-align: center;
            background: #000;
            opacity: 0.7;
            border-radius: 0 5*@px 5*@px 0;
        }
        .open{
            .left-switch;
            left:90%;
            color:#fff
        }
}
.container .doc-container{
    padding:0;
    position:absolute;
    top:0;
    bottom:0;
    left: 0;
    right:0;
    overflow:auto;
}
.page-form-container{
    position:absolute;
    left:0;
    right:0;
    top:0;
    bottom:0; 
}
.tag{
    position: absolute;
    top: -3*@px;
    right: 3*@px;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 5*@px 2.5*@px 4*@px 2.5*@px;
    border-color: #f96e0e #f96e0e transparent #f96e0e;
    font-size: @font-size-info;
}

.envelope-signature-btn{
    position: absolute;
    bottom: 0;
    width: 100%;
    display: flex;
    height: 50*@px;
    color:@color-main;
    font-size: @font-size-primary;
    border-top: 1*@px solid #ddd;
    z-index:20;

    div{
        flex:1;
        text-align: center;
    }
    .option-text{
        font-size:@font-size-info;
    }
}
.sign-btn{
    border-left: 1*@px solid #ddd;
    color:@color-white;
    text-align: center;
    line-height: 0.5rem;
}
.reject-sign{
   background: @color-white;
   line-height: 0.5rem;
}
.search-sign-location{
    background: @color-main;
    line-height: 0.5rem;
}
.sign-envelope{
    background: @color-success;
    line-height: 0.5rem;
}
.signature-popup-box{
    width: 3.2rem;
    display: flex;
    flex-direction: column;
    text-align: center;
    border-radius: 3px;
    p{
        font-size: @font-size-title;
        padding:10px 0;
        display: flex;
        flex-direction: column;
    }
}
.signature-popup-box-content{
    flex:1;
    display: flex;
    flex-direction: column;
    padding: 0 10px 10px 10px;
    .form-text{
        padding: 6px 0;
        line-height: 1;
        flex:1;
        align-items: center;
        display: flex;
        justify-content: space-around;
        span{
            padding:0 5px;
        }
    }
}
.signature-popup-box-footer-btn{
    height: 0.4rem;
    line-height: 0.4rem;
    border-top: 1px solid #ddd;
}
.signature-popup-box-footer-btn-group{
    .signature-popup-box-footer-btn;
    display: flex;
    div{
        width: 50%;
    }
    :first-child{
        border-right: 1px solid #ddd;

    }
    :last-child{
        background: @color-success;
        color: #fff;
    }
   

}

.icon{
    position: fixed;;
    bottom: 80*@px;
    right:10*@px;
    font-size:38*@px;
    z-index: 20;
}
.form-list{
    position: absolute;
    bottom: 70*@px;
    right: 72*@px;
    height: 60*@px;
    width: 270*@px;
    z-index: 99;
    font-size:@font-size-regular;
    color:#999;
    border: 1px solid #0c7ffc;
    border-radius: 10px;
    
    .content{
        display: flex;
        height: 100%;
        align-items: center;

        .form-type{
            flex:1;
        }
    }
    .icon-style{
        font-size:25*@px;
    }
    .form-option{
        width: 58*@px;
        margin: auto;
        text-align: center
    }
}
// .active{
//     color:@color-main;
// }
.icon-color{
    color:@color-main;
}
.icon-signature{
    font-size:30*@px;
}
.confirm{
    background: @color-main;
    color:#fff;
    line-height: 50*@px;
    padding: 0 15*@px;
}
</style>