<!--
    @id        page-person-auth
    @desc      个人实名认证主页
    @level     page：页面组件
    @author    周雪梅
    @date      2019-04-25 17:33:10
-->
<template>
    <div class="wrap">
        <div class="main-container">
            <div v-if="step === 0" class="auth-container" v-loading="loadingAuthData">
                <Tab :tabs="authTabs" :activeTab="activeTypeIndex" @active-tab="chooseType" class="auth-tab-nav"></Tab>
                <div v-if="!loadingAuthData" class="container-content">
                    <component class="auth-status" :is="verifyWay" :name="name" :developerEnterpriseWsid="developerEnterpriseWsid" :developerEnterpriseName="developerEnterpriseName" :phone="phone" :idCardNo="idCardNo" :invokeNo="invokeNo" :userWsid = "userWsid" @error="authError" :iddtvData="idttInfo" @success="success" @waiting="step = 3"></component>
                </div>
            </div>
            <div v-if="step === 1" class="auth-container">
                <div class="auth-result">
                    <p class="auth-resulut-title">手机三网认证结果</p>
                    <p><i class="icon-complete icon right"></i></p>
                    <p class="auth-resulut-title right">认证成功</p>
                    <el-button type="primary" v-if="enterpriseExist" class="auth-result-btn" @click="enterpriseAuth">前往企业认证</el-button>
                    <p class="hint" v-if="returnUrl!=='DEFAULT' && !enterpriseExist">{{countDown}}s后自动跳转</p>
                    <el-button v-if="returnUrl!=='DEFAULT' && !enterpriseExist" type="primary" plain class="auth-result-btn" @click="openAPIAuthCompleteJump">返回</el-button>
                </div>
            </div>
            <div v-if="step === 2" class="auth-container">
                <div class="auth-result">
                    <p class="auth-resulut-title">手机三网认证结果</p>
                    <p><i class="icon-refuse2 icon error"></i></p>
                    <p class="auth-resulut-title error">认证失败</p>
                    <p class="error reason" v-if="authErr">原因:{{authErr}}</p>
                    <p class="error reason" v-else>原因:{{idttInfo.description}}</p>
                    <div class="hint">
                        <p>请返回重新认证</p>
                        <span v-if="returnUrl!=='DEFAULT'">{{countDown}}s后自动跳转</span>
                    </div>
                    <el-button type="primary" class="auth-result-btn" @click="reAuth('RETURN')">返回</el-button>
                </div>
            </div>
            <div v-if="step === 3" class="auth-container">
                <div class="auth-result">
                    <p class="auth-resulut-title">提交成功，等待审核</p>
                    <p><i class="icon-wait2 wait icon"></i></p>
                    <p class="await-title">系统将在24小时内对您的认证信息进行审核<br>审核结果会通过手机短信或邮件通知您<br/>请耐心等待或者联系客服 021-962600</p>
                    <!--<el-button type="primary" class="auth-result-btn" @click="toBack">返回首页</el-button>-->
                </div>
            </div>
            <div v-if="step === 4" class="auth-container">
                <div class="auth-center-box">
                    <p class="auth-resulut-title">手机三网认证结果</p>
                    <p><i class="icon-notice wait icon"></i></p>
                    <p class="await-title">手机号绑定的身份证信息未通过三网验证</p>
                    <p @click="cancel" class="underline">取消</p>
                </div>
                <div class="auth-error-box">
                    <div class="contact-info-box hint">
                        <p>签约人手机：{{phone}}</p>
                        <p>签约人姓名：{{name}}</p>
                        <p>签约人身份证号：{{idCardNo}}</p>
                    </div>
                    <p class="bold">手机三网认证失败怎么办？</p>
                    <div class="auth-error-list-box hint">
                        <p class="item">1.请联系移动/联通/电信运营商确定手机号的实名人信息是否与此处一致（手机实名认证不支持以企业名义开户）。</p> 
                        <p class="item">2.如果确定第1条是一致的，但是机主在手机营业厅实名认证未超过2周（包括新购、过户手机号的情况），请等待至少2周后再使用手机三网认证。</p> 
                        <p class="item">3.如果着急完成认证，请更换一个已在手机营业厅实名认证超过1个月的手机号机主作为签约人</p> 
                    </div>
                </div>
            </div>
            <div v-if="step === 5" class="auth-container">
                <div class="auth-result">
                    <div class="set-signpassword-header">
                        请设置在签署确认时的确认密码
                    </div>
                    <hr>
                    <div style="height: 30px"></div>
                    <label class="label-title">请输入签署密码&nbsp;&nbsp;<span class="input-err">{{newPasswordErr}}</span></label>
                    <el-input class="wesign-dialog-form-group" type="password" size="large" v-model="newPassword" placeholder="请输入要设置的签署密码(至少6位数字、字母和字符的组合)"
                        :class="newPasswordErr ? 'input-err': ''" @blur="checkPassword"/>
                    <label class="label-title">请确认签署密码&nbsp;&nbsp;<span class="input-err">{{repasswordErr}}</span></label>
                    <el-input class="wesign-dialog-form-group" type="password" size="large" v-model="rePassword" placeholder="请再次确认您的签署密码"
                        :class="repasswordErr? 'input-err': ''" @blur="checkRepassword"/> 
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="step = 1">跳过</el-button>
                        <el-button type="primary" @click="confirmSetSignPassword">确认</el-button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Tab from "@components/commons/tabs/tab-default.vue"
import { personAuth, 
    getVerifications, 
    getVerificationInfo, resetAuthStatus, personCheck} from "@interfaces/auth/auth.js"
import { searchEnterprise } from "@interfaces/enterprise/search.js"
import APPVerification from "@components/openapi-authorization-auth/verifications/person/person-app.vue"
// import ZhimaVerification from "@components/openapi-authorization-auth/verifications/person/person-zhima.vue"
import ManuallCheckVerification from "@components/openapi-authorization-auth/verifications/person/person-manuall-check.vue"
import ThreeNets from "@components/openapi-authorization-auth/verifications/person/three-nets.vue"
import signit from "@images/openapi-authorization/logo-ico.png"
import querystring from "querystring"
import { getSessionData } from "@interfaces/user/sessions.js"
import { getUserData } from "@interfaces/user/user.js"
import { setSignPassword } from "@interfaces/user/user.js"

import { password_length, password_allabc, password_allnumber, password_allspecichar } from "@commons/check.js"

export default {
    data(){
        return {
            loadingAuthData: false,
            authTypes: [
                { name: "三网手机实名认证", code: "THREE_NETS" },
                // { name: "芝麻认证", code: "ZHIMA"},
                // { name: "人工认证", code: "MANUALL_CHECK"},
            ],
            activeTypeIndex: -1, //当前认证方式序号

            signit: signit,
            userWsid: "",
            idttvWsid: "", //认证信息ID
            idttInfo: null,
            step: 0,
            idCardNo: "",
            idCardType: "",
            name: "",
            phone: "",
            returnUrl: "",
            enterpriseExist: false,
            idttvStatus: "",
            authErr: "",
            developerEnterpriseName: "",
            developerEnterpriseWsid: "",
            invokeNo: "",

            countDown: 0,
            intervalHandle: null,

            //设置签署密码
            newPassword: "",
            rePassword: "",
            newPasswordErr: "",
            repasswordErr: "",
        }
    },
    computed: {
        authTabs(){
            return this.authTypes.map(t => t.name)
        },
        verifyWay(){
            let code = this.authTypes[this.activeTypeIndex].code
            switch (code){
                // case "ZHIMA": return ZhimaVerification;break
                case "THREE_NETS": return ThreeNets;break
                // default : return APPVerification;break
            }
        },
    },
    created(){
        // this.activeTypeIndex = 0
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.userWsid = this.$route.params.userWsid
        this.name = query.name
        this.authType = query.authType
        this.phone = query.phone
        this.businessLicenceImageUrl = query.businessLicenceImageUrl
        this.idCardNo = query.idCardNo
        this.idCardType = query.idCardType
        this.developerEnterpriseName = query.developerEnterpriseName
        this.developerEnterpriseWsid = query.developerEnterpriseWsid
        this.returnUrl = decodeURIComponent(query.returnUrl) || "DEFAULT"
        this.invokeNo = query.invokeNo
        if (this.businessLicenceImageUrl && this.authType){
            this.enterpriseExist = true
        }

        if (this.$route.params.type > 0){
            this.activeTypeIndex = parseInt(this.$route.params.type)
        } else {
            this.activeTypeIndex = 0
        }
        this.loadingAuthData = true
        this.getAuthId().then(id => {
            this.idttvWsid = id
            return this.getAuthInfo()
        }).then(_ => {
            this.loadingAuthData = false
        }).catch(err => {
            this.$message.error("获取认证信息数据失败")
        })
        // let imageDatas = []
        // for (let i = 0; i < query.imageCode.length; i++) {
        //     imageDatas.push({
        //         imageCode:  query.imageCode[i],
        //         imageName: query.imageName[i],
        //         imageFileWsid:query.imageFileWsid[i],
        //         imageUrl: query.imageUrl[i]
        //     });
        // }
    },
    methods: {
        chooseType(activeTypeIndex){
            this.activeTypeIndex = activeTypeIndex
            this.$router.replace({
                name: "person-auth",
                params: {
                    userWsid: this.userWsid,
                    type: activeTypeIndex
                },
                query: this.$route.query
            })
        },
        async getAuthId(){
            let res = await personAuth({
                authorWsid: this.userWsid,
                fromTag: this.developerEnterpriseWsid,
                invokeNo: this.invokeNo
            })
            return res.data.data.identity.wsid
        },
        enterpriseAuth(){
            this.$router.push({
                name: "enterprise-auth",
                query: this.$route.query
            })
        },
        cancel(){
            this.step = 2
            if (this.returnUrl !== "DEFAULT"){
                let startTime = Date.now()
                this.countDown = 5
                this.intervalHandle = setInterval(_ => {
                    let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                    this.countDown = countDown
                    if (countDown <= 0){
                        clearInterval(this.intervalHandle)
                        this.reAuth("RETURN")
                    }
                }, 33)
            }
        },
        authError(data){
            this.step = 4
            this.authErr = data
        },
        openAPIAuthCompleteJump(){
            if (this.returnUrl === "DEFAULT"){
                this.$router.replace({
                    name: "person-auth",
                    query: this.$route.query
                })
            } else {
                if (/^http/i.test(this.returnUrl)){
                    location.href = this.returnUrl
                } else {
                    location.href = "http://" + this.returnUrl
                } 
            }
        },
        success(){
            getSessionData().then(res => {
                let session = res.data.data.session
                let userId = res.data.data.session.userWsid

                return getUserData({
                    userWsid: userId
                })
            }).then(res => {
                let user = res.data.data.userInfo.user
                if (user.existSignPassword){
                    this.step = 1
                    if (this.returnUrl !== "DEFAULT" && this.enterpriseExist == false){
                        let startTime = Date.now()
                        this.countDown = 5
                        this.intervalHandle = setInterval(_ => {
                            let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                            this.countDown = countDown
                            if (countDown <= 0){
                                clearInterval(this.intervalHandle)
                                this.openAPIAuthCompleteJump()
                            }
                        }, 33)
                    }
                } else {
                    this.step = 5
                }
            })
        },
        personCheckInfo(){
            personCheck({
                name: this.name,
                idCardNo: this.idCardNo,
                notifyIfSame: true,
                invokeNo: this.invokeNo
            }).then(res => {
            }).catch(err =>{
                console.error(err)
            })
        },    
        getAuthInfo(){
            return getVerificationInfo({
                identityWsid: this.idttvWsid
            }).then(body => {
                let userIddtvStatus = body.data.data.identity
                this.idttvStatus = userIddtvStatus.status
                this.idttInfo = userIddtvStatus
                if (userIddtvStatus.status === "WAITING"){
                    this.step = 3
                } else if (userIddtvStatus.status === "PASSED"){
                    getSessionData().then(res => {
                        let session = res.data.data.session
                        let userId = res.data.data.session.userWsid

                        return getUserData({
                            userWsid: userId
                        })
                    }).then(res => {
                        let user = res.data.data.userInfo.user
                        if (user.existSignPassword){
                            this.step = 1
                            this.personCheckInfo()
                            if (this.returnUrl !== "DEFAULT" && this.enterpriseExist === false){
                                let startTime = Date.now()
                                this.countDown = 5
                                this.intervalHandle = setInterval(_ => {
                                    let countDown = 5 - Math.floor((Date.now() - startTime) / 1000)
                                    this.countDown = countDown
                                    if (countDown <= 0){
                                        clearInterval(this.intervalHandle)
                                        this.openAPIAuthCompleteJump()
                                    }
                                }, 33)
                            }
                        } else {
                            this.step = 5
                        }
                    })
                } else if (userIddtvStatus.status === "DENY"){
                    this.personCheckInfo()
                    this.step = 2
                }
                this.loadingAuthData = false
            })
        },
        reAuth(val){
            if (this.idttvStatus == "INCOMPLETE"){
                clearInterval(this.intervalHandle)
                if (val == "RETURN" && this.returnUrl !== "DEFAULT"){
                    this.openAPIAuthCompleteJump()
                } else {
                    this.step = 0 
                }
            } else {
                resetAuthStatus({
                    identityWsid: this.idttvWsid,
                }).then(_ => {
                    clearInterval(this.intervalHandle)
                    if (val === "RETURN" && this.returnUrl !== "DEFAULT"){
                        this.openAPIAuthCompleteJump()
                    } else {
                        this.step = 0 
                    }
                }).catch(_ => {
                    this.$message.error("返回重新认证失败")
                })
            }
        },
        checkPassword(checkNull = false){ //密码校验
            let val = this.newPassword
            if (val.length === 0){
                if (checkNull === true){
                    this.$data.newPasswordErr = "请输入密码"
                    return false
                }
                else {
                    this.$data.newPasswordErr = ""
                    return false
                }
               
            }
            if (!password_length(val)){
                if (val.length > 32){
                    this.$data.newPasswordErr = "密码长度不能超过32位"
                }
                else {
                    this.$data.newPasswordErr = "密码长度不能低于6位"
                }
                return false
            }
            if (password_allabc(val)){
                this.$data.newPasswordErr = "密码不能全为字母"
                return false
            }
            if (password_allnumber(val)){
                this.$data.newPasswordErr = "密码不能全为数字"
                return false
            }
            if (password_allspecichar(val)){
                this.$data.newPasswordErr = "密码不能全为字符"
                return false
            }
            this.$data.newPasswordErr = ""
            return true
        },
        checkRepassword(checkNull = false){ //确认密码
            let val = this.newPassword,
                preval = this.rePassword
            if (preval.length === 0){
                if (checkNull === true){
                    this.$data.repasswordErr = "请输入密码"
                    return false
                } else {
                    this.$data.repasswordErr = ""
                    return false
                }
            }
            if (val === preval){
                this.$data.repasswordErr = ""
                return true
            } else {
                this.$data.repasswordErr = "密码确认错误，请重新输入"
                return false
            }
        },
        confirmSetSignPassword(){
            this.checkPassword(true)
            this.checkRepassword(true)
            if (this.newPasswordErr || this.repasswordErr){
                return
            }

            let userWsid = this.userWsid
            return setSignPassword({
                userWsid,
                signPassword: this.newPassword
            }).then(_ => {
                this.$message.success("设置签署密码成功")
                this.step = 1
            }).catch(err => {
                if (err.response){
                    let code = err.response.data.code
                    switch (code){
                        case 101:{
                            this.$message.error("签署密码不能与登录密码相同")
                            this.newPasswordErr = "签署密码不能与登录密码相同"
                            break
                        }
                        default:{
                            this.$message.error("设置签署密码失败")
                        }
                    }
                } else {
                    this.$message.error("设置签署密码失败")
                }
            })
        }
    },
    components: {
        Tab,
        ThreeNets
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.header{
    .info-block-default;
    background:@color-white;
    height:60px;
    line-height:60px;
    padding:0 20px;
    color:@color-main;
    span{
        cursor:pointer;
    }
}
@media screen and (max-width: 780px){
    .main-container{
        top:0px !important;
    }
}
.main-container{
    max-width:600px;
    position:relative;
    top:70px;
    margin:0 auto;
    overflow-x:hidden;

    .auth-container{
        .info-block-default;
        max-width:600px;
        margin:0 auto;
        padding:15px;
    }
    .auth-tab-nav{
        justify-content: center;
        border-bottom:1px solid @color-border-button;
        padding-bottom: 5px;
    }
    
    .container-content{
        width:90%;
        margin:0 auto;
        padding:20px 0;
        text-align:center;
        min-height:300px;
        margin-bottom:120px;
    }
}
.auth-status{
    max-width:600px;
    margin:0 auto;
}
.auth-btn{
    width:100%;
    margin-top:40px;
    cursor:pointer;
}
.identity-message{
    max-width:480px;
    padding-top:30px;
}
.auth-result{
    margin:0 auto;
    text-align:center;
    min-height: 500px;
    p{
        padding-top:15px;
        text-align:center;
        font-size:@font-size-info
    }
}
.right{
    color:@color-success;
}
.error{
    color:@color-danger;
}
.icon{
    font-size:@font-size-largger
}
.await{
    color:@color-info;
}
.wait{
    color:@color-warning
}
.await-title{
    color:@color-font-regular;
    font-size:@font-size-info;
    line-height:25px;
}
.auth-result-btn{
    width:100%;
    max-width:300px;
    margin:40px 0;
    cursor:pointer;
}
.left{
    font-weight:@font-weight-bold;
    font-size:@font-size-title;
    vertical-align:middle;
}
// .reason{
//     font-size:@font-size-regular !important;
// }
.signit{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    text-align:center;
}
.auth-resulut-title{
    font-size:@font-size-primary !important;
}
.hint{
    color:@color-font-regular;
    font-size:@font-size-info;
    span{
        padding-top:8px;
        display:inline-block;
    }
}
.auth-center-box{
    text-align:center;
    p{
        padding-top:15px;
    }
    border-bottom:1px solid #ccc
}
.auth-error-box{
    width:90%;
    max-width:500px;
    min-width:300px;
    margin:0 auto;
    padding-bottom: 15px;
}
.contact-info-box{
    padding:15px 0;
    font-size:12px;
    p{
        line-height:20px;
    }
}
.bold{
    font-weight:bold;
}
.auth-error-list-box{
    .item{
        padding-top:10px;
        font-size:12px;
        line-height:20px;
    }
}
.underline{
    text-decoration:underline;
    height:40px;
    line-height:40px;
    cursor:pointer;
}
.underline:hover,.underline:active{
    color:@color-main
}

.set-signpassword-header{
    font-size: 20px;
    padding: 20px 0;
}
</style>

<style lang="less">
@import "~@styles/variable.less";

.input-err{
    color:@color-danger;
}
.input-err .el-input__inner{
    border-color: @color-danger;
    color:@color-danger;
}
</style>