<template>
    <router-view global-change></router-view>
</template>
<style src="@styles/openapi-authorization/index.less"></style>
