
<template>
    <div class="main-container">
        <section class="section-one">
            <h2 class="section-one-title public-center">授权开通电子签约服务</h2>
            <div class="public-center info">
                <p><span class="developer-username">{{developerEnterpriseName}}</span></p>
                <p>邀请您使用大家签在线签约服务</p>
                <p>为保障双方合法权益，请您按照下面步骤开通电子签约服务</p>
            </div>
        </section>
        <section class="section-two section-white-bg">
            <div class="steps-box">
                <div class="first-step">
                    <p class="line-space">第一步</p>
                    <img :src="register" style="width:40px">
                    <p class="line-space">签约方验证</p>
                </div>
                <div class="second-step">
                    <p class="line-space">第二步</p>
                    <img :src="auth" style="width:40px">
                    <p class="line-space">实名认证</p>
                </div>
            </div>
            <h2 class="section-two-title public-center">您将享有的服务</h2>
            <div class="compare-box clearfix">
                <div>
                    <p>传统签约形式</p>
                    <div class="pic-box">
                        <div class="pic-box-bg"></div>
                        <img :src="signit1">
                    </div>
                </div>
                <div class="vs">
                    <p>VS</p>
                </div>
                <div>
                    <p>电子签约形式</p>
                    <div class="pic-box">
                        <div class="pic-box-bg"></div>
                        <img class="pic-bg" :src="signit2">
                    </div>
                </div>
            </div>
        </section>
        <section class="section-three">
            <div class="compare-box clearfix">
                <div>
                    <div class="pic-box">
                        <div class="pic-box-bg"></div>
                        <img :src="signit3">
                    </div>
                </div>
                <div class="vs">
                &nbsp;
                </div>
                <div>
                    <div class="pic-box">
                        <div class="pic-box-bg"></div>
                        <img class="pic-bg" :src="signit4">
                    </div>
                </div>
            </div>
        </section>
        <section class="section-four section-white-bg">
            <div class="compare-box clearfix">
                <div>
                    <div class="pic-box">
                        <div class="pic-box-bg"></div>
                        <img :src="signit5">
                    </div>
                </div>
                <div class="vs">
                &nbsp;
                </div>
                <div>
                    <div class="pic-box">
                        <div class="pic-box-bg"></div>
                        <img class="pic-bg" :src="signit6">
                    </div>
                </div>
            </div>
        </section>
        <div class="signit"><img :src="signit" style="width:20px">由大家签提供技术支持</div>
        <footer class="footer">
            <el-button type="primary" round @click="openVerify">开通并验证</el-button>
        </footer>
    </div>
</template>

<script>
import { getSessionData } from "@interfaces/user/sessions.js"
import {changeSession, checkAccount, getUserData, getUserAccounts } from "@interfaces/user/user.js"
import { personCheck} from "@interfaces/auth/auth.js"

import auth from "@images/openapi-authorization/auth.svg"
import register from "@images/openapi-authorization/register.svg"
import signit from "@images/openapi-authorization/logo-ico.png"
import signit1 from "@images/openapi-authorization/signit1.png"
import signit2 from "@images/openapi-authorization/signit2.png"
import signit3 from "@images/openapi-authorization/signit3.png"
import signit4 from "@images/openapi-authorization/signit4.png"
import signit5 from"@images/openapi-authorization/signit5.png"
import signit6 from "@images/openapi-authorization/signit6.png"

import { LoginLocalStatus, LoginComponentLocalInfo } from "@classes/login/login-info.js"
import querystring from "querystring"
export default {
    data(){
        return {
            auth: auth,
            register: register,
            signit: signit,
            signit1:signit1,
            signit2:signit2,
            signit3:signit3,
            signit4:signit4,
            signit5:signit5,
            signit6:signit6,
            loading: true,
            isRegister: false,
            userWsid: "",
            targetUserId: "",

            localInfo: new LoginComponentLocalInfo(),
            loginLocalStatus: new LoginLocalStatus(),
        }
    },
    computed: {
        developerEnterpriseName(){
            return this.$store.state.developerEnterpriseName
        },
        contact(){
            return this.$store.state.phone
        },
        unifiedSocialCode(){
            return this.$store.state.unifiedSocialCode || this.$store.state.registCode
        }
    },
    mounted(){
        this.$store.commit("loadURLData", this.$route.query)
        this.checkEnvelopeStatus()
    },
    methods: {
        openVerify(){
            this.localInfo.setAuthorization(true)
            this.$router.push({
                name: "verification",
                query: this.$route.query
            })
        },
        checkEnvelopeStatus(){
            let loading = this.$loading({
                lock: true,
                text: "加载数据中",
                spinner: "el-icon-loading",
                background: "rgba(0, 0, 0, .8)"
            })
   
            this.checkUserIfLogin().then(_ => {
                loading.close()
            })
        },
        personCheckInfo(){
            personCheck({
                name: this.$store.state.name,
                idCardNo: this.$store.state.idCardNo,
                notifyIfSame: true,
                invokeNo:this.$store.state.invokeNo
            }).then(res => {
            }).catch(err =>{
                console.error(err)
            })
        },
        async checkUserIfLogin(){
            let enterpriseName = this.$store.state.enterpriseName
            let isLogin = false
            try {
                let session = await getSessionData().then(res => res.data.data.session)
                let userId = session.userWsid

                //检测联系方式是否正确
                let userInfo = await getUserData({
                    userWsid: userId,
                }).then(res => {
                    return res.data.data.userInfo.user
                })

                if (userInfo.phone === this.$store.state.phone
                    || userInfo.email === this.$store.state.phone){
                        isLogin = true
                        this.userWsid = userInfo.userWsid
                        this.$store.commit("setUserWsid", userInfo.userWsid)
                        this.$store.commit("setActiveUserWsid", session.userWsid)
                } else {
                    isLogin = false
                }
            } catch (e) {
                console.error(e)
                //未登录
            }

            if (isLogin && this.loginLocalStatus.login == true){
                if (this.userWsid.match(/^WSID_EUSR/)){
                    this.$router.push({
                        name: "enterprise-auth",
                        query: this.$route.query
                    })
                } else {
                    personCheck({
                        name: this.$store.state.name,
                        idCardNo: this.$store.state.idCardNo,
                        invokeNo:this.$store.state.invokeNo
                    }).then(res => {
                        let authResult = res.data.data.result
                        if (this.unifiedSocialCode && authResult.pass === true && authResult.same === true){
                            this.personCheckInfo()
                            this.$router.push({
                                name: "enterprise-auth",
                                query: this.$route.query
                            })
                        } else if (authResult.pass === true && authResult.same === false){
                            this.personCheckInfo()
                            this.$router.push({
                                name: "authentication",
                                query: this.$route.query
                            })
                        } else {
                            this.$router.push({
                                name: "person-auth",
                                query: this.$route.query
                            })
                        }
                    })
                }
            } else {
                if (this.localInfo.isAuthorization === false){
                    this.$router.push({
                        path: "/",
                        query: this.$route.query
                    })
                } else {
                    this.$router.push({
                        name: "verification",
                        query: this.$route.query
                    })
                }
            }
        }
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.main-container{
    position:relative;
    top:15px;
    padding-bottom:80px;
}
.public-center{
    text-align:center;
}
p{
    margin-bottom:5px;
}
.section-one-section-one-title{
    padding-top:40px;
}
.section-one-title{
    font-size:30px;
}
.developer-username{
    // color:#4E83EB;
    font-weight:bold;
}
.clearfix:after {
    content: " ";
    display: block;;
    line-height: 0;
    height: 0;
    visibility: hidden;
    clear: both;
}
.section-one{
    min-height:260px;
}
.section-white-bg{
    background:#fff;
}
.section-two{
    padding-bottom:40px;
    text-align:center;
    box-shadow: 0 1px 4px 0 rgba(0,0,1,.1);
}
.section-two-title{
    padding-top:110px;
    display:inline-block;
    border-bottom:3px solid #4E83EB;
    font-size: 30px;
    padding-bottom: 5px;
}

.steps-box{
    text-align:center;
    max-width:500px;
    width:90%;
    margin:0 auto;
    position:relative;
}
.first-step,.second-step {
    max-width: 200px;
    min-width: 100px;
    width: 48%;
    padding:10px 0;
    background:#fff;
    color:#4E83EB;
    box-shadow: 0 16px 44px 0 rgba(0,0,1,.1);
}
.first-step{
    position:absolute;
    top:-80px;
    left:0;
}

.second-step{
    position:absolute;
    top:-80px;
    right:0;
}
.line-space{
    padding-top:10px;
    font-size:16px;
}
.compare-box{
    width:90%;
    max-width:700px;
    margin:0px auto;
    // min-height:300px;

    div{
        width:40%;
        float:left;
        text-align: center;
    }
   .vs{
        width:20%;
        float:left;
        text-align: center;
    }
    .pic-box{
        width:100%;
        position:relative;
        height:100%;
        padding:8px 0; 
    }
    .pic-box-bg{
        position:absolute;
        top:0;
        bottom:0;
        width:10%;
        max-width:20px;
        min-width:20px;
        background:#4E83EB;
        height:100%;

    }
    img{
        position:relative;
        width:90%;
        max-width:260px;
        min-width:100px;
        box-shadow: 0 1px 44px 0 rgba(0,0,1,.1);
    }
}
.section-three,.section-four{
    box-shadow: 0 1px 4px 0 rgba(0,0,1,.1);
    .compare-box{
        padding:40px 0;
    }
}
// @media screen and (max-width:786px){
//     .section-four{
//         padding-bottom:90px;
//     }
// }

// .section-four {
//     padding-bottom:40px;
// }
.footer{
    position:fixed;
    bottom:0;
    left:0;
    right:0;
    background:#f4f8f9;
    padding:10px 0;
    text-align:center;
}
.signit{
    height:60px;
    line-height:60px;
    text-align:center
}
</style>