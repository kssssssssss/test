<template lang="html">
    <div @input="clearInfo" class="register-container">
        <h2 class="pic-title">签约方验证</h2>
        <div class="container">
            <div class="info">
                <div class="public-bottom-line" v-if="unifiedSocialCode">
                    <p class="title">签约方名称</p>
                    <p class="mini-size hint">{{enterpriseName}}</p>
                </div>
                <div class="public-bottom-line">
                    <p class="title">签约人姓名</p>
                    <p class="mini-size hint">{{name}}</p>
                </div>
                <div class="public-line-box"> 
                    <p class="title">签约人联系方式<span> &nbsp;(将用于接收认证、签约通知)</span></p>
                    <p class="mini-size hint">{{contact}}</p>
                </div>
                <div class="wesign-outside-error-box">
                    <p v-if="infoText" :class="infoClass">
                        <i :class="infoIcon"></i>
                        {{infoText}}
                    </p>
                </div>
                <div class="public-line-box">
                    <p>签约人身份验证</p>
                    <el-row class="wesign-outside-form-group">
                        <el-col :span="13">
                            <el-input size="large" v-model.trim="verifyCode" :disabled="!isImport" :placeholder="!isImport ? '请点击右侧获取验证码' : '请输入验证码'"
                                @input="verifyCodeCheck = false" @blur="checkVerifycodeFormat()"/>
                        </el-col>
                        <el-col :span="10" :offset="1">
                            <captchaButton size="large" style="width:100%" :developerEnterpriseWsid="developerEnterpriseWsid" :disabled="!contactCheck" :contact="contact || ''" service="SIGNATURE_ACCOUNT_LOGIN"
                                @sending="sending"
                                @error="sendVerifyCodeError" @sendsuccess="sendSuccess" @timeShow="isImport = true" :type="verifyCodeType"></captchaButton>
                        </el-col>
                    </el-row>
                </div>
                <div class="wesign-outside-form-group">
                    <el-button size="large" style="width:100%;" type="primary" :loading="logining" @click="next('CODE')">下一步</el-button>
                </div>
                <div v-show="showCodeExplain" class="wesign-outside-form-group" style="text-align:right;padding-bottom:10px">
                    <a @click="showModalCodeExplain">收不到验证码？</a>
                </div>
                <codeExplain @close-modal="close" :msg="codeExplainTitle" :type="codeExplainType" :message="codeExplainMessage" :messages="codeExplainPublicMessage" v-show="modalCodeExplain" @close-dialog="close"></codeExplain>
            </div>
        </div>
        <div class="signit">
            <img :src="signit" style="width:20px">由大家签提供技术支持
        </div>
    </div>
</template>

<script>
import {isPassword, isUserName, isPhone, isEmail } from "@wesign/check"
import { checkAccount} from "@interfaces/user/user.js"
import { opcode_post } from "@interfaces/auth/captcha.js"
import captchaButton from "@components/buttons/captcha-button.vue"
import codeExplain from "@components/modal/openapi-authorization-modal/code-explain.vue"
import { signingObjectSession} from "@interfaces/user/sessions.js"
import { personAuth, personCheck} from "@interfaces/auth/auth.js"
import querystring from "querystring"
import { LoginLocalStatus } from "@classes/login/login-info.js"
import signit from "@images/openapi-authorization/logo-ico.png"
// import Tab from "@components/commons/tabs/tab-default.vue"
export default {
    data(){
        return {
            /* ERROR_ACOUNT_ISNULL             请输入手机号或邮箱地址
             * ERROR_ACOUNT                    帐号输入错误
             * ERROR_VERIFICATION_ISNULL       请输入验证码/
             * ERROR_VERIFICATION_CODE_BUSY    验证码获取频繁，今天已无法获取
			 * ERROR_VERIFICATION_CODE		   验证码错误
             * ERROR_CONTACT                   联系人格式错误/
             * ERROR_SEND_BUSY                 发送频繁
             * ERROR_SEND_FAILED               发送失败/
             * ERROR_COMPLETE_INFO_ISNULL      请填写正确的完整信息
             *
             * ERROR_NAME_ISNULL               请输入您的真实姓名
             * ERROR_NAME                      请输入有效的姓名
             * ERROR_PASSWORD_ISNULL           请输入密码     
             * ERROR_PASSWORD-LT               密码长度不能低于6位"
             * ERROR_PASSWORD-GT               密码长度不能超过32位
             * ERROR_NOT_ALL_ABC               密码不能全为字母
             * ERROR_NOT_ALL_NUMBER            密码不能全为数字
             * ERROR_NOT_ALL_CHAR              密码不能全为字符
             * ERROR_REPASSWORD_ISNULL         请输入确认密码
             * ERROR_PASSWORD_AFFIRM           密码确认错误，请重新输入
             * ERROR_DETECTION                 检测失败/
             * ERROR_REGISTER_FAILED           请求失败，请重试
             *
             * RIGHT_PHONE_VERIFICATION_SEND   验证码已发送，请注意查收短信
             * RIGHT_EMAIL_VERIFICATION_SEND   验证码已发送至指定邮箱，请查收  
             */

            opcode: "",
            contact: "",
            password: "",
            verifyCode: "",
            contactCheck: false, //账号是否通过检测
            verifyCodeCheck: false, //验证码是否通过检测
            showCodeExplain: false, //收不到验证码说明
            modalCodeExplain: false,

            priorityStatus: [
                {name: "accountStatus", status: ""},
                {name: "codeFormat", status: ""},
                {name: "verifyPasswordStatus", status: ""}
            ],
            commonStatus: "",
            accountExist: true, //账户是否存在

            loginLocalStatus: new LoginLocalStatus(),

            signit: signit,
            authType: "",
            idCardNo: "",
            name: "",
            developerEnterpriseName: "",
            logining: false,
            userWsid: "",
            isImport: false,
            developerEnterpriseWsid: "",
            invokeNo: "",
            enterpriseName: "",
            verifyCodeType: "SMS",
            unifiedSocialCode: ""
        }

    },
    computed: {
        infoStatus(){
            let status = this.priorityStatus.find(item => {
                if (item.status){
                    return true
                }
            })

            return status && status.status || this.commonStatus
        },
        infoText(){
            let status = this.infoStatus
            switch (status){
                case "ERROR_LOGIN": return "登录失败";break
                case "ERROR_REGIST": return "注册失败";break
                case "ERROR_ACOUNT_NULL": return "帐号不存在，请确认后再输入";break
                case "ERROR_ACOUNT_PASSWORD": return "账户或密码错误";break
                case "ERROR_MULTIPLE_ACOUNT_PASSWORD": return "帐号或密码错误";break
                case "ERROR_ACOUNT_ISNULL": return "请输入手机号";break
                case "ERROR_ACOUNT": return "手机号错误";break
                case "ERROR_VERIFICATION_ISNULL": return "请输入验证码";break
                case "ERROR_VERIFICATION_CODE": return "验证码错误";break
                case "ERROR_VERIFICATION_CODE_BUSY": return "验证码获取频繁，今天已无法获取" 
                case "ERROR_CONTACT": return "联系人格式错误";break
                case "ERROR_SEND_BUSY": return "发送太频繁，请倒计时结束后再点击";break
                case "ERROR_SEND_FAILED": return "发送失败";break
                case "ERROR_SEND_TIMEOUT": return "发送请求超时";break
                case "ERROR_SEND_FREQUENTLY": return "发送请求过于频繁";break
                case "ERROR_SEND_AMOUNT_OUT_LIMIT": return "今日可接收验证码已达到上限";break
                case "ERROR_PASSWORD_ISNULL": return this.accountExist ? "请输入登录密码" : "请设置登录密码";break
                case "ERROR_PASSWORD_BLANK": return "密码不能包含空格";break
                case "ERROR_PASSWORD-LT": return "密码长度不能低于6位";break
                case "ERROR_PASSWORD-GT": return "密码长度不能超过32位";break
                case "ERROR_NOT_ALL_ABC": return "密码不能全为字母";break
                case "ERROR_NOT_ALL_NUMBER": return "密码不能全为数字";break
                case "ERROR_NOT_ALL_CHAR": return "密码不能全为字符";break
                case "ERROR_PASSWORD_ISWRONG": return "密码格式错误";break
                case "ERROR_REPASSWORD_ISNULL": return "请输入确认密码";break
                case "ERROR_PASSWORD_AFFIRM": return "密码确认错误，请重新输入";break
                case "ERROR_DETECTION": return "网络不稳定，请稍候再试";break
                case "ERROR_REGISTER_FAILED ":return "请求失败，请重试";break
                case "RIGHT_PHONE_VERIFICATION_SEND": return "验证码已发送，请注意查收短信";break
                case "RIGHT_EMAIL_VERIFICATION_SEND": return "验证码已发送至指定邮箱，请查收"
            }
        },
        infoClass(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-errorWarning"
                
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-rightWarning"
            }
        },
        infoIcon(){
            let status = this.infoStatus
            if (status.match(/^ERROR/)){
                return "wesign-outside-error el-icon-error"
                
            } else if (status.match(/^RIGHT/)) {
                return "wesign-outside-right el-icon-success"
            }
        },
        codeExplainType(){
            let val = this.contact
            if (isPhone(val).result){
                return "PHONE"
            } else if (isEmail(val).result){
                return "EMAIL"
            }
        },
        codeExplainTitle(){
            let val = this.contact
            if (isPhone(val).result){
                return "检查短信是否被屏蔽"
            } else if (isEmail(val).result){
                return "查看是否进入垃圾信息或广告信息"
            }
        },
        codeExplainPublicMessage(){
            let val = this.contact
            if (isPhone(val).result){
                return "检查您的手机号是否正确"
            } else if (isEmail(val).result){
                return "检查您的邮箱号是否正确"
            }
        },
        codeExplainMessage(){
            let val = this.contact
            if (isPhone(val).result){
                return "若2分钟内未收到短信，可重新获取"
            } else if (isEmail(val).result){
                return "若2分钟内未收到邮件，可重新获取"
            }
        },
    },
    watch: {
        contact(val){
            if (val == ""){
                this.$data.showCodeExplain = false
            }
        },
    },
    created: function(){	
        let query = location.search.slice(1)
        query = querystring.parse(query)
        this.contact = query.phone
        this.authType = query.authType
        this.idCardNo = query.idCardNo
        this.name = query.name
        this.developerEnterpriseName = query.developerEnterpriseName
        this.enterpriseName = query.enterpriseName
        this.developerEnterpriseWsid = query.developerEnterpriseWsid
        this.unifiedSocialCode = query.unifiedSocialCode || query.registCode
        this.invokeNo = query.invokeNo
        if (this.contact){
            this.checkContactExist()
        }
    },
    methods: {
        sending(){
            this.setInfoStatus("codeFormat", "")
            this.setInfoStatus("verifyPasswordStatus", "")
        },
        personCheckNoNotify(){
            personCheck({
                name: this.name,
                idCardNo: this.idCardNo,
                notifyIfSame: false,
                account: this.contact,
                invokeNo: this.invokeNo
            }).then(res => {
                let authResult = res.data.data.result
                if(authResult.pass === true){
                    this.personCheckInfoNotify()
                }

                if (this.unifiedSocialCode && authResult.pass === true && authResult.same === true){
                    this.$router.push({
                        name: "enterprise-auth",
                        query: this.$route.query
                    })
                } else if (authResult.pass === true && authResult.same === false){
                    this.$router.push({
                        name: "authentication",
                        query: this.$route.query
                    })
                } else {
                    this.$router.push({
                        name: "person-auth",
                        query: this.$route.query
                    })
                }
            })
        },
        async next(val){
            if (!await this.checkContactExist(true) || !this.checkVerifycodeFormat(true)){
                return 
            }
            this.logining = true
            let opcode = await opcode_post({
                captcha: this.verifyCode,
                contact: this.contact,
                service: "SIGNATURE_ACCOUNT_LOGIN"
            }).then(res => {
                return res.data.data.operationCodeInfo.opcode
            }).catch( err => {
                this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                this.logining = false
            })
            await signingObjectSession({
                contact: this.contact,
                enableAutoRegist: true,
                opcode
            }).then(res => {
                let session = res.data.data.session
                let userWsid = session.userWsid
                this.logining = false
                
                let loginLocalStatus = this.loginLocalStatus
                loginLocalStatus.setLogin(true)
                loginLocalStatus.setUserWsid(session.userWsid)
                loginLocalStatus.setActiveUserWsid(session.userWsid)
                this.$store.commit("setUserWsid", session.userWsid)
                this.$store.commit("setActiveUserWsid", session.userWsid)
                this.personCheckNoNotify()
            }).catch(err => {
                this.logining = false
                this.commonStatus = "ERROR_LOGIN"
                console.error(err)
            })
        },
        setInfoStatus(name, status){
            let priorityStatus = this.priorityStatus
            priorityStatus.find((item, index) => {
                if (item.name === name){
                    item.status = status
                    if (status){
                        this.commonStatus = ""
                    }
                    priorityStatus.splice(index, 1)
                    priorityStatus.splice(0, 0, item)
                    return true
                }
            })
        },
        checkContactFormat(checkNull = false) {
            let val = this.$data.contact
            if (val.length === 0){
                if (!checkNull){
                    this.setInfoStatus("accountStatus", "")
                    return true
                } else {
                    this.setInfoStatus("accountStatus", "ERROR_ACOUNT_ISNULL")
                    return false
                }
            }
            
            if (!isEmail(val).result && !isPhone(val).result){
                this.setInfoStatus("accountStatus", "ERROR_ACOUNT")
                return false
            }
            this.setInfoStatus("accountStatus", "")
            return true
        },
        showModalCodeExplain(){
            this.modalCodeExplain = true
        },
        close(){
            this.modalCodeExplain = false
        },
        //账号校验
        checkContactExist(checkNull = false) {
            if (!this.checkContactFormat(checkNull)){
                return 
            }
            let val = this.$data.contact
            if (!val) return 

            return checkAccount({
                account: val
            }).then(res => {
                let body = res.data
                this.setInfoStatus("accountStatus", "")
                if (body.data.existed){
                    this.accountExist = true
                    this.$data.contactCheck = true
                } else {
                    this.accountExist = false
                    this.$data.contactCheck = true
                }
                this.$data.showCodeExplain = true
                return true
            }).catch(err => {
                if (err.response.data){
                    let code = err.response.data.code
                    if (code == 403) {
                        this.setInfoStatus("accountExist", "ERROR_SEND_FREQUENTLY")
                    } else {
                        this.setInfoStatus("accountExist", "ERROR_DETECTION")
                    }
                }
                this.$data.contactCheck = false
                return false
            })
        },
        checkVerifycodeFormat(checkNull = false){ //验证码校验
            let val = this.verifyCode
            if (/^\d{6}$/.test(val)){
                this.verifyCodeCheck = true
                this.setInfoStatus("codeFormat", "")
                return true
            } else if (val === ""){
                if (!checkNull){
                    this.setInfoStatus("codeFormat", "")
                    return true
                } else {
                    this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_ISNULL")
                    this.verifyCodeCheck = false
                    return false
                }
            } else {
                this.setInfoStatus("codeFormat", "ERROR_VERIFICATION_CODE")
                this.verifyCodeCheck = false
                return false
            }
        },
        sendVerifyCodeError(msg) {
            switch (msg){
                case "ERROR_CONTACT": 
                    this.commonStatus = "ERROR_CONTACT"
                    break
                case "ERROR_SEND_BUSY": 
                    this.commonStatus = "ERROR_SEND_BUSY"
                    break
                case "ERROR_TIMEOUT":
                    this.commonStatus = "ERROR_SEND_TIMEOUT"
                    break
                case "ERROR_FREQUENTLY":
                    this.commonStatus = "ERROR_SEND_FREQUENTLY"
                    break
                case "ERROR_AMOUNT_OUT_LIMIT":
                    this.commonStatus = "ERROR_SEND_AMOUNT_OUT_LIMIT"
                    break
                default:
                    this.commonStatus = "ERROR_SEND_FAILED"
            }
        },
        sendSuccess(data){
            this.isImport = data
            if (isPhone(this.contact).result){
                this.commonStatus = "RIGHT_PHONE_VERIFICATION_SEND"
            } else if (isEmail(this.contact).result){
                this.commonStatus = "RIGHT_EMAIL_VERIFICATION_SEND"
            } 
        },
        clearInfo(){
            this.commonStatus = ""
        }, 
        personCheckInfoNotify(){
            personCheck({
                name: this.$store.state.name,
                idCardNo: this.$store.state.idCardNo,
                notifyIfSame: true,
                invokeNo: this.invokeNo
            }).then(res => {}).catch(err =>{
                console.error(err)
            })
        },       
    },
    components: {
        captchaButton,
        codeExplain
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.tab-box{
    border-bottom:1px solid @color-border
}
.login-tab-nav{
    justify-content: center;
    padding-top: 15px !important;
}
.forget-password-box{
    position:relative;
    height:15px;
}
.forget-password{
    display:inline-block;
    text-align:right;
    position:absolute;
    right:0;
    width:75px;
    margin-top:0.05rem;
}
.verify-img{
    cursor: pointer;
    box-sizing: border-box;
    line-height: 42px;
    height: 42px;
    min-width: 42px;
    float: right;
    border: 1px solid #000;
}
.register-container{
    position:relative;
    // top:20px;
}
.developer-username{
    font-weight:bold;
}
.line-space{
    padding-top:20px;
}
.title{
    font-size:14px;
}
.pic-title{
    text-align:center;
    padding: 20px 0; 
    // font-size:16*@px;
}
.container{
    width: 96%;
    max-width:410*@px;
    min-width: 280px;
    height: auto;
    min-height:400*@px;
    position: relative;
    top:14%;
    left:0;
    right:0;
    margin:0 auto;
    background:@color-white;
    box-shadow:@shadow-default;
    border-radius: 6px;
    z-index:99;
} 
.info{
    width:88%;
    margin:0 auto;
    padding-top:30*@px
}
.icon-pic{
    padding:30*@px 0
}
.left{
    display:inline-block;
    flex:1;
    text-align:left
}
.center{
    text-align:center;
    flex:1
}

.regist-success{
    font-size:@font-size-primary;
}
.success{
    text-align:center;
	font-size:24*@px;
    padding-bottom:25*@px;
    display:inline-block
}
.view{
    font-size:@font-size-primary;
    display:inline-block;
    cursor:pointer
}
.eye{
    color:@color-main;
}
.agreement{
    font-size:12*@px;
}
.hint{
    color:@color-font-regular;
    font-size:12*@px
}
// .footer{
//     background:#fff;
//     height:60%;
//     box-shadow:0 1px 4px 0 rgba(0,0,1,.1);
// }
.signit{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    text-align:center;
}
.forget-password-dialog{
    font-size:@font-size-info;
    a{
        color:@color-main;
        text-decoration: underline;
        display: inline-block;
    }
}
.public-bottom-line{
    padding-bottom:10*@px;
    p{
        line-height:20*@px
    }
}
.public-line-box{
    p{
        line-height:20px;
    }
}
.mini-size{
    font-size: @font-size-info;
}
</style>
<style>
.register-container .el-dialog{
    min-width:300px !important;
}
.register-container .el-dialog__body{
    max-height:380px;
    overflow:auto;
}
.el-input__inner{
    padding:0 5px !important;
}
.login-tab-nav .tab{
    width:50%;
    margin-right:0 !important;
}
</style>
