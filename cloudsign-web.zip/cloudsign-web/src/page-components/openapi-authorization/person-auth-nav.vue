<!--
    @id        page-person-auth
    @desc      个人实名认证主页
    @level     page：页面组件
    @author    周雪梅
    @date      2019-04-25 17:33:10
-->
<template>
    <div class="auth-wrap">
            <div class="main-container" v-loading="loadingAuthData" element-loading-text="加载文档中">
                <p class="auth-info-title">实名认证</p>
                <Tab :tabs="authTabs" :activeTab="activeTypeIndex" @active-tab="chooseType" class="auth-tab-nav"></Tab>
                <div class="auth-container">
                    <div class="container-content personal-auth-container">
                        <router-view v-if="!loadingAuthData"></router-view>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
import Tab from "@components/commons/tabs/tab-default.vue"
import { mapState } from "vuex"
import { AUTH_METHODS, AUTH_METHOD_INFOS, AUTH_STATUS} from "@classes/openapi-authorization/index.js"
import { personAuth, 
    getVerifications, 
    getVerificationInfo, resetAuthStatus, personCheck} from "@interfaces/auth/auth.js"

import querystring from "querystring"
import { getSessionData } from "@interfaces/user/sessions.js"
import { getUserData } from "@interfaces/user/user.js"
import { setSignPassword } from "@interfaces/user/user.js"

import { password_length, password_allabc, password_allnumber, password_allspecichar } from "@commons/check.js"

export default {
    data(){
        return {
            loadingAuthData: false,
            activeTypeIndex: 0, //当前认证方式序号

            returnUrl: "",

            countDown: 0,
            intervalHandle: null,

            //设置签署密码
            newPassword: "",
            rePassword: "",
            newPasswordErr: "",
            repasswordErr: "",
            AUTH_METHOD_INFOS,
        }
    },
    computed: {
        authMethods(){
            return this.$store.state.authModes
        },
        authTabs(){
            return this.authMethods.map(t => this.AUTH_METHOD_INFOS[t].title)
        },
        stateData(){
            return this.$store.state
        },
        userWsid(){
            return this.$store.getters.userWsid
        },
        ...mapState({
            authStatus: "authStatus",
            description: "description",
            idttvWsid:"idttvWsid",
            currentAuthMethod:"currentAuthMethod"
        }),
    },
    created(){
        let query = location.search.slice(1)
        query = querystring.parse(query)

        this.invokeNo = query.invokeNo

        this.verifyWay()
        this.loadingAuthData = true
        this.$store.dispatch("updateModule").then(_ => {
            if(this.authStatus!== AUTH_STATUS.INCOMPLETE && this.authStatus!=="PHONE_PASSED"){
                this.$store.commit("setAuthStatus", this.authStatus)
                this.$store.commit("setDescription", this.description)
                this.$router.push({path:"/result", query:this.$route.query})
            } 
            this.loadingAuthData = false
        })
    },
    methods: {
        verifyWay(){
            let authMethods = this.authMethods[0]
            switch (authMethods){
                case AUTH_METHODS.PHONE_AUTH: this.$router.push({path:"/person/phone-auth",query:this.$route.query}); break
                case AUTH_METHODS.FACE_AUTH: this.$router.push({path:"/person/face-auth",query:this.$route.query}); break
                case AUTH_METHODS.ZM_AUTH: this.$router.push({path:"/person/zhima-auth",query:this.$route.query}); break
                case AUTH_METHODS.MANUAL: this.$router.push({path:"/person/manual-auth",query:this.$route.query}); break
                case AUTH_METHODS.PHONE_FACE_AUTH: this.$router.push({path:"/person/phone-face-auth",query:this.$route.query}); break
            }
        },
        chooseType(activeTypeIndex){
            let authMethods = this.authMethods[activeTypeIndex]
            this.$store.commit("setCurrentAuthMethod", authMethods)
            this.activeTypeIndex = activeTypeIndex
            switch (authMethods){
                case AUTH_METHODS.PHONE_AUTH: this.$router.push({path:"/person/phone-auth",query:this.$route.query}); break
                case AUTH_METHODS.FACE_AUTH: this.$router.push({path:"/person/face-auth",query:this.$route.query}); break
                case AUTH_METHODS.ZM_AUTH: this.$router.push({path:"/person/zhima-auth",query:this.$route.query}); break
                case AUTH_METHODS.MANUAL: this.$router.push({path:"/person/manual-auth",query:this.$route.query}); break
                case AUTH_METHODS.PHONE_FACE_AUTH: this.$router.push({path:"/person/phone-face-auth",query:this.$route.query});break
            }
        },
    },
    components: {
        Tab
    }
}
</script>
<style lang="less" scoped>
@import "~@styles/variable.less";
.auth-wrap{
    overflow-x:hidden;
}

.main-container{
    max-width:1200px;
    margin:0 auto;
    overflow-x:hidden;

    .auth-container{
        .info-block-default;
        min-height:650px;
        position: relative;
        padding:0;
        background: #fff
    }
    
    .container-content{
        padding:40px 0;
        // text-align:center
    }
}
.auth-info-title{
    font-size:16px;
    padding: 30px 0;
}
</style>
<style lang="less">
@import "~@styles/variable.less";
.auth-wrap{
    .auth-tab-nav{
        justify-content: center;
        border-bottom:1px solid @color-border-button;
        background:#fff;
        .tab{
            height: 42px !important;
        }
        .active-tab-cursor{
            bottom: 0 !important;
        }

    }
}

</style>
