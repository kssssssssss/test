<!--
    @id        page-index-enterprise
    @desc      企业主页
    @level     page：页面组件
    @author    陈曦源 潘维
    @date      2019-11-05 10:06:41
-->
<template>
    <div class="main-container" v-loading="enterpriseInfoLoading" element-loading-text="加载中...">
        <div class="enterpirse-infos-block">
            <div class="enterpirse-infos-block-box">
                <div class="enterpiser-left">
                    <div class="enterprise-logo">
                        <img :src="enterpriseDefaultLogo" />
                    </div>
                    <div class="enterprise-infos">
                        <p class="enterprise-name">
                            <span class="enterprise-name-title">{{enterpriseName}}</span>
                            <authStatusEnterprise></authStatusEnterprise>
                            <!-- <span class="auth" v-if="enterpriseIddtvStatus !== 'SENIOR_PASSED' && enterpriseIddtvStatus !== 'SENIOR_NO_CERT' && enterpriseIddtvStatus !='WAITING' && enterpriseIddtvStatus !='WAITING_SUM' && enterpriseIddtvStatus !='WAITING_SUM_CHECK'" @click="enterpriseAuth">立即认证</span> -->
                            <!-- <span class="auth" v-if="enterpriseIddtvStatus !== 'SENIOR_PASSED' && enterpriseIddtvStatus !== 'SENIOR_NO_CERT' && (enterpriseIddtvStatus ==='WAITING' || enterpriseIddtvStatus ==='WAITING_SUM')" @click="enterpriseAuth">点击查看</span>
                            <span class="auth" v-if="enterpriseIddtvStatus !== 'SENIOR_PASSED' && enterpriseIddtvStatus !== 'SENIOR_NO_CERT' && enterpriseIddtvStatus ==='WAITING_SUM_CHECK'" @click="enterpriseAuth">点击确认</span> -->
                        </p>
                        <div class="user-name">
                            <span class="name">{{userName}}</span>
                            <span v-if="userEdition === 'e' && isAuthor" class="member-role">管理员</span>
                        </div>
                    </div>
                </div>
                <div class="enterpiser-right">
                    <div class="enterprise-info-block">
                        <p class="info-title">企业成员人数<span class="info-data">{{enterpriseData.nowMemberNumber}}</span></p>
                    </div>
                    <p class="charges-block">
                        剩余文档份数<a href="#" class="total-charges-box"><span class="total-charges">{{totalCharges}}</span><span class="purchase" @click="toPurchase">立即购买</span></a>
                    </p>
                </div>
            </div>
        </div>
        <div class="documents-info-container">
            <p class="wesign-info-title">签署统计</p>
            <div class="documents-infos-block">
                <div class="documents-status-info waiting-me-box" @click="jumpToEnvelopList('WAITING_ME')">
                    <div class="status-info">待我处理</div>
                    <div class="status-number waiting"><i class="icon wait icon-wating-me"></i><span>{{envelopNumOfWaitingMe}}</span></div>
                </div>
                <div class="documents-status-info waiting-others-box" @click="jumpToEnvelopList('WAITING_OTHERS')">
                    <div class="status-info">进行中</div>
                    <div class="status-number running"><i class="icon running icon-wating-other"></i><span>{{envelopNumOfWaitingOther}}</span></div>
                </div>
                <div class="documents-status-info complete-box" @click="jumpToEnvelopList('COMPLETE')">
                    <div class="status-info">已完成</div>
                    <div class="status-number complete"><i class="icon complete icon-real-name"></i><span>{{envelopNumOfComplete}}</span></div>
                </div>
                <div class="documents-status-info draft-box" @click="jumpToEnvelopList('DRAFT')">
                    <div class="status-info">草稿</div>
                    <div class="status-number draft"><i class="icon draft icon-drft"></i><span>{{envelopes.draft}}</span></div>
                </div>
            </div>
        </div>
        <div class="newsign-documents-info-container">
            <p class="wesign-info-title">最新签署文件</p>
            <div class="documents-list-block">
                <el-table :data="signDocuemnts" class="wesign-el-table" header-row-class-name="wesign-table-header" row-class-name="wesign-table-row"
                    :row-style="{cursor:'pointer'}" max-height="450"
                     @row-click="jumpToEnvelopeDetail"
                     tooltip-effect="light">
                    <el-table-column label="文件名" :show-overflow-tooltip="true" prop="title"></el-table-column>
                     <el-table-column label="发起人" :show-overflow-tooltip="true" prop="sender.username"></el-table-column>
                    <el-table-column label="时间">
                        <template slot-scope="scope">
                            {{ translateTime(scope.row.statusDatetime) }}
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <!--<div class="dynamic-info-container">
            <p class="wesign-info-title">最新动态</p>
            <div class="dynamic-list-block">
                <el-table :data="signDocuemnts" header-row-class-name="wesign-table-header" row-class-name="wesign-table-row" max-height="450">
                    <el-table-column label="发起人" prop="ducumentName"></el-table-column>
                    <el-table-column label="动态" prop="agentName"></el-table-column>
                    <el-table-column label="时间" prop="time"></el-table-column>
                </el-table>
            </div>
        </div>-->
    </div>
</template>

<script>
import { newFormatDate } from "@commons/util.js"
import enterpriseDefaultLogo from "@images/enterprise-logo-default.png"
import { getEnvelopesCount } from "@interfaces/envelopes/count.js"
import { getEneterpriseMember } from "@interfaces/enterprise/enterprise.js"
import { getEnvelopes } from "@interfaces/envelopes/index.js"
import { authFlow } from "@interfaces/openapi/enterprise-authentication.js"


import authStatusEnterprise from "@components/auth/auth-status-enterpise.vue"

export default {
    data(){
        return {
            enterpriseDefaultLogo: enterpriseDefaultLogo,
            enterpriseData: {
                nowMemberNumber: 1,
                maxMemberNumber: 1,
                nowUsefulDocumentNumber: 100,
                allDocumentMemberNumber: 201,
            },
            envelopes: {
                draft: 0,
                waitingForSend: 0,
                hangUp: 0,
                hangUpConfirm: 0,
                delivering: 0,
                waitingMeSign: 0,
                waitingMeCheck: 0,
                processingAfterMeCommit: 0,
                waitingOthersHandle: 0,
                waitingMeCorrect: 0,
                waitingOthersCorrect: 0,
                processingAfterAllCommit: 0,
                successCompleted: 0,
                invalidate: 0,
                reject: 0,
                notPassCheck: 0,
                revoke: 0,
                timeout: 0,
                discard: 0,
                all: 0,
                deletedToRecycle: 0
            },
            itemLimit: 5,
            signDocuemnts: [],
            memberRole: "",
            enterpriseInfoLoading: false,
            statusCodes: ["WAITING_ME_SIGN", "WAITING_ME_CHECK","WAITING_OTHERS_HANDLE", "DELIVERING", "PROCESSING_AFTER_ME_COMMIT", "PROCESSING_AFTER_ALL_COMMIT","SUCCESS_COMPLETED", "INVALIDATE","REJECT", "NOT_PASS_CHECK", "REVOKE","ED_FAIL_EXPIRED"]
        }
    },
    computed: {
        memberNumberProgressStyle(){
            let enterpriseData = this.$data.enterpriseData
            return {
                width: enterpriseData.nowMemberNumber / enterpriseData.maxMemberNumber * 100 + "%"
            }
        },
        documentNumberProgressStyle(){
            let enterpriseData = this.$data.enterpriseData
            return {
                width: enterpriseData.nowUsefulDocumentNumber / enterpriseData.allDocumentMemberNumber * 100 + "%"
            }
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        enterpriseName(){
            return this.$store.getters.enterpriseName
        },
        enterpriseIddtvStatus(){
            return this.$store.getters.enterpriseIddtvStatus
        },
        envelopNumOfWaitingMe(){
            return this.envelopes.waitingMeSign 
                + this.envelopes.waitingMeCheck
        },
        envelopNumOfWaitingOther(){
            return this.envelopes.waitingOthersHandle 
                + this.envelopes.delivering
                + this.envelopes.processingAfterMeCommit
                + this.envelopes.processingAfterAllCommit
        },
        envelopNumOfComplete(){
            return this.envelopes.successCompleted 
                + this.envelopes.invalidate
        },
        totalCharges(){
            return this.$store.state.charges.totalCharges
        },
        userName(){
            return this.$store.getters.userName
        },
        memberWsid(){
            return this.$store.getters.memberWsid
        },
        userWsid(){ 
            return this.$store.getters.userWsid
        },
        enterpriseAuthorWsid(){ //企业拥有者id
            return (this.$store.getters.enterpriseAuthorWsid)
        },
        isAuthor(){
            if (this.enterpriseAuthorWsid === this.userWsid){
                return true
            } else {
                return false
            }
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
    },
    watch: {
        enterpriseWsid(nv){
            if (nv){
                getEneterpriseMember({
                    enterpriseWsid: nv
                }).then(res => {
                    let count = res.data.data.page.totalElements
                    this.enterpriseData.nowMemberNumber = count
                    this.enterpriseData.maxMemberNumber = count
                })
                this.envelopesCount()
                this.envelopesList()
            }
        },
    },
    created(){
        let enterpriseWsid = this.$store.getters.enterpriseWsid
        this.envelopesCount()
        this.envelopesList()
        if (this.enterpriseWsid){
            getEneterpriseMember({
                enterpriseWsid: this.enterpriseWsid
            }).then(res => {
                let count = res.data.data.page.totalElements
                this.enterpriseData.nowMemberNumber = count
                this.enterpriseData.maxMemberNumber = count
            })
        }
    },
    methods: {
        enterpriseAuth(){
            authFlow({
                returnUrl:`${location.origin}/wesign`
            }).then(res =>{
                let actionUrl = res.data.data.actionUrl
                location.href = actionUrl
            }).catch(err=>{
                if (err.response){
                    let code = err.response.data.code
                    if (code === 101){
                        this.$alert("该企业已认证通过，请勿重复操作", "提示", {
                            confirmButtonText: "知道了",
                            type: "success",
                            callback: action => {
                                this.$store.dispatch("updateModule")
                            },
                        })
                    }else if(code === 102){
                        let developerMessage = err.response.data.data.msg
                        let erorInfo 
                        if(developerMessage.indexOf("该企业已经注册认证") != -1){
                            erorInfo = `若是本人，请检查自己账号下是否已有该企业。若非本人，请联系相关企业人员加入该企业。若仍然存在问题，请联系人工客服021-962600。`
                        } else {
                            erorInfo =""
                        }
                        this.$alert(`<p>${developerMessage}${erorInfo}</p>`, "提示", {
                            confirmButtonText: "知道了",
                            dangerouslyUseHTMLString: true,
                            type: "warning",
                        }).then(() => {}, () => {})
                    }
                } else {
                    this.$message.error("网络开小差了，请检查您的网络是否正或刷新页面重试")
                }
            })
        },
        envelopesCount(){
            this.enterpriseInfoLoading = true
            let authorWsid = this.$store.getters.activeUserWsid
            getEnvelopesCount({
                authorWsid
            }).then(body => {
                this.enterpriseInfoLoading = false
                this.envelopes = body.data.data.envelops
            }).catch(err => {
                this.$message.error("统计文件个数失败")
                this.enterpriseInfoLoading = false
            })
        },
        envelopesList(){
            let authorWsid = this.$store.getters.activeUserWsid
            let envelopeShownStatus = this.statusCodes.join(",")
            getEnvelopes({
                authorWsid: authorWsid,
                limit: this.itemLimit,
                envelopeShownStatus,
                filters: `currentSequence>=assignedSequence`,
            }).then(body => {
                let data = body.data.data.envelopes
                this.signDocuemnts = data
                this.signDocuemnts.forEach(element => {
                    let nameArray = element.sender.username.split(",")
                    if (nameArray.length > 1){
                        element.sender.username = nameArray[0] + " (" + nameArray[1] + ")"
                    }
                })
            }).catch(err => {
                this.$message.error("获取最新动态文件失败")
            })
        },
        translateTime(time){
            return newFormatDate(time, "HH:mm")
        },
        jumpToEnvelopList(type){
            let status
            switch (type) {
                case "WAITING_ME":
                    status = 1
                    break
                case "WAITING_OTHERS":
                    status = 2
                    break
                case "COMPLETE":
                    status = 3
                    break
                case "DRAFT":
                    status = 5
                    break
            }

            this.$router.push({
                name: "envelopes",
                query: {
                    status
                }
            })
        },
        jumpToEnvelopeDetail(row){
            let path = this.$route.path
            this.$store.dispatch("updatePathData", path)
            this.$router.push({
                name: "envelope-detail",
                params: {
                    envelopeId: row.envelopeWsid 
                }
            })
        },
        toPurchase(){
            this.$router.push({
                name: "enterprise-purchase"
            })
        }
    },
    components: {
        authStatusEnterprise
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";

@sign-top: 0;
@sign-top-sm:80px;
@sign-top-xs:100px;

@logo-img-padding-left: 0px;
@logo-img-padding-left-sm: 50px;
@logo-img-padding-left-xs: 20px;

.main-container{
    padding: 0 !important;
}

.container-block(){
    margin: 10px;
    flex: 1;
    min-width: 40%;
}

.enterpirse-infos-block{
    .info-block-default;
    border-radius:0;
    box-shadow: rgba(0, 0, 0, 0.06) 0px 0px 20px 1px;
    z-index:9;
    padding:0 20px;

    .enterpirse-infos-block-box{
        padding:10px 20px;
        min-height:80px;
        display: flex;
        flex-wrap: wrap;
        align-items:center;
        border-top:1px solid @color-border-button;
        
        .enterpiser-left{
            overflow: hidden;
            display: flex;
            flex-wrap: wrap;
            align-items:center;
            flex:1;
            min-width: 300px;

            .enterprise-logo{
                width: 80px;
                height: 80px;
                transform: 0 20px;
                img{
                    width: 100%;
                    transform: translate(0,-10px);
                    padding-left: @logo-img-padding-left;
                        .sm-devices({
                            padding-left: @logo-img-padding-left-xs;
                        });
                        .xs-devices({
                            padding-left: @logo-img-padding-left-xs;
                        });
                        .md-devices({
                            padding-left: @logo-img-padding-left-xs;
                        });
                        .lg-devices({
                            padding-left: @logo-img-padding-left;
                        });
                }
            }
        
            .enterprise-infos{
                flex: 1;
                margin-left: 30px;
                overflow: hidden;
                
                .enterprise-name{
                    margin: 0;
                    font-size: @font-size-primary;

                    .enterprise-name-title{
                        font-weight:bold;
                    }

                    a{
                        font-size: @font-size-regular;
                        color:@color-main
                    }
                }

                .user-name{
                    display: flex;
                    height: 60px;
                    line-height: 60px;
                    display: flex;
                    align-items: center;
                    font-size:@font-size-primary;

                    .name{
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                    }

                    .member-role{
                        margin-left:10px;
                        padding: 3px 5px;
                        display:inline-block;
                        color:@color-main;
                        font-size: @font-size-info;
                        line-height:18px;
                        border-radius:5px;
                        border:1px solid @color-main;
                        min-width: 40px;
                        text-align: center;
                    }
                }
            }   
        }

        .enterpiser-right{
            flex:1;
            display: flex;
            flex-wrap: wrap;
            align-items:center;

            .info-title{
                font-size:@font-size-primary;
            }

            .enterprise-info-block{
                flex:1;
                text-align:center;
                border-right:1px solid @color-border-button;

                .info-data{
                    position: relative;
                    line-height:60px;
                    height:60px;
                    display:block;
                }
            }

            .charges-block{
                flex:1;
                text-align:center;
                font-size:@font-size-primary;
                width: 300px;
                .total-charges-box{
                    display:block;
                    height:60px;
                    line-height:60px;
                }

                .purchase{
                    cursor: pointer;
                    margin-left: 10px;
                    color: @color-main;
                    font-size:@font-size-primary;

                    &:hover{
                        text-decoration: underline;
                    }
                }
            }
        }
    }
}

.documents-info-container{
    padding: 0 40px;

    .documents-infos-block{
        display: flex;
        flex-wrap:wrap;
        align-items:center;
        justify-content: space-between;

        .waiting-me-box,.waiting-others-box,.complete-box,.draft-box{
            display:flex;
            justify-content: center;
            flex-direction: column;
            background:@color-nav-background;
            min-width:260px;
            width:24%;
           .info-block-default;
        }

        .documents-status-info{
            cursor: pointer;
            margin-bottom: 25px;

            .status-number{
                font-size:@font-size-largger;
                margin: 15px 0;
                display:flex;
                align-items:center;
                flex-wrap: wrap;

                .icon{
                    width:50px;
                }

                span{
                    flex:1;
                    text-align:right;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                &.waiting {
                    color:@color-warning
                }

                &.running{
                    color:@color-main;
                }

                &.complete{
                    color:@color-success;
                }

                &.draft{
                    color:@color-info;
                }
            }

            .status-info{
                font-size:@font-size-primary;
            }
        }
    }
}

.newsign-documents-info-container{
    padding: 0 40px;

    .container-block;
    margin:0;
    margin-bottom:50px !important;
    p{  
        margin-top:0;
        margin-bottom:20px;
    }

    .documents-list-block{
        .info-block-default;
        padding: 0;
    }
}

 
@media screen and (max-width:1100px){
    .main-container{
        display:block;
    }
    
}
@media screen and (min-width:940px) and (max-width:1350px){
    .documents-status-info{
        width:48% !important;
        margin-left:0 !important;
    }
    
}
@media screen and (max-width:900px){
    .documents-status-info{
        width:100% !important;
        margin:0 0 20px 0 !important;
    }
}
.auth{
    font-size: 14px;
    color: @color-main;
}
</style>
