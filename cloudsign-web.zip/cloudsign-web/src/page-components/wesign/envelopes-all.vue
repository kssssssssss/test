<!--
    @id        page-envelopes
    @desc      信封列表页面
    @level     page 
    @author    陈曦源 潘维
    @date      2019-04-18 15:45:20
-->
<template>
    <div>
        <div>
            <!--<span class="info-title">文件</span>-->
        </div>
        <div class="envelopes-container">
            <div class="envelopes-container-content">
                <div class="envelopes-list-title-box">
                    <span v-if="bulkDownloadBtn">已选 ({{checkedEenvelope}})&nbsp;&nbsp;</span>
                    <span v-else> {{statusesName}} ({{totalElements}})</span>
                </div>
                <div class="envelopes-container-tab-box">
                    <Tab class="envelopes-container-tab" :tabs="statusTabs" :activeTab="activeStatusIndex" :checkedEenvelopes="checkedEenvelopes" @active-tab="chooseStatus"></Tab>
                    <div class="search-box">
                        <el-input class="search"
                            placeholder="按主题进行搜索"
                            size="medium"
                            v-model.trim="advancedSearchConditions.title" @blur="advancedSearch" @keyup.enter.native="advancedSearch">
                            <el-button slot="append" icon="el-icon-search" @click="advancedSearch"></el-button>
                        </el-input>
                        <el-popover
                            ref="advanced-search"
                            placement="left"
                            width="350"
                            popper-class="wesign-envelopes-advanced-search-popper-class"
                            trigger="click">
                            <div class="popper-title">
                                检索条件
                                <i class="btn-close el-icon-close" @click="closeAdvancedSearchPopper"></i>
                            </div>
                            <el-row class="search-condition">
                                <el-col class="condition-key" :span="6">主题：</el-col>
                                <el-col :span="18">
                                    <el-input v-model.trim="advancedSearchConditions.title" size="mini" placeholder="请输入搜索主题"></el-input>
                                </el-col>
                            </el-row>
                            <el-row class="search-condition">
                                <el-col class="condition-key" :span="6">发起人：</el-col>
                                <el-col :span="18">
                                    <el-input v-model.trim="advancedSearchConditions.sendername" size="mini" placeholder="请输入发起人或发起单位名称"></el-input>
                                </el-col>
                            </el-row>
                            <el-row v-if="statusesName !== '草稿'" class="search-condition">
                                <el-col class="condition-key" :span="6">签约人：</el-col>
                                <el-col :span="18">
                                    <el-input v-model.trim="participantName" size="mini" placeholder="请输入签约人或签约单位名称"></el-input>
                                </el-col>
                            </el-row>
                            <el-row class="search-condition">
                                <el-col class="condition-key" v-if="statusesName !== '草稿'" :span="6">发起时间：</el-col>
                                <el-col class="condition-key" v-else :span="6">创建时间：</el-col>
                                <el-col :span="18">
                                    <el-date-picker
                                        :value="advancedSearchConditions.timerange"
                                        size="mini"
                                        ref="sendDate"
                                        style="width:100%;"
                                        type="daterange"
                                        start-placeholder="开始日期"
                                        end-placeholder="结束日期"
                                        @input="changeSendDate"
                                        :default-value="Date.now()">
                                    </el-date-picker>
                                </el-col>
                            </el-row>
                            <el-row v-if="statusesName === '所有文件' || statusesName === '已完成' || statusesName === '其他'" class="search-condition">
                                <el-col class="condition-key" :span="6">完成时间：</el-col>
                                <el-col :span="18">
                                    <el-date-picker
                                        :value="advancedSearchConditions.finishedtimerange"
                                        size="mini"
                                        style="width:100%;"
                                        ref="finishedDate"
                                        type="daterange"
                                        start-placeholder="开始日期"
                                        end-placeholder="结束日期"
                                        @input="changeFinishedDate"
                                        :default-value="Date.now()">
                                    </el-date-picker>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col class="condition-key" :span="6">&nbsp;</el-col>
                                <el-col :span="18">
                                    <el-button size="small"  type="default" plain @click="clearAdvancedSearchCondition">清空</el-button>
                                    <el-button size="small" type="primary" @click="advancedSearch">搜索</el-button>
                                </el-col>
                            </el-row>
                        </el-popover>
                        <div  v-popover:advanced-search class="envelopes-advanced-search">
                            高级检索<img class="envelopes-filter" :src="EnvelopesFilter"/>
                        </div>
                    </div>
                </div>
                <envelopesList class="envelopes-container-list" ref="envelopes" :envelopes="envelopes" :loading="envelopesLoading" :enterpriseAll="true" 
                    @delete="deleteEnvelope" @preview="previewEnvelope"
                    @revoke="revokeEnvelope" @reject="rejectEnvelope"
                    @notpass="notpassEnvelope"
                    @transfer ="transferEnvelope"
                    @cancel="cancelEnvelope"></envelopesList>
            </div>
        </div>
        <div class="pagination-container">
            <el-pagination background :page-count="totalPages" :current-page="currentPage" @current-change="selectPage" layout="prev, pager, next, jumper, ->, total"></el-pagination>
        </div>
        <rejectDialog ref="rejectDialog"></rejectDialog>
        <revokeDialog ref="revokeDialog"></revokeDialog>
        <checkNotpassDialog ref="checkNotpassDialog"></checkNotpassDialog>
        <transferMember ref="transferMember" @inviteMembe="inviteMembe"></transferMember>
        <el-dialog width="600px" v-if="isdialogVisible" :visible.sync="isdialogVisible"                                                                                                 >
            <div class="dialog-content">
                <addMember @close="closeModal"></addMember>
            </div>
        </el-dialog>
        <cancellationDialog ref="cancellationDialog" :title="envelopeTitle" @successTitle="successTitle"></cancellationDialog>
    </div>
</template>

<script>
import { getEnterpriseAllEnvelopes, recycledEnvelope } from "@interfaces/envelopes/index.js"
import { cancelProcess,createCancelAnnounceTemplete } from "@interfaces/envelopes/cancellation.js"
import Tab from "@components/commons/tabs/tab-default.vue"
import envelopesList from "@components/envelopes/envelopes-list.vue"
import EnvelopesFilter from "@images/envelopes/filter.svg"
import {downLoadEnvelopes} from "@interfaces/envelopes/envelopes-download.js"
import rejectDialog from "@components/envelopes/dialogs/reject-dialog.vue"
import revokeDialog from "@components/envelopes/dialogs/revoke-dialog.vue"
import checkNotpassDialog from "@components/envelopes/dialogs/check-notpass-dialog.vue"
import transferMember from "@components/dialogs/transfer-member.vue"
import addMember from "@components/dialogs/members.vue"
import cancellationDialog from "@components/envelopes/dialogs/cancellation-dialog.vue"

const STORE_KEY_QUERY = "envelopes-query-all"

export default {
    data(){
        return {
            envelopes: [],
            activeName: "",
            activeStatusIndex: -1,
            statuses: [                       
                {name: "所有文件", statusCodes: ["WAITING_JOIN_ENTERPRISE", "WAITING_ME_SIGN", "WAITING_ME_CHECK", "WAITING_OTHERS_HANDLE,DELIVERING", "PROCESSING_AFTER_ME_COMMIT", "PROCESSING_AFTER_ALL_COMMIT", "SUCCESS_COMPLETED", "INVALIDATE", "REJECT", "NOT_PASS_CHECK", "REVOKE", "ED_FAIL_EXPIRED"]},
                {name: "进行中", statusCodes: ["WAITING_ME_SIGN", "WAITING_ME_CHECK", "WAITING_OTHERS_HANDLE","DELIVERING","PROCESSING_AFTER_ME_COMMIT", "WAITING_JOIN_ENTERPRISE"]},
                {name: "已完成", statusCodes: ["SUCCESS_COMPLETED"]},
                {name: "其他", statusCodes: ["REJECT", "NOT_PASS_CHECK", "REVOKE","ED_FAIL_EXPIRED","INVALIDATE"]},
            ],
            currentPage: -1,
            totalPages: 20,
            totalElements: 0,
            itemLimit: 20, //每页文档数量限制

            pickerOptions: {
                shortcuts: [
                    {
                        text: "最近一周",
                        onClick(picker) {
                            const end = new Date()
                            const start = new Date()
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
                            picker.$emit("pick", [start, end])
                        }
                    },
                    {
                        text: "最近一个月",
                        onClick(picker) {
                            const end = new Date()
                            const start = new Date()
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
                            picker.$emit("pick", [start, end])
                        }
                    }, 
                    {
                        text: "最近三个月",
                        onClick(picker) {
                            const end = new Date()
                            const start = new Date()
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
                            picker.$emit("pick", [start, end])
                        }
                    }
                ]
            },

            //高级搜索的条件
            advancedSearchConditions: {
                sendername: "",
                title: "",
                // recipentname: "",
                timerange: [],
                finishedtimerange:[]
            },
            // title: "",
            envelopesLoading: false, //是否正在加载文件数据
            bulkDownloadBtn: false,
            checkedEenvelope: "",

            EnvelopesFilter: EnvelopesFilter,
            showSearchBox: false,
            participantName:"",
            isdialogVisible:false,
            envelopeTitle:""
        }
    },
    computed: {
        activeUserWsid(){
            return this.$store.getters.activeUserWsid
        },
        statusTabs(){
            return this.statuses.map(s => s.name)
        },
        enterpriseWsid(){
            return this.$store.getters.enterpriseWsid
        },
        checkedEenvelopes(){ 
            return this.envelopes.filter(data => data.checked)
        },
        checkedEenvelopesWsid(){
            return this.checkedEenvelopes.map(e => e.envelopeWsid)
        },
        checkedTitle(){
            return this.checkedEenvelopes.map(e => e.title)
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
        statusesName(){
            return this.statusTabs[this.activeStatusIndex] || "全部文件"
        }
    },
    watch: {
        enterpriseWsid(nv){
            if (nv){
                let query = this.getURLQuery()
                if (!("page" in query) && !("status" in query)){
                    try {
                        let storeQuery = JSON.parse(sessionStorage.getItem(STORE_KEY_QUERY))
                        if (storeQuery) query = storeQuery
                    } catch (e) {}
                }
                this.updateQuery(query)
            }
        },
        userEdition(nv){
            if (nv == "p"){
                let query = this.getURLQuery()
                if (!("page" in query) && !("status" in query)){
                    try {
                        let storeQuery = JSON.parse(sessionStorage.getItem(STORE_KEY_QUERY))
                        if (storeQuery) query = storeQuery
                    } catch (e) {}
                }
                // this.updateQuery(query)
            }
        },
        checkedEenvelopes( newval, oldval){
            if (newval.length >= 1){
                this.bulkDownloadBtn = true
                this.checkedEenvelope = newval.length
            } else {
                this.bulkDownloadBtn = false
            }
        },
    },
    created(){
        let query = this.getURLQuery()
        if (!("page" in query) && !("status" in query)){
            try {
                let storeQuery = JSON.parse(sessionStorage.getItem(STORE_KEY_QUERY))
                if (storeQuery) query = storeQuery
            } catch (e) {}
        }
        //当从文件列表"我的" 切换到 “全部”时 对于没有的状态处理
        if ("status" in query){
            if (query.status > (this.statuses.length - 1)){
                query.status = 0
            }
        }
        this.updateQuery(query)
    },
    methods: {
        showSearch(){
            this.showSearchBox = !this.showSearchBox
        },
        clickBulkDownload(loadType, checkedEenvelope){
            if (checkedEenvelope > 1){
                this.$confirm("您将批量下载文件", "提示", {
                    confirmButtonText: "下载",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(() => {
                    return downLoadEnvelopes({
                        envelopes: this.checkedEenvelopesWsid,
                        withAudit: loadType
                    }).then(_ => {
                        this.$message.success("获取文件成功，正在下载")
                        this.envelopes.forEach(e => {
                            e.checked = false
                        })
                        this.bulkDownloadBtn = false
                    }).catch(err => {
                        this.$message.error("获取文件失败")
                    })
                }, () => {})
            } else {
                this.$confirm(`您确定下载文件《${this.checkedTitle}》?`, "提示", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(() => {
                    return downLoadEnvelopes({
                        envelopes: this.checkedEenvelopesWsid,
                        withAudit: loadType
                    }).then(_ => {
                        this.$message.success("获取文件成功，正在下载")
                        this.envelopes.forEach(e => {
                            e.checked = false
                        })
                        this.bulkDownloadBtn = false
                    }).catch(err => {
                        this.$message.error("获取文件失败")
                    })
                }, () => {})
            }
        },
        setTimeToStart(time){ //设置开始时间
            let date = new Date(time)
            date.setHours(0)
            date.setMinutes(0)
            date.setSeconds(0)
            date.setMilliseconds(0)
            return date.getTime()
        },
        setTimeToEnd(time){
            let date = new Date(time)
            date.setHours(23)
            date.setMinutes(59)
            date.setSeconds(59)
            date.setMilliseconds(999)
            return date.getTime()
        },
        getEnvelopesData(query = this.getURLQuery()){
            let {
                page = 1,
                status = 0
            } = query

            let filters = []
            //FIXME: 后台暂时不支持模糊查询
            if (query.sendername) filters.push(`senderName=${query.sendername}`)
            // if (query.participantName) filters.push(`participantName=${query.participantName}`)
            if (query.title) filters.push(`title=${query.title}`)
            if(this.statusesName === '草稿'){
                if (query.timerangefrom) filters.push(`createdDatetime>${Math.floor(this.setTimeToStart(query.timerangefrom) / 1000)}`)
                if (query.timerangeto) filters.push(`createdDatetime<${Math.floor(this.setTimeToEnd(query.timerangeto) / 1000)}`)
            } else {
                if (query.timerangefrom) filters.push(`sendDatetime>${Math.floor(this.setTimeToStart(query.timerangefrom) / 1000)}`)
                if (query.timerangeto) filters.push(`sendDatetime<${Math.floor(this.setTimeToEnd(query.timerangeto) / 1000)}`)
            }
            
            if (query.finishedtimerangefrom) filters.push(`finishedDatetime>${Math.floor(this.setTimeToStart(query.finishedtimerangefrom) / 1000)}`)
            if (query.finishedtimerangeto) filters.push(`finishedDatetime<${Math.floor(this.setTimeToEnd(query.finishedtimerangeto) / 1000)}`)
            filters.push(`currentSequence>=assignedSequence`)
            filters = filters.join(",")
            if (!filters) filters = undefined

            let enterpriseWsid = this.enterpriseWsid
            let statusData = this.statuses[status]
            let envelopeShownStatus = statusData.statusCodes.join(",")
            if (this.envelopesLoading) {
                this.envelopesLoadingHandle.cancel()
            } else {
                this.envelopesLoading = true
            }
            this.envelopesLoadingHandle = getEnterpriseAllEnvelopes({
                enterpriseWsid,
                envelopeShownStatus,
                participantName:this.participantName,
                offset: (page - 1) * this.itemLimit,
                limit: this.itemLimit,
                filters
            })

            this.envelopesLoadingHandle.then(res => {
                let body = res.data
                body.data.envelopes.forEach(_ => _.checked = false)
                if (body.data.envelopes.length === 0 && page > 1){
                    this.selectPage(1)
                    return
                }

                this.envelopes = body.data.envelopes
                this.totalPages = body.data.page.totalPages
                this.currentPage = page
                this.totalElements = body.data.page.totalElements
                this.envelopesLoading = false
            }).catch(err => {
                if (!err.isCancel) {
                    if (page > 1){
                        this.selectPage(1)
                    } else {
                        this.envelopesLoading = false
                        this.$message.error("获取文件列表失败")
                    }
                }
            })
        },
        selectPage(page){
            let oldQuery = this.getURLQuery()
            let query = {}
            Object.assign(query, oldQuery, {
                page: page
            })
            this.updateQuery(query)
        },
        chooseStatus(index){
            this.activeStatusIndex = index
            this.updateQuery({
                status: index,
                page: 1
            })
        },
        getURLQuery(){
            let query = this.$route.query
            if (query.status) query.status = parseInt(query.status) || 0
            if (query.page) query.page = parseInt(query.page) || 1
            if (query.timerangefrom) query.timerangefrom = parseInt(query.timerangefrom) || 0
            if (query.timerangeto) query.timerangeto = parseInt(query.timerangeto) || 24 * 60 * 60 * 1000
            if (query.finishedtimerangefrom) query.finishedtimerangefrom = parseInt(query.finishedtimerangefrom) || 0
            if (query.finishedtimerangeto) query.finishedtimerangeto = parseInt(query.finishedtimerangeto) || 24 * 60 * 60 * 1000
            return query
        },
        updateQuery(query){
            if (query.status){
                this.activeStatusIndex = query.status
            } else {
                this.activeStatusIndex = 0
            }
            
            if (query.page){
                this.currentPage = query.page
            } else {
                this.currentPage = 1
            }

            let advance = this.advancedSearchConditions
            if (query.sendername) advance.sendername = query.sendername
            if (query.recipentname) advance.recipentname = query.recipentname
            if (query.participantName) this.participantName = query.participantName
            if (query.title) advance.title = query.title

            let timerange = []
            if ("timerangefrom" in query && "timerangeto" in query) advance.timerange = [new Date(query.timerangefrom), new Date(query.timerangeto)]
            else advance.timerange = []
            let finishedtimerange = []
            if ("finishedtimerangefrom" in query && "finishedtimerangeto" in query) advance.finishedtimerange = [new Date(query.finishedtimerangefrom), new Date(query.finishedtimerangeto)]
            else advance.finishedtimerange = []
            this.getEnvelopesData(query)
            sessionStorage.setItem(STORE_KEY_QUERY, JSON.stringify(query))
            this.$router.replace({
                path: "/envelopes/all",
                query
            })
        },
        changeFinishedDate(value){
            if(value === null){
                this.advancedSearchConditions = {
                    finishedtimerange: [],
                }

                let oldQuery = this.getURLQuery()
                let query
                if(oldQuery.timerangefrom){
                    query = {
                        page: 1,
                        status: oldQuery.status || 0,
                        timerangefrom:oldQuery.timerangefrom,
                        timerangeto:oldQuery.timerangefrom,
                    }
                } else {
                    query = {
                        page: 1,
                        status: oldQuery.status || 0,
                    }
                }
                this.updateQuery(query)
            } else {
                this.advancedSearchConditions.finishedtimerange=value
            }
            this.$forceUpdate()
        },
        changeSendDate(value){
            if(value === null){
                this.advancedSearchConditions = {
                    timerange: [],
                }
                let oldQuery = this.getURLQuery()
                let query 
                if(oldQuery.finishedtimerangefrom){
                    query = {
                        page: 1,
                        status: oldQuery.status || 0,
                        finishedtimerangefrom:oldQuery.finishedtimerangefrom,
                        finishedtimerangeto:oldQuery.finishedtimerangefrom,
                    }
                } else {
                    query = {
                        page: 1,
                        status: oldQuery.status || 0,
                    }
                }
                this.updateQuery(query)
            } else {
                this.advancedSearchConditions.timerange = value
            }
            this.$forceUpdate()
        },
        advancedSearch(){
            let query = {
                page: 1,
                title: "",
                sendername:"",
                participantName: ""
            }
            let advanced = this.advancedSearchConditions
            if (advanced.sendername) query.sendername = advanced.sendername
            if (advanced.recipentname) query.recipentname = advanced.recipentname
            if (this.participantName) query.participantName = this.participantName
            if (advanced.title) query.title = advanced.title
            // if (this.title) query.title = this.title

            if (advanced.timerange){
                if (advanced.timerange[0] instanceof Date) query.timerangefrom = advanced.timerange[0].getTime()
                if (advanced.timerange[1] instanceof Date) query.timerangeto = advanced.timerange[1].getTime()
            }

            if (advanced.finishedtimerange){
                if (advanced.finishedtimerange[0] instanceof Date) query.finishedtimerangefrom = advanced.finishedtimerange[0].getTime()
                if (advanced.finishedtimerange[1] instanceof Date) query.finishedtimerangeto = advanced.finishedtimerange[1].getTime()
            }
            this.updateQuery(Object.assign({}, this.getURLQuery(), query))
            this.closeAdvancedSearchPopper()
        },
        clearAdvancedSearchCondition(){
            this.advancedSearchConditions = {
                sendername: "",
                title: "",
                timerange: [],
                finishedtimerange:[]
            }
            this.participantName = ""
            let oldQuery = this.getURLQuery()
            let query = {
                page: 1,
                status: oldQuery.status || 0
            }
            this.updateQuery(query)
        },
        closeAdvancedSearchPopper(){
            document.body.click()
        },
        deleteEnvelope(envelopeWsid){
            this.$confirm("您确认要删除该文件吗？删除后将无法恢复！", "删除文件", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                return recycledEnvelope({
                    envelopeWsid: envelopeWsid
                }).then(res => {
                    this.$message.success("文件删除成功")
                    let query = this.getURLQuery()
                    if (query.page && query.page === this.totalPages && this.envelopes.length === 1 && query.page > 1){ //删除最后一页的最后一个
                        this.currentPage = parseInt(query.page) - 1
                        this.updateQuery({
                            status: query.status,
                            page: this.currentPage
                        })
                    } else {
                        this.getEnvelopesData(query)
                    }
                }).catch(err => {
                    console.error(err)
                    this.$message.error("文件删除失败")
                })
            }).catch(() => {})
        },
        previewEnvelope(envelopeWsid){
            let path = this.$route.fullPath
            this.$store.dispatch("updatePathData", path)
            this.$router.push({
                name: "envelope-preview",
                params: {
                    envelopeId: envelopeWsid
                }
            })
        },
        revokeEnvelope(envelopeWsid){
            this.$refs.revokeDialog.revoke(envelopeWsid).then(_ => {
                this.getEnvelopesData()
            }).catch(() => {})
        },
        rejectEnvelope(envelopeWsid){
            this.$refs.rejectDialog.reject(envelopeWsid).then(_ => {
                this.getEnvelopesData()
            }).catch(() => {})
        },
        notpassEnvelope(envelopeWsid){
            this.$refs.checkNotpassDialog.notpass(envelopeWsid).then(_ => {
                this.getEnvelopesData()
            }).catch(() => {})
        },
        transferEnvelope(envelopeWsid){
            this.$refs.transferMember.transgerMember(envelopeWsid).then(_ => {
                this.getEnvelopesData()
            }).catch(() => {})
        },
        inviteMembe(){
            this.isdialogVisible = true
        },
        closeModal(){
            this.isdialogVisible = false
        },
        createTemplete(envelopeWsid){
            return createCancelAnnounceTemplete({
                envelopeWsid:envelopeWsid
            }).then(res =>{
                let fileWsid = res.data.data.fileWsid
                this.fileWsid = fileWsid
            }).catch(err=>{
                console.error(err)
            })
        },
        successTitle(fileName){
            this.envelopeTitle = fileName
        },
        async cancelEnvelope(envelopeWsid,envelopeTitle){
            this.envelopeTitle = envelopeTitle
            await this.createTemplete(envelopeWsid)
            let cancelAnnounceFile = []
            cancelAnnounceFile.push(this.fileWsid)
            cancelProcess({
                completedEnvelopeWsid:envelopeWsid,
                cancelAnnounceFile:cancelAnnounceFile
            }).then(res =>{
                let newEnvelopeWsid = res.data.data.envelope.wsid
                let contentsWsid = res.data.data.envelope.contents[0].wsid || ""
                this.$refs.cancellationDialog.cancel(newEnvelopeWsid, this.fileWsid, contentsWsid).then(_ => {
                    this.getEnvelopesData()
                }).catch(() => {})
            }).catch(err =>{
                if (err.response.data){
                    let code = err.response.data.code
                    if (code === 101){
                       this.$alert("该已经被作废，无法再次发起作废流程","提示") 
                    } else if(code === 103){
                        this.$alert("当前信封已经在作废流程中，无法再次发起作废流程","提示") 
                    } else if(code === 104){
                        this.$alert("当前信封已经在作废流程中，无法再次发起作废流程","提示")
                    }else if(code === 105){
                        this.$alert("启动作废流程失败","提示")
                    }
                } 
                console.error(err)
            })
        },
    },
    components: {
        envelopesList,
        rejectDialog,
        revokeDialog,
        checkNotpassDialog,
        Tab,
        transferMember,
        addMember,
        cancellationDialog
    }
}
</script>

<style lang="less" scoped>
@import "~@styles/variable.less";
.envelopes-info-title{
    margin: 15px 0;
    height: 55px;
    box-shadow: rgba(0, 0, 0, 0.06) 0 0 0.2rem 0.01rem;
    border-radius: 8px;
    background: #fafafa;
    padding: 0 25px;
    display: flex;
    align-items:center;
    position: relative;
    .info-title{
        font-size:16px;
        font-weight:bold;
    }
}
.envelopes-filter{
    width:15px;
    height:15px;
    margin-left:5px;
}
.envelopes-list-title-box{
    padding-top: 15px;
    padding-left: 20px;
    font-size: 16px;
}
.bulk-download{
    top:20px;
    margin-left: 10px;
}
.envelopes-container{
    position: absolute;
    left: 40px;
    right: 40px;
    top: 30px;
    bottom: 50px;

    .envelopes-container-content{
        .info-block-default;
        position: relative;
        padding: 0;
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    }

    .envelopes-container-list{
        position: absolute;
        top: 100px;
        left: 0;
        right: 0;
        bottom: 0;
    }
}

.envelopes-advanced-search{
    cursor: pointer;
    position: absolute;
    padding-top: 10px;
    top:50%;
    transform: translateY(-50%);
    width: 120px;
    color:#81878e;
    text-align: center;
    font-size:@font-size-info;
    right: 0;
    .md-devices({font-size:@font-size-regular;});
}

.pagination-container{
    position: absolute;
    left: 40px;
    right: 40px;
    bottom: 10px;
    text-align: center;
}

.search{
    display: none;
}
.wesign-envelopes-advanced-search-popper-class{
    width:300px;
    position:absolute;
    top:56px;
    right:200px;
    background: #fff;
    border-radius: 4px;
    border: 1px solid #e6ebf5;
    padding: 12px;
    z-index: 99;
    color: #81878e;
    line-height: 1.4;
    font-size: 14px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
    .popper-title{
        font-size: @font-size-primary;
        border-bottom: 1px solid @color-border-segment;
        margin-bottom: 10px;

        .btn-close{
            cursor: pointer;
            float: right;
            vertical-align: middle;
            font-size: @font-size-large;
        }
    }
    .el-date-editor .el-range__close-icon{
        position:absolute;
        top:0;
        right:0;
    }
    .search-condition{
        margin-bottom: 15px;

        .condition-key{
            line-height:25px;
        }
    }
}
.envelopes-container-tab-box{
    display:flex;
    align-items:center;
    .envelopes-container-tab{
        flex:1;
    }
     .search-box{
        width:100px;
        position:relative;
    }
}
</style>
<style lang="less">
.search-condition .el-input, .search-condition .el-range-editor.el-input__inner{
    max-width:300px;
}
.search-condition .el-range__close-icon{
    width:15px !important;
}
</style>