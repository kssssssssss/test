<!--
    @id        page-index-user
    @desc      个人主页
    @level     page：系统组件
    @author    周雪梅,陈曦源
    @date      2019-02-25 16:25:36
-->
<template>
     <div class="main-container" v-loading="envelopeUserInfoLoading">
        <div class="person-infos-block">
            <div class="person-infos-block-box">
                <div class="person-left">
                    <div class="person-logo">
                        <pictureUpload size="middle"></pictureUpload>
                    </div>
                    <div class="person-infos">
                        <p class="person-name">
                            {{userName}}
                            <authStatusPerson />
                        </p>
                        <p class="user-account">{{user.phone || user.email}}</p>
                    </div>
                </div>
                <div class="person-right">
                    <div class="person-right-info-block">
                        <div class="person-rigth-box">
                            <p class="person-rigth-box-title">我的签名</p>
                            <p class="placeholder">&nbsp;</p>
                        </div>
                        <div class="user-info-seal">
                            <template v-if="seal">
                                <div class="my-seal-block">
                                    <div><imgBox style="margin:0 auto" :width="70" :height="60" :src="this.seal.src"></imgBox></div>
                                    <p @click="sealDialogVisible = true"><a class="public-blue" @click="editAlertBox">&nbsp;&nbsp;&nbsp;重新设置</a></p>
                                </div>
                            </template>
                            <p v-else><span class="public-red">未设置&nbsp;&nbsp;&nbsp;</span><a class="public-blue" @click="editAlertBox">立即设置</a></p>
                        </div>
                    </div>
                    <p class="charges-block">
                        剩余文档份数<a href="#" class="total-charges-box"><span class="total-charges">{{totalCharges}}</span><span class="purchase" @click="toPurchase">立即购买</span></a>
                    </p>
                </div>
            </div>
        </div>
        <div class="documents-info-container">
            <p class="wesign-info-title">签署统计</p>
            <div class="documents-infos-block">
                <div class="documents-status-info waiting-me-box" @click="jumpToEnvelopList('WAITING_ME')">
                    <div class="status-info">待我处理</div>
                    <div class="status-number waiting"><i class="icon wait icon-wating-me"></i><span>{{envelopNumOfWaitingMe}}</span></div>
                </div>
                <div class="documents-status-info waiting-others-box" @click="jumpToEnvelopList('WAITING_OTHERS')">
                    <div class="status-info">进行中</div>
                    <div class="status-number running"><i class="icon running icon-wating-other"></i><span>{{envelopNumOfWaitingOther}}</span></div>
                </div>
                <div class="documents-status-info complete-box" @click="jumpToEnvelopList('COMPLETE')">
                    <div class="status-info">已完成</div>
                    <div class="status-number complete"><i class="icon complete icon-real-name"></i><span>{{envelopNumOfComplete}}</span></div>
                </div>
                <div class="documents-status-info draft-box" @click="jumpToEnvelopList('DRAFT')">
                    <div class="status-info">草稿</div>
                    <div class="status-number draft"><i class="icon draft icon-drft"></i><span>{{envelopes.draft}}</span></div>
                </div>
            </div>
        </div>
        <div class="newsign-documents-info-container">
            <p class="wesign-info-title">最新签署文件</p>
            <div class="documents-list-block">
                <el-table :data="envelopesNews" class="wesign-el-table" header-row-class-name="wesign-table-header" row-class-name="wesign-table-row" max-height="450" 
                    :row-style="{cursor:'pointer'}" @row-click="jumpToEnvelopeDetail"
                    tooltip-effect="light">
                    <el-table-column width="20"></el-table-column>
                    <el-table-column class="docment-title" label="文件名" :show-overflow-tooltip="true" prop="title">
                    </el-table-column>
                    <el-table-column label="发起人" :show-overflow-tooltip="true" prop="sender.username"></el-table-column>
                    <el-table-column label="时间">
                        <template slot-scope="scope">
                            {{ translateTime(scope.row.statusDatetime) }}
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <el-dialog title="创建签名" :visible.sync="sealDialogVisible" :close-on-click-modal="false" width="600px">
            <div class="scan-dialog" v-show="!link"> 
                <p v-if="userEdition === 'e'" class="notice-msg">注意：企业版个人签名会绑定企业信息</p>
                <p>扫描二维码后，在您的手机上签名！</p>
                <p>建议使用微信或者QQ中的扫一扫</p>  
                <div class="qr-code">
                    <img class="qrCode" :src="qrCode">
                </div>
                <el-button type="primary" plain @click="createRoom">重新获取二维码</el-button>
            </div>
            <div class="scan-dialog" v-show="link">
                <el-button type="primary" plain  @click="createRoom">重新获取二维码</el-button>
                <div class="img-area">
                <img class="signature-img" :src="imgData">
                </div>
                <div class="scan-info">
                    <p>单击“创建”，即表示您已同意该签章可用于签署您的各种文件</p>
                    <p>与手写签名或者盖章具有同等的法律效力</p>
                </div>
                <div class="btn-group">
                    <el-button class="cancel-btn" @click="cancel">取消</el-button>
                    <el-button :loading="uploading" class="confirm-btn" @click="uploadSeal">创建</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import uuidv4 from "uuid/v4"

import { newFormatDate, ImageDataToFile } from "@commons/util.js"

import {getEnvelopesCount} from "@interfaces/envelopes/count.js"
import { getEnvelopes } from "@interfaces/envelopes/index.js"
import authStatusPerson from "@components/auth/auth-status-person.vue"
import pictureUpload from "@components/modal/avatar-uploadable.vue"

import { 
    createRoom,
    closeRoom,
    createrExist,
    listenUpload,
    listenUploaderJoin,
    uploadSuccess
} from "@interfaces/web-socket/scan-upload.js"

import imgBox from "@components/commons/img-box.vue"
import { getPersonSeals,
    uploadPersonalSeals,
    deletePersonalSeal } from "@interfaces/seals/seals.js" 

import QRCode from "qrcode" 
export default {
    props: {
        linkurl: {
            type: String,
            default: "/scan-signature-pad"
        }
    },
    data(){
        return {
            envelopes: {
                draft: 0,
                waitingForSend: 0,
                hangUp: 0,
                hangUpConfirm: 0,
                delivering: 0,
                waitingMeSign: 0,
                waitingMeCheck: 0,
                processingAfterMeCommit: 0,
                waitingOthersHandle: 0,
                waitingMeCorrect: 0,
                waitingOthersCorrect: 0,
                processingAfterAllCommit: 0,
                successCompleted: 0,
                invalidate: 0,
                reject: 0,
                notPassCheck: 0,
                revoke: 0,
                timeout: 0,
                discard: 0,
                all: 0,
                deletedToRecycle: 0
            },
            itemLimit: 5,
            envelopesNews: [],

            sealDialogVisible: false,
            key: "",
            link: false,
            qrCode: "",
            imgData: "",
            seal: null,
            uploading: false,
            envelopeUserInfoLoading: false,
            statusCodes: ["WAITING_ME_SIGN", "WAITING_ME_CHECK","WAITING_OTHERS_HANDLE", "DELIVERING", "PROCESSING_AFTER_ME_COMMIT", "PROCESSING_AFTER_ALL_COMMIT","SUCCESS_COMPLETED", "INVALIDATE","REJECT", "NOT_PASS_CHECK", "REVOKE", "ED_FAIL_EXPIRED"]
        }
    },
    computed: {
        envelopNumOfWaitingMe(){
            return this.envelopes.waitingMeSign 
                + this.envelopes.waitingMeCheck
        },
        envelopNumOfWaitingOther(){
            return this.envelopes.waitingOthersHandle 
                + this.envelopes.delivering
                + this.envelopes.processingAfterMeCommit
                + this.envelopes.processingAfterAllCommit
        },
        envelopNumOfComplete(){
            return this.envelopes.successCompleted 
                + this.envelopes.invalidate
        },
        userName(){
            return this.$store.getters.userName
        },
        userWsid(){
            return this.$store.getters.activeUserWsid
        },
        user(){
            return this.$store.state.userdata
        },
        totalCharges(){
            return this.$store.state.charges.totalCharges
        },
        userEdition(){
            return this.$store.getters.userEdition
        },
    },
    created(){
        let authorWsid = this.$store.getters.userWsid
        this.envelopeUserInfoLoading = true
        getEnvelopesCount({
            authorWsid: authorWsid
        }).then(body => {
            let data = body.data.data.envelops
            this.envelopeUserInfoLoading = false
            this.envelopes = data
        }).catch(err => {
            this.envelopeUserInfoLoading = false
            this.$message.error("统计文件个数失败")
        })

        let envelopeShownStatus = this.statusCodes.join(",")
        getEnvelopes({
            authorWsid: authorWsid,
            limit: this.itemLimit,
            envelopeShownStatus,
            filters: `currentSequence>=assignedSequence`,
        }).then(body => {
            let data = body.data.data.envelopes
            this.envelopesNews = data
            this.envelopesNews.forEach(element => {
                let nameArray = element.sender.username.split(",")
                if (nameArray.length > 1){
                    element.sender.username = nameArray[0] + " (" + nameArray[1] + ")"
                }
            })
        }).catch(err => {
            this.$message.error("获取最新动态文件失败")
        })
        this.getSealsData()
    },
    methods: {
        translateTime(time){
            return newFormatDate(time, "HH:mm")
        },
        jumpToEnvelopList(type){
            let status
            switch (type) {
                case "WAITING_ME":
                    status = 1
                    break
                case "WAITING_OTHERS":
                    status = 2
                    break
                case "COMPLETE":
                    status = 3
                    break
                case "DRAFT":
                    status = 5
                    break
            }

            this.$router.push({
                name: "envelopes",
                query: {
                    status
                }
            })
        },
        jumpToEnvelopeDetail(row){
            let path = this.$route.path
            this.$store.dispatch("updatePathData", path)
            this.$router.push({
                name: "envelope-detail",
                params: {
                    envelopeId: row.envelopeWsid 
                }
            })
        },
        toPurchase(){
            this.$router.push({
                name: "person-purchase"
            })
        },
        getSealsData(){
            let userWsid = this.$store.getters.activeUserWsid
            getPersonSeals({
                authorWsid: userWsid
            }).then(res => {
                let seals = res.data.data.personSeals 
                let length = seals.length
                if (length > 0){
                    this.seal = {
                        id: seals[length - 1].personSealWsid,
                        src: seals[length - 1].link.href
                    }
                }
            }).catch(err => {
                console.error(err)
            })
        },
        deleteSealsData(id){
            deletePersonalSeal({
                personSealWsid: id
            }).then(res => {
                this.getSealsData()
            }).catch(err => {
            })
        },
        createRoom(){
            if (this.key){
                closeRoom({roomkey: this.key})
            }

            this.link = false

            this.key = uuidv4()
            this.createCode()
            createRoom({roomkey: this.key})

            listenUploaderJoin({roomkey: this.key}, data => {
                this.link = true
                createrExist({
                    roomkey: this.key,
                    uploaderId: data.uploaderId
                })
            })

            listenUpload({roomkey: this.key}, data => {
                this.imgData = data.imageData
                uploadSuccess({
                    roomkey: this.key,
                    uploaderId: data.uploaderId
                })
            })
        },
        createCode: function(){
            this.imgData = ""
            QRCode.toDataURL(location.origin + this.linkurl + "?key=" + this.key, (err, url) => {
                this.qrCode = url
            })
            console.log(location.origin + this.linkurl + "?key=" + this.key)
        },
        cancel: function(){
            this.dialogVisible = false
            this.link = false
        },
        uploadSeal(){
            let img = this.imgData
            let file = ImageDataToFile(img)
            
            this.uploading = true
            uploadPersonalSeals({
                name: "seal.png",
                file,
                from: "HAND_WRITE",
                authorWsid: this.$store.getters.activeUserWsid
            }).then(res => {
                this.$message.success("上传签名成功")
                this.sealDialogVisible = false
                let data = res.data.data.personSeal
                if (this.seal != null){
                    this.deleteSealsData(this.seal.id)
                } 
                this.seal = {
                    id: data.personSealWsid,
                    src: data.link.href
                }
            }).catch(err => {
                console.log(err)
                this.$message.error("上传签名失败")
            }).then(_ => {
                this.uploading = false
                this.sealDialogVisible = false
            })
        },
        editAlertBox(){
            this.sealDialogVisible = true
            this.createRoom()
        }
    },
    components: {
        authStatusPerson, 
        pictureUpload,
        imgBox
    }
}
</script>

<style lang="less" scoped>
@logo-padding: 0;
@logo-padding-sm: 40px;
@logo-padding-right:10px;

@info-title-padding: 0;
@info-title-padding-md: 80px;
@info-title-padding-sm: 80px;
@info-title-padding-xs: 80px;

@import "~@styles/variable.less";

.main-container{
    padding: 0 !important;
}

.public-red{
    color:@color-danger;
}
.container-block(){
    margin: 10px;
    flex: 1;
    min-width: 40%;
}
.user-account{
    height:60px;
    line-height:60px;
}
.user-info-seal{
    p{
        height:60px;
        line-height:60px;
    }
}

.person-infos-block{
    border-radius:0;
    box-shadow: rgba(0, 0, 0, 0.06) 0px 0px 20px 1px;
    z-index:9;
    padding: 0 20px;
    background:@color-nav-background;
    .person-infos-block-box{
        padding:10px 20px;
        min-height:80px;
        display: flex;
        flex-wrap: wrap;
        align-items:center;
        border-top:1px solid @color-border-button;
        .person-left{
            display: flex;
            flex-wrap: wrap;
            align-items:center;
            flex:1;
            .person-logo{
                width: 80px;
                padding-bottom: 20px;
                    .xs-devices({
                    padding-left:@logo-padding-sm;
                    padding-right: @logo-padding-right;
                });

                .sm-devices({
                    padding-left:@logo-padding-sm;
                    padding-right: @logo-padding-right;
                });
                
                .md-devices({
                    padding-left:@logo-padding;
                });

                .lg-devices({
                    padding-left:@logo-padding;
                });

                img{
                    width: 100%;
                }
            }
            .person-infos{
                flex: 1;
                margin-left: 30px;

                p{
                    font-size:@font-size-primary;
                }

                .person-name{
                    margin: 0;
                    font-size: @font-size-primary;
                }
            }
        }
    }
}


.person-right{
    flex:1;
    display: flex;
    flex-wrap: wrap;
    align-items:center;
    .person-rigth-box{
        display:flex;
        align-items:center;
        .person-rigth-box-title{
            flex:1;
            text-align:right;
        }
        .placeholder{
            flex:1;
        }
    }
    .person-right-info-block{
        flex:1;
        text-align:center;
        border-right:1px solid @color-border-button;
        font-size:@font-size-primary;
        .info-data{
            position: relative;
            padding:0 5px;
            line-height:30px;
            display:block;
        }
    }
    .my-seal-block{
        display:flex;
        align-items:center;
        color: #81878e;
        div{
            flex:1;
            text-align:right;
            display:inline-block;
        }
        p{
        font-size: @font-size-primary;
        color: @color-font-regular;
        flex:1;
        text-align:left;
        }
    }
    
    .charges-block{
        flex:1;
        text-align:center;
        font-size:@font-size-primary;
        width: 300px;
        .total-charges-box{
            display:block;
            height:60px;
            line-height:60px;
        }
        .purchase{
            cursor: pointer;
            margin-left: 10px;
            color: @color-main;
            font-size:@font-size-primary;
            .xs-devices({
                font-size:@font-size-primary;
            });
            .sm-devices({
                font-size:@font-size-regular;
            });
            .md-devices({
                font-size:@font-size-regular;
            });

            .lg-devices({
                font-size:@font-size-primary;
            });
            &:hover{
                text-decoration: underline;
            }
        }
    }
    .public-blue{
        font-size:@font-size-primary;
        color:@color-main;
        .xs-devices({
            font-size:@font-size-primary;
        });
        .sm-devices({
            font-size:@font-size-regular;
        });
        .md-devices({
            font-size:@font-size-regular;
        });
        .lg-devices({
            font-size:@font-size-primary;
        });
    }
}

.documents-info-container{
    padding: 0 40px;
    .documents-infos-block{
        display: flex;
        flex-wrap:wrap;
        align-items:center;
        justify-content: space-between;
        .waiting-me-box,.waiting-others-box,.complete-box,.draft-box{
            display:flex;
            justify-content: center;
            flex-direction: column;
            background:@color-nav-background;
            min-width:260px;
           .info-block-default;
            width:24%;
        }
        .documents-status-info{
            cursor: pointer;
            margin-bottom: 25px;

            .status-number{
                font-size:@font-size-largger;
                margin: 15px 0;
                display:flex;
                align-items:center;
                flex-wrap: wrap;
                .icon{
                    width:50px;
                }
                span{
                    flex:1;
                    text-align:right;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                &.waiting {
                    color:@color-warning
                }

                &.running{
                    color:@color-main;
                }

                &.complete{
                    color:@color-success;
                }

                &.draft{
                    color:@color-info;
                }
            }

            .status-info{
                font-size:@font-size-primary;
            }
        }
    }
}
//最新文件动态
.newsign-documents-info-container{
    .container-block;
    padding:0 40px;
    margin:0;
    margin-bottom:50px !important;
    .documents-list-block{
        .info-block-default;
        padding: 0;
    }
}

 .scan-dialog{
     text-align: center;
    .notice-msg{
        font-size:@font-size-regular;
        color:@color-font-main;
        margin: 20px 0;
    }
    .qr-code{
        width: 100%;
        text-align: center;
        padding-top: 20px;
        padding-bottom: 20px;
    }
    .img-area{
        position: relative;
        height: 300px;
        border: 1px solid #d7dbe5;
        border-radius: 1px;
        margin-top:20px;
    }
    .signature-img{
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
    }
    .scan-info{
        margin:15px 0;
    }
    .btn-group{
        text-align: right;
        .cancel-btn{
            height: 40px;
            width:120px;
            color:@color-font-main;
        }
        .confirm-btn{
            height: 40px;
            width:120px;
            color:@color-white;
            background-color: @color-main;
            margin-left:20px;
        }
    }
 }
@media screen and (max-width:1100px){
    .main-container{
        display:block;
    }
    
}
@media screen and (min-width:940px) and (max-width:1350px){
    .documents-infos-block{
        .documents-status-info{
            width:48% !important;
            margin-left:0 !important;
        }
    }
}
@media screen and (max-width:900px){
    .documents-status-info{
        width:100% !important;
        margin:0 0 20px 0 !important;
    }
}
</style>