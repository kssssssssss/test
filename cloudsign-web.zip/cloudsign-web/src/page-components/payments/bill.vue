<template>
    <div>
        <div class="bill-container">
            <div class="rcontainer-cont-select">
                <div class="all" @click.stop='dateClick(0)'>{{allValue}}</div>
                <div class="month" @click.stop='dateClick(1)'>
                    <span class="month-value">{{monthValue}}月</span>
                    <span class="carat"></span>
                    <div class="month-options" v-show='monthShow'>
                        <ul>
                            <li v-for='(m,index) in monthCount' @click.stop='monthOptionClick(maxMonth-m+1)'>{{maxMonth-m+1}}月</li>							
                        </ul>
                    </div>
                </div>
                <div class="year" @click.stop='dateClick(2)'>
                    <span class="year-value">{{yearValue}}年</span>
                    <span class="carat"></span>
                    <div class="year-options" v-show='yearShow'>
                        <ul>
                            <li @click.stop='yearOptionClick(nowYear-index)' v-for='(y,index) in yearCount'>{{nowYear-index}}年</li>                    
                        </ul>
                    </div>
                </div>
            </div>
            <div class="rcontainer-cont-records">
                <p class="p-title">账单总览</p>
                <table class="records-table">
                    <thead>
                        <tr class="records-htr">
                            <td class="records-htd td-per5">类型</td>
                            <td class="records-htd td-per5">总额(份)</td>
                        </tr>
                    </thead>
                    <tbody id="records-tot">
                        <tr class="records-btr" v-if = 'total===0'>
                            <td colspan="2" class="records-btd">暂无记录</td>
                        </tr>
                        <tr class="records-btr" v-else>
                            <td class="records-btd">文档签署</td>
                            <td class="records-btd">{{total}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="rcontainer-cont-records">
                <p class="p-title">账单明细</p>
                <table class="records-table">
                    <thead>
                        <tr class="records-htr">
                            <td class="records-htd td-per2">文档名称</td>
                            <td class="records-htd td-per2">发起者</td>
                            <td class="records-htd td-per2">签署者</td>
                            <td class="records-htd td-per2">时间</td>
                            <td class="records-htd td-per2">实扣(份)</td>
                        </tr>
                    </thead>
                    <tbody id="records-tot" v-if='total===0'>
                        <tr class="records-btr">
                            <td colspan="5" class="records-btd">暂无记录</td>
                        </tr>
                    </tbody>
                    <tbody id="records-tot" v-else>
                        <tr class="records-btr" v-for='b in bills'>
                            <td class="records-btd td-per2">{{b.docName}}</td>
                            <td class="records-btd td-per2">{{b.signUserAccount}}</td>
                            <td class="records-btd td-per2">{{b.signUserName}}</td>
                            <td class="records-btd td-per2">{{formatDate(b.builtDate,'yyyy-MM-dd hh:mm')}}</td>
                            <td class="records-btd td-per2">{{b.cost}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
        </div>
        <div class="pagination">
            <pagination :nowPage = 'nowPage'
            :maxPage='maxPage' @changePage='changePage' @nextOrlast='changePage'></pagination>
        </div>
    </div>
</template>


<script>
    import pagination from '@components/commons/pagination.vue'
    import {get_bill_sign} from '@interfaces/payments/payments.js'
    export default{
        data:function(){
            return{ 
                yearValue: 0, //当前选择年
                monthValue: 0,  //当前选择月
                nowYear:0,      //当前年
                nowMonth:0,     //当前月
                allValue: '查看全部',
                nowPage:1,
                maxPage:1,
                maxMonth:12,
                minMonth:1,
                monthShow:false,
                yearShow:false,
                bills:[],
                total:0,
                yearCount:'' ,   //当前年与注册年的差值
                registMonth:3,
                registYear:'',
                monthCount:''
            }
        },
        components:{pagination},
        created: function () {
            let date = new Date();
            this.yearValue = date.getFullYear();
            this.nowYear = this.yearValue;
            this.monthValue = date.getMonth() + 1;
            this.maxMonth = this.monthValue;
            this.nowMonth = this.monthValue;
            this.getBills({year:this.yearValue,month:this.monthValue});
            this.yearCount = this.yearValue - this.$store.state.userdata.registYear + 1;
            this.monthCount = this.maxMonth - this.minMonth + 1;
            this.registYear = this.$store.state.userdata.registYear
        },
        methods:{
            dateClick: function (flag) {
                let me = this;
                if (flag === 0) {
                    if(this.allValue === '查看全部'){
                        this.getBills({});
                        this.allValue = '返回搜索';
                    }
                    else{
                        this.getBills({year:this.yearValue,month:this.monthValue});
                        this.allValue = '查看全部';
                    }
                }
                else if (flag === 1) {
                    this.monthShow = !this.monthShow;
                    if(this.monthShow){
                        function monthDown(){
                            me.monthShow = false;
                            window.removeEventListener('click',monthDown)
                        }
                        window.addEventListener('click',monthDown);
                    }
                    
                }
                else if (flag === 2) {
                    this.yearShow = !this.yearShow;
                    if(this.yearShow){
                        function yearDown(){
                            me.yearShow = false;
                            window.removeEventListener('click',yearDown)
                        }
                    window.addEventListener('click',yearDown);
                    }
                    
                }
            },
            monthOptionClick: function (m) {
                this.monthValue = m;
                this.getBills({year:this.yearValue,month:this.monthValue});
                this.monthShow = false;
            },
            yearOptionClick:function(y){
                this.yearValue = y;
                if(y < this.nowYear && y > this.registYear){
                    this.maxMonth = 12;
                    this.minMonth = 1;
                    this.monthCount = this.maxMonth - this.minMonth + 1;
                }else if(y == this.registYear){
                    console.log(this.registMonth)
                    this.maxMonth = 12;
                    this.minMonth =  this.registMonth;
                    this.monthCount = this.maxMonth - this.minMonth + 1;
                }
                else{
                    this.maxMonth = this.nowMonth;
                    this.monthCount = this.maxMonth - this.minMonth +1;
                    this.monthValue = this.monthValue > this.nowMonth ? this.nowMonth : this.monthValue;
                }
                this.getBills({year:this.yearValue,month:this.monthValue});
                this.yearShow = false;
            },
            getQueryDate:function(year,month){
                let monthArr = [31,28,31,30,31,30,31,31,30,31,30,31];
                if(year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0)){
                    monthArr[1] = 29;
                }
                if(month > 9){
                    return {
                        fromDate: year + '-' + month + '-01' + ' 00:00:00',
                        toDate:year + '-' + month + '-' + monthArr [month - 1] + ' 23:59:59'
                    }
                }
                else{
                    return{
                        fromDate:year + '-0' + month + '-01' + ' 00:00:00',
                        toDate: year + '-0' + month + '-' + monthArr[month - 1] + ' 23:59:59'
                    }
                     
                }
            },
            formatDate:function(date,str){
                return FORMATDATE(date,str);
            },
            getBills:function(obj){
                let date = {};
                if(obj.year && obj.month){
                    date = this.getQueryDate(obj.year,obj.month);
                }
                get_bill_sign({
                    page:obj.page,
                    fromDate:date.fromDate,
                    toDate:date.toDate
                }).then(data => {
                    this.bills = data.bills;
                    this.nowPage = data.nowPage;
                    this.maxPage = data.totalPage;
                    this.total = data.total;
                }).catch(err => {
                    console.log(err);
                })
            },
            changePage:function(x){
                if(typeof x === 'number'){
                    this.nowPage = x;
                }
                else if(x === '上一页'){
                    this.nowPage-- ;
                }else{
                    this.nowPage++ ;
                }
                this.getBills({
                    page:this.nowPage,
                    year:this.yearValue,
                    month:this.monthValue
                });
            }
        }
    }
</script>

<style  scoped>
    @import '../../styles/user/payments.less';
    .bill-container{
        position: absolute;
        left: 0;
        top:0;
        right: 0;
        bottom:40px;
        overflow-y: auto;

    }
    .pagination{
        position:absolute;
        left:0;
        line-height:50px;
        right:0;
        text-align:center;
        bottom:0;
    }
</style>