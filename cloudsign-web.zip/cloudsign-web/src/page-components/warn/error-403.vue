<template>
    <h1>403 Forbidden !</h1>  
</template>

<script>
export default {
    //TODO: 待施工
}
</script>
