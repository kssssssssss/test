const iconLibrary = [
    { 
        name: "默认合同",
        href: require("@images/templates/default.png"), 
    }, {
        name: "劳动合同",
        href: require("@images/templates/labor.png"),
    }, {
        name: "经销商合同",
        href: require("@images/templates/dealers.png"),
    }, {
        name: "销售合同",
        href: require("@images/templates/sales.png"),
    }, {
        name: "买卖合同",
        href: require("@images/templates/business.png"),
    }, {
        name: "财务报销",
        href: require("@images/templates/financial.png"),
    }, {
        name: "借款协议",
        href: require("@images/templates/borrow.png"),
    }, {
        name: "项目立项",
        href: require("@images/templates/project-confirm.png"),
    }, {
        name: "项目结题",
        href: require("@images/templates/project-concluding.png"),
    }, {
        name: "承诺书",
        href: require("@images/templates/commitment.png"),
    }, {
        name: "申请书",
        href: require("@images/templates/application.png"),
    }, {
        name: "委托合同",
        href: require("@images/templates/entrust.png"),
    }, {
        name: "旅游协议",
        href: require("@images/templates/tourism.png"),
    }, {
        name: "租赁合同",
        href: require("@images/templates/lease.png"),
    }, {
        name: "采购合同",
        href: require("@images/templates/shopping.png"),
    }, {
        name: "运输合同",
        href: require("@images/templates/transport.png"),
    }, {
        name: "担保合同",
        href: require("@images/templates/guarantee.png"),
    }, {
        name: "技术合同",
        href: require("@images/templates/technology.png"),
    }, {
        name: "广告合同",
        href: require("@images/templates/advertise.png"),
    }, {
        name: "服务合同",
        href: require("@images/templates/service.png"),
    }, {
        name: "知识产权",
        href: require("@images/templates/intellectual-property-rights.png"),
    }, 
    // {
    //     name: "债权融资",
    //     href: require("@images/templates/bond-financing.png"),
    // }
]

export {
    iconLibrary
}