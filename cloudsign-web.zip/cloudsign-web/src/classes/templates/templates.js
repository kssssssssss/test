class templateConfig {
    constructor() {
        this.id = parseInt(Math.random() * 100000000) //模板配置id
        this.mainInfoFormId = "" //发起人需要填写的表单ID
        this.infosFormConfigs = new Array() //信息表单数组

        this.moreDocuments = true // 是否可以上传额外的文档
        this.maxDocumentsCount = 5 //最大可上传文档数量
        this.documentConfigs = new Array() //文档数组
        this.documentForms = new Array() //文档表单项数组

        this.actionConfigs = new Array() //行为定义数组
        this.participantConfigs = new Array() //流程参与者配置数组
        this.processGroupConfigs = new Array() //流程组配置

        this.mainProcessGroupId = "" //一个流程组配置的ID
        this.processParticipants = new Array() //预置参与者数组
        // this.mainProcessGroupId = "" //主流程预置参与者组

        this.templateConfigSubject = "" //信封备注
        this.templateConfigVersion = "2" //模板配置版本，主要是用于前端记录当前模板配置版本号，每次修改配置时 需要更新 
        //版本2修改内容:修复之前模板配置版本中信息组件 InfoFormSelect/InfoFormSingleCheckBox/InfoFormCheckBox 中设置默认选项时没有加optionId的bug;增加配置信封备注
    }
}



class MainInfoForm { //表单信息模块
    constructor() {
        this.mainInfoFormId = "" //表单信息模块id
        this.infosFormConfigs = [] //存储信息表单的数组，元素为下文的InfosFormObject
    }
}
class InfosFormObject {
    constructor() {
        this.formId = "" //表单id
        this.name = "" //表单名称
        this.infos = [] //表单信息配置数组,元素为下文的八种信息组件
    }
}

class InfoFormBase { //信息组件对象基础属性
    constructor() {
        this.infoId = "" //信息组件id
        this.name = "" //信息组件名称
        this.description = "" //描述
        this.default = "" //默认值
        this.required = true //是否必填
        this.type = "" //类别

        this.positions = {
            x: 0,
            y: 0,
            w: 12,
            h: 2,
        }
    }
}
class InfoFormInput extends InfoFormBase { //单行输入框
    constructor() {
        super()
        this.type = "INPUT" //类别
        this.name = "文本框" //信息组件名称
        this.maxLength = 0 //最大长度
        this.minLength = 0 //最小长度
        this.placeholder = "" //缺省值
    }
}
class InfoFormTextarea extends InfoFormBase { //多行输入框
    constructor() {
        super()
        this.type = "TEXTAREA" //类别
        this.name = "多行文本框" //信息组件名称
        this.maxLength = 0 // 最大长度
        this.minLength = 0 //最小长度
        this.maxLine = 0 //最多行数
        this.minLine = 0 //最少行数
        this.placeholder = "" //缺省值
    }
}
class InfoFormNumberInput extends InfoFormBase { //数值输入框
    constructor() {
        super()
        this.type = "NUMBER_INPUT" //类别
        this.default = 0 //默认值
        this.name = "数字" //信息组件名称
        this.max = "" //最大值
        this.min = "" //最小值
        this.unit = "" //单位
        this.precision = 2 //数值精度，保留小数位数
        this.Step = 2 //计数器步长
    }
}
class InfoFormSelect extends InfoFormBase { //下拉选择框
    constructor() {
        super()
        this.type = "SELECT" //类别 
        this.name = "下拉选择" //信息组件名称
        this.placeholder = "" //缺省值
        this.options = [{
            value: "",
            label: "选项1",
            default: true,
            optionId: parseInt(Math.random() * 100000000)
        }, {
            value: "",
            label: "选项2",
            default: false,
            optionId: parseInt(Math.random() * 100000000)
        }] //选项数组,元素为下文的selectObject对象
    }
}
class InfoFormSingleCheckBox extends InfoFormBase { //单项选择框
    constructor() {
        super()
        this.type = "SINGLE_CHECKBOX" //类别
        this.name = "单选" //信息组件名称
        this.options = [{
            value: "",
            label: "选项1",
            default: true,
            optionId: parseInt(Math.random() * 100000000)
        }, {
            value: "",
            label: "选项2",
            default: false,
            optionId: parseInt(Math.random() * 100000000)
        }] //选项数组,元素为下文的selectObject对象
    }
}
class InfoFormCheckBox extends InfoFormBase { //多选框
    constructor() {
        super()
        this.type = "CHECKBOX" //类别
        this.name = "多选" //信息组件名称
        this.minSelectNum = 0 //最多的选择数量
        this.maxSelectNum = 0 //最少的选择数量
        this.options = [{
            value: "",
            label: "选项1",
            default: true,
            optionId: parseInt(Math.random() * 100000000)
        }, {
            value: "",
            label: "选项2",
            default: false,
            optionId: parseInt(Math.random() * 100000000)
        }] //选项数组,元素为下文的selectObject对象
    }
}
class InfoFormPrice extends InfoFormBase { //金额输入框
    constructor() {
        super()
        this.type = "PRICE" //类别
        this.default = 0 //默认值
        this.name = "金额" //信息组件名称
        this.unit = "元" //单位
        this.max = "" //最大值
        this.min = "" //最小值
        this.point = 2 //小数位数
        this.Step = 5 //计数器步长
        this.placeholder = "" //缺省值
    }
}
class InfoFormDate extends InfoFormBase { //日期选择框
    constructor() {
        super()
        this.type = "DATE" //类别
        this.name = "日期" //信息组件名称
        this.rangeStart = new Date() //时间范围开始时间
        this.rangeEnd = new Date() //时间范围结束时间
        this.formDateType = "date" //日期选择类型（年月日/年月日时分秒）
    }
}
class selectObject { //选择框的选项对象
    constructor() {
        this.optionId = "" //选项id
        this.value = "" // 值
        this.label = "" //标签
        this.default = false //默认是否选中
    }
}


function createComponentByType(type) {
    let newComponent
    switch (type) {
        case "INPUT":
            newComponent = new InfoFormInput()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "TEXTAREA":
            newComponent = new InfoFormTextarea()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "SELECT":
            newComponent = new InfoFormSelect
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "SINGLE_CHECKBOX":
            newComponent = new InfoFormSingleCheckBox()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "NUMBER_INPUT":
            newComponent = new InfoFormNumberInput()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "PRICE":
            newComponent = new InfoFormPrice()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "CHECKBOX":
            newComponent = new InfoFormCheckBox()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
        case "DATE":
            newComponent = new InfoFormDate()
            newComponent.infoId = parseInt(Math.random() * 100000000)
            break
    }
    return newComponent
}

//增加修改配置时自动更新成最新的模板配置
function translateTemplateConfig(templateConfig){
    let infosFormConfigs = templateConfig.infosFormConfigs
    templateConfig.infosFormConfigs = infosFormConfigs.map(info => {
        let newComponent = createComponentByType(info.type)
        return Object.assign(newComponent, info)
    })
    return templateConfig
}

//修复之前模板配置版本1中InfoFormSelect/InfoFormSingleCheckBox/InfoFormCheckBox 中设置默认选项时没有加optionId的bug
function fixTemplateConfigInfoConfig(templateConfig){
    let infosFormConfigs = templateConfig.infosFormConfigs
    templateConfig.infosFormConfigs = infosFormConfigs.map(info => {
        if (info.options){
            info.options.forEach(el => {
                if (!el.optionId){
                    el.optionId = parseInt(Math.random() * 100000000)
                }
            })
        }
        return info
    })
    return templateConfig
}

export {
    createComponentByType,
    selectObject,
    templateConfig,
    translateTemplateConfig,
    fixTemplateConfigInfoConfig
}