const INIT_ERROR = {
    TOKEN_INVALID: "TOKEN_INVALID", //token无效
    TOKEN_REQUEST_FAIL: "TOKEN_REQUEST_FAIL", //token信息请求失败
    TOKEN_SCOPES_INVALID: "TOKEN_SCOPES_INVALID", //token作用域错误
    UNKOWN: "UNKOWN", //未知错误
}

//状态
const STATUS = {
    WAITING: "WAITING", //等待录入  //FIXME
    PASSED: "PASSED",　//录入通过
    DENY: "DENY",　//录入不通过
    EXPIRED: "EXPIRED",　//录入超时
}

export {
    INIT_ERROR,
    STATUS
}