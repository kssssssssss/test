//认证方式
const AUTH_METHODS = {
    PHONE_AUTH: "PHONE_AUTH",　//手机三网认证
    BANK_AUTH: "BANK_AUTH",　//银行卡认证
    FACEID_AUTH: "FACEID_AUTH", //人身核验
    MANUAL_AUTH: "MANUAL_AUTH",　//人工审核
}

const AUTH_METHOD_INFOS = {
    PHONE_AUTH: {
        title: "手机认证", 
        description: "", 
        recommend: "适用于手机号已经在中国移动、电信或联通营业厅实名认证的用户", 
    },
    BANK_AUTH: {
        title: "银行卡四要素认证", 
        description: "", 
        recommend: "适用于持有中国银行卡的用户",
    },
    FACEID_AUTH: {
        title: "人脸验证", 
        description: "采用人脸识别技术，需要读出指定数字", 
        recommend: "适用于所有具有大陆身份证的用户",
    },
    MANUAL_AUTH: {
        title: "人工审核", 
        description: "上传身份证(或护照等有效证件)正反面照以及本人手持证件照，审核时间较长", 
        recommend: "适用于不能使用其他方式的用户",
    },
}

//认证状态
const AUTH_STATUS = {
    INCOMPLETE: "INCOMPLETE",　//未完善，待用户提交认证资料
    WAITING: "WAITING", //认证未通过
    PASSED: "PASSED",　//认证通过
    DENY: "DENY",　//认证不通过
    EXPIRED: "EXPIRED",　//认证超时
}

//初始认证状态的错误情况
const AUTH_INIT_ERROR = {
    TOKEN_INVALID: "TOKEN_INVALID", //token无效
    TOKEN_REQUEST_FAIL: "TOKEN_REQUEST_FAIL", //token信息请求失败
    TOKEN_SCOPES_INVALID: "TOKEN_SCOPES_INVALID", //token作用域错误
    UNKOWN: "UNKOWN", //未知错误
}

//个人实名认证选择地区
const AUTH_METHOD_FORMS = [{
    index: 0,
    location: '中国大陆',
    methods: 'SECOND_GENERATION_IDCARD',
    forms: [{
        title: '证件类型',
        defaultVal: '身份证',
        canChange: false
    }]
}, {
    index: 1,
    location: '中国澳门/中国香港',
    methods: 'HK_MACAU_TRAVELING_PERMIT',
    forms: [{
        title: '证件类型',
        defaultVal: '回乡证（港澳居民来往内地通行证）',
        canChange: false
    }]
}, {
    index: 2,
    location: '中国台湾',
    methods: 'TAI_WAN_IDCARD',
    forms: [{
        title: '证件类型',
        defaultVal: '台胞证（台湾居民来往内地通行证）',
        canChange: false
    }]
}, {
    index: 3,
    location: '其他地区',
    methods: 'PASSPORT',
    forms: [{
        title: '证件类型',
        defaultVal: '护照（外籍护照）',
        canChange: false
    }]
}]

//选择地区类型
const AUTH_METHOD_TYPE = {
    SECOND_GENERATION_IDCARD: 'SECOND_GENERATION_IDCARD',
    HK_MACAU_TRAVELING_PERMIT: 'HK_MACAU_TRAVELING_PERMIT',
    TAI_WAN_IDCARD: 'TAI_WAN_IDCARD',
    PASSPORT: 'PASSPORT'
}

export {
    AUTH_METHODS,
    AUTH_METHOD_INFOS,
    AUTH_STATUS,
    AUTH_INIT_ERROR,
    AUTH_METHOD_FORMS,
    AUTH_METHOD_TYPE
}