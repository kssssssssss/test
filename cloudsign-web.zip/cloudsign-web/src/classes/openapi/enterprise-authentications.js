//认证方式
const AUTH_METHODS = {
    LEGAL_PERSON_AUTH: "LEGAL_PERSON_AUTH",　//企业认证
    MANUAL_MONEY_AUTH: "MANUAL_MONEY_AUTH",　//授权委托书认证
    MANUAL_AUTH:"MANUAL_AUTH"
}

const AUTH_METHOD_INFOS = {
    LEGAL_PERSON_AUTH: {
        title: "法人授权认证", 
        description: "仅支持大陆企业和个体工商户", 
        icon:"icon-legal-person",
        background:require("@images/auth/legal-person-bg.png"),
        recommend: "需营业执照、法人手机号",
    },
    MANUAL_MONEY_AUTH: {
        title: "对公打款认证", 
        description: "仅支持大陆企业和个体工商户", 
        icon:"icon-manual-money-auth",
        background:require("@images/auth/manual-money-bg.png"),
        recommend: "需营业执照、对公帐户信息",
    },
    MANUAL_AUTH: {
        title: "证件认证", 
        description: "支持非大陆企业、政府事业单位等", 
        icon:"icon-id-card",
        background:require("@images/auth/id-card-bg.png"),
        recommend: "需营业执照、经办人证件照（经办人非法人时需上传加盖公章的认证授权书）",
    },
}

//认证状态
const AUTH_STATUS = {
    INCOMPLETE: "INCOMPLETE",　//未完善，待用户提交认证资料
    PRIMARY_PASSED: "PRIMARY_PASSED", //初级认证通过
    WAITING: "WAITING",　//认证通过
    PRIMARY_DENY: "PRIMARY_DENY",　//认证不通过
    EXPIRED: "EXPIRED",　//认证超时
    POWER_OF_ATTORNEY_REVISING:"POWER_OF_ATTORNEY_REVISING", //授权书待修改状态
    BASE_INFO_COMPLETE:"BASE_INFO_COMPLETE",//基本信息
    WAITING_SUM: "WAITING_SUM", //等待打款
    WAITING_SUM_CHECK: "WAITING_SUM_CHECK", //已打款(等待用户汇款信息确认)
    SENIOR_PASSED: "SENIOR_PASSED", //高级认证通过(用户汇款信息确认成功)
    SENIOR_DENY: "SENIOR_DENY", //高级认证未通过（打款失败/汇款验证失败)
    SENIOR_NO_CERT:"SENIOR_NO_CERT", //高级认证(但颁发证书失败)
    SENIOR_DENY_NAME_REPEAT:"SENIOR_DENY_NAME_REPEAT"
}
//初始认证状态的错误情况
const AUTH_INIT_ERROR = {
    TOKEN_INVALID: "TOKEN_INVALID", //token无效
    TOKEN_REQUEST_FAIL: "TOKEN_REQUEST_FAIL", //token信息请求失败
    TOKEN_SCOPES_INVALID: "TOKEN_SCOPES_INVALID", //token作用域错误
    UNKOWN: "UNKOWN", //未知错误
}
export {
    AUTH_METHODS,
    AUTH_METHOD_INFOS,
    AUTH_STATUS,
    AUTH_INIT_ERROR
}