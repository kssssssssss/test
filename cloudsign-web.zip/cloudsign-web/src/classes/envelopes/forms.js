const FORMS_CONFIG = [
    {
        type: "SIGN",
        name: "签名框",
        icon: require("@images/envelopes/signname.png"),
        defaultSize: {
            height: 40 / 1.2,
            width: 100 / 1.2,
        }
    },
    {
        type: "SEAL",
        name: "签章框",
        icon: require("@images/envelopes/seal.png"),
        defaultSize: {
            height: 40 / 25.4 * 72,
            width: 40 / 25.4 * 72,
        }
    },
    {
        type: "TEXT",
        name: "文本框",
        icon: require("@images/envelopes/text.png"),
        defaultSize: {
            height: 15,
            width: 150 / 1.2,
        }
    },
    {
        type: "DATE",
        name: "日期框",
        icon: require("@images/envelopes/date.png"),
        defaultSize: {
            height: 15,
            width: 190 / 1.33,
        }
    }
]

const FORMS_CONFIG_TYPE_MAP = new Map()
FORMS_CONFIG.forEach(form => FORMS_CONFIG_TYPE_MAP.set(form.type, form))

class EnvelopeFormPosition{
    constructor(){
        this.ulx = 0
        this.uly = 0
        this.lrx = 0
        this.lry = 0
    }

    static formRect(top, left, width, height){
        let position = new EnvelopeFormPosition()
        position.uly = top
        position.ulx = left
        position.lry = top + height
        position.lrx = left + width
        return position
    }
}

class FormsFactory{
    createForm(formType){
        switch (formType){
            case "WRITE_SIGN":
            case "SEAL_SIGN":
            case "TEXT":
            case "DATE": return new EnvelopeBaseForm()
            case "MULTI_CHECK_MARK": return new PagingSeal()
        }
    }
}

class BaseForm{
    constructor(){
        this.random = Math.floor(Math.random() * 10000000) + "" //前端用的随机码
        /**
         * TEXT 单行文本
         * DATE 日期
         * SEAL 签章
         * SIGN 签名
         * MULTI_CHECK_MARK 骑缝章 
         * MULTI_QRCODE_MARK 二维码 
         */
        this.type = "" //表单类型 
        this.id = "" //表单ID
        this.docId = "" //表单所在文件ID
        this.participantWsid = "" //参与者ID
        this.confirmed = false //表单已被确认
        this.fileType = "" //文件类型
    }

    sameAs(other){
        if (this.type !== other.type
            || this.id !== other.id
            || this.docId !== other.docId
            || this.participantWsid !== other.participantWsid){
            return false
        }
        return true
    }

    fromEndData(endData){
        if (endData.tagId) this.random = endData.tagId
        this.type = endData.formType
        this.id = endData.formWsid
        this.docId = endData.fileWsid
        this.participantWsid = endData.participantWsid

        if (endData.confirmStatus === "CONFIRMED"){
            this.confirmed = true
        } else {
            this.confirmed = false
        }
    }

    toEndData(){
        let data = {}
        data.tagId = this.random
        data.formType = this.type
        if (this.id) data.formWsid = this.id
        data.fileWsid = this.docId
        data.participantWsid = this.participantWsid
        return data
    }
}

//信封表单基础数据对象
class EnvelopeBaseForm extends BaseForm{
    constructor(){
        super()
        this.page = 0 //表单所在页面
        this.required = false //是否必填
        this.scale = 1 //缩放比例
        this.revisable = true //是否可修改 //FIXME: 由前端控制，设置页面设为false 签名页面设置为true
        this.position = new EnvelopeFormPosition()
        this.data = null //日期和文本为String 签名和签章为Object {id:, imageData}
        this.format = "yyyy-MM-dd" //日期格式
    }

    sameAs(other){
        if (!super.sameAs(other)
            || this.page !== other.page
            || this.required !== other.required
            || this.scale !== other.scale
            || this.revisable !== other.revisable
            || JSON.stringify(this.position) !== JSON.stringify(other.position)
            || JSON.stringify(this.data) !== JSON.stringify(other.data)){
            return false
        }
        return true
    }

    fromEndData(endData){
        super.fromEndData(endData)

        //类型
        switch (endData.formType){
            case "WRITE_SIGN":
                this.type = "SIGN"
                break
            case "SEAL_SIGN":
                this.type = "SEAL"
                break
            case "TEXT":
                this.type = "TEXT"
                break
            case "DATE":
                this.type = "DATE"
                break
        }

        this.id = endData.formWsid
        this.participantWsid = endData.participantWsid
        this.docId = endData.fileWsid
        this.page = endData.page
        this.required = endData.required
        this.scale = endData.scale
        if (endData.revisable != undefined) this.revisable = endData.revisable

        this.position = new EnvelopeFormPosition()
        this.position.ulx = endData.position.ulx
        this.position.uly = endData.position.uly
        this.position.lrx = endData.position.lrx
        this.position.lry = endData.position.lry
        
        if (this.type === "DATE"){ //设置日期表单日期格式类型
            this.format = endData.format ? endData.format : "yyyy-MM-dd"
        }

        if (endData.initialValue){
            let data = endData.initialValue
            switch (this.type){
                case "SIGN":
                    if(data.writeData){
                        this.data = {
                            id: data.writeWsid,
                            imageData: data.writeData,
                        } 
                    }
                    break
                case "SEAL":
                    if(data.sealData){
                        this.data = {
                            id: data.sealWsid,
                            imageData: data.sealData,
                            width: data.width,
                            height: data.height
                        } 
                    }
                    break
                case "TEXT":
                    this.data = data
                    break
                case "DATE":
                    this.data = data
                    break
            }
        }
    }

    toEndData(){
        let data = super.toEndData()

        switch (this.type){
            case "SIGN":
                data.formType = "WRITE_SIGN"
                break
            case "SEAL":
                data.formType = "SEAL_SIGN"
                break
            case "TEXT":
                data.formType = "TEXT"
                break
            case "DATE":
                data.formType = "DATE"
                break
        }

        data.page = this.page
        data.position = JSON.parse(JSON.stringify(this.position))
        data.scale = this.scale
        data.required = this.required
        data.revisable = this.revisable
        data.format = this.format
        
        //数据
        if (this.data){
            switch (this.type){
                case "SIGN":
                    data.initialValue = {
                        writeWsid: this.data.id,
                        writeData: this.data.imageData,
                    }   
                    break
                case "SEAL":
                    data.initialValue = {
                        sealWsid: this.data.id,
                        sealData: this.data.imageData,
                        width: this.data.width,
                        height: this.data.height
                    }  
                    break
                case "TEXT":
                    data.initialValue = this.data
                    data.multiLine = true//多行
                    data.fontSize = 14//默认字体 pt为单位 1pt = 4/3px
                    break
                case "DATE":
                    data.initialValue = this.data 
                    break
            }
        }

        return data
    }
}


class MultiPageForm extends BaseForm{
    constructor(){
        super()
        this.direction = "RIGHT"
        this.percent = 1
        this.margin = 0
        this.pages = "all"
        this.certPages = "1"
    }

    sameAs(other){
        if (!super.sameAs(other)
            || this.direction !== other.direction
            || this.percent !== other.percent
            || this.margin !== other.margin
            || this.pages !== other.pages
            || this.certPages !== other.certPages){
            return false
        }
        return true
    }

    fromEndData(endData){
        super.fromEndData(endData)
        this.direction = endData.direction
        this.percent = endData.percent
        this.margin = endData.margin
        this.pages = endData.pages
        this.certPages = endData.certPages
    }

    toEndData(){
        let data = super.toEndData()
        data.direction = this.direction
        data.percent = this.percent
        data.margin = this.margin
        data.pages = this.pages
        data.certPages = this.certPages
        return data
    }
}

class PagingSeal extends MultiPageForm{
    constructor(){
        super()
        this.type = "MULTI_CHECK_MARK"

        this.resizable = true
        this.resizeWidth = 119.05
        this.resizeHeight = 119.05

        this.offset = 0
        this.sealWsid = ""
        this.sealData = ""
    }

    sameAs(other){
        if (!super.sameAs(other)
            || this.resizable !== other.resizable
            || this.resizeWidth !== other.resizeWidth
            || this.resizeHeight !== other.resizeHeight
            || this.offset !== other.offset
            || this.sealWsid !== other.sealWsid
            || this.sealData !== other.sealData){
            return false
        }
        return true
    }

    fromEndData(endData){
        super.fromEndData(endData)
        this.offset = endData.offset || 0
        this.resizable = endData.resizable
        this.resizeWidth = endData.resizeWidth
        this.resizeHeight = endData.resizeHeight

        if (endData.initialValue){
            let data = endData.initialValue
            this.sealWsid = data.sealWsid
            this.sealData = data.sealData
        }
    }

    toEndData(){
        let data = super.toEndData()
        data.offset = this.offset
        data.resizable = this.resizable
        data.resizeWidth = this.resizeWidth
        data.resizeHeight = this.resizeHeight
        data.initialValue = {
            sealWsid: this.sealWsid,
            sealData: this.sealData
        }

        return data
    }
}


function translateFormsToFront(forms){
    let factory = new FormsFactory()
    return forms.map(data => {
        let form = factory.createForm(data.formType)
        form.fromEndData(data)
        return form
    })
}

function translateFormsToEnd(forms){
    return forms.map(form => {
        return form.toEndData()
    })
}

export {
    FORMS_CONFIG,
    FORMS_CONFIG_TYPE_MAP,
    EnvelopeFormPosition,
    EnvelopeBaseForm,
    PagingSeal,
    translateFormsToFront,
    translateFormsToEnd
}