import { isEmail, isPhone } from "@wesign/check"

class FrontParticipant{
    constructor(){
        this.id = parseInt(Math.random() * 100000000) //联系人前端标识
        this.participantWsid = "" //联系人ID
        this.groupId = null //联系人所在group
        this.position = 0 //联系人所在group位置
        this.sequence = 1 //联系人的序列
        this.actionType = "SIGNER" //联系人操作类型 SIGNER CHECKER
        this.type = "PERSON" //联系人类型 PERSON ENTERPRISE_MEMBER ENTERPRISE_ROLE BULK_PERSON 
        this.contact = "" //联系人联系方式
        this.name = "" //联系人名称
        this.enterpriseName = "" //联系人企业名称
        this.enterpriseWsid = "" //联系人企业ID
        this.enterpriseRoleWsid = "" //联系人角色ID
        this.secureLevel = "DISPOSABLE_CERT" //联系人安全级别
        this.metadata = {} //额外信息
        this.authorWsid = "" //用户ID
        this.multiMode = false // 是否为群发模式
        this.multiArray = [] //批量发送参与者
        this.multiName = "" //批量发送时参与者名字("甲方、乙方...至多5方")
        this.authLevel = "LOW" //签署认证等级：HIGH：高等级，MIDDLE：中等级，LOW，低等级
        this.authType = "" //认证方式 SMS_CODE:手机验证码，EMAIL_CODE：邮箱验证码，SIGN_PIN:签署密码，LIVING_AUTH：活体认证，USBKEY，usbkey认证，MOBILE_SHIELD:手机盾认证
        this.envelopeDisplay = ""
        this.isExternal = false //是否为外部参与者

        /**
         * ING_WAIT                     等待自己处理
         * ING_PROCESS                  系统处理中
         * ED_SUCCESS                   已成功处理
         * ED_SUCCESS_AUTHORIZE         授权他人处理
         * ED_SUCCESS_REMOVE            被发送者移除
         * ED_FAIL_REJECT               拒绝处理
         * ED_FAIL_TIMEOUT              超时未处理
         * ED_FAIL_BACK                 退回
         * ED_FAIL_PROCESS_FILLOUT      填写表单失败
         * ED_FAIL_PROCESS_AUTHORIZE    授权他人处理失败
         */
        this.status = "" //联系人状态
    }
}

class ParticipantsTreeNode{
    constructor(){
        this.id = parseInt(Math.random() * 100000000) //ID
        this.type = "" //类型
        this.position = 0 //顺序
        this.groupId = null //所属组
    }
}


class Group extends ParticipantsTreeNode{
    constructor(){
        super()
        this.groupName = "" //组名
        this.nodes = [] //组节点
    }

    appendNode(node){
        this.nodes.push(node)
    }

    removeNode(removeNode){
        let index = this.nodes.findIndex(node => removeNode === node)
        return this.nodes.splice(index, 1)[0]
    }
}

class EnterpriseGroup extends Group{
    constructor(){
        super()
        this.type = "ENTERPRISE_OUTSIDE" //企业对外 ENTERPRISE_OUTSIDE 企业对内 ENTERPRISE_INSIDE
        this.enterpriseName = "" //企业名称
        this.enterpriseWsid = "" //企业ID
    }

    get isExternal(){
        return this.nodes.every(p => p.isExternal === true)
    }
}

class RootGroup extends Group{
    constructor(){
        super()
        this.id = null
        this.sender = null
    }
}

//构建树
function buildParticipantsTree(participants){
    let sender = participants.find(participant => participant.actionType === "SENDER")
    let groups = sender.metadata.groups || []
    groups = groups.map(group => {
        let g = new EnterpriseGroup()
        g.id = group.id
        if (group.groupId) g.groupId = group.groupId
        if (group.position) g.position = group.position
        if (group.type) g.type = group.type
        if (group.enterpriseName) g.enterpriseName = group.enterpriseName
        if (group.enterpriseWsid) g.enterpriseWsid = group.enterpriseWsid
        if (group.groupName) g.groupName = group.groupName
        return g
    })

    let rootGroup = new RootGroup()
    rootGroup.sender = sender

    let groupMap = {}
    groupMap[null] = rootGroup
    groups.forEach(group => {
        groupMap[group.id] = group
    })

    groups.forEach(group => {
        groupMap[group.groupId].nodes.push(group) 
    })

    let others = participants.filter(participant => participant.actionType !== "SENDER")
    others.forEach(node => {
        groupMap[node.groupId].nodes.push(node)
    })

    for (let id in groupMap){
        groupMap[id].nodes.sort((a, b) => {
            return a.position - b.position
        })
    }
    return rootGroup
}

//构件参与者结构树--自动化
function buildParticipantsTreeWithoutMetadata(participants){
    let sender = participants.find(participant => participant.actionType === "SENDER")
    let actors = participants.filter(participant => participant.actionType !== "SENDER")
    actors.forEach(p => p.id = parseInt(Math.random() * 100000000))

    let rootGroup = new RootGroup()
    rootGroup.sender = sender

    //顺序，(个人，公司(成员，角色))
    actors.sort((a, b) => {
        //先对顺序进行排列
        if(a.sequence !== b.sequence){
            return a.sequence - b.sequence
        }

        //类型(个人，企业)
        if(a.type === "PERSON" && b.type === "PERSON"){
            return a.name < b.name ? -1 : 1
        } else if(a.type === "PERSON" && b.type !== "PERSON"){ //个人在前面
            return -1
        } else if(a.type !== "PERSON" && b.type === "PERSON"){
            return 1
        } else {
            if(a.enterpriseName === b.enterpriseName){ //企业相同
                if(a.type === b.type){
                    return a.name < b.name ? -1 : 1
                } else {
                    if(a.type === "ENTERPRISE_MEMBER"){ //成员在前
                        return -1
                    } else {
                        return 1
                    }
                }
            } else {
                return a.enterpriseName < b.enterpriseName ? -1 : 1
            }
        }
    })

    for(let i = 0; i < actors.length; i++){
        let actor = actors[i]
        if(actor.type === "PERSON"){
            rootGroup.nodes.push(actor)
        } else { //是一个企业，去寻找后序的所有相同企业
            let g = new EnterpriseGroup()
            g.id = parseInt(Math.random() * 100000000)
            g.type = "ENTERPRISE_INSIDE"
            g.enterpriseName = actor.enterpriseName
            g.enterpriseWsid = actor.enterpriseWsid
            g.groupName = actor.enterpriseName
            g.nodes.push(actor)

            while(i + 1 < actors.length){
                let nextActor = actors[i + 1]
                if(nextActor.type === "PERSON" || nextActor.enterpriseName !== actor.enterpriseName) break
                g.nodes.push(nextActor)
                i++
            }
            rootGroup.nodes.push(g)
        }
    }

    return rootGroup
}

function parseParticipantsGroupTree(group, order = false){
    let nodes = group.nodes
    let participants = []
    let groups = []

    let sequence = 1
    nodes.forEach((node, index) => {
        if (node instanceof FrontParticipant){
            node.position = index
            if (order) {
                node.sequence = sequence++
            } else {
                node.sequence = 1
            }
            node.groupId = group.id
            participants.push(node)
        } else if (node instanceof Group){
            //现在的组都是在企业组
            let groupParticipants = parseParticipantsGroupTree(node)
            groupParticipants.forEach(participant => {
                if (order) {
                    participant.sequence = sequence++
                } else {
                    participant.sequence = 1
                }
                
                participant.enterpriseName = node.enterpriseName
                participant.enterpriseWsid = node.enterpriseWsid

                participants.push(participant)
            })

            groups.push({
                id: node.id,
                groupId: node.groupId,
                position: index,
                groupName: node.groupName,
                type: node.type,
                enterpriseName: node.enterpriseName,
                enterpriseWsid: node.enterpriseWsid
            })
        }
    })

    if (group.sender){
        group.sender.metadata = {
            groups
        }
        participants.push(group.sender)
    }

    return participants
}

//将后台转换前端展示结构，获取的数据 => 前端
function translateParticipantDatasFromEnd(participants){
    let returnParticipants = participants.map(participant => {
        let metadata
        try {
            metadata = JSON.parse(participant.metadata || "{}")
        } catch (err) {
            metadata = {}
        }
    
        let contact = participant.contacts
        try {
            contact = JSON.parse(contact || "[]") || []
            contact = contact[0] || {}
            contact = contact.phone || contact.email || contact.sms || ""
        } catch (err){
            contact = ""
        }
    
        let frontData = new FrontParticipant()
        if (metadata.id) frontData.id = metadata.id
        if (metadata.groupId) frontData.groupId = metadata.groupId
        if (metadata.position) frontData.position = metadata.position
        if (participant.participantWsid) frontData.participantWsid = participant.participantWsid
        if (participant.enterpriseWsid) frontData.enterpriseWsid = participant.enterpriseWsid
        if (participant.enterpriseName) frontData.enterpriseName = participant.enterpriseName
        if (participant.isExternal != null) frontData.isExternal = participant.isExternal
        
        if (participant.multiSendNum) {
            frontData.multiMode = true 
        } else {
            frontData.multiMode = false
        }
        
        if (participant.roleType === "ENTERPRISE_ROLE"){
            frontData.enterpriseRoleWsid = participant.authorWsid
        }

        frontData.sequence = participant.assignedSequence
        frontData.contact = contact
        frontData.name = participant.name

        if (frontData.multiSendNum){
            frontData.type = "BULK_PERSON"
        } else {
            frontData.type = participant.roleType
        }

        if (frontData.multiMode){
            frontData.multiName = participant.name
        }
       
        frontData.actionType = participant.type
        frontData.secureLevel = participant.secureLevel
        frontData.status = participant.status
        frontData.handleReason = participant.handleReason
        frontData.handleDatetime = participant.handleDatetime
        frontData.authorWsid = participant.authorWsid
        frontData.metadata = metadata
        frontData.authLevel = participant.authLevel || "LOW" //FIXME: 等待后台接口出来
        frontData.authType = participant.authType

        return frontData
    })
    returnParticipants = returnParticipants.sort((a, b) => {
        if (a.sequence - b.sequence === 0){ //非顺序签
            return a.metadata.position - b.metadata.position
        }
        return a.sequence - b.sequence
    })
    return returnParticipants
}

//将前端转换后台请求结构，前端 => 要提交的数据 
function translateParticipantDatasFromFront(participants){
    return participants.map(participant => {
        let contact = {}
        if (isEmail(participant.contact).result){
            contact = {
                phone: "",
                email: participant.contact
            }
        } else if (isPhone(participant.contact).result){
            contact = {
                phone: participant.contact,
                email: ""
            }
        } else {
            contact = {
                phone: "",
                email: ""
            }
        }
        
        let metadata = participant.metadata
        if (participant.actionType !== "SENDER"){
            metadata.id = participant.id
            metadata.groupId = participant.groupId
            metadata.position = participant.position
        }

        if (participant.multiMode || participant.type === "BULK_PERSON"){
            if (participant.multiArray.length > 0){ //批量发送方添加了批量参与者时，确保批量发送方的外部actionType和type与内部（数组）参与者类型一致
                let multiArray = participant.multiArray
                participant.type = multiArray[0].type
                participant.actionType = multiArray[0].actionType
            } else { 
                participant.type = "PERSON" //量发送方为空时需要设置一个后台识别的类型“BULK_PERSON”是前端定义的，因此要转换
            }
        }
        let name = ""
        if (participant.multiMode){
            name = participant.multiName
        } else {
            name = participant.name
        }
        let uploadData = {
            participantWsid: participant.participantWsid || undefined,
            name: name,
            contact: contact,
            assignedSequence: participant.sequence,
            type: participant.actionType,
            enterpriseName: participant.enterpriseName || "",
            enterpriseWsid: participant.enterpriseWsid || "",
            enterpriseRoleWsid: participant.enterpriseRoleWsid || "",
            roleType: participant.type,
            secureLevel: participant.secureLevel,
            multiSend: participant.multiMode,
            //multiSend: false,
            authLevel: participant.authLevel,
            metadata: JSON.stringify(metadata)
        }
        return uploadData
    })
    
}
//前端批量参与者转换成后台结构
function translateParticipantMultiDatasFromFront(originalParticipants){
    let participants = []
    let newparticipants = translateParticipantDatasFromFront(originalParticipants)
    newparticipants.forEach(participant => {
        let obj = {
            participantsInfo: {},
            envelopeInfo: {}
        }
        delete participant.assignedSequence
        delete participant.metadata
        obj.participantsInfo = participant
        obj.envelopeInfo = {
            subject: "",
            title: ""
        }
        participants.push(obj)
    })
    return participants
    
}
//后台批量参与者转换成前端结构
function translateParticipantMultiDatasFromEnd(originalParticipants){
    let participants = []
    participants = originalParticipants.map(participant => {
        return participant.participantsInfo
    })
    let returnParticipants = translateParticipantDatasFromEnd(participants)
    return returnParticipants
}

function translateStatusName(participantData, envelopeData){
    let status = participantData.status

    if (status === "ING_WAIT"){
        if (participantData.sequence === envelopeData.currentSequence) {
            if (envelopeData.status === "ED_FAIL_EXPIRED" && participantData.actionType === "SIGNER"){
                return "逾期未签"
            } else if(envelopeData.status === "ED_FAIL_EXPIRED" && participantData.actionType === "CHECKER") {
                return "逾期未审"
            }
    
            if (envelopeData.status === "ED_FAIL_REVOKE") {
                return "已撤销"
            }    
        }
        //如果已经结束了的还在等待 则不展示
        if (/^ED/.test(envelopeData.status)) {
            return ""
        }

        if (participantData.sequence === envelopeData.currentSequence){
            if (participantData.actionType === "SIGNER"){
                return envelopeData.envelopeFlowType === 'CANCEL_PROCESS'? "作废待确认": "待签署"
            } else {
                return envelopeData.envelopeFlowType === 'CANCEL_PROCESS'? "作废待审核" : "待审核"
            }
        } else {
            return ""
            // if (participantData.actionType === "SIGNER"){
            //     return "等待签署"
            // } else {
            //     return "等待审核"
            // }
        } 
    } else if (status === "ING_PROCESS"){
        return envelopeData.envelopeFlowType === 'CANCEL_PROCESS'? '作废处理中' :"处理中"
    } else if (status === "ED_SUCCESS"){
        if (participantData.actionType === "SIGNER"){
            return envelopeData.envelopeFlowType === 'CANCEL_PROCESS' ? '作废已确认' : "已签署"
        } else {
            return envelopeData.envelopeFlowType === 'CANCEL_PROCESS' ?'作废已通过' :  "已通过"
        }
    } else {
        switch (status){
            case "ED_SUCCESS_AUTHORIZE": return "已授权"
            case "ED_SUCCESS_REMOVE": return "被发送者移除"
            case "ED_FAIL_REJECT": return envelopeData.envelopeFlowType === 'CANCEL_PROCESS' ? '作废已拒绝' :"已拒签"
            case "ED_FAIL_PROCESS_CHECK": return "未通过"
            // case "ED_FAIL_TIMEOUT": return "超时未处理"
            case "ED_FAIL_EXPIRED": return "逾期未签"
            case "ED_FAIL_BACK": return "退回"
            case "ED_FAIL_PROCESS_FILLOUT": return "填写表单失败"
            case "ED_FAIL_PROCESS_AUTHORIZE": return "授权他人处理失败"
        }
    }
}

function getStatusNameIcon(participantData, envelopeData){
    let status = participantData.status
    
    if (status === "ING_WAIT"){
        //如果已经结束了的还在等待 则不展示
        if (/^ED/.test(envelopeData.status)){
            return ""
        }

        if (participantData.sequence === envelopeData.currentSequence){
            return "icon-wait2"
        } else {
            // return "icon-doing"
        } 
    } else {
        switch (status){
            case "ING_PROCESS": return "icon-wait"
            case "ED_SUCCESS": return "icon-complete"
            case "ED_SUCCESS_AUTHORIZE": return "icon-complete"
            case "ED_SUCCESS_REMOVE": return "icon-refuse2"
            case "ED_FAIL_REJECT": return "icon-refuse2"
            case "ED_FAIL_PROCESS_CHECK": return "icon-refuse2"
            case "ED_FAIL_TIMEOUT": return "icon-warning"
            case "ED_FAIL_EXPIRED": return "icon-warning"
            case "ED_FAIL_BACK": return "icon-refuse2"
            case "ED_FAIL_PROCESS_FILLOUT": return "icon-warning"
            case "ED_FAIL_PROCESS_AUTHORIZE": return "icon-warning"
        }
    }
}

export default {
    FrontParticipant,
    ParticipantsTreeNode,
    Group,
    EnterpriseGroup,
    buildParticipantsTree,
    buildParticipantsTreeWithoutMetadata,
    parseParticipantsGroupTree,
    translateParticipantDatasFromEnd,
    translateParticipantDatasFromFront,
    translateParticipantMultiDatasFromFront,
    translateParticipantMultiDatasFromEnd,
    getStatusNameIcon
}

export {
    FrontParticipant,
    ParticipantsTreeNode,
    Group,
    EnterpriseGroup,
    buildParticipantsTree,
    buildParticipantsTreeWithoutMetadata,
    parseParticipantsGroupTree,
    translateParticipantDatasFromEnd,
    translateParticipantDatasFromFront,
    translateParticipantMultiDatasFromFront,
    translateParticipantMultiDatasFromEnd,
    translateStatusName,
    getStatusNameIcon
}