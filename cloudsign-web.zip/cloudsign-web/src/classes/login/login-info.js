import { localStorageInterface, cookiesInterface } from "@classes/local-storage-interface.js"

//登录组件存储在本地的信息,封装对数据的存在和读取
const LOGINCOMPONENTLOCALINFO_LOCALSTORAGE_KEY = "wesign-login-info"

class LoginComponentLocalInfo extends localStorageInterface{
    constructor(){
        super(LOGINCOMPONENTLOCALINFO_LOCALSTORAGE_KEY)
        this.remenberAccount = false //是否记住用户名
        this.defaultUsername = "" //默认用户名
        this.showCaptcha = false //是否有验证码
        this.showEnvelopeFormsEditor = false //是否展示信封发起者的帮助
        this.showEnvelopeSignature = false //是否展示信封签署的帮助
        this.showUploadSealPrompt = false //是否显示上传印章提示框
        this.isAuthorization = false
        this.showTemplatesEpidemic = false
        this.loadFromLocal()
    }

    setShowCaptcha(nv){
        this.showCaptcha = nv
        this.saveToLocal()
    }
    
    setDefaultUsername(nv){
        this.defaultUsername = nv
        this.saveToLocal()
    }

    setRemenberAccount(nv){
        this.remenberAccount = nv
        this.saveToLocal()
    }

    setShowEnvelopeFormsEditor(nv){
        this.showEnvelopeFormsEditor = nv
        this.saveToLocal()
    }

    setShowEnvelopeSignature(nv){
        this.showEnvelopeSignature = nv
        this.saveToLocal()
    }

    setShowUploadSealPrompt(nv){
        this.showUploadSealPrompt = nv
        this.saveToLocal()
    }

    setAuthorization(nv){
        this.isAuthorization = nv
        this.saveToLocal()
    }

    setShowTemplatesEpidemic(nv){
        this.showTemplatesEpidemic = nv
        this.saveToLocal()
    }
}

export { LoginComponentLocalInfo }


//存储在本地的用户登录信息,封装对数据的存在和读取
const LOGINLOCALSTATUS_LOCALSTORAGE_KEY = "wesign-login-status"

class LoginLocalStatus extends localStorageInterface {
    constructor(){
        super(LOGINLOCALSTATUS_LOCALSTORAGE_KEY)
        this.login = false
        this.userWsid = "" //PUSER
        this.activeUserWsid = "" //当前用户ID
        this.lastActiveTime = 0
        this.loadFromLocal()

        if (Date.now() - this.lastActiveTime > 1000 * 60 * 30) this.login = false
    }

    setLogin(nv){
        this.login = nv
        this.updateLastActiveTime()
    }

    setUserWsid(nv){
        this.userWsid = nv
        this.updateLastActiveTime()
    }

    setActiveUserWsid(nv){
        this.activeUserWsid = nv
        this.updateLastActiveTime()
    }

    updateLastActiveTime(){
        this.lastActiveTime = Date.now()
        this.saveToLocal()
    }
}

export { LoginLocalStatus }


// 存储在本地的用户登录信息,封装对数据的存在和读取
const LOGINSESSIONLOCALSTATUS_LOCALSTORAGE_KEY = "wesign-login-session-status"

class LoginSessionLocalStatus extends cookiesInterface {
    constructor(){
        super(LOGINSESSIONLOCALSTATUS_LOCALSTORAGE_KEY)
        this.islogin = false
        this.sessionWsid = "" 
        this.lastActiveTime = 0
        this.loadFromLocal()
    }

    setLogin(nv){
        this.islogin = nv
        this.saveToLocal()
    }

    setSessionWsid(nv){
        this.sessionWsid = nv
        this.saveToLocal()
    }
}

export { LoginSessionLocalStatus }
