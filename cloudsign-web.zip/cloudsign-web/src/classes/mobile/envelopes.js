/* 信封状态
 * 流程未开始 0+：
 *      草稿          001 DRAFT    草稿模式
 *      等待发送(定时) 002 WAITING_FOR_SEND    定时后等待发送
 *      挂起          003 HANG_UP 信封内容缺省，需要补充内容
 *      处理中(挂起待确认)     004 HANG_UP_CONFIRM            信封内容补充完善，待确认后发送 //FIXME: 批量发送暂用，为了展示 挂起待确认 改为 处理中，并且不能进入详情页面
 * 流程中 100+：
 *      处理中(投递中)             101 DELIVERING          信封投递中
 *      处理中(流程处理中)         102 PROCESSING_AFTER_ME_COMMIT          信封处理中无人可正向操作
 *      处理中(流程结束系统处理中)  103 PROCESSING_AFTER_ALL_COMMIT           信封完成，正在做收尾处理
 *      待我签署             104 WAITING_ME_SIGN       待我签署
 *      待我审核           105 WAITING_ME_CHECK      待我签署
 *      待他人处理         106 WAITING_OTHERS_HANDLE         等待他人签署，可以发送提醒
 *      待我纠正           107 WAITING_ME_CORRECT    被回退信封，待我纠正
 *      待他人纠正         108 WAITING_OTHERS_CORRECT 被回退信封，待他人纠正
 * 流程结束 200+：
 *      已完成        201 SUCCESS_COMPLETED      信封处理完成，正常完成，合同内容生效
 *      作废 202 INVALIDATE    信封被作废
 *      已拒签      203  REJECT       信封被拒签
 *      审核未通过    204  NOT_PASS_CHECK     信封审核未通过
 *      已撤销      205  REVOKE       信封被撤销
 *      逾期未签      206  TIMEOUT      信封超过限制实现仍然未签署
 *      废弃          207  DISCARD     兼容旧系统的坏信封
 * 未知 300 不晓得是什么状态
 */

const ENVELOPE_STATUS = [
    {code: 1, key: "DRAFT", name: "草稿", description: ""},
    {code: 2, key: "WAITING_FOR_SEND", name: "等待发送", description: ""},
    {code: 3, key: "HANG_UP", name: "挂起", description: ""},
    {code: 4, key: "HANG_UP_CONFIRM", name: "处理中", description: ""},

    {code: 101, key: "DELIVERING", name: "处理中", description: ""},
    {code: 102, key: "PROCESSING_AFTER_ME_COMMIT", name: "处理中", description: ""},
    {code: 103, key: "PROCESSING_AFTER_ALL_COMMIT", name: "处理中", description: ""},
    {code: 104, key: "WAITING_ME_SIGN", name: "签署中", description: ""},
    {code: 105, key: "WAITING_ME_CHECK", name: "签署中", description: ""},
    {code: 106, key: "WAITING_OTHERS_HANDLE", name: "签署中", description: ""},
    {code: 107, key: "WAITING_ME_CORRECT", name: "待我纠正", description: ""},
    {code: 108, key: "WAITING_OTHERS_CORRECT", name: "待他人纠正", description: ""},
    {code: 109, key: "WAITING_JOIN_ENTERPRISE", name: "待加入企业", description: ""},

    {code: 201, key: "SUCCESS_COMPLETED", name: "已完成", description: ""},
    {code: 202, key: "INVALIDATE", name: "已作废", description: ""},
    {code: 203, key: "REJECT", name: "已拒签", description: ""},
    {code: 204, key: "NOT_PASS_CHECK", name: "审核未通过", description: ""},
    {code: 205, key: "REVOKE", name: "已撤销", description: ""},
    {code: 206, key: "TIMEOUT", name: "逾期未审", description: ""},
    {code: 207, key: "DISCARD", name: "废弃", description: ""},
    {code: 208, key: "OPEN_SENDER_CLEAN_AFTER_COMPLETED", name: "已完成", description: ""},
    {code: 209, key: "WEB_SELF_DELETED_TO_RECYCLE", name: "已删除", description: ""},
    {code: 210, key: "ED_FAIL_EXPIRED", name: "逾期未签", description: ""},

    {code: 300, key: "UNKOWN", name: "未知", description: ""},
]

const STATUS_KEY_MAP = {}
const STATUS_CODE_MAP = {}
const ENVELOPE_STATUS_KEY_CODE = {}
const ENVELOPE_STATUS_KEY_KEY = {}
//到状态的映射
ENVELOPE_STATUS.forEach(status => {
    STATUS_KEY_MAP[status.key] = status
    STATUS_CODE_MAP[status.code] = status
    ENVELOPE_STATUS_KEY_CODE[status.key] = status.code
    ENVELOPE_STATUS_KEY_KEY[status.key] = status.key
})

class EnvelopeStatus{
    constructor(){}

    static getCodeByKey(key){ //通过状态获取状态CODE
        let status = STATUS_KEY_MAP[key]
        if (status) return status.code
        else return 300
    }

    static getKeyByCode(code){ //通过状态CODE状态获取状态
        let status = STATUS_CODE_MAP[code]
        if (status) return status.key
        else return EnvelopeStatus.getStatusNameByCode(300)
    }

    static getStatusNameByKey(key){ //通过状态Key获取状态名称
        let status = STATUS_KEY_MAP[key]
        if (status) return status.name
        else return EnvelopeStatus.getStatusNameByCode(300)
    }

    static getStatusNameByCode(code){ //通过状态CODE状态获取状态名称
        let status = STATUS_CODE_MAP[code]
        if (status) return status.name
        else return EnvelopeStatus.getStatusNameByCode(300)
    }
    static getActionConfigByEnvelopeStatus(status, issender = false){
        //移动端

        let signable = false //是否可签署
        let auditable = false //是否可审核
        let editable = false //是否可编辑
        let canpreview = false //是否可预览文档
        let canremind = false //是否可提醒
        let downloadable = false //是否可下载
        let revokeable = false //是否可撤销
        let refusable = false //是否可以拒签
        let cannotpass = false //是否可以不通过审核
        let deleteable = false //是否可以删除
        let transferable = false //是否可以转签
        let cancelAble = false //是否可以作废
    
        if (status === "WAITING_ME_SIGN"
            || status === "WAITING_JOIN_ENTERPRISE"){ //未加入企业也可以选择，选择后会有提示
            signable = true
            refusable = status !== "WAITING_JOIN_ENTERPRISE"
            transferable = status !== "WAITING_JOIN_ENTERPRISE"
        }
    
        if (status === "WAITING_ME_CHECK"){
            auditable = true
            cannotpass = true
        }
    
        if (status !== "DRAFT"){
            canpreview = true
        } else {
            editable = true
        }
        
        if (status === "WAITING_OTHERS_HANDLE" && issender){
            canremind = true
        }

        if (status === "SUCCESS_COMPLETED"){
            downloadable = true
        }

        if (status === "SUCCESS_COMPLETED"){
            if(issender){
                cancelAble = true
            }
        }

        if (status === "WAITING_FOR_SEND"
            || status === "WAITING_ME_SIGN"
            || status === "WAITING_ME_CHECK"
            || status === "WAITING_OTHERS_HANDLE"){
            //需要满足我为发起人
            if (issender){
                revokeable = true
            }
        }

        //只有 已结束 状态的文件、草稿文件能删除，其他均不能删除
        if (status === "DRAFT"
            || status === "SUCCESS_COMPLETED"
            || status === "INVALIDATE"
            || status === "REJECT"
            || status === "NOT_PASS_CHECK"
            || status === "REVOKE"
            || status === "TIMEOUT"
            || status === "DISCARD"
            || status === "UNKOWN"){
            deleteable = true
        }
    
        return {
            signable,
            auditable,
            editable,
            canpreview,
            canremind,
            downloadable,
            revokeable,
            refusable,
            cannotpass,
            deleteable,
            transferable,
            cancelAble
        }
    }
}

export {
    EnvelopeStatus,
    ENVELOPE_STATUS_KEY_CODE,
    ENVELOPE_STATUS_KEY_KEY
}