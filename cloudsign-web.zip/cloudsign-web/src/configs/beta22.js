let config = {
    url: {
        app: "http://10.10.9.22:12080", //主站地址
        developer: "http://10.10.9.22:61113", //开放平台地址
        ws: "ws://10.10.9.22:61117", //websocket地址
        link:"http://10.10.9.22:61112"
    }
}

export { config }