let config = {
    url: {
        app: "http://47.104.133.242:61110", //主站地址
        developer: "http://47.104.133.242:61113", //开放平台地址
        ws: "ws://47.104.133.242:61117" //websocket地址
    }
}

export { config }