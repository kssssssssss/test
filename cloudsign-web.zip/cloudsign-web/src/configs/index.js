import merge from "lodash/merge"

let config = {
    url: {
        app: "", //主站地址
        developer: "", //开放平台地址
        ws: "" //websocket地址
    },
    usbkeyConnectors:[
        {
            sourceName: "北京CA",
            connectorName: "北京CA连接器",
            downloadURL: "https://pan.baidu.com/s/1xJw6SGnkOIulx64vRqh9gg" //FIXME:如何下载是个问题，连接器太大不能放入git管理
        },
    ]
}

//base -> env -> network
merge(config, require(`./${process.env.WESIGN_ENV}`).config, window.__global_config__ || {})

export default config