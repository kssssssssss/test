import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/finance/packages
 * @desc    获取套餐列表
 * @date    2018-04-13 10:18:10
 * @author  陈曦源
 * ----------------------------------------------------
 */
export function getPackages(obj) {
    let {
        filters,
        fields,
        offset = 0,
        limit = 20,
        sorts
    } = obj
    
    return axios.get("/api/finance/packages", {
        params: {
            filters,
            fields,
            offset,
            limit,
            sorts
        }
    })
}