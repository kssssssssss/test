import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @method  POST
 * @path    /api/finance/orders
 * @desc    新建订单
 * @date    2018-04-13 17:49:46
 * @author  陈曦源
 * ----------------------------------------------------
 */
export function createOrder(obj) {
    let {
        authorWsid,
        contentMetadata,
        promotionWsid,
        couponWsid,
        paymentChannel,
        payType,
        orderType = "NORMAL"
    } = obj
    
    return axios.post("/api/finance/orders", {
        authorWsid,
        contentMetadata,
        promotionWsid,
        couponWsid,
        paymentChannel,
        payType,
        orderType
    })
}

/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/finance/orders
 * @desc    获取订单列表
 * @date    2018-04-14 20:25:25
 * @author  潘维
 * ----------------------------------------------------
 */
export function getOrderLists(obj) {
    let {
        filters,
        fields,
        offset = 0,
        limit = 10,
        sorts = "-createdDatetime"
    } = obj
    
    return axios.get("/api/finance/orders", {
        params: {
            filters,
            fields,
            offset,
            limit,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/finance/orders/cancel
 * @method POST
 * @desc   取消订单
 * @author 潘维
 * @date   2018-04-23 21:24:56
 * ----------------------------------------------------
 */
export function cancelOrder(obj) {
    let {
        orderWsid
    } = obj

    return axios.post(`/api/finance/orders/cancel`, null, {
        params: {
            orderWsid
        }
    })
}