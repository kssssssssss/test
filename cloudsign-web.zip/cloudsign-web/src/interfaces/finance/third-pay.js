import axios from "@interfaces/axios.js"


/**
 * ----------------------------------------------------
 * @method  GET
 * @path    /api/finance/third-pay
 * @desc    获取支付结果
 * @date    2018-04-14 10:50:20
 * @author  陈曦源
 * ----------------------------------------------------
 */
export function getPaymentResult(obj) {
    let {
        orderWsid
    } = obj
    
    return axios.get("/api/finance/third-pay", {
        params: {
            orderWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @method  POST
 * @path    /api/finance/third-pay
 * @desc    支付请求
 * @date    2018-04-13 19:37:25
 * @author  陈曦源
 * ----------------------------------------------------
 */
export function createPayment(obj) {
    let {
        orderWsid
    } = obj
    
    return axios.post("/api/finance/third-pay", {
        orderWsid
    })
}