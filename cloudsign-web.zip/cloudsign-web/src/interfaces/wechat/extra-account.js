import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @desc  注册帐号并发短信给用户
 * @from  用户中心微服务API-Session | POST /users/extra-account
 * @date  2018-09-28 16:10:34
 * ----------------------------------------------------
 */
export function extra_account_sessions(obj) {
    let {
        uniqueCode,
        type,
        name,
        contact
    } = obj

    return axios.post("/api/wechat/extra-account", {
        uniqueCode,
        type,
        name,
        contact
    })
}
