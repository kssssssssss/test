import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/:memberWsid
 * @method POST
 * @desc   查询某位企业成员
 * @author 陈曦源
 * @date   2018-03-08 15:48:28
 * ----------------------------------------------------
 */
export function getEnterpriseMemberInfo(obj) {
    let {
        enterpriseWsid,
        memberWsid
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members/${memberWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members-search
 * @method GET
 * @desc   搜索企业成员列表
 * @author 周雪梅
 * @date   2018-08-11 19:31:07
 * ----------------------------------------------------
 */
export function searchEnterpriseMember(obj) {
    let {
        enterpriseWsid,
        sealWsid,
        sealUserType,
        isAuthorized,
        sortByGrantDatetime,
        fields,
        filters,
        offset,
        limit,
        sorts,
        scopes,
        keyword
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members-search`, {
        params: {
            sealWsid,
            isAuthorized,
            sealUserType,
            sortByGrantDatetime,
            fields,
            filters,
            offset,
            limit,
            sorts,
            scopes,
            keyword
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/batch-import
 * @method POST
 * @desc   企业批量导入成员
 * @author 周雪梅
 * @date   2018-08-22 14:53:39
 * ----------------------------------------------------
 */
export function batchImportMembers(obj) {
    let {
        enterpriseWsid,
        file
    } = obj

    let formdata = new FormData()
    formdata.append("file", file)
    return axios.post(`/api/enterprises/${enterpriseWsid}/members/batch-import`, formdata)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/batch-import/jobs
 * @method GET
 * @desc   获取批量导入成员任务列表
 * @author 周雪梅
 * @date   2018-08-22 14:53:39
 * ----------------------------------------------------
 */
export function batchImportJobsMembers(obj) {
    let {
        enterpriseWsid
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members/batch-import/jobs`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/batch-import/jobs/:jobId/executions/:executionId
 * @method GET
 * @desc   获取批量导入成员任务执行进度相关的信息
 * @author 周雪梅
 * @date   2018-08-22 14:53:39
 * ----------------------------------------------------
 */
export function batchImportJobsExecutionsMembers(obj) {
    let {
        enterpriseWsid,
        jobId,
        executionId
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members/batch-import/jobs/${jobId}/executions/${executionId}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/members/export-with-identity-status
 * @method POST
 * @desc   企业批量导出未认证成员信息
 * @author 陈曦源
 * @date   2019-08-20 15:13:49
 * ----------------------------------------------------
 */
export function exportMembersWithIdentityStatus(obj) {
    let {
        enterpriseWsid,
        onDownloadProgress
    } = obj

    return axios.get(`/api/enterprises/${enterpriseWsid}/members/export-with-identity-status`, {
        responseType:"blob",
        onDownloadProgress
    })
}