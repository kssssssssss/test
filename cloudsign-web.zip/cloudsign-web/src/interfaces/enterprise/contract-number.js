import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number/contract-number-check
 * @method POST
 * @desc   检查企业合同编号服务模块是否启用
 * @author 潘维
 * @date   2019-06-12 09:28:14
 * ----------------------------------------------------
 */

export function checkContractNumber(obj){
    let {
        enterpriseWsid,
    } = obj
    return axios.post(`/api/enterprise/${enterpriseWsid}/contract-number/contract-number-check`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number/contract-number-create
 * @method POST
 * @desc   创建企业合同编号服务模块
 * @author 潘维
 * @date   2019-06-12 09:28:14
 * ----------------------------------------------------
 */

export function createContractNumber(obj){
    let {
        enterpriseWsid,
        status = "ENABLE",
    } = obj
    return axios.post(`/api/enterprise/${enterpriseWsid}/contract-number/contract-number-create`, {
        status,
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number/:contractNumberWsid/contract-number-enable
 * @method POST
 * @desc   启用企业合同编号服务模块
 * @author 潘维
 * @date   2019-06-12 09:28:14
 * ----------------------------------------------------
 */
export function enableContractNumber(obj){
    let {
        enterpriseWsid,
        contractNumberWsid
    } = obj
    return axios.post(`/api/enterprise/${enterpriseWsid}/contract-number/${contractNumberWsid}/contract-number-enable`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number/:contractNumberWsid/contract-number-disable
 * @method POST
 * @desc   停用企业合同编号服务模块
 * @author 潘维
 * @date   2019-06-12 09:28:14
 * ----------------------------------------------------
 */
export function disableContractNumber(obj){
    let {
        enterpriseWsid,
        contractNumberWsid
    } = obj
    return axios.post(`/api/enterprise/${enterpriseWsid}/contract-number/${contractNumberWsid}/contract-number-disable`)
}