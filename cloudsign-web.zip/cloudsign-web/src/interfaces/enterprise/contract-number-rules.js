import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number-rules/create
 * @method POST
 * @desc   生成（添加）指定企业合同编号规则
 * @author 潘维
 * @date   2019-06-17 15:48:54
 * ----------------------------------------------------
 */
export function createRule(obj){
    let {
        enterpriseWsid,
        rule
    } = obj
    return axios.post(`/api/enterprise/${enterpriseWsid}/contract-number-rules/create`, {
        rule,
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number-rules/enables
 * @method GET
 * @desc   通过条件查询启用的企业合同编号规则列表
 * @author 潘维
 * @date   2019-06-17 17:18:08
 * ----------------------------------------------------
 */
export function getEnableRuleLists(obj){
    let {
        enterpriseWsid,
        fileds,
        filters,
        offset,
        limit = 10,
        sorts = "-modifiedDatetime",
    } = obj
    return axios.get(`/api/enterprise/${enterpriseWsid}/contract-number-rules/enables`, {
        params: {
            fileds,
            filters,
            offset,
            limit,
            sorts
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number-rules/disables
 * @method GET
 * @desc   通过条件查询停用的企业合同编号规则列表
 * @author 潘维
 * @date   2019-06-17 17:18:08
 * ----------------------------------------------------
 */
export function getDisableRuleLists(obj){
    let {
        enterpriseWsid,
        fileds,
        filters,
        offset,
        limit = 10,
        sorts = "-modifiedDatetime",
    } = obj
    return axios.get(`/api/enterprise/${enterpriseWsid}/contract-number-rules/disables`, {
        params: {
            fileds,
            filters,
            offset,
            limit,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/contract-number-rules/:ruleWsid/disable
 * @method POST
 * @desc   停用指定企业指定企业合同编号规则
 * @author 潘维
 * @date   2019-06-18 09:06:12
 * ----------------------------------------------------
 */
export function disableRule(obj){
    let {
        enterpriseWsid,
        ruleWsid
    } = obj
    return axios.post(`/api/enterprises/${enterpriseWsid}/contract-number-rules/${ruleWsid}/disable`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/contract-number-rules/:ruleWsid/enable
 * @method POST
 * @desc   启用指定企业指定企业合同编号规则
 * @author 潘维
 * @date   2019-06-18 09:42:13
 * ----------------------------------------------------
 */
export function enableRule(obj){
    let {
        enterpriseWsid,
        ruleWsid
    } = obj
    return axios.post(`/api/enterprises/${enterpriseWsid}/contract-number-rules/${ruleWsid}/enable`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/contract-number-rules/:ruleWsid
 * @method DELETE
 * @desc   删除指定企业指定企业合同编号规则
 * @author 潘维
 * @date   2019-06-18 09:48:36
 * ----------------------------------------------------
 */
export function deleteRule(obj){
    let {
        enterpriseWsid,
        ruleWsid
    } = obj
    return axios.delete(`/api/enterprises/${enterpriseWsid}/contract-number-rules/${ruleWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprises/:enterpriseWsid/contract-number-rules/:ruleWsid
 * @method PUT
 * @desc   更新指定企业指定企业合同编号规则
 * @author 潘维
 * @date   2019-06-18 09:48:36
 * ----------------------------------------------------
 */
export function modifyRule(obj){
    let {
        enterpriseWsid,
        ruleWsid,
        description
    } = obj
    return axios.put(`/api/enterprises/${enterpriseWsid}/contract-number-rules/${ruleWsid}`, {
        rule: {
            description
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprise/:enterpriseWsid/contract-number-rules/count
 * @method GET
 * @desc   通过条件统计指定企业合同编号规则列表
 * @author 潘维
 * @date   2019-06-28 11:26:27
 * ----------------------------------------------------
 */
export function getRulesCount(obj){
    let {
        enterpriseWsid,
        filters = "status=ENABLE",
    } = obj
    return axios.get(`/api/enterprise/${enterpriseWsid}/contract-number-rules/count`, {
        params: {
            filters,
        }
    })
}


/**
 * ----------------------------------------------------
 * @path  /api/enterprises/:enterprisesid/contract-number-rules/search
 * @method GET
 * @desc  通过条件搜索指定企业合同编号规则列表
 * @author 潘维
 * @date  2019-06-28 14:05:02
 * ----------------------------------------------------
 */
export function searchRulesList(obj){
    let {
        enterpriseWsid,
        keyword,
        scope = "content",
        fields,
        offset,
        limit = 10,
        filters = "status=ENABLE",
        sorts = "-modifiedDatetime"
    } = obj
    return axios.get(`/api/enterprise/${enterpriseWsid}/contract-number-rules/search`, {
        params: {
            filters,
            fields,
            keyword,
            scope,
            offset,
            limit,
            filters,
            sorts
        }
    })
}

