import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/contacts
 * @method PUT
 * @desc   查询联系人列表
 * @author 陈曦源
 * @date   2018-03-23 09:44:36
 * ----------------------------------------------------
 */
export function getContactsList(obj) {
    let {
        userWsid,
        fields,
        filters,
        offset = 0,
        limit = 20,
        sorts,
        keyword,
        scope
    } = obj

    return axios.get("/api/users/" + userWsid + "/contacts", {
        params: {
            fields,
            filters,
            offset,
            limit,
            sorts,
            keyword,
            scope
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/contacts
 * @method DELETE
 * @desc   删除联系人
 * @author 陈曦源
 * @date   2018-03-23 11:54:29
 * ----------------------------------------------------
 */
export function deleteContacts(obj) {
    let {
        userWsid,
        contacts
    } = obj

    return axios.delete(`/api/users/${userWsid}/contacts`, {
        data: {
            contacts
        }
    })
}

/**
 * ----------------------------------------------------
 * @desc  添加联系人
 * @from  用户中心微服务API-联系人 | POST /users/{user-wsid}/contacts
 * @date  2017-09-07 10:52:24
 * ----------------------------------------------------
 */
export function contacts_post(obj) {
    let {
        userWsid,
        nickname,
        enterpriseName,
        contact
    } = obj

    return axios.post("/api/users/" + userWsid + "/contacts", {
        nickname,
        enterpriseName,
        contact
    })

}

/**
 * ----------------------------------------------------
 * @desc  批量添加联系人
 * @from  用户中心微服务API-联系人 | POST /users/{user-wsid}/contacts/bulk
 * @date  2017-08-14 21:20:03
 * ----------------------------------------------------
 */
export function contactsBulk_post(obj) {
    let {
        userWsid,
        contactsBulk = []
    } = obj

    return axios.post("/api/users/" + userWsid + "/contacts/bulk", {
        contactsBulk
    })

}

/**
 * ----------------------------------------------------
 * @desc  删除某个联系人
 * @from  用户中心微服务API-联系人 | DELETE /users/{user-wsid}/contacts/{contacts-wsid}
 * @date  2017-09-07 15:23:22
 * ----------------------------------------------------
 */
export function contacts_delete(obj) {
    let {
        userWsid,
        contactWsid
    } = obj

    return axios.delete(`/api/users/${userWsid}/contacts/${contactWsid}`)
}

/**
 * ----------------------------------------------------
 * @desc  查询某个联系人
 * @from  用户中心微服务API-联系人 | GET /users/{user-wsid}/contacts/{contacts-wsid}
 * @date  2017-08-25 16:48:55
 * ----------------------------------------------------
 */
export function specificContacts_get(obj) {
    let {
        userWsid,
        contactsWsid,
        fields = ""
    } = obj

    return axios.get("/api/users/" + userWsid + "/contacts/" + contactsWsid, {
        params: {
            fields
        }
    })

}

/**
 * ----------------------------------------------------
 * @desc  修改联系人信息
 * @from  用户中心微服务API-联系人 | PATCH /users/{user-wsid}/contacts/{contacts-wsid}
 * @date  2017-09-08 10:18:00
 * ----------------------------------------------------
 */
export function contact_put(obj) {
    let {
        userWsid,
        contactWsid,
        nickname,
    } = obj

    return axios.put(`/api/users/${userWsid}/contacts/${contactWsid}`, {
        nickname
    })

}
