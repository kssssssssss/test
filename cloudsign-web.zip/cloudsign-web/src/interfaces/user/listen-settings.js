import axios from '@interfaces/axios.js'

/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/listen-settings
 * @method GET
 * @desc   查询用户消息设置列表
 * @author 陈曦源
 * @date   2018-02-01 21:00:30
 * ----------------------------------------------------
 */
export function getListenSettings(obj) {
    let {
        userWsid
    } = obj

    return axios.get(`/api/users/${userWsid}/listen-settings`)
}


/**
 * ----------------------------------------------------
 * @path   /api/users/:userWsid/listen-settings
 * @method PUT
 * @desc   修改用户消息设置列表
 * @author 陈曦源
 * @date   2018-02-01 21:00:32
 * ----------------------------------------------------
 */
export function updateListenSettings(obj) {
    let {
        userWsid,
        binds
    } = obj

    return axios.put(`/api/users/${userWsid}/listen-settings`, {
        binds
    })
}
