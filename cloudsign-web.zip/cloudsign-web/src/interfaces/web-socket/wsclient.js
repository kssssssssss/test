import io from "socket.io-client"
import config from "@configs"
import uuid from "uuid"

let deviceClientId = uuid.v4()
let deviceVoiceClientId = uuid.v4()
const scanUploadClient = io(`${config.url.ws}/scan-upload`)
const backendClient = io(`${config.url.ws}/backend`)
const deviceClient = io(`${config.url.ws}/device?deviceId=${deviceClientId}`)
const deviceVoiceClient = io(`${config.url.ws}/device?deviceId=${deviceVoiceClientId}`)
export {
    scanUploadClient,
    backendClient,
    deviceClient,
    deviceClientId,
    deviceVoiceClient,
    deviceVoiceClientId
}