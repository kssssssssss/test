import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/client-back-log
 * @method GET
 * @desc   前端日志回传,用于收集埋点数据,分析错误根源
 * @author 陈曦源
 * @date   2019-05-29 09:02:29
 * ----------------------------------------------------
 */
export function sendClientLog(log) {
    return axios.post("/api/client-back-log", log)
}
