import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts
 * @method GET
 * @desc   查询最新版本的业务场景模板
 * @author 潘维
 * @date   2018-11-16 09:54:27
 * ----------------------------------------------------
 */
export function getTemplatesList(obj) {
    let {
        fields = "wsid,name,authorWsid,status,avatar_file_wsid,configVersion,createdDatetime,description",
        status,
        offset = 0,
        limit = 10,
        sorts = "-createdDatetime",
    } = obj

    return axios.get(`/api/templates/bsts`, {
        params: {
            fields,
            status,
            offset,
            limit,
            sorts,
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts/${bstWsid}/bst-avatars/form-upload
 * @method POST
 * @desc   指定业务场景模板自身form上传头像文件
 * @author 潘维
 * @date   2018-11-19 10:33:01
 * ----------------------------------------------------
 */
export function template_avatars_post(obj) {
    let {
        bstWsid,
        file
    } = obj

    let formdata = new FormData()
    formdata.append("file", file)
    return axios.post(`/api/templates/bsts/${bstWsid}/bst-avatars/form-upload`, formdata)
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts
 * @method POST
 * @desc   创建业务场景模板
 * @author 潘维
 * @date   2018-11-21 09:42:04
 * ----------------------------------------------------
 */
export function createTemplate(obj) {
    let {
        name,
        authorWsid,
        avatarFileWsid,
        configContent,
        description,
        bstGroupWsid
    } = obj
    return axios.post(`/api/templates/bsts`, {
        name,
        authorWsid,
        avatarFileWsid,
        configContent,
        description,
        bstGroupWsid
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts/:bstWsid/enable
 * @method POST
 * @desc   启用指定业务场景模板
 * @author 潘维
 * @date   2018-11-23 10:11:55
 * ----------------------------------------------------
 */

export function enableTemplate(obj){
    let {
        bstWsid
    } = obj
    return axios.post(`/api/templates/bsts/${bstWsid}/enable`)
} 

/* @path   /api/templates/template
 * @method post
 * @desc   更新业务场景模板
 * @author 李鹏
 * @date   2018-11-22 19:42:04
 * ----------------------------------------------------
 */
export function updateTemplate(obj) {
    let {
        bstWsid,
        name,
        avatarFileWsid,
        configContent,
        description,
    } = obj
    return axios.post(`/api/templates/template`, {
        name,
        avatarFileWsid,
        configContent,
        description,
    }, {
        params: {
            bstWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/template
 * @method GET
 * @desc   查询指定业务场景模板
 * @author 李鹏
 * @date   2018-11-23 9:42:04
 * ----------------------------------------------------
 */
export function getTemplateDate(obj) {
    let {
        bstWsid
    } = obj
    return axios.get(`/api/templates/template`, {
        params: {
            bstWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts/:bstWsid/envelopes
 * @method POST
 * @desc   指定业务场景模板创建信封
 * @author 潘维
 * @date   2018-11-26 10:07:43
 * ----------------------------------------------------
 */

export function templateToEnvelop(obj = {}){
    let {
        bstWsid,
        senderWsid,
        tagId,
        envelopeType = "ANY",
        envelopeFlag,
        metadata
    } = obj
    return axios.post(`/api/templates/bsts/${bstWsid}/envelopes`, {
        senderWsid,
        tagId,
        envelopeType,
        envelopeFlag,
        metadata
    })
} 

/* @path   /api/templates/:bstWsid/documents
 * @method POST
 * @desc   上传模版文档
 * @author 李鹏
 * @date   2018-11-23 9:42:04
 * ----------------------------------------------------
 */
export function uploadTemplateDocument(obj) {
    let {
        bstWsid,
        file,
        fileOwnerPassin,
        fileHash,
        isAttached
    } = obj
    let formdata = new FormData()
    formdata.append("properties", JSON.stringify({
        fileOwnerPassin,
        fileHash,
        isAttached
    }))
    formdata.append("file", file)
    return axios.post(`/api/templates/${bstWsid}/documents`, formdata)
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts/source-files/:fileWsid/download
 * @method GET
 * @desc   下载信封内容原始文件
 * @author 潘维 陈曦源
 * @date   2019-11-14 11:14:35
 * ----------------------------------------------------
 */
export function downLoadTemplateDocument(obj) {
    let {
        fileWsid,
        name,
    } = obj

    window.open(`/api/templates/bsts/source-files/${fileWsid}/download?filename=${name}`)

    return Promise.resolve()
}

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts/:bstWsid/detele
 * @method DELETE
 * @desc   删除指定业务场景模板
 * @author 周雪梅
 * @date   2019-05-08 14:49:12
 * ----------------------------------------------------
 */

export function deleteTemplate(obj){
    let {
        bstWsid
    } = obj
    return axios.delete(`/api/templates/bsts/${bstWsid}/delete`)
} 

/**
 * ----------------------------------------------------
 * @path   /api/templates/bsts/:bstWsid/disable
 * @method POST
 * @desc   停用指定业务场景模板
 * @author 周雪梅
 * @date   2019-05-08 14:49:03
 * ----------------------------------------------------
 */

export function disableTemplate(obj){
    let {
        bstWsid
    } = obj
    return axios.post(`/api/templates/bsts/${bstWsid}/disable`)
} 

