function query(location) {
  let query = new Object();
  let query_arr = location.search.replace('?', '').split('&');
  for (let query_list of query_arr) {
    let query_tmp = query_list.split('=');
    query[query_tmp[0]] = query_tmp[1];
  }
  return query;
}

export default query;
export {query};
