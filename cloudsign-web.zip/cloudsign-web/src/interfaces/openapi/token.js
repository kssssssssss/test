import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/openapi/token/:tokenWsid
 * @method GET
 * @desc   查询token信息
 * @author 陈曦源
 * @date   2019-08-26 17:08:59
 * ----------------------------------------------------
 */
export function getTokenInfo(obj) {
    let {
        tokenWsid,
    } = obj

    return axios.get(`/api/openapi/token/${tokenWsid}`)
}