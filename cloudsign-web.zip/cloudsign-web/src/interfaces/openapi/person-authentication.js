import axios from "@interfaces/axios.js"
import uuid from "uuid"
// import { deviceClient, deviceClientId, } from "@interfaces/web-socket/wsclient.js"
// import { ERROR_CODES, createErrorByCode } from "@errors/code.js"

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid
 * @method GET
 * @desc   查找指定个人实名认证流程信息
 * @author 陈曦源
 * @date   2019-07-29 10:47:35
 * ----------------------------------------------------
 */
export function getPersonAuthenticationInfo (obj) {
    let {
        idttyWsid,
        token
    } = obj

    return axios.get(`/api/openapi/person-authentications/${idttyWsid}`, {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid/captcha/sms-code
 * @method POST
 * @desc   发送实名认证手机验证码
 * @author 陈曦源
 * @date   2019-07-30 10:13:36
 * ----------------------------------------------------
 */
export function sendSMSCode(obj) {
    let {
        idttyWsid,
        token,
        phone,
        service
    } = obj

    return  axios.post(`/api/openapi/person-authentications/${idttyWsid}/captcha/sms-code`, {
        phone,
        service,
    }, {
        params: {
            token
        }
    })

}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid/file-upload
 * @method POST
 * @desc   上传认证图片
 * @author 陈曦源
 * @date   2019-07-31 09:03:43
 * ----------------------------------------------------
 */
export function uploadAuthenticationFile(obj) {
    let {
        idttyWsid,
        token,
        imageCode,
        file,
        onUploadProgress
    } = obj

    let formData = new FormData()
    formData.set("file", file)
    return axios.post(`/api/openapi/person-authentications/${idttyWsid}/files/form-upload`, formData, {
        params: {
            token,
            imageCode
        },
        onUploadProgress
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid/ocrs/idcard
 * @method POST
 * @desc   ocr识别身份证中的数据
 * @author 陈曦源
 * @date   2019-08-02 14:48:03
 * ----------------------------------------------------
 */
export function getIDCardOCRResult(obj) {
    let {
        idttyWsid,
        token,
        fileWsid
    } = obj

    return axios.post(`/api/openapi/person-authentications/${idttyWsid}/ocrs/idcard`, null, {
        params: {
            token,
            fileWsid
        },
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/verifications/person/auth-flow'
 * @method POST
 * @desc   开启个人认证流程
 * @author 马羽
 * @date   2020-4-29
 * ----------------------------------------------------
 */

export function startPersonAuthProcess(obj) {
    let {
        authModes,
        presetPersonAuthentications,
        returnUrl 
    } = obj

    return axios.post('/api/openapi/person-authentications/verifications/person/auth-flow', {
        authModes,
        presetPersonAuthentications,
        returnUrl
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid/submit
 * @method POST
 * @desc   提交手机实名信息
 * @author 马羽
 * @date   2020-4-30
 * ----------------------------------------------------
 */
export function authPersonPhoneSubmit(obj) {
    let { 
        idttyWsid,
        captcha,
        token,
        authMode,
        name,
        phone,
        idCardNo,
        idCardType,
        fromTag
    } = obj

    return axios.post(`/api/openapi/person-authentications/${idttyWsid}/submit`, {
        authMode,
        name,
        phone,
        idCardNo,
        idCardType,
        captcha,
        fromTag
    }, {
        params: {
            token
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid/generate-faceid-url
 * @method POST
 * @desc   生成faceidURL
 * @author 马羽
 * @date   2020-5-5
 * ----------------------------------------------------
 */

export function generateFaceidUrl(obj) {
    let { 
        idttyWsid,
        token,
        authMode,
        name,
        idCardNo,
        idCardType,
        requestId,
        deviceId,
        returnUrl
    } = obj
    return axios.post(`/api/openapi/person-authentications/${idttyWsid}/generate-faceid-url`, {
        idttyWsid,
        token,
        authMode,
        name,
        idCardNo,
        idCardType,
        requestId,
        deviceId,
        returnUrl
    }, {
        params: {
            token,
            idttyWsid
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/third-verifications/zhima-idttv
 * @method POST
 * @desc   生成支付宝url
 * @author 马羽
 * @date   2020-5-5
 * ----------------------------------------------------
 */

export function generateAlipayUrl(obj) {
    let { 
        token,
        certName,
        certNo,
        userPersonWsid,
        idttvType,
        requestId,
        deviceId,
        returnUrl
    } = obj
    
    return axios.post(`/api/openapi/person-authentications/third-verifications/zhima-idttv`, {
        certName,
        certNo,
        userPersonWsid,
        idttvType,
        requestId,
        deviceId,
        returnUrl
    }, {
        params: {
            token
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/links/parse
 * @method POST
 * @desc   将支付宝的内网url转换成外网能访问的url
 * @author 马羽
 * @date   2020-5-5
 * ----------------------------------------------------
 */


export function parseLink({ token, body }) {
    return axios.post('/api/openapi/person-authentications/links/parse', body, {
        params: {
            token
        }
    })
}


/**
 * faceID socket接受消息
 */

export function socketFaceID() {
    return uuid.v4()
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid
 * @method PUT
 * @desc   更新个人实名认证流程信息
 * @author 陈曦源
 * @date   2019-07-29 10:47:35
 * ----------------------------------------------------
 */
export function updataPersonAuthenticationInfo (obj) {
    let {
        idttyWsid,
        token,
        name,
        phone,
        idCardNo,
        idCardType,
        status
    } = obj

    return axios.put(`/api/openapi/person-authentications/${idttyWsid}`, {
        name,
        phone,
        idCardNo,
        idCardType,
        status,
    }, 
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/third-verifications/dyrz-idttv
 * @method POST
 * @desc   生成上海ca多源认证(替换支付宝)二维码
 * @author 周雪梅
 * @date   2020-08-04 20:41:51
 * ----------------------------------------------------
 */

export function generatedDyrzCode(obj) {
    let { 
        token,
        certName,
        certNo,
        userPersonWsid,
        idNoType,
        requestId,
        deviceId,
        returnUrl
    } = obj
    
    return axios.post(`/api/openapi/person-authentications/third-verifications/dyrz-idttv`, {
        certName,
        certNo,
        userPersonWsid,
        idNoType,
        requestId,
        deviceId,
        returnUrl
    }, {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/third-verifications/dyrz-idttv/get-qrcode-url
 * @method POST
 * @desc   生成上海ca多源认证(替换支付宝)二维码
 * @author 周雪梅
 * @date   2020-08-04 20:41:51
 * ----------------------------------------------------
 */

export function generatedDyrzUrl(obj) {
    let { 
        token,
        certName,
        certNo,
        userPersonWsid,
        idNoType,
        requestId,
        deviceId,
        returnUrl
    } = obj
    
    return axios.post(`/api/openapi/person-authentications/third-verifications/dyrz-idttv/get-qrcode-url`, {
        certName,
        certNo,
        userPersonWsid,
        idNoType,
        requestId,
        deviceId,
        returnUrl
    }, {
        params: {
            token
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/person-authentications/:idttyWsid
 * @method GET
 * @desc   查找指定个人实名认证流程信息
 * @author 陈曦源
 * @date   2019-07-29 10:47:35
 * ----------------------------------------------------
 */
export function getPersonDyrzAuthenticationInfo (obj) {
    let {
        bizNo,
        token,
        userToken
    } = obj

    return axios.get(`/api/openapi/person-authentications/third-verifications/dyrz-idttv/notify`, {
        params: {
            token,
            bizNo,
            userToken
        }
    })
}