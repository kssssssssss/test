import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid
 * @method GET
 * @desc   查找指定企业实名认证流程信息
 * @author 周雪梅
 * @date   2019-07-29 10:47:35
 * ----------------------------------------------------
 */
export function getEnterpriseAuthenticationInfo (obj) {
    let {
        enterpriseAuthenticationWsid,
        token
    } = obj

    return axios.get(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}`, {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/files/power-of-attorney-file
 * @method GET
 * @desc   获取（下载）指定企业实名认证流程中授权委托书文件（文件模板支持通过全局配置设置）
 * @author 周雪梅 陈曦源
 * @date   2019-11-14 10:38:03
 * ----------------------------------------------------
 */
export function getGlobalConfigPowerOfAttorneyFile (obj) {
    let {
        enterpriseAuthenticationWsid,
        token
    } = obj

    window.open(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/files/power-of-attorney-file?token=${token}&filename=授权委托书.pdf`)

    return Promise.resolve()
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:personAuthenticationWsid
 * @method PUT
 * @desc   更新指定企业实名认证流程信息
 * @author 周雪梅
 * @date   2019-08-12 19:18:33
 * ----------------------------------------------------
 */
export function updataEnterpriseAuthenticationInfo (obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        authMode,
        enterprise
    } = obj

    return axios.put(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}`, {
        enterprise,
        authMode
    }, {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/tokens/:token
 * @method GET
 * @desc   查询token是否有效
 * @author 周雪梅
 * @date   2019-08-17 09:59:58
 * ----------------------------------------------------
 */
export function checkEnterpriseAuthenticationToken (obj) {
    let {
        enterpriseAuthenticationWsid,
        tokenWsid
    } = obj
    return axios.get(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/tokens/${tokenWsid}`)
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/submit
 * @method POST
 * @desc   提交认证资料
 * @author 周雪梅
 * @date   2019-08-17 09:59:54
 * ----------------------------------------------------
 */
export function submitAuthenticationData(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        authMode
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/submit`, {
        authMode
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/file-upload
 * @method POST
 * @desc   上传营业执照图片
 * @author 周雪梅
 * @date   2019-08-12 19:23:29
 * ----------------------------------------------------
 */
export function uploadBusinessLicenseFile(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        file,
        onUploadProgress
    } = obj

    let formData = new FormData()
    formData.append("file", file)

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/business-license-file-upload`, formData, {
        params: {
            token,
        },
        onUploadProgress
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/power-of-attorney-file-upload
 * @method POST
 * @desc   上传授权委托书图片
 * @author 周雪梅
 * @date   2019-08-12 19:23:25
 * ----------------------------------------------------
 */
export function uploadPowerOfAttorneyFile(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        file,
        onUploadProgress
    } = obj

    let formData = new FormData()
    formData.append("file", file)

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/power-of-attorney-file-upload`, formData, {
        params: {
            token,
        },
        onUploadProgress
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/ocrs/business-license
 * @method POST
 * @desc   ocr识别营业执照中的数据
 * @author 周雪梅
 * @date   2019-08-12 14:48:03
 * ----------------------------------------------------
 */
export function getBusinessLicenseOCRResult(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        fileWsid
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/ocrs/business-license`, null, {
        params: {
            token,
            fileWsid
        },
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/reset
 * @method POST
 * @desc   失败后切换认证方式重置认证状态,每日限制重置五次
 * @author 周雪梅
 * @date   2020-04-26 09:45:06
 * ----------------------------------------------------
 */
export function resetEnterpriseAuthenticationInfo (obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        authmode
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/reset/${authmode}`,null, {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/file-upload
 * @method POST
 * @desc   上传法人/代理人身份证
 * @author 周雪梅
 * @date   2020-04-15 19:54:40
 * ----------------------------------------------------
 */
export function uploadIdCardFile(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        file,
        imageCode,
        onUploadProgress
    } = obj

    let formData = new FormData()
    formData.append("file", file)

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/image-form-upload`, formData, {
        params: {
            token,
            imageCode,
        },
        onUploadProgress
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/submit
 * @method POST
 * @desc   提交认证资料
 * @author 周雪梅
 * @date   2020-04-26 09:44:59
 * ----------------------------------------------------
 */
export function submitAuthenticationCertificateInfo(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        enterpriseAuthType,
        area,
        idCardType
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/submit-certificate-info`, {
        enterpriseAuthType,
        area,
        idCardType
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/submit
 * @method POST
 * @desc   填写基本信息
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function submitAuthenticationBaseInfoData(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        area,
        organizationType,
        name,
        unifiedSocialCreditCode,
        legalPersonName,
        authMode
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/submit-base-info`, {
        area,
        organizationType,
        name,
        unifiedSocialCreditCode,
        legalPersonName,
        authMode
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/phone-four
 * @method POST
 * @desc   手机3要素及工商4要素认证
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function phoneFour(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        enterpriseAuthType,
        captchaCode,
        idCardNo,
        phone
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/phone-four`, {
        enterpriseAuthType,
        captchaCode,
        idCardNo,
        phone
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/senior-check
 * @method PUT
 * @desc   小额确认收到金额确认检查
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function seniorCheck(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        checkSum
    } = obj

    return axios.put(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/senior-check`, {
        checkSum
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/senior-check
 * @method POST
 * @desc   小额打款认证申请
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function seniorAuthApply(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        bankCardNo,
        bank,
        bankBranch
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/senior`, {
        bankCardNo,
        bank,
        bankBranch
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/senior-check
 * @method POST
 * @desc   发送手机验证码
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function captchaCode(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        phone
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/captcha-code`, {
        phone
    },
    {
        params: {
            token
        }
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/openapi/verifications/enterprise/auth-flow
 * @method POST
 * @desc   企业去认证
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function authFlow(obj) {
    let {
        returnUrl
    } = obj

    return axios.post(`/api/openapi/verifications/enterprise/auth-flow`, {
        returnUrl
    })
}

  /**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/sheca-senior-check
 * @method POST
 * @desc   上海ca企业实名认证流程-对公打款认证信息-金额校验
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function shecaSeniorCheck(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        amount
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/sheca-senior-check`, {
        amount
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/sheca-senior
 * @method POST
 * @desc   上海ca企业实名认证流程-对公打款认证信息-提交
 * @author 周雪梅
 * @date   2020-04-26 09:44:55
 * ----------------------------------------------------
 */
export function shecaSeniorAuthApply(obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        bankCardNo,
        bank,
        bankBranch
    } = obj

    return axios.post(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/sheca-senior`, {
        bankCardNo,
        bank,
        bankBranch
    },
    {
        params: {
            token
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/openapi/enterprise-authentications/:enterpriseAuthenticationWsid/bank-name
 * @desc   上海ca企业实名认证流程-对公打款认证查询银行信息
 * @author 周雪梅
 * @date   2020-07-28 10:54:26
 * ----------------------------------------------------
 */
export function getBankName (obj) {
    let {
        enterpriseAuthenticationWsid,
        token,
        bankCode,
        bankName,
        pageNumber,
        pageSize
    } = obj
    return axios.get(`/api/openapi/enterprise-authentications/${enterpriseAuthenticationWsid}/bank-name`,{
        params:{
            token,
            bankCode,
            bankName,
            pageNumber,
            pageSize
        }
    })
}
