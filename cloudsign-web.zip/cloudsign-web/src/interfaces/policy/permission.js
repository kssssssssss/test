import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @path   /api/enterprise-roles/users/:userWsid/privileges
 * @method GET
 * @desc   查询指定用户在指定企业中拥有的权限
 * @author 潘维
 * @date   2019-04-30 09:50:10
 * ----------------------------------------------------
 */
export function getPermissionLists(obj) {
    let {
        userWsid,
    } = obj

    return axios.get(`/api/enterprise-roles/users/${userWsid}/privileges`)
}

/**
 * ----------------------------------------------------
 * @path   /api/enterprise-role/:enterpriseRoleWsid/privileges
 * @method GET
 * @desc   查询查询企业角色权限列表
 * @author 潘维
 * @date   2019-04-30 19:00:18
 * ----------------------------------------------------
 */
export function getRolePermissions(obj) {
    let {
        enterpriseRoleWsid,
    } = obj

    return axios.get(`/api/enterprise-roles/${enterpriseRoleWsid}/privileges`)
}