import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @desc  获取标签列表: 获取所有标签列表
 * @from  标签管理微服务-获取标签 | GET /labels
 * @date  2017-07-31 15:48:52
 * ----------------------------------------------------
 */
export function labels_get(obj) {
    let {
        fields = null,
        filters = null,
        offset = 0,
        limit = 20,
        sorts = null
    } = obj

    return axios.get("/api/labels", {
        params: {
            fields,
            filters,
            offset,
            limit,
            sorts
        }
    })

}

/**
 * ----------------------------------------------------
 * @desc  获取单个标签
 * @from  标签管理微服务-获取标签 | GET /labels/{label-wsid}
 * @date  2017-07-31 15:48:52
 * ----------------------------------------------------
 */
export function specificLabel_get(obj) {
    let {
        labelWsid,
        fields = null,
        filters = null,
        offset = 0,
        limit = 20,
        sorts = null
    } = obj

    return axios.get("/api/labels/" + labelWsid, {
        params: {
            fields,
            filters,
            offset,
            limit,
            sorts
        }
    })

}

/**
 * ----------------------------------------------------
 * @desc  批量获取标签
 * @from  标签管理微服务-获取标签 | GET /labels/bulk
 * @date  2017-07-31 15:49:14
 * ----------------------------------------------------
 */
export function labelsBulk_get(obj) {
    let {
        fields = null,
        filters = null,
        offset = 0,
        limit = 20,
        sorts = null,
        labels = []
    } = obj

    return axios.get("/api/labels/bulk", { //同时有query和body，验证下此情况下是否正确
        params: {
            fields,
            filters,
            offset,
            limit,
            sorts
        },
        labels
    })

}





/* ---------- 创建标签 ---------- */

/**
 * ----------------------------------------------------
 * @desc  创建单个标签: 创建一个标签
 * @from  标签管理微服务-创建标签 | POST /labels
 * @date  2017-07-31 15:49:27
 * ----------------------------------------------------
 */
export function labels_post(obj) {
    let {
        labelWsid,
        color,
        text
    } = obj

    return axios.post("/api/labels", {
        labelWsid,
        color,
        text
    })

}

/**
 * ----------------------------------------------------
 * @desc  批量添加标签
 * @from  标签管理微服务-创建标签 | POST /labels/bulk
 * @date  2017-07-31 15:49:35
 * ----------------------------------------------------
 */
export function labelsBulk_post(obj) {
    let {
        labels = []
    } = obj

    return axios.post("/api/labels/bulk", {
        labels
    })

}





/* ---------- 更新标签 ---------- */

/**
 * ----------------------------------------------------
 * @desc  更新单个标签
 * @from  标签管理微服务-更新标签 | PUT /labels/{label-wsid}
 * @date  2017-07-31 15:49:48
 * ----------------------------------------------------
 */
export function specificLabel_put(obj) {
    let {
        labelWsid,
        color,
        text
    } = obj

    return axios.put("/api/labels/" + labelWsid, {
        color,
        text
    })

}

/**
 * ----------------------------------------------------
 * @desc  批量更新标签
 * @from  标签管理微服务-更新标签 | PUT /labels/bulk
 * @date  2017-07-31 15:49:59
 * ----------------------------------------------------
 */
export function labelsBulk_put(obj) {
    let {
        labels = []
    } = obj

    return axios.put("/api/labels/bulk", {
        labels
    })

}





/* ---------- 删除标签 ---------- */

/**
 * ----------------------------------------------------
 * @desc  删除单个标签
 * @from  标签管理微服务-删除标签 | DELETE /labels/{label-wsid}
 * @date  2017-07-31 15:50:26
 * ----------------------------------------------------
 */
export function specificLabel_delete(obj) {
    let {
        labelWsid
    } = obj

    return axios.delete("/api/labels/" + labelWsid, {})

}

/**
 * ----------------------------------------------------
 * @desc  批量删除标签
 * @from  标签管理微服务-删除标签 | DELETE /labels/bulk
 * @date  2017-07-31 15:50:59
 * ----------------------------------------------------
 */
export function labelsBulk_delete(obj) {
    let {
        labels = []
    } = obj

    return axios.delete("/api/labels/bulk", {
        labels
    })

}







export function getLabels() {
    return axios.get("/api/labels")
}

export function postLabels(obj) {
    let {
        label, //单个标签Id
        labels = [] //多个
    } = obj

    if (label != undefined) labels.push(label)

    return axios.post("/api/labels", {
        labels
    })
}

export function putLabels(obj){
    let {
        label, //单个标签Id
        labels = [] //多个
    } = obj

    if (label != undefined) labels.push(label)

    return axios.put("/api/labels", {
        labels
    })
}


export function delLabels(obj){
    let {
        labelId, //单个标签Id
        labelIds = [] //多个
    } = obj

    if (labelId != undefined) labelIds.push(labelId)


    return axios.delete("/api/labels", {
        data: {
            labels: labelIds
        }
    })
}
