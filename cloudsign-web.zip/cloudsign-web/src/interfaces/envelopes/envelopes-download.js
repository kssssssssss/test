/**
 * ----------------------------------------------------
 * @path   /api/envelopes/contents/pack/bulk
 * @method POST
 * @desc   打包下载多组文件
 * @author 潘维 陈曦源
 * @date   2019-11-14 11:15:31
 * ----------------------------------------------------
 */
export function downLoadEnvelopes(obj) {
    let {
        envelopes,
        withAudit
    } = obj
    
    window.open(`/api/envelopes/contents/pack/bulk?envelopes=${envelopes.join(",")}&withAudit=${withAudit}&filename=文件.zip`)

    return Promise.resolve()
}