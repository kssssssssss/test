
import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contract-number-rules/:contractNumberRuleWsid
 * @method POST
 * @desc   指定信封使用指定编号规则
 * @author 潘维
 * @date   2019-07-12 13:51:05
 * ----------------------------------------------------
 */
export function useContractNumberRule(obj){
    let {
        envelopeWsid,
        contractNumberRuleWsid
    } = obj
    return axios.post(`/api/envelopes/${envelopeWsid}/contract-number-rules/${contractNumberRuleWsid}`)
}


 
/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contract-number-rules/:contractNumberRuleWsid
 * @method DELETE
 * @desc   指定信封删除指定编号规则
 * @author 潘维
 * @date   2019-07-12 13:52:34
 * ----------------------------------------------------
 */
export function deleteEnvelopeContractNumberRule(obj) {
    let {
        envelopeWsid,
        contractNumberRuleWsid
    } = obj

    return axios.delete(`/api/envelopes/${envelopeWsid}/contract-number-rules/${contractNumberRuleWsid}`)
}