import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @path   /api/envelopes/cancel-process
 * @method POST
 * @desc   启动信封作废流程（创建一个空的信封，并更新待作废的合同进去
 * @author 周雪梅
 * @date   2020-05-19 14:33:12
 * ----------------------------------------------------
 */
export function cancelProcess(obj = {}){
    let {
        senderWsid,
        tagId,
        envelopeFlowType = "CANCEL_PROCESS",
        envelopeFlag,
        completedEnvelopeWsid,
        title,
        cancelAnnounceFile
    } = obj

    return axios.post("/api/envelopes/cancel-process", {
        senderWsid,
        tagId,
        envelopeFlowType,
        envelopeFlag,
        completedEnvelopeWsid,
        title,
        cancelAnnounceFile
    })
}

/**
 * ----------------------------------------------------
 * @path    /api/envelopes/:envelopeWsid/cancel-announce-templete/create
 * @method  POST
 * @desc    生成默认的合同作废模板
 * @author  周雪梅
 * @date    2020-05-19 14:32:58
 * ----------------------------------------------------
 */
export function createCancelAnnounceTemplete(obj = {}){
    let {
        envelopeWsid,
        templeteFileWsid,
        cancelReason,
        completedEnvelopeWsid,
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/cancel-announce-templete/create`,{
        templeteFileWsid,
        cancelReason,
        completedEnvelopeWsid,
    })
}
