import axios from "@interfaces/axios.js"
import { CancelToken, isCancel } from "axios"

/**
 * ----------------------------------------------------
 * @path  /api/:userWsid/envelops
 * @method GET
 * @desc  获取信封列表
 * @author 陈曦源
 * @date  2018-08-11 11:08:38
 * ----------------------------------------------------
 */
export function getEnvelopes(obj = {}) {
    let {
        authorWsid,
        envelopeShownStatus = "ALL",
        participantName,
        fields,
        filters,
        offset = 0,
        limit = 20,
        sorts = "-status_datetime"
    } = obj

    let source = CancelToken.source()

    let handle = axios.get("/api/envelopes", {
        params: {
            authorWsid,
            envelopeShownStatus,
            participantName,
            fields,
            filters,
            offset,
            limit,
            sorts
        },
        cancelToken: source.token
    }).catch(err => {
        if (isCancel(err)){
            err.isCancel = true
        }
        return Promise.reject(err)
    })

    handle.cancel = function(msg){
        source.cancel(msg)
    }
    
    return handle
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid
 * @method POST
 * @desc   获取指定信封
 * @author 陈曦源
 * @date   2018-01-15 19:21:28
 * ----------------------------------------------------
 */
export function getEnvelopeData(obj = {}){
    let {
        envelopeWsid,
        fields
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}`, {
        params: {
            fields
        }
    })
}

/**
 * ----------------------------------------------------
 * @path  /api/envelopes
 * @method POST
 * @desc  创建信封
 * @author 陈曦源
 * @date  2018-01-08 20:05:31
 * ----------------------------------------------------
 */
export function createEnvelope(obj = {}){
    let {
        senderWsid,
        tagId,
        envelopeType = "ANY",
        envelopeFlag
    } = obj

    return axios.post("/api/envelopes", {
        senderWsid,
        tagId,
        envelopeType,
        envelopeFlag
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/recycled
 * @method POST
 * @desc   移动信封到回收站
 * @author 陈曦源
 * @date   2018-01-15 17:05:29
 * ----------------------------------------------------
 */
export function recycledEnvelope(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/recycled`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/multisend-start
 * @method POST
 * @desc   启动批量信封
 * @author 潘维
 * @date   2018-01-22 21:47:06
 * ----------------------------------------------------
 */
export function startMultisendEnvelope(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/multisend-start`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/multisend-jobs
 * @method GET
 * @desc   查看指定批量信封发送的JOB信息
 * @author 潘维
 * @date   2018-10-09 10:24:12
 * ----------------------------------------------------
 */
export function getMultisendJobs(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/multisend-jobs`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/multisend-jobs/:jobId/executions/:executionId
 * @method GET
 * @desc   查看指定批量信封发送的JOB信息
 * @author 潘维
 * @date   2018-10-09 10:24:12
 * ----------------------------------------------------
 */
export function getMultisendJobsDetails(obj = {}) {
    let {
        envelopeWsid,
        jobId,
        executionId
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/multisend-jobs/${jobId}/executions/${executionId}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/start
 * @method POST
 * @desc   启动信封
 * @author 陈曦源
 * @date   2018-01-22 21:47:06
 * ----------------------------------------------------
 */
export function startEnvelope(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/start`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid
 * @method PUT
 * @desc   更新指定信封
 * @author 陈曦源
 * @date   2018-08-29 20:19:08
 * ----------------------------------------------------
 */
export function updateEnvelopeData(obj = {}){
    let {
        envelopeWsid,
        title,
        subject,
        expireDatetime,
        timerDatetime,
        needForm,
        metadata
    } = obj

    return axios.put(`/api/envelopes/${envelopeWsid}`, {
        title,
        subject,
        expireDatetime,
        timerDatetime,
        needForm,
        metadata
    })
}

/**
 * ----------------------------------------------------
 * @path  /api/envelopes/:enterpriseWsid/enterprise
 * @method GET
 * @desc   查看企业所有信封
 * @author 潘维
 * @date 2019-03-13 09:25:44
 * ----------------------------------------------------
 */
export function getEnterpriseAllEnvelopes(obj = {}) {
    let {
        enterpriseWsid,
        envelopeShownStatus = "ALL",
        participantName,
        fields,
        filters,
        offset = 0,
        limit = 20,
        sorts = "-status_datetime"
    } = obj

    let source = CancelToken.source()

    let handle = axios.get(`/api/envelopes/${enterpriseWsid}/enterprise`, {
        params: {
            envelopeShownStatus,
            participantName,
            fields,
            filters,
            offset,
            limit,
            sorts
        },
        cancelToken: source.token
    }).catch(err => {
        if (isCancel(err)){
            err.isCancel = true
        }
        return Promise.reject(err)
    })
    handle.cancel = function(msg){
        source.cancel(msg)
    }
    
    return handle
}