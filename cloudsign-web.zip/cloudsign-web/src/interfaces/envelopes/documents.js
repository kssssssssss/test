import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents
 * @method GET
 * @desc   获取信封文档列表
 * @author 陈曦源
 * @date   2018-01-15 21:18:55
 * ----------------------------------------------------
 */
export function getEnvelopeDocuments(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/documents`).then(data => {
        let documents = data.data.data.documents
        if (documents.every(_ => _.sequence)){
            documents.sort((a, b) => a.sequence - b.sequence)
        }
        return data
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents
 * @method POST
 * @desc   上传文档
 * @author 陈曦源
 * @date   2019-04-09 20:53:34
 * ----------------------------------------------------
 */
export function uploadEnvelopeDocument(obj = {}) {
    let {
        envelopeWsid,
        authorWsid,
        file,
        fileName = "",
        isAttached = false,
        fileOwnerPassin,
        fileTagId = null,
        sequence,
        fileType
    } = obj

    //削减文件名
    let filenames = fileName.split(".")
    //后缀
    let dx = filenames.pop()
    filenames = filenames.join(".").substr(0, 40)
    fileName = `${filenames}.${dx}`

    let formdata = new FormData()
    formdata.append("properties", JSON.stringify({
        fileName,
        isAttached,
        authorWsid,
        fileOwnerPassin,
        fileTagId,
        sequence,
        fileType
    }))
    
    formdata.append("file", file)

    return axios.post(`/api/envelopes/${envelopeWsid}/documents`, formdata)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents/:documentWsid
 * @method DELETE
 * @desc   删除指定信封
 * @author 陈曦源
 * @date   2018-01-16 11:51:19
 * ----------------------------------------------------
 */
export function deleteEnvelopeDocument(obj = {}){
    let {
        envelopeWsid,
        documentWsid
    } = obj

    return axios.delete(`/api/envelopes/${envelopeWsid}/documents/${documentWsid}`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/contents/wsid-upload
 * @method POST
 * @desc   上传文档（wsid方式）
 * @author 潘维
 * @date   2018-12-02 16:50:28
 * ----------------------------------------------------
 */
export function uploadEnvelopeDocumentWsid(obj = {}) {
    let {
        envelopeWsid,
        wsidList,
    } = obj
    return axios.post(`/api/envelopes/${envelopeWsid}/contents/wsid-upload`, wsidList)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/documents
 * @method put
 * @desc   批量更新信封文件
 * @author 潘维
 * @date   2019-05-15 15:49:43
 * ----------------------------------------------------
 */
export function updateEnvelopeDocuments(obj = {}) {
    let {
        envelopeWsid,
        contents
    } = obj
    
    return axios.put(`/api/envelopes/${envelopeWsid}/documents`, { contents })
}