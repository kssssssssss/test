import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/external-signature/plaintext-generate
 * @method POST
 * @desc   生成待签署明文
 * @author 周雪梅
 * @date   2020-08-12 14:40:56
 * ----------------------------------------------------
 */
export function plaintextGenerate(obj = {}) {
    let {
        envelopeWsid,
        hashAlgorithm = "SHA256",
        participantWsid,
        formWsid,
        cert,
        formType
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/external-signature/plaintext-generate`, {
        hashAlgorithm,
        participantWsid,
        formWsid,
        cert,
        formType
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/external-signature/assemble
 * @method POST
 * @desc   装配签名
 * @author 周雪梅
 * @date   2020-08-12 14:41:07
 * ----------------------------------------------------
 */
export function assembleSignature(obj = {}) {
    let {
        envelopeWsid,
        participantWsid,
        formWsid,
        signedData,
        signAlgorithm,
        signId
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/external-signature/assemble`, {
        participantWsid,
        formWsid,
        signedData,
        signAlgorithm,
        signId
    })
}