import axios from '@interfaces/axios.js'

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/forms
 * @method GET
 * @desc   获取信封参与者列表
 * @author 陈曦源
 * @date   2018-01-27 16:34:35
 * ----------------------------------------------------
 */
export function getEnvelopeFroms(obj = {}) {
    let {
        envelopeWsid,
        participantWsid
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/forms`, {
        params: {
            participantWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/forms
 * @method POST
 * @desc   创建信封表单列表
 * @author 陈曦源
 * @date   2018-01-18 17:12:08
 * ----------------------------------------------------
 */
export function createEnvelopeFroms(obj = {}) {
    let {
        envelopeWsid,
        forms
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/forms`, {
        forms
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/forms
 * @method PUT
 * @desc   修改信封表单列表
 * @author 陈曦源
 * @date   2018-01-18 17:12:10
 * ----------------------------------------------------
 */
export function updateEnvelopeFroms(obj = {}) {
    let {
        envelopeWsid,
        forms
    } = obj

    return axios.put(`/api/envelopes/${envelopeWsid}/forms`, {
        forms
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/forms
 * @method DELETE
 * @desc   删除信封表单列表
 * @author 陈曦源
 * @date   2018-01-18 17:12:15
 * ----------------------------------------------------
 */
export function deleteEnvelopeFroms(obj = {}) {
    let {
        envelopeWsid,
        forms
    } = obj

    return axios.delete(`/api/envelopes/${envelopeWsid}/forms`, {
        data: {
            forms
        }
    })
}