import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants
 * @method GET
 * @desc   获取信封参与者列表
 * @author 陈曦源
 * @date   2018-01-18 15:13:27
 * ----------------------------------------------------
 */
export function getEnvelopeParticipants(obj = {}) {
    let {
        envelopeWsid
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/participants`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants
 * @method POST
 * @desc   添加参与者
 * @author 陈曦源
 * @date   2018-01-18 15:13:30
 * ----------------------------------------------------
 */
export function createEnvelopeParticipants(obj = {}) {
    let {
        envelopeWsid,
        participants
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants`, {
        participants
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants
 * @method PUT
 * @desc   修改参与者
 * @author 陈曦源
 * @date   2018-01-19 20:24:25
 * ----------------------------------------------------
 */
export function updateEnvelopeParticipants(obj = {}) {
    let {
        envelopeWsid,
        participants
    } = obj

    return axios.put(`/api/envelopes/${envelopeWsid}/participants`, {
        participants
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants
 * @method DELETE
 * @desc   删除参与者
 * @author 陈曦源
 * @date   2018-01-18 15:13:34
 * ----------------------------------------------------
 */
export function deleteEnvelopeParticipants(obj = {}) {
    let {
        envelopeWsid,
        participants
    } = obj

    return axios.delete(`/api/envelopes/${envelopeWsid}/participants`, {
        data: {
            participants
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/multi-send
 * @method  POST
 * @desc   批量信封添加批量参与者
 * @author 潘维
 * @date   2019-11-05 09:43:30
 * ----------------------------------------------------
 */
export function addEnvelopeBulkParticipants(obj = {}) {
    let {
        envelopeWsid,
        participantWsid,
        participants
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/multi-send`, {
        participants
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/multi-send
 * @method  GET
 * @desc   获取添加批量参与者信息
 * @author 潘维
 * @date   2019-11-05 09:43:26
 * ----------------------------------------------------
 */
export function getEnvelopeBulkParticipantsInfo(obj = {}) {
    let {
        envelopeWsid,
        participantWsid
    } = obj

    return axios.get(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/multi-send`)
}

/**
 * ----------------------------------------------------
 * @path   /api/envelopes/:envelopeWsid/participants/:participantWsid/multi-send-change
 * @method  POST
 * @desc   切换参与者批量标记
 * @author 潘维
 * @date   2019-11-05 09:43:23
 * ----------------------------------------------------
 */
export function changeEnvelopeBulkParticipants(obj = {}) {
    let {
        envelopeWsid,
        participantWsid,
        originalParticipantWsid
    } = obj

    return axios.post(`/api/envelopes/${envelopeWsid}/participants/${participantWsid}/multi-send-change`, {
        originalParticipantWsid
    })
}