import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:enterpriseWsid/office-seal-use-records
 * @method GET
 * @desc   查询指定印章的所有申请记录
 * @author 周雪梅
 * @date   2019-10-15 11:11:33
 * ----------------------------------------------------
 */
export function getOfficeSealsUseRecords(obj) {
    let {   
        enterpriseWsid,
        fileds,
        filters,
        limit = 10,
        offset = 0,
        scope,
        sorts
    } = obj

    return axios.get(`/api/seals/office-seals/${enterpriseWsid}/office-seal-use-records`, {
        params: {
            fileds,
            filters,
            limit,
            offset,
            scope,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seals/:enterpriseWsid/use-records/batch-export
 * @method POST
 * @desc   企业批量导出未认证成员信息
 * @author 周雪梅
 * @date   2019-10-16 17:30:53
 * ----------------------------------------------------
 */
export function exportOfficeSealsUseRecords(obj) {
    let {
        enterpriseWsid,
        filters,
        onDownloadProgress
    } = obj

    return axios.get(`/api/seals/office-seals/${enterpriseWsid}/use-records/batch-export?filters=${filters}`, {
        responseType:"blob",
        onDownloadProgress
    })
}
