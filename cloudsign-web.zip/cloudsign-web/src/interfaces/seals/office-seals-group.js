import axios from "@interfaces/axios.js"
/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seal-groups
 * @method GET
 * @desc   查询指定企业的印章分组信息
 * @author 潘维
 * @date   2018-06-27 19:44:19
 * ----------------------------------------------------
 */
export function getOfficeSealGroups(obj) {
    let {
        fields,
        filters,
        limit = 100,
        offset = 0,
        sorts,
    } = obj

    return axios.get(`/api/seals/office-seal-groups`, {
        params: {
            fields,
            filters,
            limit,
            offset,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seal-groups
 * @method POST
 * @desc   创建企业企业分组
 * @author 潘维
 * @date   2018-06-30 20:33:44
 * ----------------------------------------------------
 */
export function createSealGroup(obj) {
    let {
        name,
        parentWsid
    } = obj
    
    return axios.post(`/api/seals/office-seal-groups`, {
        name,
        parentWsid
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/seals/office-seal-groups
 * @method delete
 * @desc   删除印章分组
 * @author 潘维
 * @date   2018-06-28 19:17:57
 * ----------------------------------------------------
 */
export function deleteSealGroup(obj) {
    let {
        groupWsid
    } = obj
    
    return axios.delete(`/api/seals/office-seal-groups`, {
        params: {
            groupWsid 
        }
    })
}

/**
 * ----------------------------------------------------
 * @path  /api/seals/office-seal-groups
 * @method PUT
 * @desc   修改印章分组名称
 * @author 潘维
 * @date   2018-06-29 14:23:11
 * ----------------------------------------------------
 */
export function modifySealGroupName(obj) {
    let {
        groupWsid,
        name
    } = obj
    
    return axios.put(`/api/seals/office-seal-groups`, { name }, {
        params: {
            groupWsid 
        }
    })
}

/**
 * ----------------------------------------------------
 * @path  /api/seals/group-tansfer
 * @method POST
 * @desc   转移分组
 * @author 周雪梅
 * @date   2018-06-30 09:38:00
 * ----------------------------------------------------
 */
export function transferSealGroup(obj) {
    let {
        groupWsid,
        parentWsid,
        officeSealWsid
    } = obj
    
    return axios.post(`/api/seals/group-tansfer`, { parentWsid, officeSealWsid }, {
        params: {
            groupWsid
        }
    })
}