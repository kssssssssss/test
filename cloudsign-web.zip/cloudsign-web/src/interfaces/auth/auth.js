import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/verifications/${identityWsid}
 * @method GET
 * @desc   单条认证信息查询: 查询指定的用户实名认证申请表单
 * @from   实名认证微服务-认证申请表单 | GET /verifications/{idttv-wsid}
 * @author 周雪梅
 * @date  2018-01-29 17:20:27
 * ----------------------------------------------------
 */
export function getVerificationInfo(obj) {
    let {
        identityWsid,
        fileds
    } = obj

    return axios.get(`/api/verifications/${identityWsid}`, {
        params: {
            fileds
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications
 * @method GET
 * @desc   认证申请表单列表查询: 查询指定条件下的用户实名认证申请表单列表
 * @date   2018-01-29 17:21:49
 * @author 周雪梅
 * ----------------------------------------------------
 */
export function getVerifications(obj) {
    let {
        fileds,
        filters,
        offset = 0,
        limit = 20,
        sorts
    } = obj

    return axios.get("/api/verifications", {
        params: {
            fileds,
            filters,
            offset,
            limit,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/person
 * @method POST
 * @desc   个人实名认证申请: 提交待认证的个人用户的基本信息
 * @author 周雪梅
 * @date   2018-01-29 19:29:10
 * ----------------------------------------------------
 */
export function personAuth(obj) {
    let {
        authorWsid,
        name,
        idCardNo,
        idCardType,
        phone,
        opcode,
        fromTag,
        invokeNo
    } = obj

    return axios.post("/api/verifications/person", {
        authorWsid,
        name,
        idCardNo,
        idCardType,
        phone,
        opcode,
        fromTag,
        invokeNo
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/enterprise
 * @method POST
 * @desc   企业实名认证申请: 提交待认证的企业用户的基本信息
 * @author 陈曦源，周雪梅
 * @date   2018-01-29 19:29:15
 * ----------------------------------------------------
 */
export function enterpriseAuth(obj) {
    let {
        authorWsid,
        name,
        telephone,
        agent,
        legalPerson,
        unifiedSocialID,
        orgCode,
        registCode,
        authType,
        bankCardInfo,
        imageFileDatas,
        fromTag,
        invokeNo
    } = obj

    return axios.post("/api/verifications/enterprise", {
        authorWsid,
        name,
        telephone,
        agent,
        legalPerson,
        unifiedSocialID,
        orgCode,
        registCode,
        authType,
        bankCardInfo,
        imageFileDatas,
        fromTag,
        invokeNo
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/${identityWsid}/senior-auth-check
 * @method POST
 * @desc   企业高级实名认证验证码验证: ，小额打款，手工方式，生成验证码
 * @author 周雪梅
 * @date   2018-01-29 19:29:22
 * ----------------------------------------------------
 */
export function seniorAuthCheck(obj) {
    let {
        identityWsid,
        checkSum
    } = obj

    return axios.post(`/api/verifications/${identityWsid}/senior-auth-check`, {
        checkSum,
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/${identityWsid}/examine
 * @method POST
 * @desc   认证信息检查: 检查指定认证记录是否具备提交的条件，检查信息完整后，记录的状态会改变为待审核（人工审核）
 * @author 周雪梅
 * @date   2018-01-29 19:29:27
 * ----------------------------------------------------
 */
export function examine(obj) {
    let {
        identityWsid
    } = obj

    return axios.post(`/api/verifications/${identityWsid}/examine`)
}

/**
 * ----------------------------------------------------
 * @desc  银行卡认证接口
 * @from  实名认证微服务-银行卡认证接口 | POST /third-verifications/bankcard-idttv
 * @date  2017-10-09 14:54:16
 * @author  陈曦源
 * ----------------------------------------------------
 */ 
export function bankcard_auth(obj) {
    let {
        userWsid,
        name,
        idCardNo,
        bankCardNo,
        phone,
        opcode
    } = obj

    return axios.post("/api/third-verifications/bankcard-idttv", {
        userWsid,
        name,
        idCardNo,
        bankCardNo,
        phone,
        opcode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/zhima-idttv
 * @method POST 
 * @desc   启动芝麻认证接口
 * @author 周雪梅
 * @date   2018-01-29 19:29:35s
 * ----------------------------------------------------
 */ 
export function zhimaAuth(obj) {
    let {
        certName,
        certNo,
        idttvType,
        returnUrl,
        userPersonWsid
    } = obj

    return axios.post("/api/third-verifications/zhima-idttv", {
        certName,
        certNo,
        idttvType,
        returnUrl,
        userPersonWsid
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/zhima-idttv
 * @method POST
 * @desc   查询芝麻认证结果接口
 * @author 周雪梅
 * @date   2018-01-29 19:29:43
 * ----------------------------------------------------
 */ 
export function getZhima(obj) {
    let {
        bizNo,
        userPersonWsid
    } = obj

    return axios.get("/api/third-verifications/zhima-idttv", {
        params: {
            bizNo,
            userPersonWsid
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/faceId-idttv
 * @method POST
 * @desc   faceId获取token
 * @author 潘维
 * @date   2018-12-27 15:53:04
 * ----------------------------------------------------
 */ 
export function faceId_auth(obj) {
    let {
        idCardName,
        idCardNo,
        notifyUrl,
        returnUrl,
        phoneFaceAuth
    } = obj

    return axios.post("/api/third-verifications/faceId-idttv", {
        idCardName,
        idCardNo,
        notifyUrl,
        returnUrl,
        phoneFaceAuth
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/faceId-idttv
 * @method POST
 * @desc   查询faceId证结果接口
 * @author 潘维
 * @date   2018-12-27 15:53:04
 * ----------------------------------------------------
 */ 
export function getFaceidRusult(obj) {
    let {
        faceToken
    } = obj

    return axios.get("/api/third-verifications/faceId-idttv", {
        params: {
            faceToken
        }
    })
}
/**
 * ----------------------------------------------------
 * @path   /api/verifications/:identityWsid/reset
 * @method POST
 * @desc   认证状态重置
 * @author 陈曦源
 * @date   2018-02-02 11:47:05
 * ----------------------------------------------------
 */
export function resetAuthStatus(obj) {
    let {
        identityWsid
    } = obj

    return axios.post(`/api/verifications/${identityWsid}/reset`)
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/phone-idttv
 * @method POST
 * @desc   手机三网认证
 * @author 周雪梅
 * @date   2018-12-17 16:43:31
 * ----------------------------------------------------
 */
export function phoneAuth(obj) {
    let {
        idCardNo,
        name,
        phone,
        fromTag,
        invokeNo,
        opcode
    } = obj

    return axios.post("/api/third-verifications/phone-idttv", {
        idCardNo,
        name,
        phone,
        fromTag,
        invokeNo,
        opcode
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/faceId-idttv
 * @method POST
 * @desc   查询faceId证结果接口
 * @author 潘维
 * @date   2018-12-27 15:53:04
 * ----------------------------------------------------
 */ 
export function getPhoneFaceidRusult(obj) {
    let {
        faceToken
    } = obj

    return axios.get("/api/third-verifications/phone-face-idttv", {
        params: {
            faceToken
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/third-verifications/phone-idttv
 * @method POST
 * @desc   手机三网认证
 * @author 周雪梅
 * @date   2018-12-17 16:43:31
 * ----------------------------------------------------
 */
export function phoneFaceAuth(obj) {
    let {
        idCardNo,
        name,
        phone,
        fromTag,
        invokeNo,
        opcode
    } = obj

    return axios.post("/api/third-verifications/phone-face-idttv", {
        idCardNo,
        name,
        phone,
        fromTag,
        invokeNo,
        opcode
    })
}


/**
 * ----------------------------------------------------
 * @path   /api/verifications/person/check
 * @method POST
 * @desc   校验个人实名认证申请信息
 * @author 周雪梅
 * @date   2018-12-18 09:35:58
 * ----------------------------------------------------
 */
export function personCheck(obj) {
    let {
        idCardNo,
        name,
        notifyIfSame,
        account,
        invokeNo
    } = obj

    return axios.post("/api/verifications/person-check", {
        idCardNo,
        name,
        notifyIfSame,
        account,
        invokeNo
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/verifications/enterprise/check
 * @method POST
 * @desc   校验企业实名认证申请信息
 * @author 周雪梅
 * @date   2018-12-18 09:35:58
 * ----------------------------------------------------
 */
export function enterpriseCheck(obj) {
    let {
        ownerWsid,
        enterpriseName,
        unifiedSocialCode,
        notifyIfSameUnifiedSocialCode,
        invokeNo,
        notifyIfExistEntesForOwner
    } = obj

    return axios.post("/api/verifications/enterprise-check", {
        ownerWsid,
        enterpriseName,
        unifiedSocialCode,
        notifyIfSameUnifiedSocialCode,
        invokeNo,
        notifyIfExistEntesForOwner
    })
}


//认证情况
export function get_auth(obj) {
    let {
        type,
        fields
    } = obj

    return axios.get("/api/user/auth", {
        params: {
            type,
            fields
        }
    })
}

export function get_auth_data(obj) {
    let {
        type = 1,
        fields = []
    } = obj

    return axios.get("/api/user/auth", {
        type,
        fields
    })
}

//获取个人认证短信验证码
export function send_auth(obj) {
    return axios.post("/api/user/send-auth", {
        sendDest: obj.phone
    })
}
//验证个人认证短信验证码
export function verify_auth(obj) {
    return axios.post("/api/user/verify-auth", {
        sendDest: obj.phone,
        verifyData: obj.code
    })
}

//获取企业认证短信验证码
export function send_enterprise(obj) {
    return axios.post("/api/auth/send-enterprise", {
        sendDest: obj.phone
    }, obj.success, obj.error)
}

//验证企业认证短信验证码
export function verify_enterprise(obj) {
    return axios.post("/api/auth/verify-enterprise", {
        sendDest: obj.phone,
        verifyData: obj.code
    })
}


//提交认证资料
// var data = {
//     type       1为个人认证，2为实名认证，默认为1
//     name       个人姓名/企业名称
//     idCard     个人身份证号/经办人身份证号
//     phone      手机号/经办人手机号
//     orgCode    组织机构代码
//     creditCode 三证合一代码
//     agentName  经办人姓名
//   }
export function post_auth(obj) {
    let {
        type = 1,
        name = "",
        idCard = "",
        phone = "",
        orgCode = "",
        creditCode = "",
        agentName = ""
    } = obj

    return axios.post("/api/user/auth", {
        type,
        name,
        idCard,
        phone,
        orgCode,
        creditCode,
        agentName
    })
}

//认证检查
export function auth_check(obj) {
    let {
        type
    } = obj

    return axios.get("/api/auth/check", {
        params: {
            type
        }
    })
}