import axios from "@interfaces/axios.js"
import uuid from "uuid"
import { deviceClient, deviceClientId, deviceVoiceClient, deviceVoiceClientId } from "@interfaces/web-socket/wsclient.js"
import { ERROR_CODES, createErrorByCode } from "@errors/code.js"

/**
 * ----------------------------------------------------
 * @path   /api/captcha/email-code
 * @method POST
 * @desc   邮件验证码：用于将验证码通过邮件发送至用户，邮件中不使用交互功能（不同于激活链接）只是用做发送信息使用
 * @author chenxiyuan,周雪梅
 * @date   2018-01-25 14:30:15
 * ----------------------------------------------------
 */
export function mail_code_post(obj) {
    let {
        email,
        service,
        pusherChannelTag,
        code
    } = obj

    return axios.post("/api/captcha/email-code", {
        email,
        service,
        pusherChannelTag,
        code
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/captcha/sms-code
 * @method POST
 * @desc   创建短信授权码
 * @author chenxiyuan,周雪梅
 * @date   2019-03-28 10:48:24
 * ----------------------------------------------------
 */
export function sms_code_post(obj) {
    let {
        phone,
        service,
        pusherChannelTag,
        code,
    } = obj

    return new Promise((resolve, reject) => {
        let requestId = uuid.v4()
        axios.post("/api/captcha/sms-code", {
            phone,
            service,
            pusherChannelTag,
            code,
            deviceId: deviceClientId,
            requestId: requestId
        }).catch(err => reject(err))

        let timeoutHandle = setTimeout(_ => {
            deviceClient.off(`response:${requestId}`)
            reject(createErrorByCode(ERROR_CODES.TIMEOUT))
        }, 20 * 1000)

        deviceClient.once(`response:${requestId}`, data => {
            clearTimeout(timeoutHandle)
            if (data.success){
                resolve(data)
            } else {
                reject(createErrorByCode(data.code, data))
            }
        })
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/opcode
 * @method POST
 * @desc   获取业务操作码: 通过验证Captcha获取业务操作码，操作码可以对用户执行一些高级操作，比如重置用户密码，签名身份验证
 * @author chenxiyuan,周雪梅
 * @date   2018-01-25 14:30:24
 * ----------------------------------------------------
 */

export function opcode_post(obj) {
    let {
        captcha,
        contact,
        service
    } = obj

    return axios.post("/api/opcode", {
        captcha,
        contact,
        service
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/captcha/voice-code
 * @method POST
 * @desc   创建语音验证码
 * @author 周雪梅
 * @date   2019-04-15 09:07:44
 * ----------------------------------------------------
 */
export function voice_code_post(obj) {
    let {
        phone,
        service,
        code
    } = obj

    return new Promise((resolve, reject) => {
        let requestId = uuid.v4()
        axios.post("/api/captcha/voice-code", {
            phone,
            service,
            code,
            deviceId: deviceVoiceClientId,
            requestId: requestId
        }).catch(err => reject(err))
        let timeoutHandle = setTimeout(_ => {
            deviceVoiceClient.off(`response:${requestId}`)
            reject(createErrorByCode(ERROR_CODES.TIMEOUT))
        }, 20 * 1000)

        deviceVoiceClient.once(`response:${requestId}`, data => {
            clearTimeout(timeoutHandle)
            if (data.success){
                resolve(data)
            } else {
                reject(createErrorByCode(data.code, data))
            }
        })
    })
}