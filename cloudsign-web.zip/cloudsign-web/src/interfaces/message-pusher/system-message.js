import axios from "@interfaces/axios.js"

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/:userWsid
 * @method GET
 * @desc   获取当前用户的所有消息
 * @author 周雪梅
 * @date   2019-01-24 21:06:40
 * ----------------------------------------------------
 */
export function getUserMessages(obj) {
    let {
        userWsid,
        fields,
        filters,
        offset = 0,
        limit = 20,
        sorts = "-createdDatetime"
    } = obj

    return axios.get(`/api/message-pusher/${userWsid}`, {
        params: {
            fields,
            filters,
            offset,
            limit,
            sorts
        }
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/:userWsid
 * @method POST
 * @desc   拉取私信
 * @author 周雪梅
 * @date   2018-10-20 16:12:37
 * ----------------------------------------------------
 */
export function pullMessage(obj) {
    let {
        userWsid
    } = obj

    return axios.get(`/api/message-pusher/${userWsid}/message-pull`)
}

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/:userWsid/announces/pull
 * @method POST
 * @desc   拉取公告
 * @author 周雪梅
 * @date   2018-10-20 16:12:37
 * ----------------------------------------------------
 */
export function pullAnnouncement(obj) {
    let {
        userWsid
    } = obj

    return axios.get(`/api/message-pusher/${userWsid}/announces/pull`)
}

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/message/common-message-send
 * @method POST
 * @desc   消息推送
 * @author 周雪梅
 * @date   2018-10-20 16:12:37
 * ----------------------------------------------------
 */
export function sendMessage(obj) {
    let {
        source,
        targetType,
        action,
        user
    } = obj

    return axios.post(`/api/message-pusher/message/common-message-send`, {
        source,
        targetType,
        action,
        user
    })
}

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/:userWsid/notifications
 * @method PUT
 * @desc   消息读取
 * @author 周雪梅
 * @date   2018-10-20 16:12:37
 * ----------------------------------------------------
 */
export function readMessage(obj) {
    let {
        userWsid,
        notifications
    } = obj

    return axios.put(`/api/message-pusher/${userWsid}/notifications`, notifications)
}

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/:userWsid/notifications
 * @method PUT
 * @desc   更新全部消息
 * @author 周雪梅
 * @date   2019-01-23 19:28:34
 * ----------------------------------------------------
 */
export function readAllMessage(obj) {
    let {
        userWsid
    } = obj

    return axios.put(`/api/message-pusher/${userWsid}/message-read-all`)
}

/**
 * ----------------------------------------------------
 * @path   /api/message-pusher/:userWsid/message/:messageId
 * @method delete
 * @desc   删除私信
 * @author 周雪梅
 * @date   2018-10-20 16:12:37
 * ----------------------------------------------------
 */
export function deleteMessage(obj) {
    let {
        userWsid,
        messageId
    } = obj

    return axios.delete(`/api/message-pusher/${userWsid}/message/${messageId}`)
}