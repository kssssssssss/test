let { hyphen } = require("name-styles")
const { addSideEffect } = require("@babel/helper-module-imports")

module.exports = function({types}){
    return {
        visitor: {
            Program: {
                exit(path, state){
                    if (state.needBase){
                        state.opts.base.forEach(base => {
                            addSideEffect(state.file.path, base)
                        })
                    }
                }
            },
            ImportDeclaration(path, state) {
                const { node } = path
                if (!node) return

                const source = node.source
                const libraryName = state.opts.libraryName
                if (source.value === libraryName){ //判定与库相同

                    //第一次导入基础库
                    state.needBase = true

                    let replace = []
                    let changers = state.opts.changers

                    let specifiers = node.specifiers

                    let names = []

                    if (specifiers.length === 0){ // 直接全局导入，类似默认导入但是
                        names.push([null, state.opts.default])
                    } else if (specifiers.length > 0){
                        if (specifiers.length === 1 && types.isImportDefaultSpecifier(specifiers[0])){
                            names.push([specifiers[0].local.name, state.opts.default])
                        } else {
                            specifiers.forEach(specifier => {
                                names.push([specifier.local.name, hyphen(specifier.local.name)])
                            })
                        }
                    }

                    names.forEach(([varname, libname]) => {
                        changers.forEach((changer, index) => {
                            if(index === 0 && varname){
                                replace.push(types.ImportDeclaration([
                                    types.importDefaultSpecifier(types.Identifier(varname))
                                ], types.StringLiteral(changer(libname))))
                            } else {
                                addSideEffect(state.file.path, changer(libname))
                            }
                        })
                    })

                    path.replaceWithMultiple(replace)
                }
            },
        },
    }
}