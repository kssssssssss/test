//加载requireHack
require("./loader.js")

//加载日志模块
const log4js = require("log4js")
log4js.configure(require("./config-log4js"))
global.LOG = log4js.getLogger()

//加载配置
global.$config = require("./config")
global.$dir = {
    main: __dirname,
    DATA: require("path").join(__dirname, "DATA")
}

require("./server.js")