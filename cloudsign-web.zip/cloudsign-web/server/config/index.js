const { merge } = require("lodash")

let env = process.env.WESIGN_ENV

if (!env){
    env = "prod"
    LOG.info(`未检测到系统所处环境，默认启用 ${env} 环境`)
}

LOG.info(`获取运行环境：${env}`)
let baseConfig = require("./base.js")
let nowConfig = require(`./${env}.js`) || {}

let config = merge(baseConfig, nowConfig)
config.env = env

module.exports = config