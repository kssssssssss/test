module.exports = {
    "cookie-top-host": "10.10.9.149",
    
    hostname: /^.*$/,

    appid: "wx0da01f5a622da625", //微信API
    secret: "56a2a5fc2de24e4da234c528781f9b49", //微信secretKey
    
    backend: {
        "wesign-mss-user://": "http://mss-api.ns.me:6153/v1/user/",
        "wesign-mss-enterprise://": "http://mss-api.ns.me:6153/v1/enterprise/",
        "wesign-mss-identity://": "http://mss-api.ns.me:6153/v1/identity/",
        "wesign-mss-errors://": "http://mss-api.ns.me:6153/errors/",
        "wesign-mss-file://": "http://mss-api.ns.me:6153/v1/file/",
        "wesign-mss-seal://": "http://mss-api.ns.me:6153/v1/seal/",
        "wesign-mss-envelope://": "http://mss-api.ns.me:6153/v1/envelope/",
        "wesign-mss-policy://": "http://mss-api.ns.me:6153/v1/policy/",
        "wesign-mss-verifier://": "http://mss-api.ns.me:6153/v1/verifier/",
        "wesign-mss-finance://": "http://mss-api.ns.me:6153/v1/finance/",
        "wesign-mss-developer://": "http://mss-api.ns.me:6153/v1/developer/",
        "wesign-mss-template://": "http://mss-api.ns.me:6153/v1/template/",
        "wesign-mss-pusher://": "http://mss-api.ns.me:6153/v1/pusher/",
        "wesign-mss-open://": "http://mss-api.ns.me:6153/v1/open/",
        "wesign-mss-link://":"http://mss-api.ns.me:6153/v1/link/",
        "weixi-api://": "https://api.weixin.qq.com/"
    }
}