module.exports = {
    httpport: 61110, //http服务器端口

    hostname: /^127\.0\.0\.1$/, //可访问的域名
    
    //session相关
    "session-outtime": 30 * 60 * 1000, //过期时间设置(单位毫秒)
    "session-secret": "wesign2018", //session秘钥
    "cookie-top-host": "127.0.0.1", //cookie顶级域名
    
    wx: {
        appid: "wx3171beca057254f0", //微信API
        secret: "6d2ba0e09ef899c4ee4079563a4e73b7", //微信secretKey
    },
    
    backend: {
        "wesign-mss-user://": "", //用户中心微服务
        "wesign-mss-enterprise://": "", //企业管理微服务
        "wesign-mss-identity://": "", //实名认证微服务
        "wesign-mss-errors://": "", //错误透传
        "wesign-mss-file://": "", //文件存储微服务
        "wesign-mss-envelope://": "", //信封微服务
        "wesign-mss-policy://": "", //权限策略微服务
        "wesign-mss-verifier://": "", //信封验签微服务
        "wesign-mss-finance://": "", //财务微服务
        "wesign-mss-developer://": "", //开发者微服务
        "wesign-mss-template://": "", //模板微服务
        "wesign-mss-pusher://": "", //消息推送微服务
        "wesign-mss-seal://": "", //签章微服务
        "wesign-mss-open://": "", //开放平台
        "wesign-mss-link://":"",//链接微服务
        "weixi-api://": "" //微信小程序
    }
}