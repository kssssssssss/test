const path = require("path")

module.exports = {
    appenders: { 
        console: { 
            type: "console"
        },
        httplog: {
            type: "dateFile",
            filename: path.resolve(__dirname, "./logs/httplog"),
            alwaysIncludePattern: true,
            pattern: "-yyyy-MM-dd.log"
        },
        errorlog: {
            type: "dateFile",
            filename: path.resolve(__dirname, "./logs/errorlog"),
            alwaysIncludePattern: true,
            pattern: "-yyyy-MM-dd.log"
        },
        clientBacklog: {
            type: "dateFile",
            filename: path.resolve(__dirname, "./logs/client-back-log"),
            alwaysIncludePattern: true,
            pattern: "-yyyy-MM-dd.log"
        }
    },
    categories: { 
        default: { 
            appenders: ["console"], 
            level: "all"
        },
        debug: {
            appenders: ["console"],
            level: "debug"
        },
        http: {
            appenders: ["console", "httplog"],
            level: "info" 
        },
        error: {
            appenders: ["console", "errorlog"],
            level: "error"
        },
        clientBack: {
            appenders: ["console", "clientBacklog"],
            level: "info"
        }
    }
}