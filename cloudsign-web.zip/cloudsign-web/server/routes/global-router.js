const express = require("express"),
    path = require("path"),
    bodyParser = require("body-parser"),
    cookieParser = require("cookie-parser"),
    log4js = require("log4js")
    uuidv4 = require("uuid/v4")

exports.setInit = function(app){
    app.set("view engine", "ejs")
    app.set("views", path.resolve(__dirname, "../../src/views"))
    app.set("view options", {layout: false})
    app.set("x-powered-by", false)

    //处理代理
    app.set("trust proxy", true)

    app.use(function(req, res, next){ //现在访问域名
        if ($config.hostname.test(req.host)){
            next()
        } else {
            res.send("error host")
        }
    })

    app.use(log4js.connectLogger(log4js.getLogger("http")))//请求日志
    app.use(express.static(path.join($dir.main, "public"), {maxAge: 1000 * 60 * 60 * 24 * 30})) //缓存一个月
    app.use(bodyParser.raw({type: "multipart/form-data", limit: "150mb"}))
    app.use(bodyParser.raw({type: "application/x-www-form-urlencoded", limit: "150mb"}))
    app.use(bodyParser.json({ type: "application/json", limit: "150mb" }))
    app.use(bodyParser.urlencoded({ extended: true }))
    app.use("*", function(req, res, next){
        res.header("Access-Control-Allow-Origin", req.headers.origin || "*")
        res.header("Access-Control-Allow-Methods", "POST,PUT,GET,OPTIONS,DELETE")
        res.header("Access-Control-Allow-Credentials", true)
        res.header("Access-Control-Allow-Headers", "content-type")
        next()
    })
    app.use(cookieParser())

    //设置设备cookie
    app.use(function(req, res, next){
        if (!req.cookies.DeviceId){
            let id = uuidv4()
            req.cookies.DeviceId = id
            res.cookie("DeviceId", id, {
                path: "/",
                maxAge: 10 * 365 * 24 * 3600 * 1000 //10年 ～= 永久
            })
        }
        next()
    })
}
