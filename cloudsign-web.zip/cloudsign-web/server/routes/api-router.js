const log4js = require("log4js")
const routeTable = require("./api-router/api-route-table.json")
const exit = require("$exit")
const proxy = require('express-http-proxy')
const url = require('url')

const METHODS = {//可支持的方法
    get: true,
    post: true,
    put: true,
    patch: true,
    delete: true,
    option: true
}

exports.setAPIs = function(app){
    for (let name in routeTable){
        let methods = require("./api-router/" + routeTable[name])
        for (let method in methods){
            if (METHODS[method]){
                LOG.debug(`加载API接口：${method.toUpperCase()} ${name} `)
                app[method](name, methods[method])
            }
        }
    }

    //代理faceid回调
    const x = url.parse($config.backend["wesign-mss-identity://"])
    app.use("/api-callback/faceid-auth", proxy(`${x.protocol}//${x.host}`, {
        proxyReqPathResolver: function(req) {
            return `${x.path}/third-verifications/face-idttv/notify`
        },
        proxyErrorHandler: function(err, res, next) {
            next(err)
        },
    }))


    app.use(function(err, req, res, next){
        log4js.getLogger("error")
            .error(`${req.ip} - - "${req.method} ${req.path}" \n - - headers: ${JSON.stringify(req.headers, null, 4)} \n - - body: ${JSON.stringify(req.body, null, 4)} \n - - error: ${err.message} :: ${err.stack} \n`)
        
        let errorCode = 100
        let errorMessage = "通用错误"
        if (err.response){
            let status = err.response.status
            if (err.response.data){
                let code = err.response.data.code
                switch (code){
                    case "100100103": 
                        exit.error(res, undefined, 401, "登录已失效", {status: 401, errorData: err})
                        return
                    case "100100105":
                        exit.error(res, undefined, 403, "请求过于频繁", {status: 403, errorData: err})
                        return
                }
            }
            exit.error(res, undefined, errorCode, errorMessage, {status, errorData: err})
        } else {
            exit.error(res, undefined, errorCode, errorMessage, {errorData: err})
        }
    })
}