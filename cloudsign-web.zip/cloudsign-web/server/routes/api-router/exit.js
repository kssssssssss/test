const uuidv4 = require("uuid/v4")

/**
 * @description 请求成功，实现预期目标
 * @param {RES} res 请求的响应对象
 * @param {Object} data 响应数据
 * @param {Number} code 响应CODE < 100
 * @param {String} msg 响应的描述
 */
function success(res, data, code = 0, msg = "成功"){
    res.json({
        code,
        msg,
        data
    })
}

/**
 * @description 请求存在失败，没有达到请求预期目标
 * @param {RES} res 请求的响应对象
 * @param {Object} data 响应数据
 * @param {Number} code 响应CODE >= 100
 * @param {Object} options 额外数据
 *      @param {Number} status 响应的状态码 默认为200
 */
function error(res, data, code = 100, msg = "失败", options = {}){
    let {
        status = 400, //默认为响应400
        errorId = uuidv4(), //错误的ID，会发给前端，主要用于线上环境，查找错误
        errorData = {} //整个错误对象 开发环境才会输出出去
    } = options

    let result = {
        code,
        msg,
        error: {
            id: errorId
        },
        data
    }

    if ($config.env !== "prod"){
        let outError = { //输出的错误
            stack: errorData.stack,
            message: errorData.message
        } 

        if (errorData.response){ //来自后台的报错
            let response = errorData.response
            if (typeof response.config.data !== "string"){
                delete response.config.data
            }
            
            outError.response = {
                headers: response.headers,
                config: response.config,
                data: response.data
            }
        } 
        result.error.data = outError
    }

    try {
        res.status(status).json(result)
    } catch (e){
        error(res, data, 100, msg = "失败", options = {
            status: 500,
            errorData: e
        })
    }
}

success.success = success
success.error = error
module.exports = success