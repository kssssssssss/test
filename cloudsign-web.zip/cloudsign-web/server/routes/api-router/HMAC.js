const axios = require("axios")

function request(obj){
    if (!obj || !obj.reqURL)
        return Promise.reject(new Error("错误的参数"))

    let reqMethod = obj.reqMethod.toUpperCase() || "POST"
    let reqURL = transURL(obj.reqURL)
    let reqHeaders = obj.reqHeaders || {}
    let reqSession = obj.reqSession
    let reqOpcode = obj.reqOpcode
    let reqDevice = obj.reqDevice
    let reqData = obj.reqData || {}
    let reqQuery = obj.reqQuery
    let reqSuccess = obj.reqSuccess
    let reqError = obj.reqError
    let resType = obj.resType || "json"
    let reqInvokeNo = obj.reqInvokeNo
    let reqFromTag = obj.reqFromTag
    let reqToken = obj.reqToken
    let reqCaptcha = obj.reqCaptcha
    let reqTimeOutDate = obj.reqTimeOutDate || 40 * 1000
    if (reqSession) reqHeaders["X-Requested-Session"] = reqSession
    if (reqOpcode) reqHeaders["X-Requested-Operation"] = reqOpcode
    if (reqDevice) reqHeaders["X-Requested-Device"] = reqDevice
    if (reqInvokeNo) reqHeaders["X-Signit-InvokeNo"] = reqInvokeNo
    if (reqFromTag) reqHeaders["X-Signit-FromTag"] = reqFromTag
    if (reqToken) reqHeaders["X-Requested-Token"] = reqToken
    if (reqCaptcha) reqHeaders["X-Requested-Captcha"] = reqCaptcha
    return axios.request({
        url: reqURL,
        method: reqMethod,
        headers: reqHeaders,
        params: reqQuery,
        data: reqData,
        responseType: resType,
        maxContentLength: 150 * 1024 * 1024, //100M
        timeout:reqTimeOutDate //FIXME: 为了让后台的慢吞吞接口可以通过 暂时延长至40秒 2018-12-27 19:56:24
    })
}

function transURL(originURL){
    if (/^.+:\/\//.test(originURL)){
        let servername = originURL.match(/^.+:\/\//)[0]
        if ($config.backend[servername]){
            return $config.backend[servername] + originURL.substr(servername.length)
        }
    }
}

request.request = request
request.askend = request
module.exports = request