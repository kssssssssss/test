const WsService = require('../../websocket/websocket-service.js')
const uuidv4 = require('uuid/v4')

const keyMap = new Map() //钥匙对应的房间
const clientRooms = new Map() //每个客户端的加入的房间

function getKey(){
    let key
    do {
        key = uuidv4()
    }
    while (keyMap.get(key))
    return key
}

class Room{
    constructor(){
        this.key = getKey()
        this.clients = new Map()
        
        keyMap.set(this.key, this)
    }

    static findRoomByKey(key){
        return keyMap.get(key)
    }

    joinClient(client, metadata){
        let clients = this.clients
        if (clients.size > 0){
            ;([...clients]).forEach(client => {
                client[0].send(client[1].reqId, {
                    code: "ORTHER_JOIN"
                })
            })
        }

        //客户端加入房间
        this.clients.set(client, metadata)

        //记录客户端所加入的房间列表
        if (!clientRooms.has(client)){
            clientRooms.set(client, new Set())
        }
        clientRooms.get(client).add(this)
    }

    leaveClient(client){
        let clients = this.clients
        //移除客户端加入的这个房间
        let set = clientRooms.get(client)
        set.delete(this)
        if (set.size === 0){
            clientRooms.delete(client)
        }

        //客户端离开房间
        clients.delete(client)
        
        if (clients.size === 0){ //没人了执行摧毁
            this.destory()
        } else { //有人发送有人离开
            ;([...clients]).forEach(client => {
                client[0].send(client[1].reqId, {
                    code: "ORTHER_LEAVE"
                })
            })
        }
    }

    destory(){
        keyMap.delete(this.key)
    }
}

const scanSignatureService = new WsService()

scanSignatureService.setMethods([
    {
        name: "room:create",
        callback(id, data, wsClient){
            let room = new Room()
            room.joinClient(wsClient, {
                reqId: id
            })
            let key = room.key
            wsClient.send(id, {
                code: "ROOM_KEY",
                key
            })
        }
    },
    {
        name: "room:join",
        callback(id, data, wsClient){
            let key = data.key
            let room = Room.findRoomByKey(key)
            if (!room){
                wsClient.error(id, {
                    code: "Invalid Key",
                    msg: "无效的key"
                })
                return
            }

            room.joinClient(wsClient, {
                reqId: id
            })
            wsClient.send(id, {
                code: "OK"
            })
        }
    },
    {
        name: "room:leave",
        callback(id, data, wsClient){
            let key = data.key
            let room = Room.findRoomByKey(key)
            if (!room){
                wsClient.error(id, {
                    code: "Invalid Key",
                    msg: "无效的key"
                })
                return
            }
            room.leaveClient(wsClient)

            wsClient.send(id, {
                code: "OK"
            })
        }
    },
    {
        name: "room:dispatch",
        callback(id, data, wsClient){
            let key = data.key
            let room = Room.findRoomByKey(key)
            if (!room){
                wsClient.error(id, {
                    code: "Invalid Key",
                    msg: "无效的key"
                })
                return
            }

            let clients = room.clients
            
            ;([...clients]).forEach(client => {
                if (client[0] === wsClient){
                    client[0].send(id, {
                        code: "OK"
                    })
                } else {
                    client[0].send(client[1].reqId, {
                        code: "MESSAGE",
                        data: data.data
                    })
                }
            })
        }
    }
])

scanSignatureService.setListeners([
    {
        event: "close",
        callback(e, wsClient){
            let rooms = clientRooms.get(wsClient)
            if (rooms){
                ;([...rooms]).forEach(room => room.leaveClient(wsClient))
                clientRooms.delete(wsClient)
            }
        }
    }
])

module.exports = scanSignatureService
